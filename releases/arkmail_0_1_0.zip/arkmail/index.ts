// src/arkmail/meta.ts
const PLUGIN_VERSION = "0.1.0";
var PLUGIN_BUILD_DATE = "17-10-2026";
var PLUGIN_NAME = "ArkMail";
var PLUGIN_AUTHOR = "Isithunzi000";
var PLUGIN_DESCRIPTION = "ArkMail to kompleksowy system pocztowy dla klienta Dargoth: skrzynki, kontakty, archiwum i pisanie listow (alias /arkmail). Plugin w pelni zgodny z regulaminem gry - wszystkie komendy wysylane swiadomie przez gracza, bez automatyki.";

// src/arkmail/index.ts
var POPUP_ID = "arkmail";
var FOOTER_BUTTON_ID = "arkmail";
var ALIAS_REGEX = /^\/arkmail$/i;
var apiRef = null;
var popup = null;
var menuHandle = null;
var footerHandle = null;
var aliasId = null;
function createContent() {
  const root = document.createElement("div");
  root.className = "arkmail-root";
  const info = document.createElement("div");
  info.className = "arkmail-placeholder";
  info.textContent = `${PLUGIN_NAME} ${PLUGIN_VERSION} (${PLUGIN_BUILD_DATE}) - moduly pocztowe w budowie.`;
  root.appendChild(info);
  return root;
}
async function init(api) {
  apiRef = api;
  popup = await api.ui.registerPersistentPopup({
    id: POPUP_ID,
    title: PLUGIN_NAME,
    initialWidth: 480,
    initialHeight: 640,
    createContent
  });
  const toggle = () => {
    if (!popup) return true;
    if (popup.isOpen) popup.close();
    else void popup.open();
    return true;
  };
  aliasId = api.aliases.register(ALIAS_REGEX, toggle);
  menuHandle = api.ui.addPopupMenuEntry(PLUGIN_NAME, () => {
    if (popup && !popup.isOpen) void popup.open();
  });
  footerHandle = api.ui.registerFooterButton(FOOTER_BUTTON_ID, {
    label: PLUGIN_NAME,
    command: "/arkmail"
  });
  return {
    name: PLUGIN_NAME,
    version: PLUGIN_VERSION,
    author: PLUGIN_AUTHOR,
    description: PLUGIN_DESCRIPTION
  };
}
async function destroy() {
  if (aliasId !== null && apiRef) {
    apiRef.aliases.remove(aliasId);
    aliasId = null;
  }
  if (footerHandle) {
    footerHandle.remove();
    footerHandle = null;
  }
  if (menuHandle) {
    menuHandle.remove();
    menuHandle = null;
  }
  if (popup) {
    popup.close();
    popup = null;
  }
  apiRef = null;
}
export {
  destroy,
  init
};
