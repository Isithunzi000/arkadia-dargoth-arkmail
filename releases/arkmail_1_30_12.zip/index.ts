var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

// src/arkmail/meta.ts
const PLUGIN_VERSION = "1.30.12";
var PLUGIN_BUILD_DATE = "19-11-2026";
var PLUGIN_NAME = "ArkMail";
var PLUGIN_DESCRIPTION = "ArkMail to kompleksowy system pocztowy: skrzynki, kontakty, archiwum i pisanie listow (alias /arkmail).";

// src/arkmail/core/protocol/parser.ts
var CLIENT_PREFIX_RE = /^\s*\[ POCZTA \]\s+/;
function stripClientPrefix(text) {
  return text.replace(CLIENT_PREFIX_RE, "").trim();
}
var MONTHS = {
  I: 1,
  II: 2,
  III: 3,
  IV: 4,
  V: 5,
  VI: 6,
  VII: 7,
  VIII: 8,
  IX: 9,
  X: 10,
  XI: 11,
  XII: 12
};
var DATE_RE = /^([A-Za-z]+), (\d{1,2}) (XII|XI|IX|VIII|VII|VI|IV|V|III|II|I|X) (\d{4}), (\d{2}:\d{2}:\d{2})$/;
function parseMailDate(raw) {
  const m = raw.match(DATE_RE);
  if (!m) return null;
  return {
    raw,
    weekday: m[1],
    day: Number(m[2]),
    month: MONTHS[m[3]],
    year: Number(m[4]),
    time: m[5]
  };
}
var LISTING_HEADER_RE = /^(?:Wybrane )?[Ll]isty (nieprzeczytane|odebrane|wyslane|niewyslane)(?: \(([^)]*)\))?:$/;
var LISTING_LIMIT_RE = /\bpierwsz\w*\s+(\d+)\b/;
var SERVER_LISTING_LIMIT = 50;
function parseListingHeader(text) {
  const m = text.match(LISTING_HEADER_RE);
  if (!m) return null;
  const limit = m[2]?.match(LISTING_LIMIT_RE);
  return {
    box: m[1],
    truncated: limit != null && Number(limit[1]) >= SERVER_LISTING_LIMIT
  };
}
var LISTING_ENTRY_RE = /^\s*(\d+)\.\s+(?:(\*R\*)\s+)?Temat: (.+)$/;
var FORWARDED_SUFFIX = " (forwardowany)";
function parseListingEntry(text) {
  const m = text.match(LISTING_ENTRY_RE);
  if (!m) return null;
  let subject = m[3];
  let forwarded = false;
  if (subject.endsWith(FORWARDED_SUFFIX)) {
    forwarded = true;
    subject = subject.slice(0, -FORWARDED_SUFFIX.length);
  }
  return { number: Number(m[1]), isRead: m[2] === "*R*", subject, forwarded };
}
var LISTING_PARTY_RE = /^(Nadawca|Odbiorc[ay]): (.+)$/;
var LISTING_DATE_SUFFIX_RE = /\s+([A-Za-z]+, \d{1,2} (?:XII|XI|IX|VIII|VII|VI|IV|V|III|II|I|X) \d{4}, \d{2}:\d{2}:\d{2})$/;
function parseListingParty(text) {
  const m = text.match(LISTING_PARTY_RE);
  if (!m) return null;
  const suffix = m[2].match(LISTING_DATE_SUFFIX_RE);
  const names = suffix ? m[2].slice(0, suffix.index).trimEnd() : m[2];
  return {
    kind: m[1] === "Nadawca" ? "nadawca" : "odbiorcy",
    names,
    date: suffix ? parseMailDate(suffix[1]) : null
  };
}
var EMPTY_LISTING_RE = /^Nie masz zadnych (nieprzeczytanych|odebranych|wyslanych|niewyslanych|otrzymanych) listow\.$/;
var FILTERED_EMPTY_RE = /^Nie znaleziono zadnych takich (nieprzeczytanych|odebranych|wyslanych|niewyslanych|otrzymanych) listow\.$/;
var BOXES_FROM_GENITIVE = {
  nieprzeczytanych: ["nieprzeczytane"],
  odebranych: ["odebrane"],
  wyslanych: ["wyslane"],
  niewyslanych: ["niewyslane"],
  otrzymanych: ["odebrane", "nieprzeczytane"]
};
var LISTS_LOADING_RE = /^Listy sa w tej chwili ladowane\.$/;
function parseEmptyListing(text) {
  const puste = text.match(EMPTY_LISTING_RE);
  if (puste) return { boxes: BOXES_FROM_GENITIVE[puste[1]], reason: "puste" };
  const filtr = text.match(FILTERED_EMPTY_RE);
  if (filtr) return { boxes: BOXES_FROM_GENITIVE[filtr[1]], reason: "filtr" };
  return null;
}
var LETTER_HEADER_RES = [
  { re: /^List\s*: ?(\d+)$/, field: "numer" },
  { re: /^Od\s*: ?(.+)$/, field: "od" },
  { re: /^Temat\s*: ?(.+)$/, field: "temat" },
  { re: /^Do\s*: ?(.*)$/, field: "do" },
  { re: /^DW\s*: ?(.+)$/, field: "dw" },
  { re: /^Data\s*: ?(.+)$/, field: "data" }
];
function parseLetterHeaderLine(text) {
  for (const { re, field } of LETTER_HEADER_RES) {
    const m = text.match(re);
    if (m) return { field, value: m[1] };
  }
  return null;
}
var PAGER_PROMPT_ANYWHERE_RE = /\[(\d+)-(\d+) [a-zA-Z.!?+<>\-]+\] \(aktualny: (\d+)\) --/;
function extractPagerPrompt(text) {
  const m = text.match(PAGER_PROMPT_ANYWHERE_RE);
  if (!m) return null;
  return { lo: Number(m[1]), hi: Number(m[2]), current: Number(m[3]) };
}
var ALIASES_HEADER = "Posiadasz nastepujace zdefiniowane aliasy pocztowe:";
var ALIAS_ENTRY_RE = /^\s*(\S+): (.+)$/;
function parseAliasesBlock(lines) {
  if (!lines.length || lines[0] !== ALIASES_HEADER) return [];
  const out = [];
  for (let i = 1; i < lines.length; i++) {
    const m = lines[i].match(ALIAS_ENTRY_RE);
    if (!m) break;
    out.push({ name: m[1], targets: m[2].split(",").map((s) => s.trim()).filter(Boolean) });
  }
  return out;
}
var IMPORT_PREFIX_RE = /^\[\d+\]\s*/;
function splitImportedNames(raw) {
  return raw.split(/\s*,\s*|\s+i\s+/).map((s) => s.trim()).filter(Boolean);
}
function parseRememberedLine(text) {
  const t = text.replace(IMPORT_PREFIX_RE, "").trim();
  const m = t.match(/^Zapamietane przez ciebie imiona to (.+)\.$/);
  if (!m) return null;
  return splitImportedNames(m[1]);
}
function parseIntroducedLine(text) {
  const t = text.replace(IMPORT_PREFIX_RE, "").trim();
  const m = t.match(/^Osoby, ktore zostaly ci ostatnio przedstawione, to (.+)\.$/);
  if (!m) return null;
  return splitImportedNames(m[1]);
}
function parseNotification(text) {
  const t = stripClientPrefix(text);
  const nowa = t.match(/^Masz nowa poczte od ([A-Za-z]+)\.$/);
  if (nowa) return { kind: "nowa-poczte", nadawca: nowa[1] };
  const wysylasz = t.match(/^Wysylasz ([A-Za-z]+) na poczte\.$/);
  if (wysylasz) return { kind: "wysylasz", zwierze: wysylasz[1] };
  const powrot = t.match(/^Wsrod trzepotu skrzydel ([A-Za-z]+) laduje na (?:twoim|twojej) \w+(?: \w+)?\.$/);
  if (powrot) return { kind: "powrot-zwierzecia", zwierze: powrot[1] };
  if (t === "List zostal pomyslnie wyslany.") return { kind: "list-wyslany" };
  if (t === "Kasuje listy...") return { kind: "kasowanie" };
  if (t === "Slucham?") return { kind: "slucham" };
  return null;
}
function parseMailError(text) {
  const zly = text.match(/^Zly numer listu: (\d+)\.$/);
  if (zly) return { kind: "zly-numer", numer: Number(zly[1]) };
  const adresat = text.match(/^(?:Adresat: |DW: |Temat: )?Nie ma takiego adresata \(gracza, aliasu\): (.+)\.$/);
  if (adresat) return { kind: "brak-adresata", adresat: adresat[1] };
  if (text === "Zadne listy nie zostaly wybrane.") return { kind: "brak-wyboru" };
  return null;
}
var COMPOSE_ECHO_RE = /^(?:(Adresat|Temat|DW): )+$/;
function parseComposeEcho(text) {
  if (!COMPOSE_ECHO_RE.test(text)) return null;
  const out = [];
  for (const m of text.matchAll(/(Adresat|Temat|DW): /g)) {
    out.push(m[1] === "Adresat" ? "adresat" : m[1] === "Temat" ? "temat" : "dw");
  }
  return out.length ? out : null;
}
var EDITOR_READY_RE = /Wpisz ~\?, zeby uzyskac pomoc, lub \*\*, by zakonczyc edycje\./;
var EDITOR_ECHO_RE = /^(\s*\d+\])+/;
var RESULT_WYSLANY = "List zostal pomyslnie wyslany.";
function isEditorReady(text) {
  return EDITOR_READY_RE.test(text);
}
var RESULT_GOTOWY = "List jest gotowy do wyslania.";
function parseEditorEcho(text) {
  const m = text.match(EDITOR_ECHO_RE);
  if (!m) return null;
  const numbers = [...m[0].matchAll(/(\d+)\]/g)].map((x) => Number(x[1]));
  const rest = text.slice(m[0].length);
  let result = null;
  if (rest === RESULT_WYSLANY) result = "wyslany";
  else if (rest === RESULT_GOTOWY) result = "gotowy";
  else if (rest !== "") return null;
  return { consumed: Math.max(...numbers), result };
}
function parseComposeResult(text) {
  if (text === RESULT_WYSLANY) return "wyslany";
  if (text === RESULT_GOTOWY) return "gotowy";
  return null;
}

// src/arkmail/core/session/lines.ts
function isEchoLine(text) {
  return text.startsWith("\u2192 ") || text === "\u2192";
}
function isPromptLine(text) {
  return /^>+\s*$/.test(text);
}

// src/arkmail/core/session/orphanPager.ts
var suspected = false;
function suspectPagerOrphan() {
  suspected = true;
}
function clearPagerOrphan() {
  suspected = false;
}
function isPagerOrphanSuspected() {
  return suspected;
}

// src/arkmail/core/protocol/commands.ts
var ROMAN_MONTHS = [
  "I",
  "II",
  "III",
  "IV",
  "V",
  "VI",
  "VII",
  "VIII",
  "IX",
  "X",
  "XI",
  "XII"
];
var SEARCH_DATE_ERROR = "Podaj prawidlowa date w formacie RRRR-MM-DD.";
var SEARCH_RANGE_ERROR = "Od dnia pozniej niz Do dnia.";
function isValidPersonName(name) {
  return /^[A-Za-z]+$/.test(name);
}
function isValidDateYMD(date) {
  if (!Number.isInteger(date.day) || !Number.isInteger(date.month) || !Number.isInteger(date.year)) {
    return false;
  }
  if (date.year < 1 || date.month < 1 || date.month > 12 || date.day < 1) return false;
  const leap = date.year % 4 === 0 && (date.year % 100 !== 0 || date.year % 400 === 0);
  const monthDays = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  return date.day <= monthDays[date.month - 1];
}
function assertValidDateYMD(date) {
  if (!isValidDateYMD(date)) throw new RangeError(SEARCH_DATE_ERROR);
}
function compareDates(a, b) {
  return a.year - b.year || a.month - b.month || a.day - b.day;
}
function hasPreviousDay(date) {
  return date.year > 1 || date.month > 1 || date.day > 1;
}
function olderListingCommand(box, date) {
  assertValidDateYMD(date);
  const roman = ROMAN_MONTHS[date.month - 1];
  return `listy ${box} przed ${date.day} ${roman} ${date.year}`;
}
function nextDay(date) {
  assertValidDateYMD(date);
  const leap = date.year % 4 === 0 && (date.year % 100 !== 0 || date.year % 400 === 0);
  const monthDays = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const max = monthDays[date.month - 1];
  if (date.day < max) return { day: date.day + 1, month: date.month, year: date.year };
  if (date.month < 12) return { day: 1, month: date.month + 1, year: date.year };
  return { day: 1, month: 1, year: date.year + 1 };
}
function prevDay(date) {
  assertValidDateYMD(date);
  if (!hasPreviousDay(date)) throw new RangeError(SEARCH_DATE_ERROR);
  const leap = date.year % 4 === 0 && (date.year % 100 !== 0 || date.year % 400 === 0);
  const monthDays = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (date.day > 1) return { day: date.day - 1, month: date.month, year: date.year };
  if (date.month > 1) {
    return { day: monthDays[date.month - 2], month: date.month - 1, year: date.year };
  }
  return { day: 31, month: 12, year: date.year - 1 };
}
function validateSearchText(query) {
  if (query.osoba && !/^[a-zA-Z]+$/.test(query.osoba)) {
    return "Osoba: tylko litery a-z i A-Z.";
  }
  if (query.temat && /[;#]/.test(query.temat)) {
    return "Temat nie moze zawierac znakow ; ani #.";
  }
  if (query.tresc && /[;#]/.test(query.tresc)) {
    return "Tresc nie moze zawierac znakow ; ani #.";
  }
  return null;
}
function validateListingSearch(query) {
  const textError = validateSearchText(query);
  if (textError) return textError;
  if (query.odDaty && (!isValidDateYMD(query.odDaty) || !hasPreviousDay(query.odDaty))) {
    return SEARCH_DATE_ERROR;
  }
  if (query.doDaty && !isValidDateYMD(query.doDaty)) return SEARCH_DATE_ERROR;
  if (query.odDaty && query.doDaty && compareDates(query.odDaty, query.doDaty) > 0) {
    return SEARCH_RANGE_ERROR;
  }
  return null;
}
function validateSearchDraft(draft) {
  const textError = validateSearchText(draft);
  if (textError) return textError;
  const odDaty = draft.odDaty === "" ? null : fromISODate(draft.odDaty);
  const doDaty = draft.doDaty === "" ? null : fromISODate(draft.doDaty);
  if (draft.odDaty !== "" && !odDaty || draft.doDaty !== "" && !doDaty) {
    return SEARCH_DATE_ERROR;
  }
  if (odDaty && !hasPreviousDay(odDaty)) return SEARCH_DATE_ERROR;
  if (odDaty && doDaty && compareDates(odDaty, doDaty) > 0) return SEARCH_RANGE_ERROR;
  return null;
}
var SENDER_BOXES = /* @__PURE__ */ new Set(["odebrane", "nieprzeczytane"]);
var datePart = (d) => `${d.day} ${ROMAN_MONTHS[d.month - 1]} ${d.year}`;
function searchListingCommand(box, q) {
  const validationError = validateListingSearch(q);
  if (validationError) throw new RangeError(validationError);
  const parts = [`listy ${box}`];
  if (q.osoba) {
    const osoba = q.osoba.toLowerCase();
    parts.push(SENDER_BOXES.has(box) ? `od ${osoba}` : `do ${osoba}`);
  }
  if (q.odDaty) parts.push(`po ${datePart(prevDay(q.odDaty))}`);
  if (q.doDaty) parts.push(`przed ${datePart(nextDay(q.doDaty))}`);
  if (q.tresc) parts.push(`o tresci ${q.tresc}`);
  if (q.temat) parts.push(`o temacie ${q.temat}`);
  return parts.join(" ");
}
var ISO_RE = /^(\d{4})-(\d{2})-(\d{2})$/;
function fromISODate(iso) {
  const m = iso.match(ISO_RE);
  if (!m) return null;
  const date = { year: Number(m[1]), month: Number(m[2]), day: Number(m[3]) };
  try {
    nextDay(date);
  } catch {
    return null;
  }
  return date;
}
var isoOf = (d) => `${d.year}-${String(d.month).padStart(2, "0")}-${String(d.day).padStart(2, "0")}`;
function searchDescription(box, q) {
  const parts = [box];
  if (q.osoba) parts.push(`${SENDER_BOXES.has(box) ? "nadawca" : "adresat"}: ${q.osoba}`);
  if (q.odDaty) parts.push(`od dnia: ${isoOf(q.odDaty)}`);
  if (q.doDaty) parts.push(`do dnia: ${isoOf(q.doDaty)}`);
  if (q.temat) parts.push(`temat: "${q.temat}"`);
  if (q.tresc) parts.push(`tresc: "${q.tresc}"`);
  return parts.join(", ");
}

// src/arkmail/core/composeValidation.ts
function validRecipients(value, required) {
  const trimmed = value.trim();
  if (!trimmed) return !required;
  if (/[^a-zA-Z, ]/.test(value)) return false;
  return trimmed.split(",").every((part) => {
    const names = part.trim();
    if (/(?:^|\s)i(?:\s|$)/i.test(names)) return false;
    return /^[a-zA-Z]+(?: +[a-zA-Z]+)*$/.test(names);
  });
}
function validateCompose(input) {
  if (!/\S/.test(input.tresc)) return "Brak tresci listu.";
  if (/[;#]/.test(input.tresc)) return "Tresc nie moze zawierac znakow ; ani #.";
  if (!input.adresat.trim()) return "Podaj adresata.";
  if (!validRecipients(input.adresat, true)) {
    return "Adresatow oddziel przecinkami lub spacjami, bez spojnika 'i'. Dozwolone: litery a-z i A-Z.";
  }
  if (!input.temat.trim()) return "Podaj temat.";
  if (/[;#]/.test(input.temat)) return "Temat nie moze zawierac znakow ; ani #.";
  if (!validRecipients(input.dw, false)) {
    return "Adresatow DW oddziel przecinkami lub spacjami, bez spojnika 'i'. Dozwolone: litery a-z i A-Z.";
  }
  return null;
}
function splitRecipients(value, known = /* @__PURE__ */ new Set()) {
  const knownKeys = new Set([...known].map((name) => name.trim().toLowerCase()));
  const maxWords = Math.max(1, ...[...knownKeys].map((name) => name.split(/\s+/).length));
  const out = [];
  for (const rawSegment of value.split(",")) {
    const words = rawSegment.trim().split(/\s+/).filter(Boolean);
    let index = 0;
    while (index < words.length) {
      let matched = null;
      let matchedLength = 0;
      const limit = Math.min(maxWords, words.length - index);
      for (let length = limit; length >= 1; length--) {
        const candidate = words.slice(index, index + length).join(" ");
        if (knownKeys.has(candidate.toLowerCase())) {
          matched = candidate;
          matchedLength = length;
          break;
        }
      }
      if (matched !== null) {
        out.push(matched);
        index += matchedLength;
      } else {
        out.push(words[index]);
        index++;
      }
    }
  }
  return out;
}
function unknownRecipients(input, known) {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const name of [...splitRecipients(input.adresat, known), ...splitRecipients(input.dw, known)]) {
    const key = name.toLowerCase();
    if (known.has(key) || seen.has(key)) continue;
    seen.add(key);
    out.push(name);
  }
  return out;
}

// src/arkmail/core/session/errors.ts
var AmbiguousResponseError = class extends Error {
  constructor(detail) {
    super(`niejednoznaczna_odpowiedz: ${detail}`);
    __publicField(this, "code", "niejednoznaczna_odpowiedz");
    this.name = "AmbiguousResponseError";
  }
};
var UnknownPagerError = class extends Error {
  constructor() {
    super("nieznany_pager: przerwano listing");
    __publicField(this, "code", "nieznany_pager");
    this.name = "UnknownPagerError";
  }
};

// src/arkmail/core/session/mailbox.ts
var MAIL_ERROR_RE = /^Data zostala podana w zlym formacie\./;
var LISTS_LOADING_RETRY_MS = 2e3;
var DEFAULT_IDLE_FLUSH_MS = 600;
var entryKey = (entry) => [entry.party, entry.subject, entry.forwarded ? "f" : "", entry.date?.raw ?? ""].join("|");
var MailboxSession = class {
  constructor(transport2, opts) {
    __publicField(this, "transport", transport2);
    __publicField(this, "opts", opts);
  }
  /**
   * Pobiera listing skrzynki. command: wlasna komenda (paginacja wstecz
   * "listy <skrzynka> przed <data>", patrz protocol/commands.ts);
   * domyslnie "listy <skrzynka>".
   */
  fetch(box, command) {
    return new Promise((resolve, reject) => {
      const session = this.transport.openSession();
      const cmd = command ?? `listy ${box}`;
      let header = null;
      const entries = [];
      let done = false;
      let loadRetried = false;
      let loadRetryTimer = null;
      const idleMs = this.opts.idleMs ?? DEFAULT_IDLE_FLUSH_MS;
      let idleTimer = null;
      let cancelUnsub = () => {
      };
      const cleanup = () => {
        done = true;
        clearTimeout(timer);
        if (idleTimer) clearTimeout(idleTimer);
        if (loadRetryTimer) clearTimeout(loadRetryTimer);
        cancelUnsub();
        session.close();
      };
      const fail = (error) => {
        if (done) return;
        if (error instanceof AmbiguousResponseError || error instanceof UnknownPagerError) {
          this.transport.beginRecovery();
        }
        cleanup();
        reject(error instanceof Error ? error : new Error(String(error)));
      };
      const send = (line) => {
        if (done) return;
        try {
          void Promise.resolve(this.transport.send(line)).catch(fail);
        } catch (error) {
          fail(error);
        }
      };
      const finish = (r) => {
        cleanup();
        clearPagerOrphan();
        resolve(r);
      };
      const armIdle = () => {
        if (idleTimer) clearTimeout(idleTimer);
        idleTimer = setTimeout(() => {
          if (done || !header) return;
          finish({ kind: "lista", header, entries, confirmed: false });
        }, idleMs);
      };
      const timer = setTimeout(() => {
        this.transport.beginRecovery();
        cleanup();
        reject(new Error(`timeout: mailbox fetch ${box}`));
      }, this.opts.timeoutMs);
      session.subscribe((line) => {
        if (done) return;
        if (MAIL_ERROR_RE.test(line.text)) {
          cleanup();
          reject(new Error(line.text.trim()));
          return;
        }
        if (LISTS_LOADING_RE.test(line.text)) {
          if (loadRetried) {
            cleanup();
            reject(new Error("Listy sa w tej chwili ladowane."));
            return;
          }
          loadRetried = true;
          loadRetryTimer = setTimeout(() => {
            if (!done) send(cmd);
          }, LISTS_LOADING_RETRY_MS);
          return;
        }
        if (!header) {
          if (line.cls === "command" || isEchoLine(line.text)) return;
          if (extractPagerPrompt(line.text)) {
            fail(new UnknownPagerError());
            return;
          }
          const empty = parseEmptyListing(line.text);
          if (empty) {
            if (!empty.boxes.includes(box)) {
              fail(new AmbiguousResponseError(
                `pusta ${empty.boxes.join("/")} podczas fetch ${box}`
              ));
              return;
            }
            if (empty.reason === "puste" && empty.boxes.length > 1) {
              fail(new AmbiguousResponseError(
                `pusta ${empty.boxes.join("/")} bez jednej skrzynki podczas fetch ${box}`
              ));
              return;
            }
            finish({ kind: "pusta", box, reason: empty.reason });
            return;
          }
          const h = parseListingHeader(line.text);
          if (h) {
            if (h.box !== box) {
              fail(new AmbiguousResponseError(`listing ${h.box} podczas fetch ${box}`));
              return;
            }
            if (loadRetryTimer) {
              clearTimeout(loadRetryTimer);
              loadRetryTimer = null;
            }
            header = h;
            armIdle();
          }
          return;
        }
        if (line.cls === "prompt" || line.cls === "command" || isPromptLine(line.text) || isEchoLine(line.text)) {
          finish({ kind: "lista", header, entries, confirmed: true });
          return;
        }
        armIdle();
        const entry = parseListingEntry(line.text);
        if (entry) {
          entries.push({ ...entry, party: "", partyKind: null, date: null });
          return;
        }
        const party = parseListingParty(line.text);
        if (party && entries.length > 0) {
          const last = entries[entries.length - 1];
          last.party = party.names;
          last.partyKind = party.kind;
          last.date = party.date;
        }
      });
      cancelUnsub = this.opts.onCancel?.(() => {
        cleanup();
        reject(new Error("operacja anulowana"));
      }) ?? (() => {
      });
      if (!done) send(cmd);
    });
  }
};

// src/arkmail/core/archive.ts
var SENDER_BOXES2 = /* @__PURE__ */ new Set(["odebrane", "nieprzeczytane"]);
var RECIPIENT_BOXES = /* @__PURE__ */ new Set(["wyslane", "niewyslane"]);
function fnv1a(input) {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16).padStart(8, "0");
}
function sortKeyOf(date) {
  if (!date) return "0000-00-00 00:00:00";
  const p = (n) => String(n).padStart(2, "0");
  return `${date.year}-${p(date.month)}-${p(date.day)} ${date.time}`;
}
function letterId(box, party, subject, forwarded, dateRaw) {
  return fnv1a([box, party, subject, forwarded ? "f" : "", dateRaw ?? ""].join("|"));
}
function scanKeyOfEntries(entries) {
  return fnv1a(
    entries.map(
      (e) => [
        e.number,
        e.isRead ? "R" : "N",
        e.forwarded ? "F" : "",
        e.party,
        e.subject,
        e.date?.raw ?? ""
      ].join("|")
    ).join("\n")
  );
}
function recordId(box, scanKey, position) {
  return fnv1a([box, scanKey, String(position)].join("|"));
}
function contentKeyOf(letter) {
  return fnv1a(
    [letter.party, letter.subject, letter.forwarded === true ? "f" : "", letter.dateRaw ?? ""].join(
      "|"
    )
  );
}
function fromMailboxEntry(box, entry, scanKey, position) {
  const dateRaw = entry.date?.raw ?? null;
  return {
    id: scanKey !== void 0 && position !== void 0 ? recordId(box, scanKey, position) : letterId(box, entry.party, entry.subject, entry.forwarded, dateRaw),
    box,
    number: entry.number,
    party: entry.party,
    subject: entry.subject,
    forwarded: entry.forwarded,
    dateRaw,
    sortKey: sortKeyOf(entry.date),
    read: entry.isRead,
    body: []
  };
}
function fromOpenedLetter(box, letter, entry) {
  const headers = {
    from: letter.from,
    to: letter.to,
    cc: letter.cc
  };
  if (entry) {
    const base = entry.archiveId ? {
      ...fromMailboxEntry(box, entry),
      id: entry.archiveId
    } : fromMailboxEntry(box, entry);
    return { ...base, read: true, body: letter.body, headers };
  }
  const party = SENDER_BOXES2.has(box) ? letter.from : letter.to;
  const dateRaw = letter.date;
  const parsed = dateRaw ? parseMailDate(dateRaw) : null;
  return {
    id: letterId(box, party, letter.subject, false, dateRaw),
    box,
    number: letter.number,
    party,
    subject: letter.subject,
    forwarded: false,
    dateRaw,
    sortKey: sortKeyOf(parsed),
    read: true,
    body: letter.body,
    headers
  };
}
function archiveLetterContent(letter) {
  const sender = SENDER_BOXES2.has(letter.box);
  const headers = letter.headers;
  return {
    number: letter.number,
    from: headers?.from ?? (sender ? letter.party : ""),
    subject: letter.subject,
    to: headers?.to ?? (sender ? "" : letter.party),
    cc: headers ? headers.cc : null,
    date: letter.dateRaw,
    body: letter.body
  };
}
var ARCHIVE_DATE_SUFFIX_RE = /\s+([A-Za-z]+, \d{1,2} (?:XII|XI|IX|VIII|VII|VI|IV|V|III|II|I|X) \d{4}, \d{2}:\d{2}:\d{2})$/;
var ARCHIVE_SORT_KEY_RE = /^(\d{4})-(\d{2})-(\d{2}) ((?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d)$/;
var ARCHIVE_WEEKDAYS = ["N", "Pn", "Wt", "Sr", "Cz", "Pt", "So"];
var ARCHIVE_MONTHS = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"];
function dateFromSortKey(sortKey2) {
  const match = sortKey2.match(ARCHIVE_SORT_KEY_RE);
  if (!match) return null;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const calendar = /* @__PURE__ */ new Date(0);
  calendar.setUTCFullYear(year, month - 1, day);
  calendar.setUTCHours(0, 0, 0, 0);
  if (calendar.getUTCFullYear() !== year || calendar.getUTCMonth() !== month - 1 || calendar.getUTCDate() !== day) {
    return null;
  }
  const raw = `${ARCHIVE_WEEKDAYS[calendar.getUTCDay()]}, ${day} ${ARCHIVE_MONTHS[month - 1]} ${year}, ${match[4]}`;
  return parseMailDate(raw);
}
function compareText(a, b) {
  return a < b ? -1 : a > b ? 1 : 0;
}
function validArchiveHeaders(value) {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return void 0;
  const candidate = value;
  if (typeof candidate.from !== "string" || typeof candidate.to !== "string") return void 0;
  if (candidate.cc !== null && typeof candidate.cc !== "string") return void 0;
  return { from: candidate.from, to: candidate.to, cc: candidate.cc };
}
function mergeArchiveDuplicates(group) {
  if (group.length === 1) return group[0];
  const ordered = [...group].sort((a, b) => compareText(JSON.stringify(a), JSON.stringify(b)));
  const bodies = /* @__PURE__ */ new Map();
  for (const letter of ordered) {
    const key = JSON.stringify(letter.body);
    if (!bodies.has(key)) bodies.set(key, letter.body);
  }
  const orderedBodies = [...bodies.values()].sort(
    (a, b) => b.length - a.length || compareText(JSON.stringify(a), JSON.stringify(b))
  );
  const body = [...orderedBodies[0] ?? []];
  for (const candidate of orderedBodies.slice(1)) {
    for (const line of candidate) {
      if (!body.includes(line)) body.push(line);
    }
  }
  const merged = {
    ...ordered[0],
    number: Math.max(...group.map((letter) => letter.number)),
    read: group.some((letter) => letter.read),
    body
  };
  const headers = ordered.find((letter) => letter.headers)?.headers;
  if (headers) merged.headers = { ...headers };
  else delete merged.headers;
  return merged;
}
function normalizeArchive(letters) {
  const groups = /* @__PURE__ */ new Map();
  for (const letter of letters) {
    const suffix = letter.party.match(ARCHIVE_DATE_SUFFIX_RE);
    const suffixDate = suffix ? parseMailDate(suffix[1]) : null;
    const directDate = letter.dateRaw ? parseMailDate(letter.dateRaw) : null;
    const date = directDate ?? suffixDate ?? dateFromSortKey(letter.sortKey);
    const party = suffixDate ? letter.party.slice(0, suffix.index).trimEnd() : letter.party;
    const dateRaw = date?.raw ?? letter.dateRaw;
    const { headers: rawHeaders, ...withoutHeaders } = letter;
    const headers = validArchiveHeaders(rawHeaders);
    const normalized = {
      ...withoutHeaders,
      ...headers ? { headers } : {},
      party,
      dateRaw,
      sortKey: date ? sortKeyOf(date) : letter.sortKey,
      body: [...letter.body]
    };
    const group = groups.get(normalized.id);
    if (group) group.push(normalized);
    else groups.set(normalized.id, [normalized]);
  }
  return [...groups.values()].map(mergeArchiveDuplicates).sort(byNewest);
}
function byNewest(a, b) {
  if (a.sortKey !== b.sortKey) return a.sortKey < b.sortKey ? 1 : -1;
  if (a.number !== b.number) return b.number - a.number;
  return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
}
function insertLetters(existing, incoming) {
  const map = new Map(existing.map((l) => [l.id, l]));
  let added = 0;
  for (const inc of incoming) {
    if (map.has(inc.id)) continue;
    map.set(inc.id, inc);
    added++;
  }
  return { letters: [...map.values()].sort(byNewest), added };
}
function mergeListingPage(existing, box, incoming) {
  const pool = /* @__PURE__ */ new Map();
  for (const l of existing) {
    if (l.box !== box) continue;
    const key = contentKeyOf(l);
    const arr = pool.get(key);
    if (arr) arr.push(l);
    else pool.set(key, [l]);
  }
  const resolvedIds = [];
  const freshIds = /* @__PURE__ */ new Set();
  const toInsert = [];
  for (const rec of incoming) {
    const candidates = pool.get(contentKeyOf(rec));
    if (candidates && candidates.length > 0) {
      const matched = candidates.shift();
      resolvedIds.push(matched.id);
      freshIds.add(matched.id);
    } else {
      resolvedIds.push(rec.id);
      freshIds.add(rec.id);
      toInsert.push(rec);
    }
  }
  const inserted = insertLetters(existing, toInsert);
  return { letters: inserted.letters, added: inserted.added, resolvedIds, freshIds };
}
function replaceBoxLetters(existing, box, incoming) {
  const merged = mergeListingPage(existing, box, incoming);
  const removedIds = /* @__PURE__ */ new Set();
  const letters = merged.letters.filter((letter) => {
    if (letter.box !== box || merged.freshIds.has(letter.id)) return true;
    removedIds.add(letter.id);
    return false;
  });
  if (removedIds.size === 0 && merged.added === 0) {
    return { letters: [...existing], removedIds, resolvedIds: merged.resolvedIds };
  }
  return { letters, removedIds, resolvedIds: merged.resolvedIds };
}
function upsertLetters(existing, incoming) {
  const map = new Map(existing.map((l) => [l.id, l]));
  let added = 0;
  let updated = 0;
  for (const inc of incoming) {
    const prev = map.get(inc.id);
    if (!prev) {
      map.set(inc.id, inc);
      added++;
      continue;
    }
    const merged = {
      ...prev,
      ...inc,
      body: inc.body.length > 0 ? inc.body : prev.body
    };
    const headers = inc.headers ?? prev.headers;
    if (headers) merged.headers = { ...headers };
    else delete merged.headers;
    map.set(inc.id, merged);
    updated++;
  }
  return { letters: [...map.values()].sort(byNewest), added, updated };
}
function purgeGoneLettersNewerThan(existing, box, freshIds, boundaryDay) {
  const removedIds = /* @__PURE__ */ new Set();
  const letters = existing.filter((letter) => {
    if (letter.box !== box || freshIds.has(letter.id)) return true;
    if (letter.sortKey.slice(0, 10) <= boundaryDay) return true;
    removedIds.add(letter.id);
    return false;
  });
  if (removedIds.size === 0) return { letters: [...existing], removedIds };
  return { letters, removedIds };
}
var validArchiveDate = (value) => value !== void 0 && fromISODate(value) !== null ? value : void 0;
function filterVisibleArchive(letters, filter) {
  const odDaty = validArchiveDate(filter.odDaty);
  const doDaty = validArchiveDate(filter.doDaty);
  const out = [];
  for (const l of letters) {
    if (filter.skrzynka !== void 0 && l.box !== filter.skrzynka) continue;
    if (filter.tresc !== void 0 && !norm(l.body.join("\n")).includes(norm(filter.tresc)))
      continue;
    if (filter.od !== void 0) {
      if (!SENDER_BOXES2.has(l.box)) continue;
      if (!norm(l.party).includes(norm(filter.od))) continue;
    }
    if (filter.do !== void 0) {
      if (!RECIPIENT_BOXES.has(l.box)) continue;
      if (!norm(l.party).includes(norm(filter.do))) continue;
    }
    if (filter.osoba !== void 0 && !norm(l.party).includes(norm(filter.osoba))) continue;
    if (filter.temat !== void 0 && !norm(l.subject).includes(norm(filter.temat))) continue;
    if (odDaty !== void 0 && l.sortKey.slice(0, 10) < odDaty) continue;
    if (doDaty !== void 0 && l.sortKey.slice(0, 10) > doDaty) continue;
    out.push(l);
  }
  return out.sort(byNewest);
}
var norm = (s) => s.toLowerCase();

// src/arkmail/core/pagination.ts
var PAGE_PACE_MS = 400;
var ANCHOR_RETRY_WAITS_MS = [2500, 4e3, 4e3];
function oldestEntry(entries) {
  let oldest = null;
  for (const entry of entries) {
    if (!entry.date) continue;
    if (!oldest || sortKey(entry) < sortKey(oldest)) oldest = entry;
  }
  return oldest;
}
var sortKey = (entry) => {
  const d = entry.date;
  const p = (n) => String(n).padStart(2, "0");
  return `${d.year}-${p(d.month)}-${p(d.day)} ${d.time}`;
};
var isoDay = (entry) => entry.date ? sortKey(entry).slice(0, 10) : null;
var oneDayOf = (entries) => {
  if (entries.length === 0) return null;
  const first = isoDay(entries[0]);
  if (first === null) return null;
  return entries.every((entry) => isoDay(entry) === first) ? first : null;
};
var gapReason = (day) => `ponad ${SERVER_LISTING_LIMIT} listow z dnia ${day} - serwer nie pokazuje reszty`;
async function scanMailboxPages(options) {
  const { box } = options;
  const seenCounts = /* @__PURE__ */ new Map();
  const all = [];
  const gapDays = [];
  let pages = 0;
  let addedToView = 0;
  let archiveAdded = 0;
  let unconfirmedPages = 0;
  let oldestSeenDay = null;
  let anchorRetries = 0;
  let wallProbed = false;
  let probePending = false;
  let probeDay = null;
  let result = await options.fetchPage(options.initialCommand);
  const finish = (end, skipWhy = null) => ({
    end,
    pages,
    addedToView,
    archiveAdded,
    unconfirmedPages,
    all,
    oldestSeenDay,
    gapDays: [...gapDays],
    skipWhy
  });
  const observeConfirmation = (value) => {
    if (value.kind === "lista" && value.confirmed === false) unconfirmedPages += 1;
  };
  const addGap = (day) => {
    if (gapDays.includes(day)) return;
    gapDays.push(day);
    gapDays.sort();
    options.onGap?.(day);
  };
  const incompleteWithGaps = () => finish("incomplete", gapDays.map(gapReason).join("; "));
  for (; ; ) {
    if (options.cancelled()) return finish("cancelled");
    observeConfirmation(result);
    if (result.kind !== "lista") {
      options.onEmpty?.(result);
      if (probePending && probeDay !== null) addGap(probeDay);
      if (gapDays.length > 0) return incompleteWithGaps();
      return finish("complete");
    }
    const rowsPerKey = /* @__PURE__ */ new Map();
    for (const entry of result.entries) {
      const k = fnv1a(entryKey(entry));
      rowsPerKey.set(k, (rowsPerKey.get(k) ?? 0) + 1);
      const day = isoDay(entry);
      if (day !== null && (oldestSeenDay === null || day < oldestSeenDay)) oldestSeenDay = day;
    }
    let freshCount = 0;
    for (const [k, n] of rowsPerKey) {
      if ((seenCounts.get(k) ?? 0) !== n) {
        seenCounts.set(k, n);
        freshCount += n;
      }
    }
    all.push(...result.entries);
    if (probePending && probeDay !== null) {
      const excludedDay = probeDay;
      const reachedOlderDay = result.entries.some((entry) => {
        const day = isoDay(entry);
        return day !== null && day < excludedDay;
      });
      if (!reachedOlderDay) {
        return finish("incomplete", "serwer chwilowo odpowiada wolno - sprobuj ponownie za chwile");
      }
      addGap(probeDay);
    }
    pages += 1;
    const visit = await options.onPage(result, pages);
    addedToView += visit.addedToView ?? 0;
    archiveAdded += visit.archiveAdded ?? 0;
    if (options.cancelled()) return finish("cancelled");
    if (!result.header.truncated) {
      if (gapDays.length > 0) return incompleteWithGaps();
      return finish("complete");
    }
    if (options.singlePage && freshCount > 0) {
      if (gapDays.length > 0) return incompleteWithGaps();
      return finish("partial");
    }
    if (visit.stop) {
      if (gapDays.length > 0) return incompleteWithGaps();
      return finish("clamped");
    }
    if (freshCount === 0) {
      const oldestDuplicate = oldestEntry(all);
      if (!oldestDuplicate?.date) return finish("incomplete", "brak daty w wpisach");
      const attempt = anchorRetries;
      if (attempt < ANCHOR_RETRY_WAITS_MS.length) {
        anchorRetries += 1;
        await options.wait(ANCHOR_RETRY_WAITS_MS[attempt]);
        if (options.cancelled()) return finish("cancelled");
        const base = await options.fetchPage();
        observeConfirmation(base);
        options.onBaseRefresh?.(base);
        if (options.cancelled()) return finish("cancelled");
        result = await options.fetchPage(olderListingCommand(box, nextDay(oldestDuplicate.date)));
        continue;
      }
      if (!wallProbed) {
        wallProbed = true;
        probePending = true;
        probeDay = oneDayOf(result.entries);
        result = await options.fetchPage(olderListingCommand(box, oldestDuplicate.date));
        continue;
      }
      return finish("incomplete", "serwer chwilowo odpowiada wolno - sprobuj ponownie za chwile");
    }
    anchorRetries = 0;
    wallProbed = false;
    probePending = false;
    probeDay = null;
    const oldest = oldestEntry(all);
    if (!oldest?.date) return finish("incomplete", "brak daty w wpisach");
    await options.wait(PAGE_PACE_MS);
    if (options.cancelled()) return finish("cancelled");
    result = await options.fetchPage(olderListingCommand(box, nextDay(oldest.date)));
  }
}

// src/arkmail/core/contacts.ts
var CONTACT_NAME_RE = /^[A-Za-z]+$/;
var WEEKDAYS = /* @__PURE__ */ new Set([
  "n",
  "nd",
  "nie",
  "niedziela",
  "pn",
  "pon",
  "poniedzialek",
  "wt",
  "wto",
  "wtorek",
  "sr",
  "sro",
  "sroda",
  "cz",
  "czw",
  "czwartek",
  "pt",
  "pi",
  "piatek",
  "so",
  "sob",
  "sobota"
]);
function splitParty(party) {
  const out = [];
  for (const part of party.split(/, | i /)) {
    const name = part.trim();
    if (!CONTACT_NAME_RE.test(name) || WEEKDAYS.has(name.toLowerCase())) continue;
    if (!out.includes(name)) out.push(name);
  }
  return out;
}
var directionOf = (box) => box === "odebrane" || box === "nieprzeczytane" ? "in" : "out";
function korespondencjaFromLetters(letters) {
  const byDedupKey = /* @__PURE__ */ new Map();
  for (const l of letters) {
    if (!l.party) continue;
    for (const name of splitParty(l.party)) {
      const dedupKey = [
        l.direction,
        name.toLowerCase(),
        l.subject,
        l.forwarded ? "f" : "",
        l.dateRaw ?? ""
      ].join("|");
      const n = l.count ?? 1;
      let entry = byDedupKey.get(dedupKey);
      if (!entry) {
        entry = {
          name,
          direction: l.direction,
          dateRaw: l.dateRaw ?? void 0,
          dateKey: l.dateKey,
          perBox: /* @__PURE__ */ new Map()
        };
        byDedupKey.set(dedupKey, entry);
      }
      entry.perBox.set(l.box, (entry.perBox.get(l.box) ?? 0) + n);
      if (entry.dateKey === void 0 && l.dateKey !== void 0) entry.dateKey = l.dateKey;
    }
  }
  return [...byDedupKey.values()].map((entry) => ({
    name: entry.name,
    direction: entry.direction,
    dateRaw: entry.dateRaw,
    dateKey: entry.dateKey,
    // Miedzy skrzynkami MAX - replika to ten sam fizyczny list.
    count: Math.max(...entry.perBox.values())
  }));
}
function archiveToLetterLike(l) {
  const digits = Number(l.sortKey.replace(/\D/g, ""));
  return {
    direction: directionOf(l.box),
    party: l.party,
    subject: l.subject,
    forwarded: l.forwarded === true,
    dateRaw: l.dateRaw,
    dateKey: digits > 0 ? digits : void 0,
    box: l.box
  };
}
function contactsFromArchiveWithAliases(letters, aliases) {
  return mergeContacts({
    people: [],
    // Fala 18b: szkice (niewyslane) to nie wyslana korespondencja.
    korespondencja: korespondencjaFromLetters(
      letters.filter((l) => l.box !== "niewyslane").map((l) => ({ ...archiveToLetterLike(l), count: l.occurrences ?? 1 }))
    ),
    aliasy: aliases.map((a) => ({ name: a.name, targets: [...a.targets] }))
  });
}
var SOURCE_ORDER = ["people", "korespondencja", "alias"];
function mergeContacts(input) {
  const byKey = /* @__PURE__ */ new Map();
  const get = (name) => {
    const key = name.toLowerCase();
    let c = byKey.get(key);
    if (!c) {
      c = { name, sources: [], lettersReceived: 0, lettersSent: 0 };
      byKey.set(key, c);
    }
    return c;
  };
  const addSource = (c, s) => {
    if (!c.sources.includes(s)) c.sources.push(s);
  };
  for (const p of input.people) {
    const c = get(p.name);
    c.name = p.name;
    addSource(c, "people");
    if (p.description) c.description = p.description;
    if (p.guild) c.guild = p.guild;
  }
  for (const k of input.korespondencja) {
    const c = get(k.name);
    addSource(c, "korespondencja");
    const n = k.count ?? 1;
    if (k.direction === "in") c.lettersReceived += n;
    else c.lettersSent += n;
    if (k.dateKey !== void 0) {
      if (c.lastContactKey === void 0 || k.dateKey > c.lastContactKey) {
        c.lastContactKey = k.dateKey;
        if (k.dateRaw) c.lastContactRaw = k.dateRaw;
      }
    } else if (k.dateRaw && c.lastContactKey === void 0) {
      if (!c.lastContactRaw || k.dateRaw > c.lastContactRaw) {
        c.lastContactRaw = k.dateRaw;
      }
    }
  }
  for (const a of input.aliasy) {
    for (const target of a.targets) {
      const c = get(target);
      addSource(c, "alias");
      if (!c.mailAlias) c.mailAlias = a.name;
    }
  }
  const out = [...byKey.values()];
  for (const c of out) {
    c.sources.sort((x, y) => SOURCE_ORDER.indexOf(x) - SOURCE_ORDER.indexOf(y));
  }
  out.sort((a, b) => a.name.localeCompare(b.name, "pl"));
  return out;
}
function viewContacts(contacts, opts = {}) {
  const f = (opts.filter ?? "").trim().toLowerCase();
  const filtered = f === "" ? [...contacts] : contacts.filter(
    (c) => c.name.toLowerCase().includes(f) || c.mailAlias !== void 0 && c.mailAlias.toLowerCase().includes(f)
  );
  const byName = (a, b) => a.name.localeCompare(b.name, "pl");
  switch (opts.sort ?? "nazwa") {
    case "liczba":
      filtered.sort(
        (a, b) => b.lettersReceived + b.lettersSent - (a.lettersReceived + a.lettersSent) || byName(a, b)
      );
      break;
    case "ostatni":
      filtered.sort(
        (a, b) => (b.lastContactKey ?? -1) - (a.lastContactKey ?? -1) || byName(a, b)
      );
      break;
    default:
      filtered.sort(byName);
  }
  return filtered;
}

// src/arkmail/core/addressBook.ts
var GROUPS_KEY = "grupy-kontaktow";
var PEOPLE_KEY = "osoby";
var LEGACY_PEOPLE_KEY = "osoby-importowane";
var ALIASES_KEY = "aliasy-importowane";
function groupAliasConflict(name, aliases) {
  const key = name.trim().toLowerCase();
  return key !== "" && aliases.some((alias) => alias.name.trim().toLowerCase() === key);
}
function findGroupAliasConflicts(groups, aliases) {
  return groups.filter((group) => groupAliasConflict(group.name, aliases));
}
function cleanNames(value) {
  if (!Array.isArray(value)) return [];
  const out = [];
  for (const item of value) {
    if (typeof item !== "string") continue;
    const name = item.trim();
    if (name && !out.includes(name)) out.push(name);
  }
  return out;
}
function cleanBookNames(value) {
  if (!Array.isArray(value)) return [];
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  for (const item of value) {
    if (typeof item !== "string") continue;
    const name = item.trim();
    if (!name) continue;
    const key = name.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(name);
  }
  return out;
}
function cleanGroups(value) {
  if (!Array.isArray(value)) return [];
  const out = [];
  for (const item of value) {
    if (typeof item !== "object" || item === null) continue;
    const candidate = item;
    if (typeof candidate.name !== "string") continue;
    const name = candidate.name.trim();
    if (!name) continue;
    if (!Array.isArray(candidate.members)) continue;
    const members = cleanBookNames(candidate.members);
    const existing = out.find((g) => g.name.toLowerCase() === name.toLowerCase());
    if (existing) {
      for (const member of members) {
        if (!existing.members.some((m) => m.toLowerCase() === member.toLowerCase())) {
          existing.members.push(member);
        }
      }
    } else {
      out.push({ name, members });
    }
  }
  return out;
}
function cleanAliases(value) {
  if (!Array.isArray(value)) return [];
  const out = [];
  for (const item of value) {
    if (typeof item !== "object" || item === null) continue;
    const candidate = item;
    if (typeof candidate.name !== "string") continue;
    const name = candidate.name.trim();
    if (!name) continue;
    if (!Array.isArray(candidate.targets)) continue;
    const targets = cleanNames(candidate.targets);
    const existing = out.find((a) => a.name === name);
    if (existing) {
      for (const target of targets) {
        if (!existing.targets.includes(target)) existing.targets.push(target);
      }
    } else {
      out.push({ name, targets });
    }
  }
  return out;
}
function loadGroups(io) {
  return cleanGroups(io.getJSON(GROUPS_KEY));
}
function saveGroups(io, groups) {
  io.setJSON(GROUPS_KEY, cleanGroups(groups));
}
function savePeople(io, people) {
  io.setJSON(PEOPLE_KEY, cleanBookNames(people));
}
function unionPeople(existing, incoming) {
  return cleanBookNames([...existing, ...incoming]);
}
function migratePeople(io) {
  const current = io.getJSON(PEOPLE_KEY);
  if (current !== null) return cleanBookNames(current);
  const legacy = io.getJSON(
    LEGACY_PEOPLE_KEY
  );
  const names = cleanBookNames([
    ...legacy && typeof legacy === "object" ? cleanNames(legacy.zapamietani) : [],
    ...legacy && typeof legacy === "object" ? cleanNames(legacy.przedstawieni) : []
  ]);
  savePeople(io, names);
  return names;
}
function withGroupMembers(people, groups) {
  return unionPeople(people, groups.flatMap((g) => g.members));
}
function mergeAddressBook(existing, incoming) {
  const groups = cleanGroups(existing.groups).map((g) => ({
    ...g,
    members: [...g.members]
  }));
  let addedGroups = 0;
  let mergedGroups = 0;
  for (const group of cleanGroups(incoming.groups)) {
    const found = groups.find((g) => g.name.toLowerCase() === group.name.toLowerCase());
    if (found) {
      mergedGroups += 1;
      for (const member of group.members) {
        if (!found.members.some((m) => m.toLowerCase() === member.toLowerCase())) {
          found.members.push(member);
        }
      }
    } else {
      addedGroups += 1;
      groups.push(group);
    }
  }
  const before = cleanBookNames(existing.people);
  const people = withGroupMembers(unionPeople(before, incoming.people), groups);
  return {
    data: { people, groups },
    stats: {
      addedGroups,
      mergedGroups,
      addedPeople: Math.max(0, people.length - before.length)
    }
  };
}
function applyBookImport(existing, incoming, mode = "dolacz") {
  if (mode === "dolacz") return mergeAddressBook(existing, incoming);
  const groups = cleanGroups(incoming.groups);
  const before = cleanBookNames(existing.people);
  const people = withGroupMembers(cleanBookNames(incoming.people), groups);
  return {
    data: { people, groups },
    stats: {
      addedGroups: groups.length,
      mergedGroups: 0,
      addedPeople: Math.max(0, people.length - before.length)
    }
  };
}
function loadImportedAliases(io) {
  return cleanAliases(io.getJSON(ALIASES_KEY));
}
function saveImportedAliases(io, aliases) {
  io.setJSON(ALIASES_KEY, cleanAliases(aliases));
}
var ADDRESSBOOK_FORMAT = "arkmail-addressbook";
var ADDRESSBOOK_VERSION = 2;
function isStringArray(value) {
  return Array.isArray(value) && value.every((item) => typeof item === "string");
}
function hasGroupsShape(value) {
  return Array.isArray(value) && value.every((item) => {
    if (typeof item !== "object" || item === null || Array.isArray(item)) return false;
    const group = item;
    return typeof group.name === "string" && isStringArray(group.members);
  });
}
function parseAddressBookExport(json) {
  let raw;
  try {
    raw = JSON.parse(json);
  } catch {
    return null;
  }
  if (typeof raw !== "object" || raw === null) return null;
  const candidate = raw;
  if (candidate.format !== ADDRESSBOOK_FORMAT) return null;
  if (typeof candidate.version !== "number") return null;
  if (candidate.version === 1) {
    const pools = typeof candidate.importedPeople === "object" && candidate.importedPeople !== null ? candidate.importedPeople : {};
    return {
      people: cleanBookNames([
        ...cleanNames(pools.zapamietani),
        ...cleanNames(pools.przedstawieni)
      ]),
      groups: cleanGroups(candidate.groups)
    };
  }
  if (candidate.version !== 2) return null;
  if (!isStringArray(candidate.people) || !hasGroupsShape(candidate.groups)) return null;
  return {
    people: cleanBookNames(candidate.people),
    groups: cleanGroups(candidate.groups)
  };
}
function buildAddressBookExport(book) {
  return JSON.stringify(
    {
      format: ADDRESSBOOK_FORMAT,
      version: ADDRESSBOOK_VERSION,
      people: cleanBookNames(book.people),
      groups: cleanGroups(book.groups)
    },
    null,
    2
  );
}

// src/arkmail/core/session/importer.ts
var IMPORT_COMMANDS = {
  zapamietani: "zapamietani",
  przedstawieni: "przedstawieni"
};
var ImportSession = class {
  constructor(transport2, opts) {
    __publicField(this, "transport", transport2);
    __publicField(this, "opts", opts);
  }
  collect(command) {
    return new Promise((resolve, reject) => {
      const session = this.transport.openSession();
      const lines = [];
      let done = false;
      let cleaned = false;
      let cancelUnsub;
      const cleanup = () => {
        if (cleaned) return;
        cleaned = true;
        clearTimeout(timeout);
        unsubscribe();
        cancelUnsub?.();
        session.close();
      };
      const finish = () => {
        if (done) return;
        done = true;
        cleanup();
        resolve(lines);
      };
      const fail = (err) => {
        if (done) return;
        done = true;
        cleanup();
        reject(err);
      };
      const unsubscribe = session.subscribe((line) => {
        if (done) return;
        const text = line.text;
        if (isPromptLine(text) || isEchoLine(text) && !line.own) {
          finish();
          return;
        }
        lines.push(text);
      });
      const timeout = setTimeout(() => {
        this.transport.beginRecovery();
        fail(new Error(`import ${command}: timeout`));
      }, this.opts.timeoutMs);
      cancelUnsub = this.opts.onCancel?.(() => {
        fail(new Error(`import ${command}: przerwano`));
      });
      void Promise.resolve(this.transport.send(command)).catch((err) => {
        fail(err instanceof Error ? err : new Error(String(err)));
      });
    });
  }
  /** Osoby zapamietane lub ostatnio przedstawione; pula pusta = []. */
  async fetchPeople(kind) {
    const lines = await this.collect(IMPORT_COMMANDS[kind]);
    const parse = kind === "zapamietani" ? parseRememberedLine : parseIntroducedLine;
    for (const line of lines) {
      const names = parse(line);
      if (names !== null) return names;
    }
    return [];
  }
  /** Alias pocztowe z gry (tylko odczyt; rozstrzyga je serwer). */
  async fetchAliases() {
    const lines = await this.collect("aliasy pocztowe");
    const start = lines.findIndex((l) => l.startsWith("Posiadasz nastepujace"));
    return parseAliasesBlock(start === -1 ? [] : lines.slice(start));
  }
};

// src/arkmail/core/archiveDownload.ts
function makeArchiveDownloadDiagnostic(input) {
  return {
    operationId: input.operationId,
    generation: input.generation,
    recordAlias: input.recordAlias,
    result: input.outcome.kind,
    stage: input.outcome.stage,
    consecutiveErrors: input.consecutiveErrors
  };
}
var DIAGNOSTIC_LIMIT = 500;
var diagnostics = [];
function recordArchiveDownloadDiagnostic(input) {
  const diagnostic = makeArchiveDownloadDiagnostic(input);
  diagnostics.push(diagnostic);
  if (diagnostics.length > DIAGNOSTIC_LIMIT) diagnostics.shift();
  return diagnostic;
}

// src/arkmail/core/archiveStats.ts
function liveArchiveGroups(letters) {
  const groups = /* @__PURE__ */ new Map();
  for (const letter of letters) {
    const key = contentKeyOf(letter);
    const group = groups.get(key);
    if (group) group.push(letter);
    else groups.set(key, [letter]);
  }
  return [...groups.values()];
}
function totalLive(letters) {
  const byKey = /* @__PURE__ */ new Map();
  for (const letter of letters) {
    const key = contentKeyOf(letter);
    let perBox = byKey.get(key);
    if (!perBox) {
      perBox = /* @__PURE__ */ new Map();
      byKey.set(key, perBox);
    }
    perBox.set(letter.box, (perBox.get(letter.box) ?? 0) + 1);
  }
  let total = 0;
  for (const perBox of byKey.values()) {
    total += Math.max(...perBox.values());
  }
  return total;
}

// src/arkmail/core/timing.ts
var DIAGNOSTIC_LIMIT2 = 500;
var waitDiagnostics = [];
var recordWait = (stage, plannedMs, startedAt, outcome) => {
  waitDiagnostics.push({
    stage,
    plannedMs,
    actualMs: Math.max(0, Date.now() - startedAt),
    outcome
  });
  if (waitDiagnostics.length > DIAGNOSTIC_LIMIT2) waitDiagnostics.shift();
};
function cancelFlag(flag) {
  if (flag.cancelled) return;
  flag.cancelled = true;
  for (const wake of [...flag.waiters ?? []]) wake();
}
function waitOrCancel(ms, flag, stage, onCancel) {
  const startedAt = Date.now();
  return new Promise((resolve) => {
    let settled = false;
    let timer = null;
    let offCancel = null;
    const finish = (outcome) => {
      if (settled) return;
      settled = true;
      if (timer !== null) clearTimeout(timer);
      offCancel?.();
      flag.waiters?.delete(wake);
      recordWait(stage, ms, startedAt, outcome);
      resolve();
    };
    const wake = () => finish("anulowano");
    flag.waiters ?? (flag.waiters = /* @__PURE__ */ new Set());
    flag.waiters.add(wake);
    offCancel = onCancel?.(() => cancelFlag(flag)) ?? null;
    timer = setTimeout(() => finish("wykonano"), ms);
    if (flag.cancelled) wake();
  });
}
var DownloadEta = class {
  constructor(now) {
    __publicField(this, "emaMs", null);
    __publicField(this, "lastAt");
    this.lastAt = now;
  }
  reset(now) {
    this.emaMs = null;
    this.lastAt = now;
  }
  sample(now, processed, total) {
    const elapsed = Math.max(0, now - this.lastAt);
    this.lastAt = now;
    this.emaMs = this.emaMs === null ? elapsed : 0.3 * elapsed + 0.7 * this.emaMs;
    if (processed < 3) return null;
    return Math.max(1e3, Math.round(this.emaMs * Math.max(0, total - processed)));
  }
};

// src/arkmail/core/replyRecipients.ts
var knownRecipientNames = (state) => {
  const known = /* @__PURE__ */ new Set();
  const add = (name) => {
    const key = name.trim().toLowerCase();
    if (key) known.add(key);
  };
  for (const contact of state.contacts) {
    add(contact.name);
    if (contact.mailAlias) add(contact.mailAlias);
  }
  for (const name of state.people) add(name);
  for (const alias of state.importedAliases) add(alias.name);
  for (const group of state.groups) for (const member of group.members) add(member);
  return known;
};
function parseReplyHeader(value, known) {
  return splitRecipients(value.replace(/\s+i\s+/gi, ","), known);
}
function buildReplyAllPrefill(letter, currentCharacter, known, scope = "all") {
  const current = currentCharacter?.trim().toLowerCase() || null;
  const primary = [];
  const carbon = [];
  const seen = /* @__PURE__ */ new Set();
  const add = (header, destination) => {
    for (const name of parseReplyHeader(header ?? "", known)) {
      const key = name.trim().toLowerCase();
      if (!key || seen.has(key)) continue;
      seen.add(key);
      if (key === current) continue;
      destination.push(name);
    }
  };
  const received = letter.box === "odebrane" || letter.box === "nieprzeczytane";
  if (received) add(letter.from, primary);
  add(letter.to, primary);
  add(letter.cc, carbon);
  if (scope === "cc") {
    if (carbon.length === 0) return null;
    return { adresat: carbon.join(", "), dw: "" };
  }
  if (scope === "to") {
    if (primary.length === 0) return null;
    return { adresat: primary.join(", "), dw: "" };
  }
  if (primary.length === 0 && carbon.length > 0) {
    primary.push(...carbon);
    carbon.length = 0;
  }
  if (primary.length === 0) return null;
  return { adresat: primary.join(", "), dw: carbon.join(", ") };
}

// src/arkmail/core/errors.ts
var isOperationCancelled = (error) => error instanceof Error && error.message === "operacja anulowana";
var RULES = [
  {
    re: /^nieznany_pager: przerwano listing$/,
    msg: "Poczta jest otwarta w innym widoku - zamknij go i sprobuj ponownie."
  },
  {
    re: /^timeout: mailbox fetch /,
    msg: "Serwer nie odpowiedzial na czas - sprobuj ponownie."
  },
  {
    re: /^timeout: pager session list \d+$/,
    msg: "Odczyt listu trwal za dlugo - sprobuj ponownie."
  },
  {
    re: /^pager session list \d+: przerwano$/,
    msg: "Przerwano odczyt listu."
  },
  {
    // Sierocy pager serwera (17a domyka, ale porazka moze sie zdarzyc).
    // Fala 21b: bez slowa "pager" - gracz nie zna tego pojecia.
    re: /odrzucono przez sierocy pager$|^sierocy pager podczas fetch /,
    msg: "Poczta sie zawiesila - sprobuj ponownie."
  },
  {
    re: /Listy sa w tej chwili ladowane\.$/,
    msg: "Serwer jeszcze laduje listy - sprobuj ponownie za chwile."
  },
  {
    // Straznik desynchronizacji (Fala 14d/17b): surowy format
    // "pusta <skrzynka> podczas fetch <skrzynka>" / "listing ...".
    // Krok 16.2 moze poprzedzic go typem niejednoznacznej odpowiedzi.
    re: /^(?:niejednoznaczna_odpowiedz: )?(?:pusta|listing) (\S+) podczas fetch (\S+)$/,
    msg: (m) => `Serwer odpowiedzial za inna skrzynke (${m[1]} zamiast ${m[2]}) - sprobuj ponownie.`
  },
  {
    // "pager session list N: <linia serwera>" - linia serwera jest
    // juz po polsku ("Zly numer listu: 5."), tniemy tylko prefiks.
    re: /^pager session list \d+: (.+)$/,
    msg: (m) => m[1]
  }
];
var SERVER_LINE_RE = /^[A-Z][^]*\.$/;
function humanizeMailError(raw) {
  const text = raw.trim();
  for (const rule of RULES) {
    const m = text.match(rule.re);
    if (m) return typeof rule.msg === "string" ? rule.msg : rule.msg(m);
  }
  if (SERVER_LINE_RE.test(text)) return text;
  return "Operacja nie powiodla sie - sprobuj ponownie.";
}

// src/arkmail/core/exportTxt.ts
var ANSI_RE = /\[[0-9;]*m/g;
function stripAnsi(s) {
  return s.replace(ANSI_RE, "");
}
function letterTxt(l) {
  const meta = [];
  if (l.from) meta.push(`Od: ${stripAnsi(l.from)}`);
  if (l.to) meta.push(`Do: ${stripAnsi(l.to)}`);
  if (l.cc) meta.push(`DW: ${stripAnsi(l.cc)}`);
  if (l.date) meta.push(stripAnsi(l.date));
  meta.push(`skrzynka: ${l.box}`);
  const lines = [stripAnsi(l.subject), meta.join(" | "), "", ...l.body.map(stripAnsi)];
  return lines.join("\n") + "\n";
}
function archiveLetterTxt(l) {
  return letterTxt({ ...archiveLetterContent(l), box: l.box });
}
function slugAscii(s, max = 40) {
  const slug = s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
  return (slug || "list").slice(0, max);
}
var p2 = (n) => String(n).padStart(2, "0");
function txtFileName(party, subject, dateRaw) {
  const d = dateRaw ? parseMailDate(dateRaw) : null;
  const stamp = d ? `${d.year}-${p2(d.month)}-${p2(d.day)}_${d.time.replace(/:/g, "-")}` : "0000-00-00_00-00-00";
  return `${stamp}_${slugAscii(party, 24)}_${slugAscii(subject, 40)}.txt`;
}
function archiveExportStats(letters) {
  let count = 0;
  let skipped = 0;
  for (const letter of letters) {
    if (letter.body.length > 0) count += 1;
    else skipped += 1;
  }
  return { count, skipped };
}
function archiveExportHeaderGaps(letters) {
  let gaps = 0;
  for (const letter of letters) {
    if (letter.body.length > 0 && !letter.headers) gaps += 1;
  }
  return gaps;
}
function archiveExportEntries(letters) {
  let skipped = 0;
  const withBody = [];
  for (const l of letters) {
    if (l.body.length > 0) withBody.push(l);
    else skipped += 1;
  }
  const sorted = [...withBody].sort((a, b) => {
    if (a.sortKey !== b.sortKey) return a.sortKey < b.sortKey ? 1 : -1;
    return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
  });
  const used = /* @__PURE__ */ new Map();
  const entries = sorted.map((letter) => {
    const base = `${letter.box}/${txtFileName(letter.party, letter.subject, letter.dateRaw)}`;
    const n = (used.get(base) ?? 0) + 1;
    used.set(base, n);
    const name = n === 1 ? base : base.replace(/\.txt$/, `-${n}.txt`);
    return { name, txt: archiveLetterTxt(letter) };
  });
  return { entries, skipped };
}

// src/arkmail/core/zipStore.ts
var CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(data) {
  let c = 4294967295;
  for (let i = 0; i < data.length; i++) c = CRC_TABLE[(c ^ data[i]) & 255] ^ c >>> 8;
  return (c ^ 4294967295) >>> 0;
}
function nameBytes(name) {
  const out = new Uint8Array(name.length);
  for (let i = 0; i < name.length; i++) out[i] = name.charCodeAt(i) & 127;
  return out;
}
var ByteSink = class {
  constructor() {
    __publicField(this, "chunks", []);
    __publicField(this, "len", 0);
  }
  push(b) {
    this.chunks.push(b);
    this.len += b.length;
  }
  u16(v) {
    this.push(new Uint8Array([v & 255, v >>> 8 & 255]));
  }
  u32(v) {
    this.push(new Uint8Array([v & 255, v >>> 8 & 255, v >>> 16 & 255, v >>> 24 & 255]));
  }
  get length() {
    return this.len;
  }
  concat() {
    const out = new Uint8Array(this.len);
    let off = 0;
    for (const c of this.chunks) {
      out.set(c, off);
      off += c.length;
    }
    return out;
  }
};
var DOS_TIME = 0;
var DOS_DATE = 33;
function buildZip(files) {
  const local = new ByteSink();
  const central = new ByteSink();
  for (const f of files) {
    const name = nameBytes(f.name);
    const crc = crc32(f.data);
    const offset = local.length;
    local.u32(67324752);
    local.u16(20);
    local.u16(0);
    local.u16(0);
    local.u16(DOS_TIME);
    local.u16(DOS_DATE);
    local.u32(crc);
    local.u32(f.data.length);
    local.u32(f.data.length);
    local.u16(name.length);
    local.u16(0);
    local.push(name);
    local.push(f.data);
    central.u32(33639248);
    central.u16(20);
    central.u16(20);
    central.u16(0);
    central.u16(0);
    central.u16(DOS_TIME);
    central.u16(DOS_DATE);
    central.u32(crc);
    central.u32(f.data.length);
    central.u32(f.data.length);
    central.u16(name.length);
    central.u16(0);
    central.u16(0);
    central.u16(0);
    central.u16(0);
    central.u32(0);
    central.u32(offset);
    central.push(name);
  }
  const cd = central.concat();
  const body = local.concat();
  const eocd = new ByteSink();
  eocd.u32(101010256);
  eocd.u16(0);
  eocd.u16(0);
  eocd.u16(files.length);
  eocd.u16(files.length);
  eocd.u32(cd.length);
  eocd.u32(body.length);
  eocd.u16(0);
  const out = new Uint8Array(body.length + cd.length + eocd.length);
  out.set(body, 0);
  out.set(cd, body.length);
  out.set(eocd.concat(), body.length + cd.length);
  return out;
}

// src/arkmail/ui/download.ts
var impl = null;
function downloadBlob(name, data) {
  try {
    if (impl) {
      impl(name, data);
      return true;
    }
    const g = globalThis;
    const doc = g.document;
    const urlApi = g.URL;
    if (!doc?.body || !urlApi) return false;
    const a = doc.createElement("a");
    const url = urlApi.createObjectURL(data);
    a.href = url;
    a.download = name;
    doc.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => {
      try {
        urlApi.revokeObjectURL(url);
      } catch {
      }
    }, 1e3);
    return true;
  } catch {
    return false;
  }
}

// src/arkmail/ui/deletion.ts
function emptyDeletionFilters() {
  return { osoba: "", temat: "", tresc: "", odDaty: "", doDaty: "" };
}
function formatListCount(count) {
  const lastTwo = count % 100;
  const last = count % 10;
  const form = count === 1 ? "list" : last >= 2 && last <= 4 && (lastTwo < 12 || lastTwo > 14) ? "listy" : "listow";
  return `${count} ${form}`;
}

// src/arkmail/ui/operationSummary.ts
function buildDownloadSummary(result) {
  const { done, total, failed, missing } = result;
  const remaining = result.remaining ?? Math.max(0, total - done - failed - missing);
  if (failed === 0 && missing === 0 && remaining === 0) {
    return {
      text: `Pobrano tresci do archiwum (${formatListCount(done)}).`,
      level: "success"
    };
  }
  const parts = [`Pobrano: ${done} z ${total}.`];
  if (failed > 0) parts.push(`Nieudane: ${failed}.`);
  if (missing > 0) parts.push(`Nie ma juz w skrzynce: ${missing}.`);
  if (remaining > 0) parts.push(`Pozostale: ${remaining}.`);
  return { text: parts.join(" "), level: "warning" };
}
function buildExportSummary(fileCount, skipped, incompleteHeaders = 0) {
  const gaps = incompleteHeaders > 0 ? ` Niepelne historyczne naglowki: ${incompleteHeaders}.` : "";
  return {
    text: `Zapisano pliki TXT do ZIP. Liczba plikow: ${fileCount}. Pominiete bez tresci: ${skipped}.${gaps}`,
    level: incompleteHeaders > 0 ? "warning" : "success"
  };
}

// src/arkmail/core/session/pager.ts
var CLOSE_GRACE_MS = 400;
var numbersInRange = (range) => {
  const out = /* @__PURE__ */ new Set();
  for (const part of range.split(",")) {
    const m = part.trim().match(/^(\d+)(?:-(\d+))?$/);
    if (!m) continue;
    const from = Number(m[1]);
    const to = m[2] === void 0 ? from : Number(m[2]);
    const step = from <= to ? 1 : -1;
    for (let n = from; step > 0 ? n <= to : n >= to; n += step) out.add(n);
  }
  return [...out].sort((a, b) => a - b);
};
var rangeOf = (numbers) => {
  const sorted = [...new Set(numbers)].sort((a, b) => a - b);
  const parts = [];
  for (let i = 0; i < sorted.length; ) {
    const from = sorted[i];
    let to = from;
    while (i + 1 < sorted.length && sorted[i + 1] === to + 1) to = sorted[++i];
    parts.push(from === to ? String(from) : `${from}-${to}`);
    i++;
  }
  return parts.join(",");
};
var sameNumbers = (a, b) => a.length === b.length && a.every((n, i) => n === b[i]);
var numbersOfConfirmation = (text) => [...text.matchAll(/\d+/g)].map((m) => Number(m[0]));
var PAGER_REJECTION_RE = /Nie ma takiej komendy\./;
var ADVANCE_MAX_TRIES = 3;
var PagerSession = class {
  constructor(transport2, opts) {
    __publicField(this, "transport", transport2);
    __publicField(this, "opts", opts);
  }
  /**
   * Odczyt listu. shouldAbort (Fala 17a, zgloszenie pkt 4): Przerwij
   * petli pobierania w trakcie odczytu - sesja domyka pager od razu
   * ("q" tylko gdy pager faktycznie otwarty albo naglowki kompletne;
   * przed otwarciem zadnego smieciowego "q") i odrzuca "przerwano",
   * zamiast wisiec do timeoutu z otwartym pagerem serwera.
   */
  readLetter(numer, shouldAbort) {
    return this.run(numer, () => null, (letter, pager) => ({ letter, pager }), shouldAbort);
  }
  deleteLetters(numer, zakres, shouldAbort) {
    const requested = numbersInRange(zakres);
    let selectedNumbers = [];
    let confirmed = [];
    let deleteSent = false;
    let selectionAccepted = false;
    let uncertain = false;
    const build = () => {
      const deletedNumbers = [...new Set(confirmed)].filter((n) => requested.includes(n)).sort((a, b) => a - b);
      const unexpectedNumbers = [...new Set(confirmed)].filter((n) => !requested.includes(n)).sort((a, b) => a - b);
      const complete = requested.length > 0 && unexpectedNumbers.length === 0 && requested.every((n) => deletedNumbers.includes(n));
      const status = uncertain ? "unknown" : complete ? "complete" : deletedNumbers.length > 0 ? "partial" : selectionAccepted ? "unknown" : "none";
      return { status, deleted: deletedNumbers.length > 0, deletedNumbers, selectedNumbers, unexpectedNumbers };
    };
    return this.run(
      numer,
      (ctx) => {
        const withdraw = () => {
          if (deleteSent && !selectionAccepted) ctx.send(`u ${rangeOf([...requested, ...selectedNumbers])}`);
        };
        return {
          onPager: () => {
            deleteSent = true;
            ctx.send(`d ${zakres}`);
          },
          onLine: (line) => {
            const m = line.text.match(/^Zaznaczono do skasowania: (.+)\.$/);
            if (m) {
              selectedNumbers = [...new Set(numbersOfConfirmation(m[1]))].sort((a, b) => a - b);
              if (!sameNumbers(selectedNumbers, requested)) {
                withdraw();
                return "close";
              }
              selectionAccepted = true;
              return "close";
            }
            return parseMailError(line.text) ? "close" : void 0;
          },
          onClosingLine: (line) => {
            const m = line.text.match(/^Kasuje: (.+)\.$/);
            if (m) {
              for (const n of numbersOfConfirmation(m[1])) confirmed.push(n);
            }
          },
          onAbort: withdraw,
          onTimeout: withdraw,
          onCancel: () => {
            if (!deleteSent) return;
            withdraw();
            ctx.send("q");
          }
        };
      },
      build,
      shouldAbort
    ).catch((error) => {
      if (!deleteSent) throw error;
      uncertain = true;
      return build();
    });
  }
  forwardLetter(numer, adresat) {
    let queued = false;
    let error = null;
    let dwAnswered = false;
    return this.run(
      numer,
      (ctx) => ({
        onPager: () => ctx.send(`f ${adresat}`),
        onLine: (line) => {
          const err = parseMailError(line.text);
          if (err && err.kind === "brak-adresata") {
            if (!error) error = err;
            return void 0;
          }
          if (/^DW: *$/.test(line.text)) {
            if (!dwAnswered) {
              dwAnswered = true;
              ctx.send("");
            }
            return void 0;
          }
          if (line.text === "List jest gotowy do wyslania.") {
            queued = true;
            return "close";
          }
          return void 0;
        }
      }),
      () => ({ queued, error })
    );
  }
  /**
   * Otwiera pager na liscie `numer`, wykonuje akcje, zamyka "q".
   * onPager: odpalane przy pierwszym pager prompt (wyslij akcje).
   * onLine: moze zwrocic 'close' -> wysylamy "q" przy najblizszym
   * pager prompcie. Konczy sie wylacznie na zwyklym promptcie gry
   * (klasa albo tresc); brak promptu odrzuca dopiero pelny limit czasu.
   */
  run(numer, makeActions, build, shouldAbort) {
    return new Promise((resolve, reject) => {
      const session = this.transport.openSession();
      const letter = {
        number: numer,
        from: "",
        subject: "",
        to: "",
        cc: null,
        date: null,
        body: []
      };
      let pager = { lo: 0, hi: 0, current: numer };
      let state = "letter";
      let headersDone = false;
      let wantClose = false;
      let pagerFired = false;
      let idleOpened = false;
      let retried = false;
      let loadRetried = false;
      let loadRetryTimer = null;
      let done = false;
      let ambiguous = null;
      let advances = 0;
      const idleMs = this.opts.idleMs ?? DEFAULT_IDLE_FLUSH_MS;
      let quietTimer = null;
      let graceTimer = null;
      let cancelUnsub = () => {
      };
      const cleanup = () => {
        done = true;
        clearTimeout(timer);
        if (quietTimer) clearTimeout(quietTimer);
        if (graceTimer) clearTimeout(graceTimer);
        if (loadRetryTimer) clearTimeout(loadRetryTimer);
        cancelUnsub();
        session.close();
      };
      const fail = (error) => {
        if (done) return;
        cleanup();
        reject(error instanceof Error ? error : new Error(String(error)));
      };
      const send = (line) => {
        if (done) return;
        try {
          void Promise.resolve(this.transport.send(line)).catch(fail);
        } catch (error) {
          fail(error);
        }
      };
      const actions = makeActions({ send });
      let aborted = false;
      const finish = (confirmed = true) => {
        cleanup();
        if (aborted) {
          reject(new Error(`pager session list ${numer}: przerwano`));
          return;
        }
        if (ambiguous !== null) {
          if (confirmed) clearPagerOrphan();
          else suspectPagerOrphan();
          reject(new AmbiguousResponseError(ambiguous));
          return;
        }
        if (confirmed) clearPagerOrphan();
        else suspectPagerOrphan();
        resolve(build(letter, pager));
      };
      const checkAbort = () => {
        if (done || aborted || !shouldAbort || !shouldAbort()) return;
        aborted = true;
        actions?.onAbort?.();
        if (state === "pager" || pagerFired || idleOpened || headersDone) {
          if (state !== "closing") enterClosing();
          return;
        }
        cleanup();
        reject(new Error(`pager session list ${numer}: przerwano`));
      };
      const onQuiet = () => {
        if (done) return;
        checkAbort();
        if (done || aborted) return;
        if (state === "letter" && headersDone) {
          if (advances < ADVANCE_MAX_TRIES) {
            advances++;
            send("");
            if (!done) armQuiet();
            return;
          }
          state = "pager";
          pagerFired = true;
          idleOpened = true;
          if (actions && actions.onPager) {
            actions.onPager();
            if (!done) armQuiet();
          } else {
            enterClosing();
          }
          return;
        }
        if (state === "pager" && (wantClose || idleOpened)) enterClosing();
      };
      const armQuiet = () => {
        if (quietTimer) clearTimeout(quietTimer);
        quietTimer = setTimeout(onQuiet, idleMs);
      };
      const timer = setTimeout(() => {
        actions?.onTimeout?.();
        if (state === "closing") {
          this.transport.beginRecovery();
          suspectPagerOrphan();
          cleanup();
          reject(new Error(`timeout: pager session list ${numer}`));
          return;
        }
        state = "closing";
        wantClose = false;
        idleOpened = false;
        send("q");
        if (!done) {
          graceTimer = setTimeout(() => {
            this.transport.beginRecovery();
            suspectPagerOrphan();
            cleanup();
            reject(new Error(`timeout: pager session list ${numer}`));
          }, Math.max(idleMs, CLOSE_GRACE_MS));
        }
      }, this.opts.timeoutMs);
      const enterClosing = () => {
        wantClose = false;
        idleOpened = false;
        state = "closing";
        if (quietTimer) clearTimeout(quietTimer);
        send("q");
      };
      session.subscribe((line) => {
        if (done || line.cls === "command" || isEchoLine(line.text)) return;
        checkAbort();
        if (done) return;
        if (state === "closing") {
          if (line.cls === "prompt" || isPromptLine(line.text)) {
            finish();
            return;
          }
          actions?.onClosingLine?.(line);
          return;
        }
        if (state === "recovering") {
          if (line.cls === "prompt" || isPromptLine(line.text)) {
            state = "letter";
            send(`przeczytaj list ${numer}`);
          }
          return;
        }
        if (state === "letter" && !headersDone && PAGER_REJECTION_RE.test(line.text)) {
          send("q");
          if (done) return;
          if (retried) {
            suspectPagerOrphan();
            cleanup();
            reject(new Error(`pager session list ${numer}: odrzucono przez sierocy pager`));
            return;
          }
          retried = true;
          state = "recovering";
          return;
        }
        if (state === "letter" && !headersDone) {
          if (LISTS_LOADING_RE.test(line.text)) {
            if (loadRetried) {
              cleanup();
              reject(new Error(`pager session list ${numer}: Listy sa w tej chwili ladowane.`));
              return;
            }
            loadRetried = true;
            loadRetryTimer = setTimeout(() => {
              if (!done && state === "letter") {
                send(`przeczytaj list ${numer}`);
              }
            }, LISTS_LOADING_RETRY_MS);
            return;
          }
          const mailErr = parseMailError(line.text);
          if (mailErr) {
            cleanup();
            reject(new Error(`pager session list ${numer}: ${line.text.trim()}`));
            return;
          }
        }
        const pp = extractPagerPrompt(line.text);
        if (pp) {
          if (pp.current !== numer) {
            ambiguous = `prompt pagera list ${pp.current} podczas odczytu ${numer}`;
            enterClosing();
            return;
          }
          advances = 0;
          if (quietTimer) clearTimeout(quietTimer);
          pager = pp;
          state = "pager";
          if (pagerFired && wantClose) {
            enterClosing();
            return;
          }
          if (!pagerFired) {
            pagerFired = true;
            if (actions && actions.onPager) {
              actions.onPager();
              return;
            }
            enterClosing();
            return;
          }
          return;
        }
        if (state === "letter" && !headersDone) {
          const h = parseLetterHeaderLine(line.text);
          if (h) {
            if (h.field === "numer") {
              const received = Number(h.value);
              if (received !== numer) {
                ambiguous = `naglowek list ${h.value} podczas odczytu ${numer}`;
                enterClosing();
                return;
              }
              letter.number = received;
            } else if (h.field === "od") letter.from = h.value;
            else if (h.field === "temat") letter.subject = h.value;
            else if (h.field === "do") letter.to = h.value;
            else if (h.field === "dw") letter.cc = h.value;
            else if (h.field === "data") {
              letter.date = h.value;
              headersDone = true;
              armQuiet();
            }
            return;
          }
          return;
        }
        if (state === "letter") {
          letter.body.push(line.text);
          advances = 0;
          armQuiet();
          return;
        }
        if (actions && actions.onLine) {
          const verdict = actions.onLine(line);
          if (verdict === "close") wantClose = true;
        }
        armQuiet();
      });
      cancelUnsub = this.opts.onCancel?.(() => {
        actions?.onCancel?.();
        cleanup();
        reject(new Error("operacja anulowana"));
      }) ?? (() => {
      });
      if (!done) send(`przeczytaj list ${numer}`);
    });
  }
};

// src/arkmail/core/session/editor.ts
var EditorSession = class {
  constructor(transport2, opts) {
    __publicField(this, "transport", transport2);
    __publicField(this, "opts", opts);
  }
  send(input) {
    return new Promise((resolve, reject) => {
      const session = this.transport.openSession();
      let stage = "adresat";
      let done = false;
      let editorReady = false;
      let bodyStarted = false;
      const dw = input.dw ?? "";
      let cancelUnsub = () => {
      };
      let transition = Promise.resolve();
      const cleanup = () => {
        done = true;
        clearTimeout(timer);
        cancelUnsub();
        unsub();
        session.close();
      };
      const finish = (r) => {
        cleanup();
        resolve(r);
      };
      const fail = (error) => {
        if (done) return;
        cleanup();
        reject(error);
      };
      const enqueue = (job) => {
        transition = transition.then(job);
        transition.catch(fail);
      };
      const sendLine = async (line) => {
        if (!done) await this.transport.send(line, true);
      };
      const timer = setTimeout(() => {
        this.transport.beginRecovery();
        cleanup();
        resolve({ result: "blad", error: { kind: "timeout" } });
      }, this.opts.timeoutMs);
      const flush = async (confirmed) => {
        const order = ["adresat", "temat", "dw"];
        for (const c of confirmed) {
          if (done) return;
          const idx = order.indexOf(c);
          const cur = order.indexOf(stage);
          if (idx < cur) continue;
          stage = order[idx + 1] ?? "tresc";
          if (c === "temat") await sendLine(input.temat);
          else if (c === "dw") await sendLine(dw);
        }
      };
      const sendBody = async () => {
        if (done || bodyStarted || stage !== "tresc" || !editorReady) return;
        bodyStarted = true;
        stage = "tresc-wyslana";
        for (const linia of input.linie) {
          if (done) return;
          await sendLine(linia);
        }
        if (!done) await sendLine("**");
      };
      const unsub = session.subscribe((line) => {
        if (done || line.cls === "command" || isEchoLine(line.text)) return;
        if (line.text === "Zaniechane.") {
          finish({ result: "zaniechany" });
          return;
        }
        const err = parseMailError(line.text);
        if (err) {
          finish({ result: "blad", error: err });
          return;
        }
        const standalone = parseComposeResult(line.text);
        if (standalone) {
          finish({ result: standalone });
          return;
        }
        const echo = parseEditorEcho(line.text);
        if (echo?.result) {
          finish({ result: echo.result });
          return;
        }
        if (stage === "tresc-wyslana") return;
        if (isEditorReady(line.text)) editorReady = true;
        const prompts = parseComposeEcho(line.text);
        if (prompts) {
          enqueue(async () => {
            await flush(prompts);
            await sendBody();
          });
        } else if (editorReady) {
          enqueue(sendBody);
        }
      });
      cancelUnsub = this.opts.onCancel?.(() => {
        cleanup();
        reject(new Error("operacja anulowana"));
      }) ?? (() => {
      });
      if (!done) {
        transition = (async () => {
          await this.transport.send("napisz list", true);
          if (!done) await this.transport.send(input.adresat, true);
        })();
        transition.catch(fail);
      }
    });
  }
};

// src/arkmail/core/sessionLock.ts
var SessionLock = class {
  constructor() {
    __publicField(this, "tail", Promise.resolve());
    __publicField(this, "active", 0);
    __publicField(this, "waiting", /* @__PURE__ */ new Set());
  }
  get locked() {
    return this.active > 0;
  }
  async acquire() {
    this.active++;
    let releaseNext;
    const next = new Promise((resolve) => {
      releaseNext = resolve;
    });
    const prev = this.tail;
    this.tail = prev.then(() => next);
    return new Promise((resolve, reject) => {
      let settled = false;
      let released = false;
      const cancel = () => {
        if (settled) return;
        settled = true;
        this.active--;
        this.waiting.delete(cancel);
        reject(new Error("operacja anulowana"));
      };
      this.waiting.add(cancel);
      void prev.then(() => {
        this.waiting.delete(cancel);
        if (settled) {
          releaseNext();
          return;
        }
        settled = true;
        resolve(() => {
          if (released) return;
          released = true;
          this.active--;
          releaseNext();
        });
      });
    });
  }
  /** Odrzuca operacje oczekujace; aktywna konczy sie przez swoja sesje. */
  cancelWaiting() {
    for (const cancel of [...this.waiting]) cancel();
  }
  async runExclusive(fn) {
    const release = await this.acquire();
    try {
      return await fn();
    } finally {
      release();
    }
  }
};

// src/arkmail/core/session/transport.ts
var RegisteredSession = class {
  constructor(id, generation, onClose) {
    __publicField(this, "id", id);
    __publicField(this, "generation", generation);
    __publicField(this, "onClose", onClose);
    __publicField(this, "callbacks", /* @__PURE__ */ new Set());
    __publicField(this, "open", true);
  }
  get active() {
    return this.open;
  }
  subscribe(cb) {
    if (!this.open) return () => {
    };
    this.callbacks.add(cb);
    return () => {
      this.callbacks.delete(cb);
    };
  }
  dispatch(line) {
    if (!this.open) return;
    for (const cb of [...this.callbacks]) cb(line);
  }
  close() {
    if (!this.open) return;
    this.open = false;
    this.callbacks.clear();
    this.onClose(this);
  }
};
var SessionScopeRegistry = class {
  constructor() {
    __publicField(this, "sessions", /* @__PURE__ */ new Set());
    __publicField(this, "nextId", 0);
    __publicField(this, "generation", 0);
  }
  get hasActive() {
    return this.sessions.size > 0;
  }
  openSession() {
    if (this.sessions.size > 0) throw new Error("operacja anulowana");
    const session = new RegisteredSession(
      ++this.nextId,
      this.generation,
      (closed) => this.sessions.delete(closed)
    );
    this.sessions.add(session);
    return session;
  }
  dispatch(line) {
    for (const session of [...this.sessions]) session.dispatch(line);
  }
  reconnect() {
    this.generation++;
    this.closeAll();
  }
  closeAll() {
    for (const session of [...this.sessions]) session.close();
  }
};

// src/arkmail/adapters/notify.ts
var DEFAULT_NOTIFY_TIME_MS = 8e3;
function notify(api, text, opts = {}) {
  api.notifications.show({
    text,
    ...opts.title !== void 0 ? { title: opts.title } : {},
    level: opts.level ?? "info",
    time: opts.time ?? DEFAULT_NOTIFY_TIME_MS
  });
}

// src/arkmail/adapters/dargothTransport.ts
var MODAL_HOOK_PRIORITY = 100;
var PENDING_ECHO_CAP = 10;
var PENDING_ECHO_TTL_MS = 1e4;
var RECOVERY_LIMIT_MS = 1e4;
var isPagerCommand = (command) => {
  const value = command.trim();
  if (value.startsWith("!")) return false;
  if (value === "") return true;
  if (/^(?:\.|<|>|\?|\d+|m|e|q|x)$/i.test(value)) return true;
  if (/^[-+](?:\s+.*)?$/s.test(value)) return true;
  return /^(?:h|r|f|a|d|u|n)(?:\s+.*)?$/is.test(value);
};
var DargothTransport = class {
  constructor(api) {
    __publicField(this, "api", api);
    __publicField(this, "subscribers", /* @__PURE__ */ new Set());
    __publicField(this, "sessions", new SessionScopeRegistry());
    __publicField(this, "triggerArmed", false);
    __publicField(this, "modalActive", false);
    __publicField(this, "hookId", null);
    __publicField(this, "pagerModal", null);
    __publicField(this, "pagerOpen", false);
    __publicField(this, "queue", []);
    __publicField(this, "commandQueue", Promise.resolve());
    __publicField(this, "connectionGeneration", 0);
    __publicField(this, "sendingOwn", false);
    /** Fala 42: teksty wysylek z echem (echo=true) czekajacych na
     *  linie-echo w strumieniu. FIFO z limitem. Wysylka bez echa NIE
     *  rejestruje sie - identyczny tekst wpisany recznie przez gracza
     *  nigdy nie dostanie znacznika own. */
    __publicField(this, "pendingEchoSends", []);
    __publicField(this, "nextEchoId", 1);
    // Fala 25 (blad 3): transport startuje ROZBROJONY. Brama otwiera
    // wylacznie sygnal obecnosci w grze (gmcp.char.info / char.name /
    // mail.state / room.long albo proxy.session z faktycznym wznowieniem
    // sesji); client.connect sam w sobie NIE uzbraja, bo odpala tez na
    // ekranie logowania - komenda "listy ..." na prompcie nazwy postaci
    // zabijala logowanie ("Nie ma takiej postaci").
    __publicField(this, "online", false);
    /** Fala 16j: kiedy tlumic linie pocztowe (index.ts: blokada sesji). */
    __publicField(this, "gagWhen", null);
    /** Niepotwierdzony koniec odpowiedzi: mail gagowany do promptu gry. */
    __publicField(this, "recovering", false);
    __publicField(this, "recoveryTimer", null);
  }
  /**
   * Fala 16j: predykat gagowania linii pocztowych (cls 'mail'). Linie
   * przychodzace podczas operacji pluginowej (listingi, tresci listow)
   * nie smieca glownego okna gry; poza operacja wszystko przechodzi
   * bez zmian (reczne "listy" gracza, powiadomienie POCZTA).
   */
  setGagPredicate(pred) {
    this.gagWhen = pred;
  }
  send(line, echo = false) {
    if (this.pagerModal && /^(?:q|x)$/i.test(line.trim())) this.pagerOpen = false;
    return this.enqueue(line, echo);
  }
  /** Jedna komenda czeka na zakonczenie przetwarzania poprzedniej. */
  enqueue(line, echo, source = "arkmail") {
    if (!this.online) return Promise.reject(new Error("transport offline"));
    if (source === "arkmail" && this.recovering) {
      return Promise.reject(new Error("operacja anulowana"));
    }
    const generation = this.connectionGeneration;
    const task = this.commandQueue.then(async () => {
      if (!this.online || generation !== this.connectionGeneration) {
        throw new Error("transport offline: wysylka anulowana");
      }
      if (source === "arkmail" && this.recovering) {
        throw new Error("operacja anulowana");
      }
      let echoEntry;
      if (echo) {
        const entry = {
          id: this.nextEchoId++,
          line,
          source,
          timer: setTimeout(() => this.removePendingEcho(entry), PENDING_ECHO_TTL_MS)
        };
        entry.timer.unref?.();
        echoEntry = entry;
        this.pendingEchoSends.push(entry);
        if (this.pendingEchoSends.length > PENDING_ECHO_CAP) {
          this.removePendingEcho(this.pendingEchoSends[0]);
        }
      }
      try {
        this.sendingOwn = true;
        let pending;
        try {
          pending = this.api.command.send(line, echo, { preserveCase: true });
        } finally {
          this.sendingOwn = false;
        }
        await pending;
      } catch (err) {
        if (echoEntry) this.removePendingEcho(echoEntry);
        throw err;
      }
    });
    this.commandQueue = task.catch(() => {
    });
    return task;
  }
  removePendingEcho(entry) {
    const index = this.pendingEchoSends.findIndex((candidate) => candidate.id === entry.id);
    if (index < 0) return;
    this.pendingEchoSends.splice(index, 1);
    clearTimeout(entry.timer);
  }
  clearPendingEchoes() {
    for (const entry of this.pendingEchoSends) clearTimeout(entry.timer);
    this.pendingEchoSends = [];
  }
  openSession() {
    if (this.recovering) throw new Error("operacja anulowana");
    this.armTrigger();
    return this.sessions.openSession();
  }
  clearRecoveryTimer() {
    if (this.recoveryTimer) clearTimeout(this.recoveryTimer);
    this.recoveryTimer = null;
  }
  finishRecovery() {
    this.recovering = false;
    this.clearRecoveryTimer();
  }
  beginRecovery() {
    if (this.recovering) {
      this.armTrigger();
      return;
    }
    this.recovering = true;
    this.armTrigger();
    const generation = this.connectionGeneration;
    this.recoveryTimer = setTimeout(() => {
      this.recoveryTimer = null;
      if (!this.recovering || generation !== this.connectionGeneration) return;
      notify(
        this.api,
        "Nie potwierdzono zakonczenia poprzedniej odpowiedzi. Poczekaj na powrot zwyklego widoku gry lub polacz ponownie.",
        { title: "Brak synchronizacji z gra", level: "error" }
      );
    }, RECOVERY_LIMIT_MS);
    this.recoveryTimer.unref?.();
  }
  subscribe(cb) {
    this.armTrigger();
    this.subscribers.add(cb);
    return () => {
      this.subscribers.delete(cb);
    };
  }
  /** Liczba komend gracza odlozonych w trakcie sesji modalnej. */
  get modalQueueLength() {
    return this.queue.length;
  }
  beginModal(options) {
    if (this.modalActive) return;
    this.modalActive = true;
    this.pagerModal = options?.pager ?? null;
    this.pagerOpen = false;
    this.hookId = this.api.commandHooks.register((command) => {
      if (this.sendingOwn) return void 0;
      if (this.pagerModal && this.pagerOpen && isPagerCommand(command)) {
        const hooks = this.pagerModal;
        if (/^(?:q|x)$/i.test(command.trim())) this.pagerOpen = false;
        hooks.onUserCommand(command);
        void this.enqueue(command, true, "user").catch(() => {
        });
      } else {
        this.queue.push(command);
      }
      return null;
    }, MODAL_HOOK_PRIORITY);
  }
  /** Przekazuje pierwsza odlozona komende czytania do wlasnie
   *  otwartego pagera, zanim sesja pluginu zdazy wyslac q. */
  takeoverQueuedPagerCommand() {
    if (!this.pagerModal) return;
    const index = this.queue.findIndex(isPagerCommand);
    if (index < 0) return;
    const command = this.queue.splice(index, 1)[0];
    const hooks = this.pagerModal;
    if (/^(?:q|x)$/i.test(command.trim())) this.pagerOpen = false;
    hooks.onUserCommand(command);
    void this.enqueue(command, true, "user").catch(() => {
    });
  }
  endModal() {
    if (!this.modalActive) return;
    this.modalActive = false;
    const pagerHooks = this.pagerModal;
    this.pagerModal = null;
    this.pagerOpen = false;
    if (this.hookId !== null) {
      this.api.commandHooks.unregister(this.hookId);
      this.hookId = null;
    }
    const pending = this.queue.splice(0);
    if (!this.online) return;
    let dropped = false;
    for (const command of pending) {
      if (pagerHooks && isPagerCommand(command)) {
        dropped = true;
        continue;
      }
      void this.enqueue(command, true, "user").catch(() => {
      });
    }
    if (dropped) pagerHooks?.onCommandDropped();
  }
  /** Odcina stare wysylki i porzuca kolejke bez drenowania. */
  setOnline(online) {
    this.online = online;
    if (online) return;
    this.connectionGeneration++;
    const needsRecovery = this.recovering || this.sessions.hasActive;
    this.recovering = false;
    this.clearRecoveryTimer();
    if (needsRecovery) this.beginRecovery();
    this.sessions.reconnect();
    this.commandQueue = Promise.resolve();
    this.clearPendingEchoes();
    if (this.hookId !== null) {
      this.api.commandHooks.unregister(this.hookId);
      this.hookId = null;
    }
    this.modalActive = false;
    this.pagerModal = null;
    this.pagerOpen = false;
    this.queue = [];
  }
  /** Zdejmuje trigger i modal-guard; do wywolania w destroy() pluginu. */
  dispose() {
    this.endModal();
    if (this.triggerArmed) {
      this.api.triggers.removeByTag("arkmail");
      this.triggerArmed = false;
    }
    this.subscribers.clear();
    this.sessions.closeAll();
    this.queue = [];
    this.clearPendingEchoes();
    this.finishRecovery();
    this.connectionGeneration++;
    this.commandQueue = Promise.resolve();
  }
  armTrigger() {
    if (this.triggerArmed) return;
    this.triggerArmed = true;
    this.api.triggers.register(
      /^/,
      // 4. argument (originalLine) niesie dziewiczy tekst linii z gry -
      // system triggerow Dargoth przekazuje kolejnym callbackom buffer
      // po cudzych modyfikacjach (np. newMail klienta dokleja prefix
      // "\n[ POCZTA ] " i suffix "\n\n"), co lamalo dopasowania
      // (Fala 8a, dowod: Triggers.ts TriggerCallback + newMail.ts).
      (line, _matches, type, originalLine) => {
        const proto = { text: originalLine ?? line.text, cls: type ?? "" };
        if (this.recovering && (proto.cls === "prompt" || isPromptLine(proto.text))) {
          this.finishRecovery();
        }
        if (this.pendingEchoSends.length > 0) {
          const echoed = proto.text.startsWith("\u2192 ") ? proto.text.slice(2) : proto.cls === "command" ? proto.text : null;
          if (echoed !== null) {
            const i = this.pendingEchoSends.findIndex((entry) => entry.line === echoed);
            if (i >= 0) {
              const entry = this.pendingEchoSends[i];
              this.removePendingEcho(entry);
              if (entry.source === "arkmail") proto.own = true;
            }
          }
        }
        if (this.modalActive && this.pagerModal) {
          if (extractPagerPrompt(proto.text)) {
            this.pagerOpen = true;
            this.takeoverQueuedPagerCommand();
          } else if (proto.cls === "prompt" || isPromptLine(proto.text)) {
            this.pagerOpen = false;
          }
        }
        this.sessions.dispatch(proto);
        for (const cb of [...this.subscribers]) cb(proto);
        if (type === "mail" && (this.recovering || this.gagWhen?.())) return null;
        return line;
      },
      "arkmail"
    );
  }
};

// src/arkmail/adapters/storageDriver.ts
var MemoryStorageDriver = class {
  constructor() {
    __publicField(this, "values", /* @__PURE__ */ new Map());
    __publicField(this, "letters", /* @__PURE__ */ new Map());
  }
  async loadAll() {
    return Object.fromEntries(this.values);
  }
  async loadAllLetters() {
    return Object.fromEntries(
      [...this.letters].map(([character, values]) => [character, Object.fromEntries(values)])
    );
  }
  async put(key, value) {
    this.values.set(key, value);
  }
  async putMany(values) {
    for (const [key, value] of Object.entries(values)) this.values.set(key, value);
  }
  async putLetters(character, values) {
    const current = this.letters.get(character) ?? /* @__PURE__ */ new Map();
    this.letters.set(character, current);
    for (const [id, value] of Object.entries(values)) current.set(id, value);
  }
  async deleteLetters(character, ids) {
    const current = this.letters.get(character);
    if (!current) return;
    for (const id of ids) current.delete(id);
  }
  async delete(key) {
    this.values.delete(key);
  }
  async clearLetters(character) {
    await this.clearMailData(character, []);
  }
  async clearMailData(character, keys) {
    this.letters.delete(character);
    for (const key of keys) this.values.delete(key);
  }
  async close() {
  }
};
var STATE_STORE = "state";
var LETTERS_STORE = "letters";
var LEGACY_STORE = "dane";
var DATABASE_VERSION = 2;
var IndexedDbStorageDriver = class {
  constructor(factory, databaseName = "arkmail") {
    __publicField(this, "databaseName", databaseName);
    __publicField(this, "databasePromise", null);
    __publicField(this, "database", null);
    __publicField(this, "factory");
    this.factory = factory ?? globalThis.indexedDB;
  }
  async loadAll() {
    const database = await this.openDatabase();
    return new Promise((resolve, reject) => {
      const values = {};
      const transaction = database.transaction(STATE_STORE, "readonly");
      const request = transaction.objectStore(STATE_STORE).openCursor();
      request.onsuccess = () => {
        const cursor = request.result;
        if (!cursor) return;
        values[String(cursor.key)] = String(cursor.value);
        cursor.continue();
      };
      transaction.oncomplete = () => resolve(values);
      transaction.onerror = () => reject(transaction.error ?? new Error("Blad odczytu IndexedDB."));
      transaction.onabort = () => reject(transaction.error ?? new Error("Odczyt IndexedDB przerwany."));
    });
  }
  async loadAllLetters() {
    const database = await this.openDatabase();
    return new Promise((resolve, reject) => {
      const result = {};
      const transaction = database.transaction(LETTERS_STORE, "readonly");
      const request = transaction.objectStore(LETTERS_STORE).openCursor();
      request.onsuccess = () => {
        var _a;
        const cursor = request.result;
        if (!cursor) return;
        const record = cursor.value;
        (result[_a = record.character] ?? (result[_a] = {}))[record.id] = record.value;
        cursor.continue();
      };
      transaction.oncomplete = () => resolve(result);
      transaction.onerror = () => reject(transaction.error ?? new Error("Blad odczytu listow."));
      transaction.onabort = () => reject(transaction.error ?? new Error("Odczyt listow przerwany."));
    });
  }
  async put(key, value) {
    await this.writeState("put", key, value);
  }
  async putMany(values) {
    const database = await this.openDatabase();
    await new Promise((resolve, reject) => {
      const transaction = database.transaction(STATE_STORE, "readwrite");
      const store2 = transaction.objectStore(STATE_STORE);
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error ?? new Error("Blad zapisu IndexedDB."));
      transaction.onabort = () => reject(transaction.error ?? new Error("Zapis IndexedDB przerwany."));
      try {
        for (const [key, value] of Object.entries(values)) store2.put(value, key);
      } catch (error) {
        transaction.abort();
        reject(error);
      }
    });
  }
  async putLetters(character, values) {
    if (Object.keys(values).length === 0) return;
    const database = await this.openDatabase();
    await new Promise((resolve, reject) => {
      const transaction = database.transaction(LETTERS_STORE, "readwrite");
      const store2 = transaction.objectStore(LETTERS_STORE);
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error ?? new Error("Blad zapisu listow."));
      transaction.onabort = () => reject(transaction.error ?? new Error("Zapis listow przerwany."));
      try {
        for (const [id, value] of Object.entries(values)) store2.put({ character, id, value });
      } catch (error) {
        transaction.abort();
        reject(error);
      }
    });
  }
  async deleteLetters(character, ids) {
    if (ids.length === 0) return;
    const database = await this.openDatabase();
    await new Promise((resolve, reject) => {
      const transaction = database.transaction(LETTERS_STORE, "readwrite");
      const store2 = transaction.objectStore(LETTERS_STORE);
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error ?? new Error("Blad kasowania listow."));
      transaction.onabort = () => reject(transaction.error ?? new Error("Kasowanie listow przerwane."));
      try {
        for (const id of ids) store2.delete([character, id]);
      } catch (error) {
        transaction.abort();
        reject(error);
      }
    });
  }
  async delete(key) {
    await this.writeState("delete", key);
  }
  async clearLetters(character) {
    await this.clearMailData(character, []);
  }
  async clearMailData(character, keys) {
    const database = await this.openDatabase();
    await new Promise((resolve, reject) => {
      const transaction = database.transaction([LETTERS_STORE, STATE_STORE], "readwrite");
      const request = transaction.objectStore(LETTERS_STORE).index("character").openCursor(character);
      request.onsuccess = () => {
        const cursor = request.result;
        if (!cursor) return;
        cursor.delete();
        cursor.continue();
      };
      try {
        const state = transaction.objectStore(STATE_STORE);
        for (const key of keys) state.delete(key);
      } catch (error) {
        transaction.abort();
        reject(error);
      }
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error ?? new Error("Blad usuwania danych."));
      transaction.onabort = () => reject(transaction.error ?? new Error("Usuwanie danych przerwane."));
    });
  }
  async close() {
    const pending = this.databasePromise;
    if (pending) {
      try {
        await pending;
      } catch {
        return;
      }
    }
    this.database?.close();
    this.database = null;
    this.databasePromise = null;
  }
  openDatabase() {
    if (this.databasePromise) return this.databasePromise;
    const opening = new Promise((resolve, reject) => {
      if (!this.factory) {
        reject(new Error("Baza w przegladarce nie dziala - zapis bedzie tylko w pamieci."));
        return;
      }
      let request;
      try {
        request = this.factory.open(this.databaseName, DATABASE_VERSION);
      } catch (error) {
        reject(error);
        return;
      }
      let failed = false;
      request.onupgradeneeded = () => {
        const database = request.result;
        if (database.objectStoreNames.contains(LEGACY_STORE)) {
          database.deleteObjectStore(LEGACY_STORE);
        }
        if (!database.objectStoreNames.contains(STATE_STORE)) {
          database.createObjectStore(STATE_STORE);
        }
        if (!database.objectStoreNames.contains(LETTERS_STORE)) {
          const letters = database.createObjectStore(LETTERS_STORE, {
            keyPath: ["character", "id"]
          });
          letters.createIndex("character", "character", { unique: false });
        }
      };
      request.onerror = () => {
        failed = true;
        reject(request.error ?? new Error("Nie mozna otworzyc IndexedDB."));
      };
      request.onblocked = () => {
        failed = true;
        reject(new Error("Otwarcie IndexedDB jest zablokowane."));
      };
      request.onsuccess = () => {
        if (failed) {
          request.result.close();
          return;
        }
        this.database = request.result;
        resolve(request.result);
      };
    });
    this.databasePromise = opening;
    void opening.catch(() => {
      if (this.databasePromise === opening) this.databasePromise = null;
    });
    return opening;
  }
  async writeState(operation, key, value) {
    const database = await this.openDatabase();
    await new Promise((resolve, reject) => {
      const transaction = database.transaction(STATE_STORE, "readwrite");
      const store2 = transaction.objectStore(STATE_STORE);
      if (operation === "put") store2.put(value, key);
      else store2.delete(key);
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error ?? new Error("Blad zapisu IndexedDB."));
      transaction.onabort = () => reject(transaction.error ?? new Error("Zapis IndexedDB przerwany."));
    });
  }
};

// src/arkmail/adapters/writeThroughStorage.ts
var STORAGE_WRITE_ERROR = "Nie udalo sie zapisac danych archiwum";
var WriteThroughStorage = class _WriteThroughStorage {
  constructor(driver, initialValues, initialLetters, onError, durable) {
    __publicField(this, "driver", driver);
    __publicField(this, "onError", onError);
    __publicField(this, "durable", durable);
    __publicField(this, "values");
    __publicField(this, "letters", /* @__PURE__ */ new Map());
    __publicField(this, "pendingLetters", /* @__PURE__ */ new Map());
    __publicField(this, "queue", Promise.resolve());
    __publicField(this, "errorReported", false);
    this.values = new Map(Object.entries(initialValues));
    for (const [character, letters] of Object.entries(initialLetters)) {
      this.letters.set(character, new Map(Object.entries(letters)));
    }
  }
  static async open(driver, onError, durable = true) {
    const [values, letters] = await Promise.all([
      driver.loadAll(),
      driver.loadAllLetters ? driver.loadAllLetters() : Promise.resolve({})
    ]);
    return new _WriteThroughStorage(driver, values, letters, onError, durable);
  }
  get(key) {
    return this.values.get(key) ?? null;
  }
  getLetters(character) {
    return Object.fromEntries(this.letters.get(character) ?? []);
  }
  set(key, value) {
    this.values.set(key, value);
    this.enqueue(() => this.driver.put(key, value));
  }
  setMany(values) {
    const batch = { ...values };
    for (const [key, value] of Object.entries(batch)) this.values.set(key, value);
    this.enqueue(() => this.driver.putMany(batch));
  }
  setLetters(character, letters) {
    void this.writeLetters(character, letters, true).catch(() => {
    });
  }
  /** Potwierdza trwaly zapis zmienionych rekordow bez pelnego flush magazynu. */
  async setLettersConfirmed(character, letters) {
    if (!this.durable) {
      throw new Error("Nie mozna potwierdzic trwalego zapisu, poniewaz IndexedDB nie dziala.");
    }
    await this.writeLetters(character, letters, false);
  }
  writeLetters(character, letters, reportError) {
    const current = this.letters.get(character) ?? /* @__PURE__ */ new Map();
    this.letters.set(character, current);
    let changed = false;
    let retryPending = false;
    for (const letter of letters) {
      const value = JSON.stringify(letter);
      const key = JSON.stringify([character, letter.id]);
      if (current.get(letter.id) === value) {
        if (this.pendingLetters.has(key)) retryPending = true;
        continue;
      }
      current.set(letter.id, value);
      this.pendingLetters.set(key, { character, id: letter.id, value });
      changed = true;
    }
    const alive = new Set(letters.map((letter) => letter.id));
    const removed = [];
    for (const id of current.keys()) {
      if (alive.has(id)) continue;
      removed.push(id);
      this.pendingLetters.delete(JSON.stringify([character, id]));
    }
    for (const id of removed) current.delete(id);
    const operations = [];
    if (changed || retryPending) {
      operations.push(this.enqueue(() => this.flushPendingLetters(), reportError));
    }
    if (removed.length > 0) {
      const batch = removed;
      operations.push(this.enqueue(() => this.driver.deleteLetters(character, batch), reportError));
    }
    return Promise.all(operations).then(() => {
    });
  }
  delete(key) {
    this.values.delete(key);
    this.enqueue(() => this.driver.delete(key));
  }
  clearLetters(character) {
    this.letters.delete(character);
    for (const [key, letter] of this.pendingLetters) {
      if (letter.character === character) this.pendingLetters.delete(key);
    }
    this.enqueue(() => this.driver.clearLetters(character));
  }
  async clearMailData(character, keys) {
    const operation = this.queue.then(async () => {
      await this.driver.clearMailData(character, keys);
      this.letters.delete(character);
      for (const [key, letter] of this.pendingLetters) {
        if (letter.character === character) this.pendingLetters.delete(key);
      }
      for (const key of keys) this.values.delete(key);
    });
    this.queue = operation.catch(() => {
      if (this.errorReported) return;
      this.errorReported = true;
      this.onError();
    });
    await operation;
  }
  async flush() {
    await this.queue;
    if (this.pendingLetters.size === 0) return;
    this.enqueue(() => this.flushPendingLetters());
    await this.queue;
  }
  async close() {
    await this.flush();
    await this.driver.close();
  }
  async flushPendingLetters() {
    if (this.pendingLetters.size === 0) return;
    const pending = [...this.pendingLetters.entries()];
    const byCharacter = /* @__PURE__ */ new Map();
    for (const [, letter] of pending) {
      let values = byCharacter.get(letter.character);
      if (!values) {
        values = {};
        byCharacter.set(letter.character, values);
      }
      values[letter.id] = letter.value;
    }
    for (const [character, values] of byCharacter) {
      await this.driver.putLetters(character, values);
      for (const [key, letter] of pending) {
        if (letter.character === character && this.pendingLetters.get(key) === letter) {
          this.pendingLetters.delete(key);
        }
      }
    }
  }
  enqueue(operation, reportError = true) {
    const pending = this.queue.then(operation);
    this.queue = pending.catch(() => {
      if (!reportError || this.errorReported) return;
      this.errorReported = true;
      this.onError();
    });
    return pending;
  }
};
async function openWriteThroughStorage(onError, factory) {
  const persistent = new IndexedDbStorageDriver(factory);
  try {
    return await WriteThroughStorage.open(persistent, onError);
  } catch {
    await persistent.close();
    onError();
    return WriteThroughStorage.open(new MemoryStorageDriver(), onError, false);
  }
}

// src/arkmail/adapters/storage.ts
var CharStorage = class _CharStorage {
  constructor(char, storage) {
    __publicField(this, "char", char);
    __publicField(this, "storage", storage);
  }
  static async open(character, driver, onError) {
    const normalized = character.trim().toLowerCase();
    if (!normalized) throw new Error("Brak nazwy postaci dla magazynu.");
    return new _CharStorage(normalized, await WriteThroughStorage.open(driver, onError));
  }
  static fromWriteThrough(character, storage) {
    const normalized = character.trim().toLowerCase();
    if (!normalized) throw new Error("Brak nazwy postaci dla magazynu.");
    return new _CharStorage(normalized, storage);
  }
  get character() {
    return this.char;
  }
  getLetters() {
    const letters = [];
    for (const raw of Object.values(this.storage.getLetters(this.char))) {
      try {
        letters.push(JSON.parse(raw));
      } catch {
      }
    }
    return letters;
  }
  setLetters(letters) {
    this.storage.setLetters(this.char, letters);
  }
  async setLettersConfirmed(letters) {
    await this.storage.setLettersConfirmed(this.char, letters);
  }
  clearLetters() {
    this.storage.clearLetters(this.char);
  }
  async clearMailData(keys) {
    await this.storage.clearMailData(this.char, keys.map((key) => this.scoped(key)));
  }
  getJSON(key) {
    const raw = this.storage.get(this.scoped(key));
    if (raw === null) return null;
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }
  setJSON(key, value) {
    this.storage.set(this.scoped(key), JSON.stringify(value));
  }
  setJSONBatch(values) {
    const batch = {};
    for (const [key, value] of Object.entries(values)) {
      batch[this.scoped(key)] = JSON.stringify(value);
    }
    this.storage.setMany(batch);
  }
  remove(key) {
    this.storage.delete(this.scoped(key));
  }
  async flush() {
    await this.storage.flush();
  }
  async close() {
    await this.storage.close();
  }
  scoped(key) {
    return `arkmail.${this.char}.${key}`;
  }
};
async function openCharStorage(character, onError, factory) {
  const storage = await openWriteThroughStorage(onError, factory);
  return CharStorage.fromWriteThrough(character, storage);
}
function cleanupLegacyStorage() {
  try {
    const legacy = globalThis.localStorage;
    const keys = [];
    for (let i = 0; i < legacy.length; i++) {
      const key = legacy.key(i);
      if (key?.startsWith("arkmail.")) keys.push(key);
    }
    for (const key of keys) legacy.removeItem(key);
  } catch {
  }
}

// src/arkmail/ui/store.ts
function contentKeyOfEntry(e) {
  return [e.party, e.subject, e.forwarded ? "f" : "", e.date?.raw ?? ""].join("|");
}
function deletionState(revision) {
  return {
    box: "odebrane",
    filters: emptyDeletionFilters(),
    command: null,
    result: null,
    selected: [],
    message: null,
    revision,
    armedAt: 0
  };
}
var INDEX_BOXES = ["odebrane", "nieprzeczytane", "wyslane", "niewyslane"];
var allBoxesIndexed = (meta) => INDEX_BOXES.every((b) => meta[b] !== void 0);
var DEFAULT_STATE = {
  tab: "listy",
  wide: false,
  characterName: null,
  activeBox: "odebrane",
  boxes: {},
  badge: 0,
  badgeUnsent: 0,
  busy: null,
  loadAll: null,
  archiveDownload: null,
  search: null,
  letter: null,
  contacts: [],
  people: [],
  importedAliases: [],
  groups: [],
  archive: [],
  notifyEnabled: true,
  autoRefreshEnabled: true,
  animalFlying: false,
  unsentFlash: false,
  composeTemplate: "plain",
  composeWidth: 60,
  composeClearSeq: 0,
  indexMeta: {},
  archiveGaps: {},
  indexRun: null,
  deletion: deletionState(0)
};
var MailUiStore = class {
  constructor(initial) {
    __publicField(this, "current");
    __publicField(this, "listeners", /* @__PURE__ */ new Set());
    /** Schowek pelnych widokow skrzynek na czas trybu wynikow szukania. */
    __publicField(this, "stashedViews", {});
    /**
     * Zakladka, do ktorej wraca Zamknij list (Fala 17d, zgloszenie
     * pkt 2): list otwarty z Archiwum zamyka sie DO Archiwum, nie na
     * Listy. Zapisywana przy openLetter z zakladki innej niz 'list'
     * (openLetter nad otwartym listem nie nadpisuje pierwszego zrodla).
     */
    __publicField(this, "letterReturnTab", null);
    this.current = { ...DEFAULT_STATE, ...initial };
  }
  get state() {
    return this.current;
  }
  subscribe(cb) {
    this.listeners.add(cb);
    return () => {
      this.listeners.delete(cb);
    };
  }
  setTab(tab) {
    const patch = { tab };
    if (this.current.tab === "usuwanie" && tab !== "usuwanie") {
      patch.deletion = deletionState(this.current.deletion.revision + 1);
    }
    this.update(patch);
  }
  /**
   * Flip szerokosci w trakcie czytania nie gubi listu (Fala 10):
   * wide->waski przenosi otwarty list do pelnego panelu (zakladka
   * 'list'), waski->wide wraca do podzialu (zakladka 'listy').
   * Bez otwartego listu zakladka zostaje jak jest.
   */
  setWide(wide) {
    const patch = { wide };
    if (this.current.letter) {
      if (!wide && this.current.tab === "listy") patch.tab = "list";
      else if (wide && this.current.tab === "list") patch.tab = "listy";
    }
    this.update(patch);
  }
  setActiveBox(box) {
    this.update({ activeBox: box });
  }
  applyMailbox(box, result) {
    const view = result.kind === "lista" ? (
      // Fala 34: listing 1:1 - para blizniakow (identyczne
      // metadane, rozne numery) to DWA wiersze. Cala strona =
      // blok glowy (sync paruje z nim, nie ze starszymi stronami).
      {
        entries: result.entries,
        truncated: result.header.truncated,
        empty: null,
        headCount: result.entries.length
      }
    ) : { entries: [], truncated: false, empty: result.reason, headCount: 0 };
    const boxes = { ...this.current.boxes, [box]: view };
    const b = computeBadges(boxes);
    this.update({ boxes, badge: b.unread, badgeUnsent: b.unsent });
  }
  /**
   * Dokleja strone starszych listow (paginacja "Wybrane listy") PRZED
   * istniejace wpisy - widok trzyma kolejnosc serwera (najstarszy
   * pierwszy). Fala 34: w obrebie strony NIC nie deduplikujemy;
   * zdejmujemy jedynie wpisy juz widoczne (sonda sciany paginacji
   * odpytuje ponownie dzien graniczny - to te same fizyczne listy).
   * Tozsamosc wpisu = archiveId rekordu archiwum (Fala 41): blizniak
   * o identycznych metadanych ma WLASNE archiveId i zostaje wlasnym
   * wierszem, nawet gdy drugi blizniak juz jest widoczny. Klucz
   * tresci zostaje filtrem WYLACZNIE dla wpisow bez archiveId (zapisy
   * legacy sprzed stemplowania). truncated=false oznacza koniec
   * starszych (przycisk znika).
   */
  /** Dokleja strone starszych wpisow; zwraca liczbe NOWYCH wierszy. */
  appendMailboxPage(box, entries, truncated) {
    const view = this.current.boxes[box];
    if (!view) return 0;
    const knownIds = /* @__PURE__ */ new Set();
    const knownKeys = /* @__PURE__ */ new Set();
    for (const e of view.entries) {
      if (e.archiveId !== void 0) knownIds.add(e.archiveId);
      else knownKeys.add(contentKeyOfEntry(e));
    }
    const fresh = entries.filter(
      (e) => e.archiveId !== void 0 ? !knownIds.has(e.archiveId) : !knownKeys.has(contentKeyOfEntry(e))
    );
    const next = {
      entries: [...fresh, ...view.entries],
      truncated,
      empty: null,
      headCount: view.headCount
    };
    const boxes = { ...this.current.boxes, [box]: next };
    const b = computeBadges(boxes);
    this.update({ boxes, badge: b.unread, badgeUnsent: b.unsent });
    return fresh.length;
  }
  /**
   * Sync najnowszej strony z widokiem (Fala 12b; zastepuje "replace"
   * z Fali 11e jako domyslny tryb odswiezania). Wczytane starsze strony
   * ("Wczytaj starsze" / "Wczytaj wszystkie") NIE znikaja przy
   * odswiezeniu - gracz nie wraca do domyslnych 50 wpisow.
   *
   * - Fala 34: parowanie wielozbiorowe (multiset) W OBREBIE bloku
   *   glowy - wpisy swiezej strony parowane po kluczu tresci ze
   *   starymi wpisami bloku glowy i aktualizowane W MIEJSCU (np.
   *   znacznik *R*); drugi blizniak na swiezej stronie = DOKLADANY
   *   wiersz (blizniaki nigdy nie sa sklejane);
   * - nowe listy doklejane sa NA KONCU tablicy (koniec najnowszy; UI
   *   renderuje odwrotnie, wiec laduja na gorze ekranu);
   * - znacznik uciecia odpowiada najswiezszemu listingowi: komplet go
   *   zdejmuje, a pozniejszy limit ustawia go ponownie;
   * - usuwanie wpisow TYLKO gdy swiezy listing jest kompletny (bez
   *   uciecia): wtedy serwer raportuje pelna prawde (np. przeczytany
   *   list znika z 'nieprzeczytane'). Przy ucietych listingach brak
   *   wpisu moze byc wypchnieciem poza pierwsza strone - nic nie
   *   usuwamy.
   *
   * Fala 30b: przy UCIETYM listingu opcjonalna granica dnia
   * (pruneNewerThan, ISO YYYY-MM-DD = najstarszy dzien swiezej strony).
   * Strona jest ciagla od najnowszego, wiec wpis SCISELE NOWSZY niz
   * granica, nieobecny na stronie, na pewno nie ma go juz w skrzynce -
   * usuwamy. Dzien graniczny, starsze i wpisy bez daty zostaja
   * (strona moze byc ucieta w polowie dnia).
   *
   * Zwraca null, gdy brak widoku lub widok pusty - caller powinien
   * zrobic applyMailbox. Zwraca liczby {updated, added, removed}.
   */
  syncMailboxPage(box, entries, truncated, pruneNewerThan) {
    const view = this.current.boxes[box];
    if (!view || view.empty !== null) return null;
    const key = contentKeyOfEntry;
    const isoDay2 = (e) => {
      if (!e.date) return null;
      const p = (n) => String(n).padStart(2, "0");
      return `${e.date.year}-${p(e.date.month)}-${p(e.date.day)}`;
    };
    const all = view.entries;
    const headCount = Math.min(view.headCount, all.length);
    const older = all.slice(0, all.length - headCount);
    const head = all.slice(all.length - headCount);
    const headSlots = /* @__PURE__ */ new Map();
    head.forEach((e, i) => {
      const k = key(e);
      const list = headSlots.get(k);
      if (list) list.push(i);
      else headSlots.set(k, [i]);
    });
    const used = /* @__PURE__ */ new Set();
    const newHead = head.map(() => null);
    let updated = 0;
    let added = 0;
    for (const e of entries) {
      const free = headSlots.get(key(e))?.find((i) => !used.has(i));
      if (free === void 0) {
        newHead.push(e);
        added += 1;
      } else {
        used.add(free);
        newHead[free] = e;
        updated += 1;
      }
    }
    let removed = 0;
    let keptHead;
    if (!truncated) {
      removed += newHead.filter((e) => e === null).length;
      keptHead = newHead.filter((e) => e !== null);
    } else if (pruneNewerThan !== void 0) {
      keptHead = [];
      for (let i = 0; i < newHead.length; i++) {
        const slot = newHead[i];
        if (slot === null) {
          const day = isoDay2(head[i]);
          if (day !== null && day > pruneNewerThan) {
            removed += 1;
            continue;
          }
          keptHead.push(head[i]);
        } else {
          keptHead.push(slot);
        }
      }
    } else {
      keptHead = newHead.map((e, i) => e ?? head[i]);
    }
    let next = [...older, ...keptHead];
    if (!truncated) {
      const freshCounts = /* @__PURE__ */ new Map();
      for (const e of entries) {
        const k = key(e);
        freshCounts.set(k, (freshCounts.get(k) ?? 0) + 1);
      }
      const keptOlder = older.filter((e) => {
        const c = freshCounts.get(key(e)) ?? 0;
        if (c > 0) {
          freshCounts.set(key(e), c - 1);
          return true;
        }
        return false;
      });
      removed += older.length - keptOlder.length;
      next = [...keptOlder, ...keptHead];
    }
    const nextView = {
      entries: next,
      truncated,
      empty: null,
      headCount: keptHead.length
    };
    const boxes = { ...this.current.boxes, [box]: nextView };
    const b = computeBadges(boxes);
    this.update({ boxes, badge: b.unread, badgeUnsent: b.unsent });
    return { updated, added, removed };
  }
  /**
   * Usuwa z widoku skrzynki wpisy, ktorych rekord archiwum oznaczono
   * jako nieobecny na serwerze (Fala 30c). Gone-marking dotyka archiwum;
   * bez tego widoku martwy wpis zostawal klikalny ("Nie ma tego listu
   * na liscie"). Lokalne, zero komend; zwraca liczbe usunietych.
   */
  pruneMailboxEntries(box, goneIds) {
    const view = this.current.boxes[box];
    if (!view || view.empty !== null || goneIds.size === 0) return 0;
    const id = (e) => e.archiveId ?? letterId(box, e.party, e.subject, e.forwarded, e.date?.raw ?? null);
    const kept = view.entries.filter((e) => !goneIds.has(id(e)));
    const removed = view.entries.length - kept.length;
    if (removed === 0) return 0;
    const headCount = Math.min(view.headCount, view.entries.length);
    const removedFromHead = view.entries.slice(view.entries.length - headCount).filter((e) => goneIds.has(id(e))).length;
    const boxes = {
      ...this.current.boxes,
      [box]: { ...view, entries: kept, headCount: Math.max(0, headCount - removedFromHead) }
    };
    const b = computeBadges(boxes);
    this.update({ boxes, badge: b.unread, badgeUnsent: b.unsent });
    return removed;
  }
  setDeletionBox(box) {
    this.update({
      deletion: {
        ...this.current.deletion,
        box,
        command: null,
        result: null,
        selected: [],
        message: null,
        revision: this.current.deletion.revision + 1,
        armedAt: 0
      }
    });
  }
  // Commit filtrow z ekranu (przycisk 'Szukaj / Odswiez'). Celowo NIE kasuje
  // wyniku / zaznaczenia / polecenia: wpisanie litery w pole nie jest
  // 'szukaj', a repaint po kazdym znaku skasowalby liste pod palcem.
  // Stare wyniki nadal wisza az do skonczonego wyszukiwania
  // (applyDeletionResult / clearDeletionResult z osobna garda rewizji).
  // armedAt: 0 - nowy draft = nowa intencja, zamknieta potwierdzanie.
  setDeletionFilters(filters) {
    this.update({
      deletion: {
        ...this.current.deletion,
        filters: { ...filters },
        revision: this.current.deletion.revision + 1,
        armedAt: 0
      }
    });
  }
  applyDeletionResult(box, command, result) {
    const limited = result.kind === "lista" ? { ...result, entries: result.entries.slice(0, 50) } : result;
    this.update({
      deletion: {
        ...this.current.deletion,
        box,
        command,
        result: limited,
        selected: [],
        message: null,
        revision: this.current.deletion.revision + 1,
        armedAt: 0
      }
    });
  }
  /** Uzbrojenie potwierdzenia usuwania (zgloszenie 2026-10-30). Bez
   *  podbicia revision: to stan czysto UI, nie sygnal nieaktualnosci
   *  wynikow - guardy sesji usuwania maja zostac nietkniete. */
  armDeletionConfirm() {
    this.update({ deletion: { ...this.current.deletion, armedAt: Date.now() } });
  }
  disarmDeletionConfirm() {
    if (this.current.deletion.armedAt === 0) return;
    this.update({ deletion: { ...this.current.deletion, armedAt: 0 } });
  }
  toggleDeletionEntry(number) {
    const current = this.current.deletion;
    if (current.result?.kind !== "lista") return;
    if (!current.result.entries.some((entry) => entry.number === number)) return;
    const selected = current.selected.includes(number) ? current.selected.filter((value) => value !== number) : [...current.selected, number];
    this.update({ deletion: { ...current, selected } });
  }
  selectAllDeletionEntries() {
    const current = this.current.deletion;
    if (current.result?.kind !== "lista") return;
    this.update({
      deletion: {
        ...current,
        selected: current.result.entries.map((entry) => entry.number)
      }
    });
  }
  clearDeletionSelection() {
    const current = this.current.deletion;
    if (current.selected.length === 0) return;
    this.update({ deletion: { ...current, selected: [] } });
  }
  clearDeletionResult(message) {
    const current = this.current.deletion;
    this.update({
      deletion: {
        ...current,
        result: null,
        selected: [],
        message,
        revision: current.revision + 1,
        armedAt: 0
      }
    });
  }
  resetDeletion() {
    this.update({ deletion: deletionState(this.current.deletion.revision + 1) });
  }
  setBusy(label) {
    this.update({ busy: label });
  }
  setLoadAll(loadAll) {
    this.update({ loadAll });
  }
  setArchiveDownload(archiveDownload) {
    this.update({ archiveDownload });
  }
  setIndexMeta(indexMeta) {
    this.update({ indexMeta });
  }
  setIndexRun(indexRun) {
    this.update({ indexRun });
  }
  setArchiveGaps(archiveGaps) {
    this.update({ archiveGaps });
  }
  setSearch(search) {
    this.update({ search });
  }
  /**
   * Wpisy wynikow szukania ZASTEPUJA widok skrzynki; pelny widok
   * chowany jest do schowka (pierwszy raz na skrzynke - powtorne
   * szukanie nie nadpisuje schowka wynikami). Przywrocenie przez
   * clearSearch - bez strzalu do serwera.
   */
  applySearchResults(box, result) {
    if (!(box in this.stashedViews)) {
      const current = this.current.boxes[box];
      if (current) this.stashedViews[box] = current;
    }
    this.applyMailbox(box, result);
  }
  /** Przywraca schowany pelny widok skrzynki i konczy tryb szukania. */
  clearSearch(box) {
    const stashed = this.stashedViews[box];
    delete this.stashedViews[box];
    const patch = { search: null };
    if (stashed) {
      const boxes = { ...this.current.boxes, [box]: stashed };
      patch.boxes = boxes;
      const b = computeBadges(boxes);
      patch.badge = b.unread;
      patch.badgeUnsent = b.unsent;
    }
    this.update(patch);
  }
  /**
   * Kasuje tryb szukania BEZ przywracania schowka - dla swiezego
   * refresha skrzynki (nowy listing i tak nadpisze widok).
   */
  clearSearchBoxes(boxes) {
    for (const b of boxes) delete this.stashedViews[b];
    if (this.current.search && boxes.includes(this.current.search.box)) {
      this.update({ search: null });
    }
  }
  /**
   * Otwiera list i ZAWSZE go pokazuje (Fala 17d): waski -> zakladka
   * 'list', szeroki -> 'listy' (split: listing + list obok). Stary
   * kod w trybie szerokim zostawial zakladke bez zmian - klik w wpis
   * archiwum ladowal list niewidoczny dla gracza (zgloszenie pkt 2).
   */
  openLetter(box, letter, source, archiveId) {
    if (this.current.tab !== "list") this.letterReturnTab = this.current.tab;
    const opened = { ...letter, box, source };
    if (archiveId) opened.archiveId = archiveId;
    const next = { letter: opened };
    next.tab = this.current.wide ? "listy" : "list";
    this.update(next);
  }
  closeLetter() {
    const tab = this.letterReturnTab ?? "listy";
    this.letterReturnTab = null;
    this.update({ letter: null, tab });
  }
  /**
   * Czysci pamiec podreczna pluginu (Fala 12e): widoki skrzynek,
   * archiwum (RAM; storage kasuje caller), kontakty, schowek wynikow
   * szukania i tryb szukania. ZACHOWUJE ustawienia (powiadomienia,
   * automatyczne odswiezanie, szablon/szerokosc compose) i otwarty list.
   */
  clearCacheData() {
    for (const b of Object.keys(this.stashedViews)) {
      delete this.stashedViews[b];
    }
    this.update({
      boxes: {},
      archive: [],
      contacts: [],
      badge: 0,
      badgeUnsent: 0,
      indexMeta: {},
      archiveGaps: {},
      search: null,
      unsentFlash: false
    });
  }
  setContacts(contacts) {
    this.update({ contacts });
  }
  /** Ksiazka adresowa (Fala UI-2): podmiana puli osob importowanych. */
  setPeople(people) {
    this.update({ people });
  }
  /** Ksiazka adresowa (Fala UI-2): podmiana puli aliasow importowanych. */
  setImportedAliases(importedAliases) {
    this.update({ importedAliases });
  }
  /** Ksiazka adresowa (Fala UI-2): podmiana listy grup recznych. */
  setGroups(groups) {
    this.update({ groups });
  }
  /** Jedna aktualizacja Ksiazki i grup, bez posredniego repaintu. */
  setAddressBook(people, groups) {
    this.update({ people, groups });
  }
  setArchive(archive) {
    this.update({ archive });
  }
  setNotifyEnabled(notifyEnabled) {
    this.update({ notifyEnabled });
  }
  setAutoRefreshEnabled(autoRefreshEnabled) {
    this.update({ autoRefreshEnabled });
  }
  setAnimalFlying(animalFlying) {
    this.update({ animalFlying });
  }
  setUnsentFlash(unsentFlash) {
    this.update({ unsentFlash });
  }
  setCompose(prefs) {
    const patch = {};
    if (prefs.template !== void 0) patch.composeTemplate = prefs.template;
    if (prefs.width !== void 0) patch.composeWidth = prefs.width;
    this.update(patch);
  }
  /** Fala 16e: wyczyszczenie formularza compose po udanym zapisie/
   *  wyslaniu (render zeruje draft przy najblizszym renderze). */
  clearCompose() {
    this.update({ composeClearSeq: this.current.composeClearSeq + 1 });
  }
  /** Render-on-demand bez zmiany stanu (np. pod-pigulki Kontaktow). */
  refresh() {
    this.update({});
  }
  update(patch) {
    this.current = { ...this.current, ...patch };
    for (const cb of [...this.listeners]) cb(this.current);
  }
};
function computeBadges(boxes) {
  const unreadBox = boxes.nieprzeczytane;
  const unread = unreadBox ? unreadBox.entries.length : boxes.odebrane?.entries.filter((e) => !e.isRead).length ?? 0;
  const unsent = boxes.niewyslane?.entries.length ?? 0;
  return { unread, unsent };
}
function formatBadgeSuffix(unread, unsent) {
  if (unread <= 0 && unsent <= 0) return "";
  return unsent > 0 ? ` (${unread}/${unsent})` : ` (${unread})`;
}

// src/arkmail/core/letterRender.ts
var MIN_LINE_WIDTH = 20;
var MAX_LINE_WIDTH = 120;
var DEFAULT_LINE_WIDTH = 60;
function clampLineWidth(width) {
  const rounded = Math.round(width);
  return Math.min(MAX_LINE_WIDTH, Math.max(MIN_LINE_WIDTH, rounded));
}
function normalizeLine(line) {
  return line.replace(/\s+/g, " ").trim();
}
function splitLongWord(word, width) {
  const parts = [];
  for (let i = 0; i < word.length; i += width) {
    parts.push(word.slice(i, i + width));
  }
  return parts;
}
var DEFAULT_LETTER_ALIGNMENT = "justify";
function justifyWords(words, lettersLength, width) {
  if (words.length === 1) {
    return words[0];
  }
  const gaps = words.length - 1;
  const totalSpaces = width - lettersLength;
  const baseSpace = Math.max(1, Math.floor(totalSpaces / gaps));
  let extra = totalSpaces - baseSpace * gaps;
  let line = words[0];
  for (let i = 1; i < words.length; i += 1) {
    let spaces = baseSpace;
    if (extra > 0) {
      spaces += 1;
      extra -= 1;
    }
    line += " ".repeat(spaces) + words[i];
  }
  return line;
}
function alignWords(words, width, alignment, isLastLine) {
  if (alignment === "justify" && !isLastLine) {
    return justifyWords(words, words.reduce((sum, word) => sum + word.length, 0), width);
  }
  const text = words.join(" ");
  if (alignment === "right") {
    return text.padStart(width, " ");
  }
  if (alignment === "center") {
    return " ".repeat(Math.max(0, Math.floor((width - text.length) / 2))) + text;
  }
  return text;
}
function wrapWords(normalizedLine, width) {
  if (!normalizedLine) {
    return [];
  }
  const groups = [];
  let currentWords = [];
  let lettersLength = 0;
  const flush = () => {
    if (currentWords.length) {
      groups.push(currentWords);
    }
    currentWords = [];
    lettersLength = 0;
  };
  normalizedLine.split(" ").forEach((word) => {
    if (word.length > width) {
      flush();
      const parts = splitLongWord(word, width);
      const lastPart = parts.pop();
      parts.forEach((part) => groups.push([part]));
      if (lastPart) {
        currentWords = [lastPart];
        lettersLength = lastPart.length;
      }
      return;
    }
    const minimalSpaces = currentWords.length;
    if (lettersLength + word.length + minimalSpaces > width && currentWords.length) {
      flush();
    }
    currentWords.push(word);
    lettersLength += word.length;
  });
  flush();
  return groups;
}
function wrapLine(line, width, letterAlignment) {
  const alignRight = line.startsWith(">");
  const alignment = alignRight ? "right" : letterAlignment;
  const groups = wrapWords(normalizeLine(alignRight ? line.slice(1) : line), width);
  return groups.map((words, index) => alignWords(words, width, alignment, index === groups.length - 1));
}
function formatContent(content, width, alignment) {
  const rawLines = content.split(/\r?\n/);
  const result = [];
  let pendingBlankLine = false;
  let hasContent = false;
  rawLines.forEach((line) => {
    const wrapped = wrapLine(normalizeLine(line), width, alignment);
    if (!wrapped.length) {
      if (hasContent) {
        pendingBlankLine = true;
      }
      return;
    }
    if (pendingBlankLine && result.length) {
      result.push("");
      pendingBlankLine = false;
    }
    result.push(...wrapped);
    hasContent = true;
  });
  return result;
}
var FILL_PATTERN = /\{([^{}]+)\}/g;
function expandFillLine(line, width) {
  return line.replace(FILL_PATTERN, (_match, pattern) => pattern.repeat(Math.ceil(width / pattern.length)).slice(0, width));
}
function splitBodyPattern(pattern) {
  const lines = pattern.split(/\r?\n/);
  while (lines.length > 1 && lines[lines.length - 1] === "") {
    lines.pop();
  }
  return lines;
}
function longestLength(lines) {
  return lines.reduce((max, line) => Math.max(max, line.length), 0);
}
function getLayoutBodyWidth(layout, totalWidth) {
  if (layout.raw) {
    return Infinity;
  }
  const prefixWidth = longestLength(splitBodyPattern(layout.bodyPrefix));
  const suffixWidth = longestLength(splitBodyPattern(layout.bodySuffix));
  return Math.max(1, totalWidth - prefixWidth - suffixWidth);
}
function formatBody(layout, lines, width) {
  if (layout.raw) {
    return [...lines];
  }
  const prefixes = splitBodyPattern(layout.bodyPrefix);
  const suffixes = splitBodyPattern(layout.bodySuffix);
  const prefixWidth = longestLength(prefixes);
  const framed = prefixWidth > 0 || longestLength(suffixes) > 0;
  return lines.map((line, index) => {
    const trimmed = line.length > width ? line.slice(0, width) : line;
    if (!framed) {
      return trimmed.trimEnd();
    }
    const prefix = prefixes[index % prefixes.length].padEnd(prefixWidth, " ");
    const suffix = suffixes[index % suffixes.length];
    return `${prefix}${trimmed.padEnd(width, " ")}${suffix}`;
  });
}
var BUILTIN_LETTER_LAYOUTS = {
  none: {
    header: [],
    footer: [],
    bodyPrefix: "",
    bodySuffix: ""
  },
  plain: {
    header: [
      " +--{-}--+ ",
      " |  { }  | ",
      " |  { }  | "
    ],
    footer: [
      " |  { }  | ",
      " |  { }  | ",
      " +--{-}--+ "
    ],
    bodyPrefix: " |  ",
    bodySuffix: "  | "
  },
  parchment: {
    header: [
      "  ____{_}___  ",
      "/ \\   { }   \\.",
      "|  |  { }   |.",
      "\\_ |  { }   |.",
      "   |  { }   |."
    ],
    footer: [
      "   |  { }   |.   ",
      "   |   {_}__|___ ",
      "   |  /{ }     /.",
      "   \\_/_{_}____/. "
    ],
    bodyPrefix: "   |   ",
    bodySuffix: "  |."
  },
  parchment2: {
    header: [
      " ______{_}_____  ",
      " / _\\  { }     \\ ",
      "|/ >|  { }     | ",
      " |\\_/__{_}______/",
      " \\.    { }   ./  ",
      " |     { }   |   "
    ],
    footer: [
      " |  ___{_}___|   ",
      " |/\\   { }     \\ ",
      " \\_|   { }      |",
      "  \\_/_ {_}_____/ "
    ],
    bodyPrefix: " |     ",
    bodySuffix: "   |   "
  },
  parchment3: {
    header: [
      "             { }  .---.   ",
      "             { } /  .  \\ ",
      "             { }|\\_/|   |",
      "             { }|   |  /| ",
      "   .---------{-}-------'|",
      "  /  .-.     { }        | ",
      " |  /   \\   { }         |",
      " | |\\_.  |  { }         |",
      " |\\|  | /|  { }         |",
      " | `---' |  { }         |"
    ],
    footer: [
      " |       |   { }        /   ",
      " |       |---{-}--------' ",
      " \\       |  { }            ",
      " \\.___./    { }            "
    ],
    bodyPrefix: " |       |   ",
    bodySuffix: "        | "
  },
  raw: {
    header: [],
    footer: [],
    bodyPrefix: "",
    bodySuffix: "",
    raw: true
  }
};
function renderLetterLayout(content, layout, lineWidth = DEFAULT_LINE_WIDTH, alignment = DEFAULT_LETTER_ALIGNMENT) {
  const bodyWidth = getLayoutBodyWidth(layout, lineWidth);
  const baseLines = layout.raw ? content.split(/\r?\n/) : formatContent(content, bodyWidth, alignment);
  const bodySource = baseLines.length ? baseLines : [""];
  const lines = [
    ...layout.header.map((line) => expandFillLine(line, bodyWidth)),
    ...formatBody(layout, bodySource, bodyWidth),
    ...layout.footer.map((line) => expandFillLine(line, bodyWidth))
  ];
  const hasContent = baseLines.some((line) => line.trim().length > 0);
  return { lines, hasContent };
}
function renderLetter(content, template, lineWidth = DEFAULT_LINE_WIDTH, alignment = DEFAULT_LETTER_ALIGNMENT) {
  return renderLetterLayout(content, BUILTIN_LETTER_LAYOUTS[template], lineWidth, alignment);
}

// src/arkmail/ui/styles.ts
var BG = "var(--arkmail-bg)";
var BG_PANEL = "var(--arkmail-panel-bg)";
var BG_RAISED = "var(--arkmail-raised-bg)";
var BG_INPUT = "var(--arkmail-input-bg)";
var FG = "var(--arkmail-text)";
var FG_DIM = "var(--arkmail-secondary)";
var BORDER = "var(--arkmail-border)";
var CONTROL_BORDER = "var(--arkmail-control-border)";
var ACCENT = "var(--arkmail-accent)";
var ACCENT_FG = "var(--arkmail-on-accent)";
var DANGER_TEXT = "var(--arkmail-danger-text)";
var BG_UNREAD = "var(--arkmail-unread-bg)";
var UNREAD_MARKER = "var(--arkmail-unread-marker)";
var STYLES = `
/* Naglowek jest poza .arkmail-root; selektor ogranicza sie do jednej klasy. */
.arkmail-animal-send.popup-header-btn {
  color: var(--popup-accent);
  background: var(--popup-accent-subtle-bg);
}
.arkmail-root {
  --arkmail-bg: var(--popup-bg);
  --arkmail-panel-bg: var(--popup-section-bg);
  --arkmail-raised-bg: var(--popup-control-bg);
  --arkmail-input-bg: var(--popup-input-bg);
  --arkmail-text: var(--popup-text);
  --arkmail-secondary: color-mix(in oklab, var(--popup-text) 95%, transparent);
  --arkmail-placeholder: color-mix(in oklab, var(--popup-text) 95%, transparent);
  --arkmail-border: var(--popup-border);
  --arkmail-control-border: color-mix(in oklab, var(--popup-text) 60%, transparent);
  --arkmail-accent: var(--popup-accent);
  --arkmail-on-accent: black;
  --arkmail-danger-text: color-mix(in oklab, var(--popup-danger) 60%, var(--popup-text) 40%);
  --arkmail-danger-bg: var(--popup-danger-bg);
  --arkmail-unread-bg: var(--popup-accent-subtle-bg);
  --arkmail-unread-marker: color-mix(in oklab, var(--popup-accent) 60%, var(--popup-text) 40%);
  --arkmail-focus: var(--popup-text);
  display: flex;
  flex-direction: column;
  height: 100%;
  /* Fala 11c: panele scrolluja sie niezaleznie (overflow:auto na
     .arkmail-pane); root nie rosnie poza popup i nie scrolluje calosci. */
  overflow: hidden;
  box-sizing: border-box;
  padding: calc(10px * var(--window-font-scale, 1));
  gap: calc(8px * var(--window-font-scale, 1));
  background: ${BG};
  color: ${FG};
  line-height: 1.45;
}
.arkmail-version-footer {
  flex: 0 0 auto;
  min-width: 0;
  max-width: 100%;
  overflow-wrap: anywhere;
  color: ${FG_DIM};
  font-size: calc(11px * var(--window-font-scale, 1));
  line-height: 1.3;
  text-align: right;
}
.arkmail-root *, .arkmail-root *::before, .arkmail-root *::after {
  box-sizing: border-box;
}

/* Kazdy przycisk ma natywne klasy klienta. Lokalne reguly zmieniaja
 * wylacznie uklad albo udowodnione stany kontrastu. */
.arkmail-root :is(button, input, textarea, select, [tabindex]):focus-visible {
  outline: calc(2px * var(--window-font-scale, 1)) solid var(--arkmail-focus);
  outline-offset: calc(1px * var(--window-font-scale, 1));
}
.arkmail-root button.popup-btn--solid,
.arkmail-root button.popup-btn.popup-btn--solid:hover:not(:disabled),
.arkmail-root button.popup-btn--solid:active {
  background: ${ACCENT};
  border-color: ${ACCENT};
  color: ${ACCENT_FG};
  filter: none;
}
.arkmail-root button.popup-btn--control:not(.popup-btn--ghost),
.arkmail-root .popup-input--control {
  border-color: ${CONTROL_BORDER};
}
.arkmail-root .dialog-tabs {
  border-color: ${CONTROL_BORDER};
}
.arkmail-root .dialog-tab.is-active,
.arkmail-root .dialog-tab.is-active:hover {
  background: ${ACCENT};
  border-color: ${ACCENT};
  color: ${ACCENT_FG};
}

/* Zgloszenie 2026-11-05 (A3): poziomy przyciskow to klasy natywnego
 * UI klienta (popup-btn--control/solid/danger/ghost) - zero wlasnych
 * regul kolorow; wyglad i kontrast pilnuje motyw klienta.
 * K2: uzbrojony guard dwukliku (pierwszy klik) dostaje wypelnienie
 * danger i grubsza jasniejsza obwodke - stan "drugi klik kasuje" widac
 * z daleka, wyraznie odroznialny od ghosta w spoczynku. Selektor ma
 * wyzsza specyficznosc niz .popup-btn--danger.ghost klienta. */
.arkmail-root button.popup-btn--danger[data-armed="1"] {
  background: var(--arkmail-danger-bg);
  border-color: ${DANGER_TEXT};
  color: ${DANGER_TEXT};
  outline: calc(2px * var(--window-font-scale, 1)) solid ${DANGER_TEXT};
  outline-offset: calc(1px * var(--window-font-scale, 1));
}
/* Zgloszenie 2026-11-05 (F4c): pola tekstowe uzywaja natywnych klas
 * klienta (popup-input popup-input--control) - tlo, obwodka, fokus
 * i placeholder pilnuje motyw klienta. Zostaja tylko checkboxy. */
.arkmail-root input[type='checkbox'] { accent-color: ${ACCENT}; }
.arkmail-root input[type='radio'] { accent-color: ${ACCENT}; }
.arkmail-root .popup-input::placeholder {
  color: var(--arkmail-placeholder);
  opacity: 1;
}
.arkmail-root select.popup-input {
  appearance: none;
  background-image:
    linear-gradient(45deg, transparent 50%, ${FG_DIM} 50%),
    linear-gradient(135deg, ${FG_DIM} 50%, transparent 50%);
  background-position:
    right calc(16px * var(--window-font-scale, 1)) top 50%,
    right calc(11px * var(--window-font-scale, 1)) top 50%;
  background-size:
    calc(5px * var(--window-font-scale, 1)) calc(5px * var(--window-font-scale, 1)),
    calc(5px * var(--window-font-scale, 1)) calc(5px * var(--window-font-scale, 1));
  background-repeat: no-repeat;
  border-color: ${CONTROL_BORDER};
  padding-right: calc(28px * var(--window-font-scale, 1));
}

/* --- zakladki: segmentowana belka --- */
/* Zgloszenie 2026-11-05 (F4c): belka zakladek to klasy natywnego UI
 * klienta (dialog-tabs / dialog-tab + is-active) - segment, kolory
 * i hover pilnuje motyw klienta. */

/* --- pasek operacji --- */
.arkmail-root .arkmail-tabs.dialog-tabs {
  flex: 0 0 auto;
  align-self: stretch;
  width: 100%;
  flex-wrap: wrap;
  overflow-x: visible;
}
.arkmail-root .arkmail-tabs .arkmail-tab {
  flex: 1 1 calc(110px * var(--window-font-scale, 1));
  height: auto;
  min-height: calc(32px * var(--window-font-scale, 1));
  white-space: normal;
  overflow-wrap: anywhere;
}

.arkmail-busy {
  padding: calc(5px * var(--window-font-scale, 1)) calc(10px * var(--window-font-scale, 1));
  border: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
  border-left: calc(3px * var(--window-font-scale, 1)) solid ${ACCENT};
  border-radius: calc(6px * var(--window-font-scale, 1));
  background: ${BG_PANEL};
  color: ${FG_DIM};
  font-size: calc(12px * var(--window-font-scale, 1));
  white-space: normal;
  overflow-wrap: anywhere;
}
/* Fala UI-1: wspolny pasek na dole okna - status (lewo) + wersja
   (prawo). Zawsze zamontowany: wysokosc layoutu stala niezaleznie
   od tego, czy status jest pokazany. */
.arkmail-status {
  flex: 0 0 auto;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: flex-end;
  gap: calc(8px * var(--window-font-scale, 1));
}
.arkmail-status .arkmail-busy { flex: 1 1 auto; min-width: 0; }
.arkmail-busy-empty { visibility: hidden; }
/* Fala 18d (zgloszenie pkt 2): pasek postepu pod tekstem busy przy
   masowym pobieraniu tresci (jedyna petla ze znanym total). */
.arkmail-busy-track {
  margin-top: calc(4px * var(--window-font-scale, 1));
  height: calc(6px * var(--window-font-scale, 1));
  border-radius: calc(3px * var(--window-font-scale, 1));
  background: ${BG};
  overflow: hidden;
}
.arkmail-busy-bar {
  height: 100%;
  border-radius: calc(3px * var(--window-font-scale, 1));
  background: ${ACCENT};
  transition: width 200ms ease-out;
}

/* --- panele --- */
.arkmail-pane {
  flex: 1;
  overflow: auto;
  min-height: 0;
  background: ${BG_PANEL};
  border: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
  border-radius: calc(8px * var(--window-font-scale, 1));
  padding: calc(8px * var(--window-font-scale, 1));
}
/* W zwyklym ukladzie naglowek zostaje na miejscu, a liste przewija
   .arkmail-list-scroll. Gdy duza skala nie zostawia na liste zadnego
   miejsca, caly panel moze sie przewinac zamiast ukryc wiersze. */
.arkmail-listy {
  display: flex;
  flex-direction: column;
  overflow: auto;
}
/* Etap 8: semantyczne podpanele nie zmieniaja ukladu Archiwum;
   Kontakty zachowuja kolumnowy uklad listy w dodatkowym kontenerze. */
.arkmail-subpanel { display: contents; }
.arkmail-contact-subpanel {
  flex: 1;
  min-height: 0;
  display: flex;
  flex-direction: column;
}
.arkmail-contact-subpanel-scroll { overflow: auto; }
.arkmail-list-scroll {
  flex: 1 0 calc(96px * var(--window-font-scale, 1));
  min-height: calc(96px * var(--window-font-scale, 1));
  overflow: auto;
}
/* Wydanie 1.30.1 (zgloszenia 2/3): klient daje natywnym kontrolkom
   min-height: 0, wiec jako dzieci kolumny o ograniczonej wysokosci
   kurcza sie do zera (etykiety nakladaja sie). Naglowek ma twarde
   flex: none; caly skurcz idzie w .arkmail-list-scroll. */
.arkmail-listy > button,
.arkmail-listy > .arkmail-boxes,
.arkmail-listy > .arkmail-search-row,
.arkmail-listy > .arkmail-search-banner,
.arkmail-listy > .arkmail-book-filter,
.arkmail-listy > .arkmail-book-count,
.arkmail-listy > .arkmail-group-add,
.arkmail-listy > .arkmail-group-filter { flex: none; }
.arkmail-pane::-webkit-scrollbar,
.arkmail-list-scroll::-webkit-scrollbar { width: calc(8px * var(--window-font-scale, 1)); }
.arkmail-pane::-webkit-scrollbar-thumb,
.arkmail-list-scroll::-webkit-scrollbar-thumb { background: ${BORDER}; border-radius: calc(4px * var(--window-font-scale, 1)); }

/* --- skrzynki: pigulki --- */
.arkmail-boxes { display: flex; gap: calc(4px * var(--window-font-scale, 1)); margin-bottom: calc(8px * var(--window-font-scale, 1)); flex-wrap: wrap; }
.arkmail-root button.arkmail-box {
  border-radius: calc(999px * var(--window-font-scale, 1));
  padding: calc(3px * var(--window-font-scale, 1)) calc(12px * var(--window-font-scale, 1));
}
.arkmail-root button.arkmail-box-active {
  background: ${ACCENT};
  border-color: ${ACCENT};
  color: ${ACCENT_FG};
  font-weight: 600;
}
.arkmail-root button.arkmail-box-active:hover { background: ${ACCENT}; color: ${ACCENT_FG}; }
/* Fala 16f: trwaly akcent (obwodka) na skrzynce z licznikiem > 0 -
   Nieprzeczytane/Niewyslane widac z daleka (zgloszenie pkt 5/8). */
.arkmail-root button.arkmail-box-attention {
  border-color: ${ACCENT};
  color: ${FG};
}

/* Fala 11e: zbiorcze operacje na aktywnej skrzynce (zamiast obrotu per box). */
/* Wydanie 1.30.1 (zgloszenie 1): klawisze operacji naturalnej
   szerokosci (bez rozciagania), odstep jak miedzy pigulkami skrzynek. */
.arkmail-box-ops { display: flex; flex-wrap: wrap; gap: calc(8px * var(--window-font-scale, 1)); margin-bottom: calc(8px * var(--window-font-scale, 1)); }
.arkmail-destructive-zone {
  flex: none;
  margin-top: auto;
  margin-bottom: 0;
  padding-top: calc(8px * var(--window-font-scale, 1));
}
.arkmail-box-ops button { flex: 0 1 auto; }
/* Wszystkie klawisze maja popup-btn, wiec jeden stan disabled
 * obejmuje tez skrzynki i miniakcje. */
.arkmail-root .popup-btn:disabled { opacity: 0.45; cursor: default; }
/* Zgloszenie 2026-11-05 (Etap 9): wybor pliku importu otwiera klawisz
 * - sama kontrolka pliku jest niewidoczna. */
.arkmail-root input[data-book-import] { display: none; }
/* Zgloszenie 2026-11-05: poziome linie oddzielajace sekcje w tokenach
 * obramowania (wczesniej domyslny styl klienta/browsera). */
.arkmail-root hr { border: none; border-top: calc(1px * var(--window-font-scale, 1)) solid ${BORDER}; margin: calc(8px * var(--window-font-scale, 1)) 0; }

/* --- wiersze listow: nadawca | temat | data --- */
.arkmail-entry {
  display: flex;
  align-items: baseline;
  gap: calc(8px * var(--window-font-scale, 1));
  padding: calc(6px * var(--window-font-scale, 1)) calc(8px * var(--window-font-scale, 1));
  border-radius: calc(6px * var(--window-font-scale, 1));
  border-bottom: calc(1px * var(--window-font-scale, 1)) solid ${BG};
  cursor: pointer;
}
.arkmail-entry:hover { background: ${BG_RAISED}; }
.arkmail-entry-num { color: ${FG_DIM}; font-size: calc(11px * var(--window-font-scale, 1)); min-width: calc(26px * var(--window-font-scale, 1)); text-align: right; }
.arkmail-entry-party {
  min-width: calc(110px * var(--window-font-scale, 1));
  max-width: calc(180px * var(--window-font-scale, 1));
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: ${FG};
}
.arkmail-entry-subject {
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: ${FG_DIM};
}
.arkmail-entry-date { color: ${FG_DIM}; font-size: calc(11px * var(--window-font-scale, 1)); white-space: nowrap; }
.arkmail-root:not(.arkmail-wide) .arkmail-entry { flex-wrap: wrap; }
.arkmail-root:not(.arkmail-wide) .arkmail-entry-party {
  min-width: 0;
  max-width: 100%;
  white-space: normal;
  overflow-wrap: anywhere;
}
.arkmail-root:not(.arkmail-wide) .arkmail-entry-subject {
  min-width: 0;
  white-space: normal;
  overflow-wrap: anywhere;
}
.arkmail-root:not(.arkmail-wide) .arkmail-entry-date {
  max-width: 100%;
  white-space: normal;
  overflow-wrap: anywhere;
}
/* Fala 16f: nieprzeczytany wiersz dodatkowo JASNIEJSZY (pkt 8: kropka +
   pogrubienie + rozjasnienie; po odczyciu listing daje *R* i wiersz
   wraca do normalnego). */
.arkmail-unread { background: ${BG_UNREAD}; box-shadow: inset calc(3px * var(--window-font-scale, 1)) 0 0 ${UNREAD_MARKER}; }
.arkmail-unread .arkmail-entry-party, .arkmail-unread .arkmail-entry-subject {
  color: ${FG};
  font-weight: 700;
}
.arkmail-unread::before {
  content: '';
  align-self: center;
  width: calc(7px * var(--window-font-scale, 1));
  height: calc(7px * var(--window-font-scale, 1));
  border-radius: 50%;
  background: ${UNREAD_MARKER};
  flex: none;
}

.arkmail-root .arkmail-older { margin-top: calc(8px * var(--window-font-scale, 1)); width: 100%; }
/* Fala 11a: szukajka stosowo (2 kolumny), nie 5 w linii - w waskiej
   kolumnie splitu pola tekstowe zachowuja sensowna szerokosc. */
.arkmail-search-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: calc(6px * var(--window-font-scale, 1));
  margin: calc(8px * var(--window-font-scale, 1)) 0;
  align-items: center;
}
.arkmail-search-row .arkmail-search-go { grid-column: 1 / -1; }
/* Fala 30a: Tresc pelna szerokosc, dzieki temu pola dat laduja para
   Od|Do w jednym rzedzie (lewo-prawo, jak czyta sie zakres). */
.arkmail-search-row .arkmail-search-wide { grid-column: 1 / -1; }
/* Pole daty z widoczna etykieta (placeholder na date nie dziala). */
.arkmail-date-field { display: flex; flex-direction: column; gap: calc(2px * var(--window-font-scale, 1)); min-width: 0; }
.arkmail-date-field input { width: 100%; box-sizing: border-box; }
.arkmail-root input[type='date'] { color-scheme: inherit; }
.arkmail-date-label { color: ${FG_DIM}; font-size: calc(11px * var(--window-font-scale, 1)); }
.arkmail-dates-error { color: ${DANGER_TEXT}; font-size: calc(12px * var(--window-font-scale, 1)); margin-bottom: calc(6px * var(--window-font-scale, 1)); }
.arkmail-search-banner {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: calc(8px * var(--window-font-scale, 1));
  background: ${BG_RAISED};
  border: calc(1px * var(--window-font-scale, 1)) solid ${ACCENT};
  border-radius: calc(8px * var(--window-font-scale, 1));
  padding: calc(6px * var(--window-font-scale, 1)) calc(10px * var(--window-font-scale, 1));
  margin-bottom: calc(8px * var(--window-font-scale, 1));
  color: ${FG};
  font-size: calc(12px * var(--window-font-scale, 1));
  overflow-wrap: anywhere;
}
.arkmail-root button.arkmail-search-clear { flex: none; padding: calc(2px * var(--window-font-scale, 1)) calc(10px * var(--window-font-scale, 1)); }
.arkmail-root .arkmail-older-all { flex: 1; }
.arkmail-root button.arkmail-older-all { margin-top: calc(8px * var(--window-font-scale, 1)); width: 100%; }
/* Fala 17e: "Wczytaj wszystkie" w box-ops - regula paginacji wyzej
 * (margin-top: 8px; width: 100%) lapala go specyficznoscia 0,2,1 i
 * przycisk odjezdzal od sasiadow (zgloszenie pkt 1). */
.arkmail-box-ops button.arkmail-older-all { margin-top: 0; width: auto; flex: 0 1 auto; }

/* --- wspolny wiersz akcji --- */
.arkmail-action-row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: calc(6px * var(--window-font-scale, 1));
  max-width: 100%;
}
.arkmail-action-group {
  display: flex;
  flex: 0 1 auto;
  flex-wrap: wrap;
  align-items: center;
  gap: calc(6px * var(--window-font-scale, 1));
  min-width: 0;
  max-width: 100%;
}
.arkmail-action-row > button,
.arkmail-action-group > button { flex: 0 1 auto; width: auto; max-width: 100%; }

/* Pole i akcja: ghost jest bezposrednim elastycznym dzieckiem flexa. */
.arkmail-field-action {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: calc(6px * var(--window-font-scale, 1));
  max-width: 100%;
}
.arkmail-field-action > input,
.arkmail-field-action > .arkmail-ghost-wrap { flex: 1 1 calc(140px * var(--window-font-scale, 1)); min-width: 0; }
.arkmail-field-action > button { flex: 0 1 auto; width: auto; max-width: 100%; }
.arkmail-field-action > .arkmail-group-error { flex: 1 0 100%; }
.arkmail-book-alias {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: calc(6px * var(--window-font-scale, 1));
  max-width: 100%;
}
.arkmail-book-alias-text { flex: 1 1 auto; min-width: 0; overflow-wrap: anywhere; }
.arkmail-book-alias > button { flex: 0 0 auto; width: auto; max-width: 100%; }
.arkmail-root:not(.arkmail-wide) .arkmail-book-alias { flex-direction: column; align-items: stretch; }
.arkmail-root:not(.arkmail-wide) .arkmail-book-alias > button { align-self: flex-start; }
.arkmail-alias-import { margin-top: calc(12px * var(--window-font-scale, 1)); }

.arkmail-group {
  min-width: 0;
  max-width: 100%;
  margin-bottom: calc(10px * var(--window-font-scale, 1));
  padding: calc(8px * var(--window-font-scale, 1));
  background: ${BG_RAISED};
  border: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
  border-radius: calc(8px * var(--window-font-scale, 1));
}
.arkmail-group-header { display: flex; align-items: center; min-width: 0; max-width: 100%; }
.arkmail-group-header .arkmail-group-toggle {
  flex: 0 1 auto;
  min-width: 0;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
}
.arkmail-group-body {
  margin-top: calc(8px * var(--window-font-scale, 1));
  padding-top: calc(8px * var(--window-font-scale, 1));
  border-top: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
}
.arkmail-group-actions { margin-top: calc(8px * var(--window-font-scale, 1)); }
.arkmail-group-members {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: calc(6px * var(--window-font-scale, 1));
  margin-top: calc(8px * var(--window-font-scale, 1));
}
.arkmail-group-member { max-width: 100%; overflow-wrap: anywhere; }
.arkmail-group-member-add { margin-top: calc(8px * var(--window-font-scale, 1)); }

/* --- widok listu --- */
.arkmail-letter-head {
  position: relative;
  display: flex;
  align-items: flex-start;
  gap: calc(8px * var(--window-font-scale, 1));
  background: ${BG};
  border: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
  border-radius: calc(8px * var(--window-font-scale, 1));
  padding: calc(8px * var(--window-font-scale, 1)) calc(12px * var(--window-font-scale, 1));
  margin-bottom: calc(8px * var(--window-font-scale, 1));
}
.arkmail-letter-heading { flex: 1; min-width: 0; }
.arkmail-letter-subject { font-size: calc(15px * var(--window-font-scale, 1)); font-weight: 700; color: ${FG}; overflow-wrap: anywhere; }
.arkmail-letter-meta { color: ${FG_DIM}; font-size: calc(12px * var(--window-font-scale, 1)); margin-top: calc(2px * var(--window-font-scale, 1)); }
.arkmail-letter-body {
  white-space: pre-wrap;
  font-family: var(--output-font-family, 'IBM Plex Mono', ui-monospace, monospace);
  font-size: var(--output-font-size, calc(12px * var(--window-font-scale, 1)));
  background: ${BG};
  border: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
  border-radius: calc(8px * var(--window-font-scale, 1));
  padding: calc(10px * var(--window-font-scale, 1)) calc(12px * var(--window-font-scale, 1));
  color: ${FG};
  overflow-wrap: anywhere;
}
.arkmail-letter-ops { display: flex; flex-wrap: wrap; gap: calc(6px * var(--window-font-scale, 1)); margin-top: calc(8px * var(--window-font-scale, 1)); align-items: center; }
.arkmail-letter-ops input { flex: 1; }
.arkmail-reply-all-panel {
  display: grid;
  min-width: 0;
  max-width: 100%;
  margin-top: calc(8px * var(--window-font-scale, 1));
  padding: calc(10px * var(--window-font-scale, 1));
  gap: calc(10px * var(--window-font-scale, 1));
  background: ${BG_RAISED};
  color: ${FG};
  border: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
  border-radius: calc(8px * var(--window-font-scale, 1));
}
.arkmail-reply-all-scopes {
  display: grid;
  min-inline-size: 0;
  margin: 0;
  padding: 0;
  border: 0;
  gap: calc(6px * var(--window-font-scale, 1));
}
.arkmail-reply-all-scopes legend {
  margin-bottom: calc(4px * var(--window-font-scale, 1));
  padding: 0;
  color: ${FG_DIM};
  font-size: calc(12px * var(--window-font-scale, 1));
}
.arkmail-reply-all-choice {
  display: flex;
  align-items: center;
  min-width: 0;
  max-width: 100%;
  gap: calc(7px * var(--window-font-scale, 1));
  cursor: pointer;
}
.arkmail-reply-all-choice input { flex: 0 0 auto; margin: 0; }
.arkmail-reply-all-choice span { min-width: 0; overflow-wrap: anywhere; }
.arkmail-reply-all-quote-row {
  padding-top: calc(8px * var(--window-font-scale, 1));
  border-top: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
}
.arkmail-reply-all-actions { display: flex; flex-wrap: wrap; max-width: 100%; gap: calc(6px * var(--window-font-scale, 1)); }
.arkmail-reply-all-actions > button { flex: 0 0 auto; width: auto; max-width: 100%; white-space: normal; }
/* Zgloszenie 2026-11-05 (A3): kolory klawisza kasowania listu daje
 * klasa natywna popup-btn--danger. */
.arkmail-fwd { flex: none; }

/* --- formularz compose --- */
.arkmail-compose-settings { display: grid; grid-template-columns: minmax(0, 1fr); gap: calc(6px * var(--window-font-scale, 1)); }
.arkmail-compose-setting { min-width: 0; }
.arkmail-wide .arkmail-compose-settings { grid-template-columns: repeat(2, minmax(0, 1fr)); }
.arkmail-compose-actions { margin-top: calc(10px * var(--window-font-scale, 1)); }
.arkmail-form label { display: block; min-width: 0; overflow-wrap: anywhere; margin: calc(6px * var(--window-font-scale, 1)) 0 calc(3px * var(--window-font-scale, 1)); color: ${FG_DIM}; font-size: calc(12px * var(--window-font-scale, 1)); }
.arkmail-form input, .arkmail-form textarea, .arkmail-form select {
  width: 100%;
}
/* Wydanie 1.30.1 (B1): sila 0,2,1 - regula klienta textarea.popup-input.popup-input--control
   (0,2,1; height: auto; min-height: var(--ui-ctrl)) inaczej zaglusza pluginowi
   wysokosc pola compose; remis specyficznosci wygrywa kolejnoscia. */
.arkmail-root .arkmail-form textarea { min-height: calc(120px * var(--window-font-scale, 1)); resize: vertical; }
.arkmail-preview {
  margin: 0;
  padding: calc(8px * var(--window-font-scale, 1)) calc(10px * var(--window-font-scale, 1));
  background: ${BG_INPUT};
  color: ${FG_DIM};
  border: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
  border-radius: calc(6px * var(--window-font-scale, 1));
  font-family: var(--output-font-family, 'IBM Plex Mono', ui-monospace, monospace);
  font-size: var(--output-font-size, calc(12px * var(--window-font-scale, 1)));
  white-space: pre;
  overflow: auto;
  max-height: calc(220px * var(--window-font-scale, 1));
}
/* Fala 12d: podglad compose bez obcinania. W split (wide) pre rozciaga
   sie na pelna wysokosc prawego panelu; tryb "Pelne okno" to ten sam
   pre na calym popupie. Belka z przyciskiem nad podgladem. */
.arkmail-preview-bar {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: center;
  gap: calc(8px * var(--window-font-scale, 1));
  margin-bottom: calc(4px * var(--window-font-scale, 1));
}
.arkmail-preview-bar label { margin: 0; }
.arkmail-split-compose .arkmail-pane { display: flex; flex-direction: column; }
/* Wydanie 1.30.1: ta sama ochrona co w .arkmail-listy - pola klienta
   (min-height: 0) nie moga sie skurczyc do zera w kolumnie compose. */
.arkmail-split-compose .arkmail-pane > input,
.arkmail-split-compose .arkmail-pane > textarea,
.arkmail-split-compose .arkmail-pane > select,
.arkmail-split-compose .arkmail-pane > button { flex: none; }
.arkmail-split-compose .arkmail-preview { flex: 1; max-height: none; }
.arkmail-preview-full-pane { display: flex; flex-direction: column; }
.arkmail-preview-full-pane .arkmail-preview { flex: 1; max-height: none; }
.arkmail-root .arkmail-send {
  margin-top: 0;
  padding: calc(6px * var(--window-font-scale, 1)) calc(18px * var(--window-font-scale, 1));
  font-weight: 600;
}

/* --- usuwanie listow --- */
.arkmail-deletion {
  display: flex;
  flex-direction: column;
  overflow: auto;
}
.arkmail-deletion-intro, .arkmail-deletion-message, .arkmail-deletion-summary,
.arkmail-deletion-limit, .arkmail-deletion-selected { margin: 0 0 calc(8px * var(--window-font-scale, 1)); }
.arkmail-deletion-intro, .arkmail-deletion-limit { color: ${FG_DIM}; }
.arkmail-deletion-controls, .arkmail-deletion-selection-ops {
  display: flex;
  flex-wrap: wrap;
  gap: calc(6px * var(--window-font-scale, 1));
  margin-bottom: calc(8px * var(--window-font-scale, 1));
}
.arkmail-root .arkmail-deletion-box { flex: 1 1 calc(140px * var(--window-font-scale, 1)); min-width: 0; }
.arkmail-deletion-filters {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(calc(150px * var(--window-font-scale, 1)), 1fr));
  gap: calc(6px * var(--window-font-scale, 1));
  margin-bottom: calc(10px * var(--window-font-scale, 1));
}
.arkmail-deletion-filter { min-width: 0; color: ${FG_DIM}; font-size: calc(12px * var(--window-font-scale, 1)); }
.arkmail-deletion-filter span { display: block; margin-bottom: calc(2px * var(--window-font-scale, 1)); }
.arkmail-root .arkmail-deletion-filter input { width: 100%; min-width: 0; }
.arkmail-deletion-results {
  flex: 1 0 calc(96px * var(--window-font-scale, 1));
  min-height: calc(96px * var(--window-font-scale, 1));
  overflow: auto;
  border-top: calc(1px * var(--window-font-scale, 1)) solid ${BG};
}
.arkmail-deletion > :not(.arkmail-deletion-results) { flex: none; }
.arkmail-deletion-entry {
  display: flex;
  align-items: flex-start;
  gap: calc(8px * var(--window-font-scale, 1));
  padding: calc(7px * var(--window-font-scale, 1)) calc(4px * var(--window-font-scale, 1));
  border-bottom: calc(1px * var(--window-font-scale, 1)) solid ${BG};
  cursor: pointer;
}
.arkmail-deletion-entry input { flex: none; margin-top: calc(3px * var(--window-font-scale, 1)); }
.arkmail-deletion-entry span { min-width: 0; overflow-wrap: anywhere; }
/* Zgloszenie 2026-11-05 (A3): kolor daje klasa natywna
 * popup-btn--danger. */

/* --- kontakty i archiwum --- */
.arkmail-contact, .arkmail-arch-entry {
  display: flex;
  gap: calc(8px * var(--window-font-scale, 1));
  padding: calc(5px * var(--window-font-scale, 1)) calc(8px * var(--window-font-scale, 1));
  border-radius: calc(6px * var(--window-font-scale, 1));
  border-bottom: calc(1px * var(--window-font-scale, 1)) solid ${BG};
}
.arkmail-contact {
  flex-wrap: wrap;
  align-items: center;
  min-width: 0;
}
.arkmail-arch-entry {
  flex-wrap: wrap;
  align-items: center;
  min-width: 0;
}
/* Fala 12c: klikalne jest IMIE (kierunek domyslny) + przyciski kierunku. */
.arkmail-contact:hover, .arkmail-arch-entry:hover { background: ${BG_RAISED}; }
.arkmail-contact-name {
  flex: 1 0 100%;
  min-width: 0;
  max-width: 100%;
  overflow-wrap: anywhere;
  color: ${FG};
  font-weight: 600;
  cursor: pointer;
}
.arkmail-wide .arkmail-contact .arkmail-contact-name {
  flex: 1 1 auto;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.arkmail-contact-name:hover { text-decoration: underline; }
.arkmail-contact-dirs {
  display: flex;
  flex: 0 1 auto;
  flex-wrap: wrap;
  gap: calc(4px * var(--window-font-scale, 1));
  max-width: 100%;
  margin-left: auto;
}
.arkmail-contact-dirs > button,
.arkmail-contact > .arkmail-contact-addbook {
  flex: 0 1 auto;
  width: auto;
  max-width: 100%;
}
/* Rodzina mini: kompaktowy wariant poziomu action (jeden jezyk przyciskow). */
.arkmail-root button.arkmail-contact-dir, .arkmail-root button.arkmail-contact-addbook {
  border-radius: calc(6px * var(--window-font-scale, 1));
  padding: calc(1px * var(--window-font-scale, 1)) calc(8px * var(--window-font-scale, 1));
  font-size: calc(11px * var(--window-font-scale, 1));
}
/* Etap 9 (A1): panel osob uzywa calej dostepnej wysokosci.
 * Jedynym przewijanym obszarem jest sama lista. */
.arkmail-root .arkmail-arch-people-panel {
  display: flex;
  flex-direction: column;
  flex: 1;
  min-height: 0;
  overflow: hidden;
}
.arkmail-root .arkmail-arch-people-list {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
}
/* Waski popup: wiersz ksiazki trzyma checkbox, imie i oba przyciski
 * w jednej linii; imie sie skraca (wielokropek), nie wypycha przyciskow.
 * Head grupy zawija kontrolki zamiast je ucinac. */
.arkmail-root .arkmail-book-row {
  display: flex;
  align-items: center;
  gap: calc(6px * var(--window-font-scale, 1));
}
.arkmail-root .arkmail-book-name {
  flex: 1 1 auto;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.arkmail-root .arkmail-group-head {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: calc(6px * var(--window-font-scale, 1));
}
.arkmail-contact-stats, .arkmail-arch-meta { color: ${FG_DIM}; font-size: calc(12px * var(--window-font-scale, 1)); }
.arkmail-contact-stats {
  flex: 1 1 auto;
  min-width: 0;
  overflow-wrap: anywhere;
}
.arkmail-arch-subject {
  flex: 1 0 100%;
  min-width: 0;
  max-width: 100%;
  overflow-wrap: anywhere;
}
.arkmail-wide .arkmail-arch-entry .arkmail-arch-subject {
  flex: 1 1 auto;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.arkmail-arch-meta {
  flex: 0 1 auto;
  min-width: 0;
  max-width: 100%;
  overflow-wrap: anywhere;
}
.arkmail-arch-date {
  flex: 0 0 auto;
  max-width: 100%;
  color: ${FG_DIM};
  font-size: calc(11px * var(--window-font-scale, 1));
  white-space: nowrap;
}
.arkmail-root:not(.arkmail-wide) .arkmail-arch-date {
  white-space: normal;
  overflow-wrap: anywhere;
}
.arkmail-contact-controls {
  display: flex;
  flex-wrap: wrap;
  gap: calc(6px * var(--window-font-scale, 1));
  margin-bottom: calc(8px * var(--window-font-scale, 1));
}
.arkmail-root .arkmail-arch-people-panel .arkmail-contact-controls { flex: none; }
.arkmail-arch-list {
  flex: 1 0 calc(96px * var(--window-font-scale, 1));
  min-height: calc(96px * var(--window-font-scale, 1));
  overflow: auto;
}
.arkmail-archive-steps {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(min(calc(220px * var(--window-font-scale, 1)), 100%), 1fr));
  gap: calc(10px * var(--window-font-scale, 1));
  margin: calc(10px * var(--window-font-scale, 1)) 0 calc(12px * var(--window-font-scale, 1));
}
.arkmail-archive-step {
  position: relative;
  display: flex;
  flex-direction: column;
  min-width: 0;
  padding: calc(10px * var(--window-font-scale, 1));
  border: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
  border-left: calc(3px * var(--window-font-scale, 1)) solid ${FG_DIM};
  border-radius: calc(6px * var(--window-font-scale, 1));
  background: ${BG_RAISED};
}
.arkmail-archive-step-title { font-weight: 700; margin-bottom: calc(5px * var(--window-font-scale, 1)); }
.arkmail-archive-step-status {
  display: flex;
  flex-direction: column;
  gap: calc(3px * var(--window-font-scale, 1));
  min-height: calc(34px * var(--window-font-scale, 1));
  margin-bottom: calc(9px * var(--window-font-scale, 1));
  color: ${FG_DIM};
  font-size: calc(12px * var(--window-font-scale, 1));
  line-height: 1.4;
}
.arkmail-archive-step-status-row {
  display: flex;
  flex-wrap: wrap;
  column-gap: calc(4px * var(--window-font-scale, 1));
  min-width: 0;
}
.arkmail-archive-step-status-label { flex: none; font-weight: 600; }
.arkmail-archive-step-status-value { min-width: 0; overflow-wrap: anywhere; }
.arkmail-archive-step button { width: 100%; margin: 0; margin-top: auto; }
.arkmail-step-active { border-left-color: ${ACCENT}; }
.arkmail-step-done { border-left-color: var(--popup-success); }
.arkmail-step-warning, .arkmail-step-incomplete { border-left-color: ${CONTROL_BORDER}; }
.arkmail-arch-controls {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: calc(6px * var(--window-font-scale, 1));
  margin-bottom: calc(8px * var(--window-font-scale, 1));
}
.arkmail-wide .arkmail-arch-controls {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}
.arkmail-arch-controls > * { min-width: 0; }
.arkmail-arch-controls .arkmail-arch-clear {
  grid-column: 1 / -1;
  justify-self: start;
  width: auto;
  max-width: 100%;
}
.arkmail-listy > .arkmail-subpanel > .arkmail-archive-steps,
.arkmail-listy > .arkmail-subpanel > .arkmail-arch-controls,
.arkmail-listy > .arkmail-subpanel > .arkmail-arch-counts,
.arkmail-listy > .arkmail-subpanel > .arkmail-dates-error,
.arkmail-listy > .arkmail-subpanel > .arkmail-tresc-note { flex: none; }
.arkmail-contact-controls > .arkmail-ghost-wrap {
  flex: 1 1 calc(140px * var(--window-font-scale, 1));
  min-width: 0;
}
.arkmail-root .arkmail-contact-filter { min-width: 0; }
.arkmail-root .arkmail-contact-sort { max-width: 100%; }
.arkmail-contact-last {
  flex: 0 1 auto;
  min-width: 0;
  max-width: 100%;
  overflow-wrap: anywhere;
  color: ${FG_DIM};
  font-size: calc(11px * var(--window-font-scale, 1));
}

.arkmail-notify-toggle { margin-right: calc(4px * var(--window-font-scale, 1)); }
.arkmail-dim { color: ${FG_DIM}; }

/* --- ghost-podpowiedzi (Fala 9g): wyszarzona sugestia za kursorem --- */
.arkmail-root .arkmail-ghost-wrap { position: relative; display: block; min-width: 0; }
.arkmail-root .arkmail-ghost-wrap > input { width: 100%; box-sizing: border-box; }
/* Pole przekazania moze zmniejszyc szerokosc albo przejsc do nowego rzedu. */
.arkmail-root .arkmail-letter-ops .arkmail-ghost-wrap { flex: 1 1 calc(180px * var(--window-font-scale, 1)); min-width: 0; }
.arkmail-root .arkmail-ghost {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  /* Wydanie 1.30.1 (B2): ten sam font-size co pole klienta
     (var(--ui-input-fs)) i wyrownanie pionowe jak tekst w inputcie -
     podpowiedz stoi 1:1 za kursorem. Padding poziomy = padding
     inputu (8px) + jego border (1px). */
  font-size: var(--ui-input-fs, 14px);
  line-height: normal;
  padding: 0 calc(9px * var(--window-font-scale, 1));
  overflow: hidden;
  pointer-events: none;
  white-space: pre;
}
.arkmail-root .arkmail-ghost-typed { visibility: hidden; white-space: pre; }
.arkmail-root .arkmail-ghost-rest { color: ${FG_DIM}; white-space: pre; }

/* --- podzial lista|list na szerokim popupie (Fala 10) ---
   Uklad sterowany WYLACZNIE klasa .arkmail-wide z JS (ResizeObserver,
   prog 900px) - zero @container, jedno zrodlo prawdy, testowalne. */
.arkmail-wide .arkmail-split {
  display: grid;
  grid-template-columns: minmax(calc(280px * var(--window-font-scale, 1)), 2fr) minmax(0, 3fr);
  gap: calc(10px * var(--window-font-scale, 1));
  flex: 1;
  min-height: 0;
}
/* Fala 11d: compose - formularz szerszy, podglad wezszy. */
.arkmail-wide .arkmail-split-compose {
  grid-template-columns: minmax(0, 3fr) minmax(calc(280px * var(--window-font-scale, 1)), 2fr);
}
.arkmail-root .arkmail-letter-close {
  flex: 0 0 auto;
  padding: calc(2px * var(--window-font-scale, 1)) calc(10px * var(--window-font-scale, 1));
}

/* Fala 14b: pulsowanie Listy/Niewyslane po odlozeniu listu w kolejce.
   Kontrakt uiStyles: jawne hex (bez transparent/inherit). */
@keyframes arkmailFlash {
  0%, 100% { background: ${BG_RAISED}; color: ${FG}; }
  50% { background: ${ACCENT}; color: ${ACCENT_FG}; }
}
.arkmail-root .arkmail-flash {
  animation: arkmailFlash 0.6s ease-in-out 5;
}
`;

// src/arkmail/ui/ghost.ts
function attachGhost(doc, input, source, opts) {
  const wrap = doc.createElement("span");
  wrap.className = "arkmail-ghost-wrap";
  input.parentNode?.insertBefore(wrap, input);
  wrap.appendChild(input);
  const ghost = doc.createElement("span");
  ghost.className = "arkmail-ghost";
  ghost.style.display = "none";
  const typed = doc.createElement("span");
  typed.className = "arkmail-ghost-typed";
  const rest = doc.createElement("span");
  rest.className = "arkmail-ghost-rest";
  ghost.appendChild(typed);
  ghost.appendChild(rest);
  wrap.appendChild(ghost);
  let candidate = null;
  let candidateHead = "";
  let candidateSegment = "";
  let candidateValue = "";
  let escapeHidden = false;
  const syncScroll = () => {
    ghost.scrollLeft = input.scrollLeft;
  };
  const hide = () => {
    candidate = null;
    ghost.style.display = "none";
  };
  const segmentStarts = (value) => {
    if (value.length === 0) return [];
    if (!opts?.segment) return [0];
    const starts = [0];
    for (let idx = 0; idx < value.length; idx += 1) {
      if (value[idx] !== "," && value[idx] !== " ") continue;
      let start = idx + 1;
      while (value[start] === " ") start += 1;
      if (start < value.length && !starts.includes(start)) starts.push(start);
    }
    return starts.sort((a, b) => a - b);
  };
  const update = () => {
    escapeHidden = false;
    syncScroll();
    candidate = null;
    candidateHead = "";
    candidateSegment = "";
    candidateValue = "";
    const value = input.value;
    const atEnd = input.selectionStart === value.length && input.selectionEnd === value.length;
    const candidates = atEnd ? source().map((c) => typeof c === "string" ? { text: c } : c).map((c) => ({ ...c, text: c.text.trim() })).filter((c) => c.text.length > 0) : [];
    for (const start of segmentStarts(value)) {
      const segment = value.slice(start);
      const key = segment.toLowerCase();
      const match = candidates.find((c) => c.text.toLowerCase() === key) ?? candidates.find(
        (c) => c.text.length > segment.length && c.text.toLowerCase().startsWith(key)
      );
      if (!match) continue;
      candidate = match;
      candidateHead = value.slice(0, start);
      candidateSegment = segment;
      candidateValue = value;
      break;
    }
    if (!candidate) {
      ghost.style.display = "none";
      return;
    }
    typed.textContent = value;
    rest.textContent = candidate.text.slice(candidateSegment.length);
    ghost.style.display = "";
    syncScroll();
  };
  input.addEventListener("input", update);
  input.addEventListener("focus", update);
  input.addEventListener("scroll", syncScroll);
  input.addEventListener("blur", hide);
  input.addEventListener("keydown", (ev) => {
    if (ev.key === "ArrowRight" && candidate && !escapeHidden) {
      const value = input.value;
      if (input.selectionStart === value.length && input.selectionEnd === value.length && candidateValue === value) {
        ev.preventDefault();
        const insert = candidate.expand ?? candidate.text;
        input.value = candidateHead + insert;
        input.selectionStart = input.value.length;
        input.selectionEnd = input.value.length;
        const view = doc.defaultView;
        input.dispatchEvent(
          view ? new view.Event("input", { bubbles: true }) : new Event("input", { bubbles: true })
        );
        hide();
      }
    } else if (ev.key === "Escape" && candidate) {
      escapeHidden = true;
      ghost.style.display = "none";
    }
  });
}

// src/arkmail/ui/render.ts
var TEMPLATES = [
  ["none", "Bez ramki"],
  ["plain", "Prosta ramka"],
  ["parchment", "Pergamin"],
  ["parchment2", "Pergamin II"],
  ["parchment3", "Pergamin III"],
  ["raw", "Surowy (jak wpisane)"]
];
var TABS = [
  ["listy", "Listy"],
  ["napisz", "Napisz list"],
  ["kontakty", "Kontakty"],
  ["archiwum", "Archiwum"],
  ["usuwanie", "Usuwanie listow"]
];
var BOXES = [
  ["odebrane", "Odebrane"],
  ["nieprzeczytane", "Nieprzeczytane"],
  ["wyslane", "Wyslane"],
  ["niewyslane", "Niewyslane"]
];
var DELETION_ARM_MS = 5e3;
function mountMailUi(container, store2, handlers) {
  const doc = container.ownerDocument;
  const nativeFieldClass = (el) => {
    el.classList.add("popup-input", "popup-input--control");
  };
  const style = doc.createElement("style");
  style.textContent = STYLES;
  container.appendChild(style);
  const root = doc.createElement("div");
  container.appendChild(root);
  const archFilter = {};
  const contactView = {
    filter: "",
    sort: "nazwa",
    sub: "ksiazka"
  };
  const archView = { sub: "listy" };
  const ARCHIVE_CLEAR_TITLE = "Czysci filtry Archiwum i Osob z listow oraz przywraca sortowanie osob: Nazwa A-Z.";
  const archiveFiltersDirty = () => Object.values(archFilter).some((value) => value !== void 0 && value !== "") || contactView.filter !== "" || contactView.sort !== "nazwa";
  const clearArchiveFilters = () => {
    if (!archiveFiltersDirty()) return false;
    for (const key of ["osoba", "temat", "tresc", "odDaty", "doDaty", "skrzynka"]) {
      archFilter[key] = void 0;
    }
    contactView.filter = "";
    contactView.sort = "nazwa";
    return true;
  };
  const wireArchiveClearButton = (button) => {
    button.textContent = "Wyczysc filtry";
    button.setAttribute("title", ARCHIVE_CLEAR_TITLE);
    const sync = () => {
      if (archiveFiltersDirty()) button.removeAttribute("disabled");
      else button.setAttribute("disabled", "1");
    };
    button.addEventListener("click", () => {
      if (clearArchiveFilters()) store2.refresh();
    });
    sync();
    return sync;
  };
  let bookImportMode = "dolacz";
  let bookImportSelection = 0;
  let pendingBookReplace = null;
  const bookSelection = /* @__PURE__ */ new Set();
  let bookPeopleRef = null;
  let bookFilter = "";
  let groupFilter = "";
  const expandedGroups = /* @__PURE__ */ new Set();
  let previewFull = false;
  const searchDraft = { osoba: "", temat: "", tresc: "", odDaty: "", doDaty: "" };
  const deletionDraft = emptyDeletionFilters();
  const setButtonLabel = (button, label, title = label) => {
    button.textContent = label;
    button.setAttribute("title", title);
  };
  const SEARCH_GO_LABEL = "Szukaj / Odswiez";
  const SEARCH_GO_TITLE = "Szuka listow po wpisanych filtrach. Przy pustych filtrach odswieza wybrana skrzynke.";
  const GUARD_ARM_MS = 3e3;
  const ERROR_LABEL_MS = 3e3;
  const filterClearClass = (viewClass) => `${viewClass ? `${viewClass} ` : ""}arkmail-filter-clear popup-btn popup-btn--control popup-btn--ghost`;
  const armedButtons = /* @__PURE__ */ new Set();
  const disarmButton = (g) => {
    if (g.timer !== null) clearTimeout(g.timer);
    g.timer = null;
    g.el.removeAttribute("data-armed");
    g.el.textContent = g.baseText;
    g.el.setAttribute("title", g.baseTitle);
    if (g.baseAriaLabel === null) g.el.removeAttribute("aria-label");
    else g.el.setAttribute("aria-label", g.baseAriaLabel);
    armedButtons.delete(g);
  };
  const disarmAllButtons = () => {
    for (const g of [...armedButtons]) disarmButton(g);
  };
  const guardDeleteButton = (btn, onConfirm, opts = {}) => {
    if (!btn.getAttribute("aria-label")) {
      btn.setAttribute("aria-label", btn.getAttribute("title") ?? btn.textContent ?? "Usun");
    }
    const g = {
      el: btn,
      timer: null,
      baseText: btn.textContent ?? "",
      baseTitle: btn.getAttribute("title") ?? "",
      baseAriaLabel: btn.getAttribute("aria-label")
    };
    btn.addEventListener("click", () => {
      if (g.timer === null) {
        g.timer = setTimeout(() => disarmButton(g), GUARD_ARM_MS);
        btn.setAttribute("data-armed", "1");
        if (opts.armedLabel !== void 0) btn.textContent = opts.armedLabel;
        const armedTitle = opts.armedTitle ?? "Kliknij ponownie, aby usunac.";
        btn.setAttribute("title", armedTitle);
        btn.setAttribute("aria-label", opts.armedLabel ?? armedTitle);
        armedButtons.add(g);
        return;
      }
      disarmButton(g);
      onConfirm();
    });
  };
  const fillButtonTitles = (scope) => {
    scope.querySelectorAll("button").forEach((element) => {
      const button = element;
      if ((button.getAttribute("title") ?? "").trim()) return;
      const label = (button.textContent ?? "").trim();
      if (label) button.setAttribute("title", label);
    });
  };
  const makeClickable = (el, onActivate) => {
    el.setAttribute("role", "button");
    el.setAttribute("tabindex", "0");
    el.addEventListener("click", onActivate);
    el.addEventListener("keydown", (ev) => {
      if (ev.key === "Enter" || ev.key === " ") {
        ev.preventDefault();
        onActivate();
      }
    });
  };
  const submitOnEnter = (input, activate) => {
    input.addEventListener("keydown", (ev) => {
      if (ev.key !== "Enter" || ev.repeat || ev.isComposing) return;
      ev.preventDefault();
      activate();
    });
  };
  const wireTabKeyboard = (bar, buttons, activate) => {
    bar.addEventListener("keydown", (ev) => {
      const current = buttons.indexOf(ev.target);
      if (current < 0) return;
      let next;
      if (ev.key === "ArrowRight") next = (current + 1) % buttons.length;
      else if (ev.key === "ArrowLeft") next = (current - 1 + buttons.length) % buttons.length;
      else if (ev.key === "Home") next = 0;
      else if (ev.key === "End") next = buttons.length - 1;
      else return;
      ev.preventDefault();
      activate(next);
    });
  };
  const focusKeyOf = (el) => {
    if (!el || typeof el.getAttribute !== "function") return null;
    if (!root.contains(el)) return null;
    for (const attr of [
      "data-search",
      "data-field",
      "data-filter",
      "data-deletion-filter",
      "data-deletion-number",
      "data-book-check",
      "data-book-filter",
      "data-book-new",
      "data-group-filter",
      "data-group-add",
      "data-group-rename",
      "data-member-add"
    ]) {
      const value = el.getAttribute(attr);
      if (value !== null) return { attribute: attr, value };
    }
    return null;
  };
  const snapshotView = () => {
    const snap = { focusKey: null, focusValue: null, caret: null, scroll: {} };
    const active = doc.activeElement;
    const key = focusKeyOf(active);
    if (key) {
      snap.focusKey = key;
      const inp = active;
      snap.focusValue = inp.getAttribute("type") === "checkbox" ? inp.checked ? "1" : "0" : active.value ?? null;
      try {
        if (typeof inp.selectionStart === "number") {
          snap.caret = [inp.selectionStart, inp.selectionEnd ?? inp.selectionStart];
        }
      } catch {
      }
    }
    for (const pane of Array.from(root.querySelectorAll("[data-pane-key]"))) {
      const k = pane.getAttribute("data-pane-key");
      if (k !== null) snap.scroll[k] = pane.scrollTop;
    }
    return snap;
  };
  const restoreView = (snap) => {
    for (const pane of Array.from(root.querySelectorAll("[data-pane-key]"))) {
      const k = pane.getAttribute("data-pane-key");
      if (k !== null && snap.scroll[k] !== void 0) {
        pane.scrollTop = snap.scroll[k];
      }
    }
    if (snap.focusKey) {
      const el = Array.from(root.querySelectorAll(`[${snap.focusKey.attribute}]`)).find(
        (candidate) => candidate.getAttribute(snap.focusKey.attribute) === snap.focusKey.value
      );
      if (el) {
        if (el.getAttribute("type") === "checkbox") {
          el.checked = snap.focusValue === "1";
        } else if (snap.focusValue !== null) {
          el.value = snap.focusValue;
        }
        el.focus();
        if (snap.caret) {
          try {
            el.setSelectionRange(snap.caret[0], snap.caret[1]);
          } catch {
          }
        }
      }
    }
  };
  const personSource = () => {
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    const push = (v) => {
      if (!v) return;
      const k = v.toLowerCase();
      if (seen.has(k)) return;
      seen.add(k);
      out.push(v);
    };
    const contacts = [...store2.state.contacts].sort(
      (a, b) => (b.lastContactKey ?? -1) - (a.lastContactKey ?? -1)
    );
    for (const c of contacts) {
      push(c.name);
      push(c.mailAlias);
    }
    for (const name of store2.state.people) push(name);
    for (const alias of store2.state.importedAliases) push(alias.name);
    return out;
  };
  const adresatSource = () => [
    ...personSource(),
    ...store2.state.groups.filter((g) => g.members.length > 0 && !groupAliasConflict(g.name, store2.state.importedAliases)).map((g) => ({ text: g.name, expand: g.members.join(", ") }))
  ];
  const groupNameSource = () => store2.state.groups.map((g) => g.name);
  const subjectSource = () => {
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const l of store2.state.archive) {
      if (!l.subject) continue;
      const k = l.subject.toLowerCase();
      if (seen.has(k)) continue;
      seen.add(k);
      out.push(l.subject);
    }
    return out;
  };
  const renderStatusFooter = (state) => {
    const footer = doc.createElement("footer");
    footer.className = "arkmail-status";
    const busyEl = doc.createElement("div");
    busyEl.className = "arkmail-busy" + (state.busy !== null ? "" : " arkmail-busy-empty");
    busyEl.setAttribute("role", "status");
    busyEl.setAttribute("aria-live", "polite");
    busyEl.setAttribute("aria-atomic", "true");
    const label = doc.createElement("span");
    const dl = state.archiveDownload;
    label.textContent = `${state.busy ?? ""}` + (dl !== null && dl.etaMs !== null ? ` (${formatEta(dl.etaMs)})` : "");
    busyEl.appendChild(label);
    if (dl !== null && dl.total > 0) {
      const pct = Math.min(100, Math.round(dl.done / dl.total * 100));
      const track = doc.createElement("div");
      track.className = "arkmail-busy-track";
      track.setAttribute("role", "progressbar");
      track.setAttribute("aria-valuemin", "0");
      track.setAttribute("aria-valuemax", "100");
      track.setAttribute("aria-valuenow", String(pct));
      track.setAttribute("aria-valuetext", `${dl.done} z ${dl.total}`);
      const bar = doc.createElement("div");
      bar.className = "arkmail-busy-bar";
      bar.style.width = `${pct}%`;
      track.appendChild(bar);
      busyEl.appendChild(track);
    }
    footer.appendChild(busyEl);
    const version = doc.createElement("span");
    version.className = "arkmail-version-footer";
    version.textContent = `v${PLUGIN_VERSION} | ${PLUGIN_BUILD_DATE}`;
    footer.appendChild(version);
    return footer;
  };
  const render = (state) => {
    const snap = snapshotView();
    root.className = "arkmail-root" + (state.wide ? " arkmail-wide" : "");
    composePreview = null;
    if (state.tab !== "napisz") previewFull = false;
    const selectedTab = state.tab === "list" ? null : state.tab;
    const nodes = [renderTabs(state)];
    let panel;
    if (state.tab === "napisz" && previewFull) {
      panel = renderPreviewFull();
    } else if (state.wide && state.tab === "listy") {
      const split = doc.createElement("div");
      split.className = "arkmail-split";
      split.appendChild(renderListy(state));
      split.appendChild(renderList(state));
      panel = split;
    } else if (state.wide && state.tab === "napisz") {
      const split = doc.createElement("div");
      split.className = "arkmail-split arkmail-split-compose";
      split.appendChild(renderNapisz(state));
      split.appendChild(renderComposePreview());
      panel = split;
    } else {
      panel = renderPane(state);
    }
    panel.id = `arkmail-panel-${state.tab}`;
    panel.setAttribute("role", "tabpanel");
    if (selectedTab === null) panel.setAttribute("aria-label", "List");
    else panel.setAttribute("aria-labelledby", `arkmail-tab-${selectedTab}`);
    nodes.push(panel);
    nodes.push(renderStatusFooter(state));
    root.replaceChildren(...nodes);
    fillButtonTitles(root);
    restoreView(snap);
  };
  const renderTabs = (state) => {
    const selectedTab = state.tab === "list" ? null : state.tab;
    const bar = doc.createElement("div");
    bar.className = "arkmail-tabs dialog-tabs";
    bar.setAttribute("role", "tablist");
    bar.setAttribute("aria-label", "ArkMail");
    const buttons = [];
    for (const [id, label] of TABS) {
      const btn = doc.createElement("button");
      btn.className = "arkmail-tab dialog-tab" + (selectedTab === id ? " is-active" : "") + // Fala 14b: flash po odlozeniu listu w niewyslanych (compose
      // poza poczta zawsze kolejkuje) - gracz widzi, gdzie kliknac.
      (state.unsentFlash && id === "listy" ? " arkmail-flash" : "");
      btn.setAttribute("data-tab", id);
      btn.id = `arkmail-tab-${id}`;
      btn.setAttribute("role", "tab");
      btn.setAttribute("aria-selected", selectedTab === id ? "true" : "false");
      btn.setAttribute("aria-controls", `arkmail-panel-${id}`);
      btn.tabIndex = selectedTab === id || selectedTab === null && id === "listy" ? 0 : -1;
      btn.textContent = id === "listy" ? label + formatBadgeSuffix(state.badge, state.badgeUnsent) : label;
      btn.addEventListener("click", () => store2.setTab(id));
      bar.appendChild(btn);
      buttons.push(btn);
    }
    wireTabKeyboard(bar, buttons, (index) => {
      const id = TABS[index][0];
      store2.setTab(id);
      root.querySelector(`[data-tab="${id}"]`)?.focus();
    });
    return bar;
  };
  const formatEta = (ms) => ms < 45e3 ? `zostalo ok. ${Math.max(1, Math.round(ms / 1e3))} s` : `zostalo ok. ${Math.max(1, Math.round(ms / 6e4))} min`;
  const renderPane = (state) => {
    switch (state.tab) {
      case "listy":
        return renderListy(state);
      case "list":
        return renderList(state);
      case "napisz":
        return renderNapisz(state);
      case "kontakty":
        return renderKontakty(state);
      case "archiwum":
        return renderArchiwum(state);
      case "usuwanie":
        return renderUsuwanie(state);
    }
  };
  const renderUsuwanie = (state) => {
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane arkmail-deletion";
    pane.setAttribute("data-pane-key", "usuwanie");
    const intro = doc.createElement("p");
    intro.className = "arkmail-deletion-intro";
    intro.textContent = "Wybierz skrzynke i kliknij Szukaj / Odswiez. Zaznacz listy, ktore chcesz usunac, i potwierdz operacje. Wyniki nie odswiezaja sie automatycznie. Wyjscie z zakladki czysci wyniki i zaznaczenie.";
    pane.appendChild(intro);
    const controls = doc.createElement("div");
    controls.className = "arkmail-deletion-controls";
    const box = doc.createElement("select");
    nativeFieldClass(box);
    box.classList.add("arkmail-deletion-box");
    box.setAttribute("title", "Wybierz skrzynke");
    for (const [id, label] of BOXES) {
      const option = doc.createElement("option");
      option.value = id;
      option.textContent = label;
      option.selected = state.deletion.box === id;
      box.appendChild(option);
    }
    box.value = state.deletion.box;
    controls.appendChild(box);
    const search = doc.createElement("button");
    search.className = "arkmail-deletion-search popup-btn popup-btn--control popup-btn--solid";
    setButtonLabel(search, SEARCH_GO_LABEL, SEARCH_GO_TITLE);
    let searchErrorTimer = null;
    const showSearchError = (message) => {
      if (searchErrorTimer) clearTimeout(searchErrorTimer);
      setButtonLabel(search, message);
      searchErrorTimer = setTimeout(
        () => setButtonLabel(search, SEARCH_GO_LABEL, SEARCH_GO_TITLE),
        ERROR_LABEL_MS
      );
    };
    const fireSearch = () => {
      const current = store2.state.deletion;
      const osoba = deletionDraft.osoba.trim();
      const temat = deletionDraft.temat.trim();
      const tresc = deletionDraft.tresc.trim();
      const validationError = validateSearchDraft({
        osoba,
        temat,
        tresc,
        odDaty: deletionDraft.odDaty,
        doDaty: deletionDraft.doDaty
      });
      if (validationError) {
        showSearchError(validationError);
        return;
      }
      if (searchErrorTimer) clearTimeout(searchErrorTimer);
      setButtonLabel(search, SEARCH_GO_LABEL, SEARCH_GO_TITLE);
      store2.setDeletionFilters({ ...deletionDraft });
      const query = {};
      if (osoba) query.osoba = osoba;
      if (temat) query.temat = temat;
      if (tresc) query.tresc = tresc;
      const odDaty = fromISODate(deletionDraft.odDaty);
      const doDaty = fromISODate(deletionDraft.doDaty);
      if (odDaty) query.odDaty = odDaty;
      if (doDaty) query.doDaty = doDaty;
      handlers.onDeletionSearch?.(current.box, query);
    };
    search.addEventListener("click", fireSearch);
    box.addEventListener("change", () => {
      store2.setDeletionBox(box.value);
      fireSearch();
    });
    controls.appendChild(search);
    const clearFilters = doc.createElement("button");
    clearFilters.className = filterClearClass("arkmail-deletion-clear-filters");
    clearFilters.textContent = "Wyczysc filtry";
    clearFilters.addEventListener("click", () => {
      for (const key of ["osoba", "temat", "tresc", "odDaty", "doDaty"]) {
        deletionDraft[key] = "";
      }
      filterRow.querySelectorAll("[data-deletion-filter]").forEach((el) => {
        el.value = "";
      });
      store2.setDeletionFilters(emptyDeletionFilters());
      handlers.onDeletionSearch?.(store2.state.deletion.box, {});
    });
    controls.appendChild(clearFilters);
    pane.appendChild(controls);
    const filterRow = doc.createElement("div");
    filterRow.className = "arkmail-deletion-filters";
    const fields = [
      ["osoba", "Osoba (kogo? czego?)", "Wpisz imie w dopelniaczu"],
      ["temat", "Temat", "Fragment tematu"],
      ["tresc", "Tresc", "Fragment tresci"],
      ["odDaty", "Od daty", ""],
      ["doDaty", "Do daty", ""]
    ];
    for (const [key, label, placeholder] of fields) {
      const wrap = doc.createElement("label");
      wrap.className = "arkmail-deletion-filter";
      const caption = doc.createElement("span");
      caption.textContent = label;
      wrap.appendChild(caption);
      const field = doc.createElement("input");
      nativeFieldClass(field);
      field.type = key === "odDaty" || key === "doDaty" ? "date" : "text";
      field.value = deletionDraft[key];
      field.setAttribute("data-deletion-filter", key);
      if (placeholder) field.setAttribute("placeholder", placeholder);
      field.addEventListener("input", () => {
        deletionDraft[key] = field.value;
      });
      submitOnEnter(field, () => search.click());
      wrap.appendChild(field);
      filterRow.appendChild(wrap);
    }
    pane.appendChild(filterRow);
    if (state.deletion.message !== null) {
      const message = doc.createElement("p");
      message.className = "arkmail-deletion-message";
      message.textContent = state.deletion.message;
      pane.appendChild(message);
    }
    const result = state.deletion.result;
    const entries = result?.kind === "lista" ? result.entries : [];
    if (result !== null) {
      const summary = doc.createElement("p");
      summary.className = "arkmail-deletion-summary";
      summary.textContent = result.kind === "lista" ? `Wyniki: ${formatListCount(entries.length)}.` : "Brak listow dla podanych filtrow.";
      pane.appendChild(summary);
      if (result.kind === "lista" && result.header.truncated) {
        const limit = doc.createElement("p");
        limit.className = "arkmail-dim arkmail-deletion-limit";
        limit.textContent = "Serwer pokazuje maksymalnie 50 wynikow.";
        pane.appendChild(limit);
      }
    }
    const selectionOps = doc.createElement("div");
    selectionOps.className = "arkmail-deletion-selection-ops";
    const selectAll = doc.createElement("button");
    selectAll.className = "arkmail-deletion-select-all popup-btn popup-btn--control";
    selectAll.textContent = "Zaznacz wszystkie";
    if (entries.length === 0) selectAll.setAttribute("disabled", "");
    selectAll.addEventListener("click", () => store2.selectAllDeletionEntries());
    selectionOps.appendChild(selectAll);
    const clearSelection = doc.createElement("button");
    clearSelection.className = "arkmail-deletion-clear-selection popup-btn popup-btn--control";
    clearSelection.textContent = "Odznacz wszystkie";
    if (state.deletion.selected.length === 0) clearSelection.setAttribute("disabled", "");
    clearSelection.addEventListener("click", () => store2.clearDeletionSelection());
    selectionOps.appendChild(clearSelection);
    const remove = doc.createElement("button");
    remove.className = "arkmail-deletion-delete popup-btn popup-btn--control popup-btn--danger popup-btn--ghost";
    const selectedCount = state.deletion.selected.length;
    const armedAt = state.deletion.armedAt;
    const armed = armedAt !== 0 && Date.now() - armedAt < DELETION_ARM_MS;
    if (armed) {
      setButtonLabel(
        remove,
        `Potwierdz usuniecie: ${formatListCount(selectedCount)}`,
        `Usunac zaznaczone listy (liczba: ${selectedCount})? Tej operacji nie mozna cofnac. Kliknij ponownie, aby potwierdzic. ESC anuluje.`
      );
    } else {
      setButtonLabel(remove, "Usun zaznaczone", "Usun zaznaczone listy. Tej operacji nie mozna cofnac.");
    }
    if (selectedCount === 0) remove.setAttribute("disabled", "");
    remove.addEventListener("click", () => {
      if (!armed) {
        store2.armDeletionConfirm();
        const armedStamp = store2.state.deletion.armedAt;
        setTimeout(() => {
          if (store2.state.deletion.armedAt === armedStamp) store2.disarmDeletionConfirm();
        }, DELETION_ARM_MS);
        return;
      }
      store2.disarmDeletionConfirm();
      handlers.onDeletionDelete?.();
    });
    selectionOps.appendChild(remove);
    pane.appendChild(selectionOps);
    if (selectedCount > 0) {
      const selected = doc.createElement("p");
      selected.className = "arkmail-deletion-selected";
      selected.textContent = `Zaznaczono: ${formatListCount(selectedCount)}.`;
      pane.appendChild(selected);
    }
    if (entries.length > 0) {
      const list = doc.createElement("div");
      list.className = "arkmail-deletion-results";
      list.setAttribute("data-pane-key", "usuwanie:wyniki");
      for (const entry of [...entries].reverse()) {
        const row = doc.createElement("label");
        row.className = "arkmail-deletion-entry";
        const checkbox = doc.createElement("input");
        checkbox.type = "checkbox";
        checkbox.checked = state.deletion.selected.includes(entry.number);
        checkbox.setAttribute("data-deletion-number", String(entry.number));
        checkbox.addEventListener("change", () => store2.toggleDeletionEntry(entry.number));
        row.appendChild(checkbox);
        const text = doc.createElement("span");
        const date = entry.date?.raw ? ` | ${entry.date.raw}` : "";
        text.textContent = `${entry.party} | ${entry.subject}${date}`;
        row.appendChild(text);
        list.appendChild(row);
      }
      pane.appendChild(list);
    }
    return pane;
  };
  const renderListy = (state) => {
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane arkmail-listy";
    const boxes = doc.createElement("div");
    boxes.className = "arkmail-boxes";
    for (const [box, label] of BOXES) {
      const btn = doc.createElement("button");
      btn.className = "arkmail-box popup-btn popup-btn--control" + (state.activeBox === box ? " arkmail-box-active" : "") + // Fala 14b: flash celu kolejki niewyslanych (jak zakladka Listy).
      (state.unsentFlash && box === "niewyslane" ? " arkmail-flash" : "") + // Fala 16f: trwala obwodka akcentu, gdy licznik skrzynki > 0
      // (zgloszenie pkt 5/8: "zaznaczone, ze cos jest w niewyslanych").
      (state.badge > 0 && box === "nieprzeczytane" ? " arkmail-box-attention" : "") + (state.badgeUnsent > 0 && box === "niewyslane" ? " arkmail-box-attention" : "");
      btn.setAttribute("data-box", box);
      btn.setAttribute("aria-pressed", String(state.activeBox === box));
      btn.textContent = label;
      btn.addEventListener("click", () => {
        store2.setActiveBox(box);
        handlers.onRefreshBox(box);
      });
      boxes.appendChild(btn);
    }
    pane.appendChild(boxes);
    const ops = doc.createElement("div");
    ops.className = "arkmail-box-ops";
    const view0 = state.boxes[state.activeBox];
    const searchMode0 = state.search && state.search.box === state.activeBox ? state.search : null;
    const loopHere = state.loadAll !== null && state.loadAll.box === state.activeBox;
    const loadAllBtn = doc.createElement("button");
    loadAllBtn.className = "arkmail-older-all popup-btn popup-btn--control";
    loadAllBtn.textContent = loopHere ? `Przerwij (${state.loadAll.pages})` : "Wczytaj wszystkie";
    const nothingToLoad = !loopHere && (searchMode0 !== null || !view0 || view0.empty !== null || !view0.truncated || state.loadAll !== null);
    if (nothingToLoad) loadAllBtn.setAttribute("disabled", "");
    loadAllBtn.addEventListener("click", () => handlers.onLoadAll(state.activeBox));
    ops.appendChild(loadAllBtn);
    const clearBtn = doc.createElement("button");
    clearBtn.className = "arkmail-cache-clear popup-btn popup-btn--control popup-btn--danger popup-btn--ghost";
    clearBtn.textContent = "Wyczysc zapisane dane";
    const clearTitle = "Kasuje lokalnie listy, archiwum, kontakty i indeksy. Na serwerze Arkadii nic nie znika - skrzynki pobierzesz od nowa. Ustawienia, grupy i ksiazka adresowa zostaja. Aliasy pobierzesz z gry ponownie.";
    clearBtn.setAttribute("title", clearTitle);
    guardDeleteButton(clearBtn, () => handlers.onClearCache?.(), {
      armedLabel: "Na pewno? Kliknij ponownie",
      armedTitle: "Kliknij ponownie, aby wyczyscic zapisane dane."
    });
    ops.appendChild(clearBtn);
    pane.appendChild(ops);
    const notifyTitle = "Pokazuje komunikat o nowej poczcie. To ustawienie nie wplywa na automatyczne odswiezanie skrzynek.";
    const notifyRow = doc.createElement("label");
    notifyRow.className = "arkmail-dim";
    notifyRow.setAttribute("title", notifyTitle);
    const chk = doc.createElement("input");
    chk.setAttribute("type", "checkbox");
    chk.className = "arkmail-notify-toggle";
    chk.setAttribute("title", notifyTitle);
    chk.checked = state.notifyEnabled;
    chk.addEventListener("click", () => store2.setNotifyEnabled(!store2.state.notifyEnabled));
    notifyRow.appendChild(chk);
    notifyRow.appendChild(doc.createTextNode(" Powiadomienia o nowej poczcie"));
    pane.appendChild(notifyRow);
    const autoRefreshTitle = "Po nowej poczcie i innych zdarzeniach pocztowych ArkMail automatycznie sprawdza skrzynki oraz aktualizuje archiwum, kontakty i liczniki. Wylaczenie tej opcji zatrzymuje odswiezanie w tle, ale nie wylacza powiadomien. Dane moga byc nieaktualne do czasu recznego odswiezenia. Uzyj przycisku Odswiez, aby pobrac aktualne dane.";
    const autoRefreshRow = doc.createElement("label");
    autoRefreshRow.className = "arkmail-dim";
    autoRefreshRow.setAttribute("title", autoRefreshTitle);
    const autoRefreshToggle = doc.createElement("input");
    autoRefreshToggle.setAttribute("type", "checkbox");
    autoRefreshToggle.className = "arkmail-auto-refresh-toggle";
    autoRefreshToggle.setAttribute("title", autoRefreshTitle);
    autoRefreshToggle.checked = state.autoRefreshEnabled;
    autoRefreshToggle.addEventListener("click", () => store2.setAutoRefreshEnabled(!store2.state.autoRefreshEnabled));
    autoRefreshRow.appendChild(autoRefreshToggle);
    autoRefreshRow.appendChild(doc.createTextNode(" Automatyczne odswiezanie poczty"));
    pane.appendChild(autoRefreshRow);
    if (!state.autoRefreshEnabled) {
      const warning = doc.createElement("div");
      warning.className = "arkmail-dim arkmail-auto-refresh-warning";
      warning.setAttribute("role", "status");
      warning.textContent = "Automatyczne odswiezanie jest wylaczone. Archiwum, kontakty i liczniki moga byc nieaktualne. Uzyj przycisku Odswiez, aby pobrac aktualne dane.";
      pane.appendChild(warning);
    }
    const searchRow = doc.createElement("div");
    searchRow.className = "arkmail-search-row";
    const mkSearch = (key, placeholder, type = "text") => {
      const input = doc.createElement("input");
      nativeFieldClass(input);
      input.setAttribute("data-search", key);
      input.setAttribute("type", type);
      input.setAttribute("placeholder", placeholder);
      input.value = searchDraft[key] ?? "";
      input.addEventListener("input", () => {
        searchDraft[key] = input.value;
      });
      return input;
    };
    const sOsoba = mkSearch("osoba", "Osoba (kogo? czego?)");
    sOsoba.setAttribute("title", "Wpisz szukana fraze w dopelniaczu (kogo? czego?).");
    const sTemat = mkSearch("temat", "Temat");
    const sTresc = mkSearch("tresc", "Tresc");
    sTresc.classList.add("arkmail-search-wide");
    const sOd = mkSearch("odDaty", "Od dnia", "date");
    const sDo = mkSearch("doDaty", "Do dnia", "date");
    const sOdF = mkDateField(doc, sOd, "Od dnia (wlacznie)", "Szukanie zwroci listy wyslane od tego dnia WLACZNIE.");
    const sDoF = mkDateField(doc, sDo, "Do dnia (wlacznie)", "Szukanie zwroci listy wyslane do tego dnia WLACZNIE.");
    const go = doc.createElement("button");
    go.className = "arkmail-search-go popup-btn popup-btn--control popup-btn--solid";
    setButtonLabel(go, SEARCH_GO_LABEL, SEARCH_GO_TITLE);
    let searchErrorTimer = null;
    const showSearchError = (message) => {
      if (searchErrorTimer) clearTimeout(searchErrorTimer);
      setButtonLabel(go, message);
      searchErrorTimer = setTimeout(() => setButtonLabel(go, SEARCH_GO_LABEL, SEARCH_GO_TITLE), ERROR_LABEL_MS);
    };
    const fireSearch = () => {
      const osoba = sOsoba.value.trim();
      const temat = sTemat.value.trim();
      const tresc = sTresc.value.trim();
      const isoOd = sOd.value;
      const isoDo = sDo.value;
      const validationError = validateSearchDraft({
        osoba,
        temat,
        tresc,
        odDaty: isoOd,
        doDaty: isoDo
      });
      if (validationError) {
        showSearchError(validationError);
        return;
      }
      if (searchErrorTimer) clearTimeout(searchErrorTimer);
      setButtonLabel(go, SEARCH_GO_LABEL, SEARCH_GO_TITLE);
      const odDaty = fromISODate(isoOd) ?? void 0;
      const doDaty = fromISODate(isoDo) ?? void 0;
      const query = {
        ...osoba !== "" ? { osoba } : {},
        ...odDaty ? { odDaty } : {},
        ...doDaty ? { doDaty } : {},
        ...temat !== "" ? { temat } : {},
        ...tresc !== "" ? { tresc } : {}
      };
      if (Object.keys(query).length === 0) {
        handlers.onRefreshBox(state.activeBox);
        return;
      }
      handlers.onSearch(state.activeBox, query);
    };
    go.addEventListener("click", fireSearch);
    for (const el of [sOsoba, sTemat, sTresc, sOd, sDo]) {
      el.addEventListener("keydown", (ev) => {
        if (ev.key === "Enter") {
          ev.preventDefault();
          fireSearch();
        }
      });
    }
    searchRow.appendChild(sOsoba);
    searchRow.appendChild(sTemat);
    searchRow.appendChild(sTresc);
    searchRow.appendChild(sOdF);
    searchRow.appendChild(sDoF);
    searchRow.appendChild(go);
    pane.appendChild(searchRow);
    attachGhost(doc, sTemat, subjectSource);
    const scroll = doc.createElement("div");
    scroll.className = "arkmail-list-scroll";
    scroll.setAttribute("data-pane-key", `listy:${state.activeBox}`);
    const searchMode = state.search && state.search.box === state.activeBox ? state.search : null;
    if (searchMode) {
      const banner = doc.createElement("div");
      banner.className = "arkmail-search-banner";
      banner.appendChild(doc.createTextNode(`Wyniki szukania: ${searchMode.label}`));
      const clear = doc.createElement("button");
      clear.className = filterClearClass("arkmail-search-clear");
      clear.textContent = "Wyczysc wyniki i filtry";
      clear.setAttribute(
        "title",
        "Usuwa wyniki szukania, czysci wszystkie pola i przywraca pelny widok skrzynki."
      );
      clear.addEventListener("click", () => {
        for (const key of ["osoba", "temat", "tresc", "odDaty", "doDaty"]) searchDraft[key] = "";
        for (const el of [sOsoba, sTemat, sTresc, sOd, sDo]) el.value = "";
        handlers.onClearSearch(state.activeBox);
      });
      banner.appendChild(clear);
      pane.appendChild(banner);
    }
    pane.appendChild(scroll);
    const view = state.boxes[state.activeBox];
    if (!view) {
      scroll.appendChild(dim("Skrzynka nie zaladowana - kliknij jej nazwe, aby ja pobrac."));
      return pane;
    }
    if (view.empty !== null) {
      scroll.appendChild(dim(view.empty === "puste" ? "Skrzynka jest pusta." : "Brak pasujacych listow."));
      return pane;
    }
    const displayed = [...view.entries].reverse();
    for (const [idx, e] of displayed.entries()) {
      const row = doc.createElement("div");
      const unreadMark = !e.isRead && (state.activeBox === "odebrane" || state.activeBox === "nieprzeczytane");
      row.className = "arkmail-entry" + (unreadMark ? " arkmail-unread" : "");
      row.setAttribute("data-number", String(e.number));
      const num = doc.createElement("span");
      num.className = "arkmail-entry-num";
      num.textContent = `${idx + 1}.`;
      row.appendChild(num);
      const party = doc.createElement("span");
      party.className = "arkmail-entry-party";
      party.textContent = e.party || "(brak)";
      row.appendChild(party);
      const subject = doc.createElement("span");
      subject.className = "arkmail-entry-subject";
      subject.textContent = e.subject + (e.forwarded ? " (przekazany)" : "");
      row.appendChild(subject);
      const date = doc.createElement("span");
      date.className = "arkmail-entry-date";
      date.textContent = e.date ? e.date.raw : "";
      row.appendChild(date);
      makeClickable(row, () => handlers.onOpenLetter(state.activeBox, e));
      scroll.appendChild(row);
    }
    if (searchMode) {
    } else if (view.truncated && !state.loadAll) {
      const btn = doc.createElement("button");
      btn.className = "arkmail-older popup-btn popup-btn--control";
      btn.textContent = "Wczytaj starsze";
      btn.addEventListener("click", () => handlers.onLoadOlder(state.activeBox));
      scroll.appendChild(btn);
    }
    return pane;
  };
  const renderList = (state) => {
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane";
    const l = state.letter;
    pane.setAttribute("data-pane-key", l ? `list:${l.box}:${l.number}` : "list:brak");
    if (!l) {
      pane.appendChild(
        dim(state.wide ? "Wybierz list, aby go przeczytac." : "Nie otwarto zadnego listu.")
      );
      return pane;
    }
    const head = doc.createElement("div");
    head.className = "arkmail-letter-head";
    const heading = doc.createElement("div");
    heading.className = "arkmail-letter-heading";
    head.appendChild(heading);
    if (state.wide) {
      const close = doc.createElement("button");
      close.className = "arkmail-letter-close popup-btn popup-btn--control";
      close.textContent = "Zamknij";
      close.addEventListener("click", () => handlers.onCloseLetter());
      head.appendChild(close);
    }
    const subj = doc.createElement("div");
    subj.className = "arkmail-letter-subject";
    subj.textContent = l.subject;
    heading.appendChild(subj);
    const meta = doc.createElement("div");
    meta.className = "arkmail-letter-meta";
    const parts = [`Od: ${l.from}`];
    if (l.to) parts.push(`Do: ${l.to}`);
    if (l.cc) parts.push(`DW: ${l.cc}`);
    if (l.date) parts.push(l.date);
    meta.textContent = parts.join(" | ");
    heading.appendChild(meta);
    pane.appendChild(head);
    const body = doc.createElement("div");
    body.className = "arkmail-letter-body";
    body.textContent = l.body.join("\n");
    pane.appendChild(body);
    const ops = doc.createElement("div");
    ops.className = "arkmail-letter-ops arkmail-action-row";
    const replies = doc.createElement("div");
    replies.className = "arkmail-action-group arkmail-letter-replies";
    ops.appendChild(replies);
    const forward = doc.createElement("div");
    forward.className = "arkmail-action-group arkmail-letter-forward";
    ops.appendChild(forward);
    const danger = doc.createElement("div");
    danger.className = "arkmail-action-group arkmail-letter-danger";
    ops.appendChild(danger);
    const source = l.source;
    const applyReplyPrefill = (prefill, quote) => {
      composeDraft.adresat = prefill.adresat;
      composeDraft.dw = prefill.dw;
      composeDraft.temat = quote ? `Odp: ${l.subject}` : "";
      composeDraft.tresc = quote ? `

---
${l.body.join("\n")}
---` : "";
      store2.setTab("napisz");
    };
    const replyTo = () => {
      const received = l.box === "odebrane" || l.box === "nieprzeczytane";
      composeDraft.adresat = received ? l.from : l.to || l.cc || "";
      composeDraft.dw = "";
      composeDraft.temat = "";
      composeDraft.tresc = "";
      store2.setTab("napisz");
    };
    const replyAllTo = (scope, quote) => {
      if (l.archiveId && handlers.onReplyAllArchive) {
        const before = { ...composeDraft };
        handlers.onReplyAllArchive(l.archiveId, scope, (prefill2) => {
          if (store2.state.letter !== l) return false;
          if (composeDraft.adresat !== before.adresat || composeDraft.temat !== before.temat || composeDraft.dw !== before.dw || composeDraft.tresc !== before.tresc) {
            return false;
          }
          applyReplyPrefill(prefill2, quote);
          return true;
        });
        return;
      }
      const prefill = buildReplyAllPrefill(
        l,
        store2.state.characterName,
        knownRecipientNames(store2.state),
        scope
      );
      if (!prefill) {
        handlers.onReplyAllEmpty?.();
        return;
      }
      applyReplyPrefill(prefill, quote);
    };
    const reply = doc.createElement("button");
    reply.className = "arkmail-reply popup-btn popup-btn--control";
    reply.textContent = "Odpowiedz";
    reply.addEventListener("click", () => replyTo());
    replies.appendChild(reply);
    const replyAll = doc.createElement("button");
    replyAll.className = "arkmail-reply-all popup-btn popup-btn--control";
    replyAll.textContent = "Odpowiedz wszystkim";
    let replyAllPanel = null;
    replyAll.addEventListener("click", () => {
      if (replyAllPanel) return;
      const panel = doc.createElement("div");
      replyAllPanel = panel;
      panel.className = "arkmail-reply-all-panel";
      panel.setAttribute("role", "group");
      panel.setAttribute("aria-label", "Odpowiedz wszystkim");
      const choices = doc.createElement("fieldset");
      choices.className = "arkmail-reply-all-scopes";
      const legend = doc.createElement("legend");
      legend.textContent = "Odbiorcy odpowiedzi";
      choices.appendChild(legend);
      const scopeInputs = /* @__PURE__ */ new Map();
      for (const [scope, label] of [
        ["all", "DO + DW"],
        ["to", "Tylko DO"],
        ["cc", "Tylko DW"]
      ]) {
        const row = doc.createElement("label");
        row.className = "arkmail-reply-all-choice";
        const input = doc.createElement("input");
        input.type = "radio";
        input.name = "arkmail-reply-all-scope";
        input.value = scope;
        input.checked = scope === "all";
        input.setAttribute("data-reply-scope", scope);
        scopeInputs.set(scope, input);
        row.appendChild(input);
        const text = doc.createElement("span");
        text.textContent = label;
        row.appendChild(text);
        choices.appendChild(row);
      }
      panel.appendChild(choices);
      const quoteRow = doc.createElement("label");
      quoteRow.className = "arkmail-reply-all-choice arkmail-reply-all-quote-row";
      const quoteInput = doc.createElement("input");
      quoteInput.type = "checkbox";
      quoteInput.className = "arkmail-reply-all-quote";
      quoteInput.checked = false;
      quoteRow.appendChild(quoteInput);
      const quoteText = doc.createElement("span");
      quoteText.textContent = "Z cytowaniem";
      quoteRow.appendChild(quoteText);
      panel.appendChild(quoteRow);
      const close = () => {
        panel.remove();
        if (replyAllPanel === panel) replyAllPanel = null;
        replyAll.focus();
      };
      panel.addEventListener("keydown", (event) => {
        if (event.key !== "Escape") return;
        event.preventDefault();
        event.stopPropagation();
        close();
      });
      const actions = doc.createElement("div");
      actions.className = "arkmail-reply-all-actions";
      const proceed = doc.createElement("button");
      proceed.className = "arkmail-reply-all-continue popup-btn popup-btn--control popup-btn--solid";
      proceed.textContent = "Kontynuuj";
      proceed.addEventListener("click", () => {
        const scope = [...scopeInputs].find(([, input]) => input.checked)?.[0] ?? "all";
        const quote = quoteInput.checked;
        panel.remove();
        if (replyAllPanel === panel) replyAllPanel = null;
        replyAllTo(scope, quote);
      });
      actions.appendChild(proceed);
      const cancel = doc.createElement("button");
      cancel.className = "arkmail-reply-all-cancel popup-btn popup-btn--control";
      cancel.textContent = "Anuluj";
      cancel.addEventListener("click", close);
      actions.appendChild(cancel);
      panel.appendChild(actions);
      ops.parentElement?.insertBefore(panel, ops.nextSibling);
      scopeInputs.get("all")?.focus();
    });
    replies.appendChild(replyAll);
    const replyQuote = doc.createElement("button");
    replyQuote.className = "arkmail-reply-quote popup-btn popup-btn--control";
    replyQuote.textContent = "Odpowiedz z cytowaniem";
    if (l.body.some((line) => line.trim() !== "")) {
      replyQuote.addEventListener("click", () => {
        const received = l.box === "odebrane" || l.box === "nieprzeczytane";
        composeDraft.adresat = received ? l.from : l.to || l.cc || "";
        composeDraft.dw = "";
        composeDraft.temat = `Odp: ${l.subject}`;
        composeDraft.tresc = `

---
${l.body.join("\n")}
---`;
        store2.setTab("napisz");
      });
    } else {
      replyQuote.setAttribute("disabled", "");
      replyQuote.setAttribute("title", "List bez tresci - nie ma czego cytowac.");
    }
    replies.appendChild(replyQuote);
    const del = doc.createElement("button");
    del.className = "arkmail-del popup-btn popup-btn--control popup-btn--danger popup-btn--ghost";
    del.textContent = "Usun";
    if (source) {
      del.setAttribute("title", "Usun ten list. Tej operacji nie mozna cofnac.");
      guardDeleteButton(del, () => handlers.onDeleteLetter(l.box, source), {
        armedLabel: "Na pewno? Kliknij ponownie"
      });
    } else {
      del.setAttribute("disabled", "");
      del.setAttribute("title", "Otworz list z zakladki Listy, aby go usunac.");
    }
    danger.appendChild(del);
    const fwdInput = doc.createElement("input");
    nativeFieldClass(fwdInput);
    fwdInput.setAttribute("data-field", "forward");
    fwdInput.setAttribute("placeholder", "Przekaz do (gracz lub alias)");
    if (!source) fwdInput.setAttribute("disabled", "");
    forward.appendChild(fwdInput);
    attachGhost(doc, fwdInput, personSource);
    const fwd = doc.createElement("button");
    fwd.className = "arkmail-fwd popup-btn popup-btn--control";
    fwd.textContent = "Przekaz";
    if (source) {
      fwd.addEventListener("click", () => {
        const adresat = fwdInput.value.trim();
        if (adresat) handlers.onForwardLetter(l.box, source, adresat);
      });
      submitOnEnter(fwdInput, () => fwd.click());
    } else {
      fwd.setAttribute("disabled", "");
      fwd.setAttribute("title", "Otworz list z zakladki Listy, aby go przekazac.");
    }
    forward.appendChild(fwd);
    const exp = doc.createElement("button");
    exp.className = "arkmail-export-letter popup-btn popup-btn--control";
    exp.textContent = "Zapisz list jako TXT";
    exp.addEventListener("click", () => handlers.onExportLetter?.());
    forward.appendChild(exp);
    pane.appendChild(ops);
    if (!state.wide) {
      const back = doc.createElement("button");
      back.className = "arkmail-older popup-btn popup-btn--control";
      back.textContent = "Zamknij list";
      back.addEventListener("click", () => handlers.onCloseLetter());
      pane.appendChild(back);
    }
    return pane;
  };
  const composeDraft = { adresat: "", temat: "", dw: "", tresc: "" };
  const writeTo = (adresat) => {
    composeDraft.adresat = adresat;
    composeDraft.dw = "";
    composeDraft.temat = "";
    composeDraft.tresc = "";
    store2.setTab("napisz");
  };
  const partyLabel = (names) => names.join(", ");
  let composePreview = null;
  const repaintCompose = () => {
    if (!composePreview) return;
    const st = store2.state;
    composePreview.textContent = renderLetter(
      composeDraft.tresc,
      st.composeTemplate,
      st.composeWidth
    ).lines.join("\n");
  };
  const previewOpenBtn = () => {
    const btn = doc.createElement("button");
    btn.className = "arkmail-preview-open popup-btn popup-btn--control";
    btn.textContent = "Pelne okno";
    btn.addEventListener("click", () => {
      previewFull = true;
      render(store2.state);
    });
    return btn;
  };
  const renderPreviewFull = () => {
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane arkmail-preview-full-pane";
    pane.setAttribute("data-pane-key", "napisz:podglad-full");
    const bar = doc.createElement("div");
    bar.className = "arkmail-preview-bar";
    const lab = doc.createElement("label");
    lab.textContent = "Podglad wysylanego listu";
    bar.appendChild(lab);
    const close = doc.createElement("button");
    close.className = "arkmail-preview-close popup-btn popup-btn--control";
    close.textContent = "Zamknij podglad";
    close.addEventListener("click", () => {
      previewFull = false;
      render(store2.state);
    });
    bar.appendChild(close);
    pane.appendChild(bar);
    const pre = doc.createElement("pre");
    pre.className = "arkmail-preview";
    pane.appendChild(pre);
    composePreview = pre;
    repaintCompose();
    return pane;
  };
  const renderComposePreview = () => {
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane";
    pane.setAttribute("data-pane-key", "napisz:podglad");
    const bar = doc.createElement("div");
    bar.className = "arkmail-preview-bar";
    const lab = doc.createElement("label");
    lab.textContent = "Podglad wysylanego listu";
    bar.appendChild(lab);
    bar.appendChild(previewOpenBtn());
    pane.appendChild(bar);
    const pre = doc.createElement("pre");
    pre.className = "arkmail-preview";
    pane.appendChild(pre);
    composePreview = pre;
    repaintCompose();
    return pane;
  };
  let seenComposeClearSeq = 0;
  const renderNapisz = (state) => {
    if (state.composeClearSeq !== seenComposeClearSeq) {
      seenComposeClearSeq = state.composeClearSeq;
      composeDraft.adresat = "";
      composeDraft.temat = "";
      composeDraft.dw = "";
      composeDraft.tresc = "";
    }
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane arkmail-form";
    pane.setAttribute("data-pane-key", "napisz");
    const fields = [
      ["adresat", "Adresat"],
      ["temat", "Temat"],
      ["dw", "DW (opcjonalnie)"]
    ];
    for (const [field, label] of fields) {
      const lab2 = doc.createElement("label");
      lab2.textContent = label;
      lab2.htmlFor = `arkmail-compose-${field}`;
      pane.appendChild(lab2);
      const input = doc.createElement("input");
      nativeFieldClass(input);
      input.id = `arkmail-compose-${field}`;
      input.setAttribute("data-field", field);
      input.value = composeDraft[field];
      input.addEventListener("input", () => {
        composeDraft[field] = input.value;
      });
      pane.appendChild(input);
      if (field === "temat") attachGhost(doc, input, subjectSource);
      else attachGhost(doc, input, adresatSource, { segment: true });
    }
    const settings = doc.createElement("div");
    settings.className = "arkmail-compose-settings";
    const templateSetting = doc.createElement("div");
    templateSetting.className = "arkmail-compose-setting";
    const widthSetting = doc.createElement("div");
    widthSetting.className = "arkmail-compose-setting";
    settings.appendChild(templateSetting);
    settings.appendChild(widthSetting);
    pane.appendChild(settings);
    const labSz = doc.createElement("label");
    labSz.textContent = "Szablon";
    labSz.htmlFor = "arkmail-compose-szablon";
    templateSetting.appendChild(labSz);
    const sel = doc.createElement("select");
    nativeFieldClass(sel);
    sel.id = "arkmail-compose-szablon";
    sel.setAttribute("data-field", "szablon");
    for (const [value, label] of TEMPLATES) {
      const opt = doc.createElement("option");
      opt.setAttribute("value", value);
      opt.textContent = label;
      sel.appendChild(opt);
    }
    sel.value = state.composeTemplate;
    sel.addEventListener("change", () => {
      store2.setCompose({ template: sel.value });
    });
    templateSetting.appendChild(sel);
    const labW = doc.createElement("label");
    labW.textContent = "Szerokosc linii (20-120)";
    labW.htmlFor = "arkmail-compose-szerokosc";
    widthSetting.appendChild(labW);
    const width = doc.createElement("input");
    nativeFieldClass(width);
    width.id = "arkmail-compose-szerokosc";
    width.setAttribute("data-field", "szerokosc");
    width.setAttribute("inputmode", "numeric");
    width.setAttribute("aria-describedby", "arkmail-compose-szerokosc-error");
    width.value = String(state.composeWidth);
    const widthError = doc.createElement("div");
    widthError.id = "arkmail-compose-szerokosc-error";
    widthError.className = "arkmail-dim arkmail-compose-width-error";
    widthError.setAttribute("data-compose-width-error", "");
    widthError.setAttribute("role", "alert");
    width.addEventListener("change", () => {
      if (!/^\d+$/.test(width.value)) {
        width.setAttribute("aria-invalid", "true");
        widthError.textContent = "Podaj liczbe calkowita od 20 do 120.";
        return;
      }
      const parsed = Number(width.value);
      if (parsed < 20 || parsed > 120) {
        width.setAttribute("aria-invalid", "true");
        widthError.textContent = "Podaj liczbe calkowita od 20 do 120.";
        return;
      }
      width.removeAttribute("aria-invalid");
      widthError.textContent = "";
      store2.setCompose({ width: clampLineWidth(parsed) });
    });
    widthSetting.appendChild(width);
    widthSetting.appendChild(widthError);
    const lab = doc.createElement("label");
    lab.textContent = "Tresc";
    lab.htmlFor = "arkmail-compose-tresc";
    pane.appendChild(lab);
    const tresc = doc.createElement("textarea");
    nativeFieldClass(tresc);
    tresc.id = "arkmail-compose-tresc";
    tresc.setAttribute("data-field", "tresc");
    tresc.value = composeDraft.tresc;
    pane.appendChild(tresc);
    if (!state.wide) {
      const barP = doc.createElement("div");
      barP.className = "arkmail-preview-bar";
      const labP = doc.createElement("label");
      labP.textContent = "Podglad wysylanego listu";
      barP.appendChild(labP);
      barP.appendChild(previewOpenBtn());
      pane.appendChild(barP);
      const preview = doc.createElement("pre");
      preview.className = "arkmail-preview";
      pane.appendChild(preview);
      composePreview = preview;
      repaintCompose();
    }
    tresc.addEventListener("input", () => {
      composeDraft.tresc = tresc.value;
      repaintCompose();
    });
    const actions = doc.createElement("div");
    actions.className = "arkmail-compose-actions arkmail-action-row";
    const send = doc.createElement("button");
    send.className = "arkmail-send popup-btn popup-btn--control popup-btn--solid";
    send.textContent = "Zapisz w niewyslanych";
    const SEND_LABEL = "Zapisz w niewyslanych";
    let sendTimer = null;
    const disarmSend = () => {
      setButtonLabel(send, SEND_LABEL);
    };
    send.addEventListener("click", () => {
      const st = store2.state;
      const val = (f) => pane.querySelector(`[data-field="${f}"]`).value;
      const input = {
        adresat: val("adresat"),
        temat: val("temat"),
        dw: val("dw"),
        tresc: tresc.value
      };
      const validationError = validateCompose(input);
      if (validationError) {
        if (sendTimer) clearTimeout(sendTimer);
        setButtonLabel(send, validationError);
        sendTimer = setTimeout(disarmSend, ERROR_LABEL_MS);
        return;
      }
      const rendered = renderLetter(input.tresc, st.composeTemplate, st.composeWidth);
      if (sendTimer) clearTimeout(sendTimer);
      disarmSend();
      handlers.onSendCompose({
        ...input,
        linie: rendered.lines
      });
    });
    actions.appendChild(send);
    const clearCompose = doc.createElement("button");
    clearCompose.className = "arkmail-compose-clear popup-btn popup-btn--control popup-btn--danger popup-btn--ghost";
    clearCompose.textContent = "Wyczysc pola listu";
    clearCompose.setAttribute("title", "Czysci pola listu: adresat, temat, DW i tresc.");
    guardDeleteButton(clearCompose, () => {
      composeDraft.adresat = "";
      composeDraft.temat = "";
      composeDraft.dw = "";
      composeDraft.tresc = "";
      for (const f of ["adresat", "temat", "dw", "tresc"]) {
        const el = pane.querySelector(`[data-field="${f}"]`);
        if (el) el.value = "";
      }
      repaintCompose();
    }, {
      armedLabel: "Na pewno? Kliknij ponownie",
      armedTitle: "Kliknij ponownie, aby wyczyscic pola listu."
    });
    actions.appendChild(clearCompose);
    pane.appendChild(actions);
    return pane;
  };
  const renderGrupy = (state, pane) => {
    const error = doc.createElement("div");
    error.className = "arkmail-dim arkmail-group-error";
    error.setAttribute("data-group-error", "");
    const showError = (msg) => {
      error.textContent = msg;
    };
    const save = (groups) => {
      showError("");
      handlers.onSaveGroups?.(groups);
    };
    const nameTaken = (name, ignore) => state.groups.some(
      (g) => g.name !== ignore && g.name.toLowerCase() === name.toLowerCase()
    );
    pane.appendChild(error);
    const groupAddRow = doc.createElement("div");
    groupAddRow.className = "arkmail-group-add arkmail-field-action";
    const groupAddInput = doc.createElement("input");
    nativeFieldClass(groupAddInput);
    groupAddInput.setAttribute("data-group-add", "");
    groupAddInput.setAttribute("placeholder", "Nazwa nowej grupy");
    const groupAddBtn = doc.createElement("button");
    groupAddBtn.className = "popup-btn popup-btn--control";
    groupAddBtn.textContent = "Utworz grupe";
    groupAddBtn.setAttribute("data-group-create", "");
    groupAddBtn.setAttribute("title", "Tworzy pusta grupe. Czlonkow dolaczysz po utworzeniu.");
    groupAddBtn.addEventListener("click", () => {
      const name = groupAddInput.value.trim();
      if (!name) {
        showError("Podaj nazwe grupy.");
        return;
      }
      if (state.groups.some((g) => g.name.toLowerCase() === name.toLowerCase())) {
        showError(`Grupa "${name}" juz istnieje.`);
        return;
      }
      if (groupAliasConflict(name, state.importedAliases)) {
        showError(`Nazwa grupy "${name}" koliduje z aliasem pocztowym z gry. Wybierz inna nazwe.`);
        return;
      }
      groupAddInput.value = "";
      handlers.onSaveGroups?.([...state.groups, { name, members: [] }]);
    });
    submitOnEnter(groupAddInput, () => groupAddBtn.click());
    groupAddRow.appendChild(groupAddInput);
    groupAddRow.appendChild(groupAddBtn);
    pane.appendChild(groupAddRow);
    const filterRow = doc.createElement("div");
    filterRow.className = "arkmail-group-filter arkmail-field-action";
    const filterInput = doc.createElement("input");
    nativeFieldClass(filterInput);
    filterInput.setAttribute("data-group-filter", "");
    filterInput.setAttribute("placeholder", "Filtruj grupy");
    filterInput.setAttribute("title", "Pokazuje tylko grupy z nazwa zawierajaca wpisany fragment.");
    filterInput.value = groupFilter;
    const filterClear = doc.createElement("button");
    filterClear.className = filterClearClass();
    filterClear.textContent = "Wyczysc filtr";
    filterClear.setAttribute("data-group-filter-clear", "");
    filterClear.setAttribute("title", "Czysci filtr grup i pokazuje wszystkie grupy.");
    if (!groupFilter) filterClear.setAttribute("disabled", "1");
    filterClear.addEventListener("click", () => {
      groupFilter = "";
      filterInput.value = "";
      filterClear.setAttribute("disabled", "1");
      paintGroups();
    });
    filterInput.addEventListener("input", () => {
      groupFilter = filterInput.value;
      if (groupFilter) filterClear.removeAttribute("disabled");
      else filterClear.setAttribute("disabled", "1");
      paintGroups();
    });
    filterRow.appendChild(filterInput);
    filterRow.appendChild(filterClear);
    attachGhost(doc, filterInput, groupNameSource);
    pane.appendChild(filterRow);
    const list = doc.createElement("div");
    const groupScroll = doc.createElement("div");
    groupScroll.className = "arkmail-list-scroll";
    groupScroll.setAttribute("data-pane-key", "kontakty:grupy");
    groupScroll.appendChild(list);
    pane.appendChild(groupScroll);
    const paintGroups = () => {
      const needle = groupFilter.trim().toLowerCase();
      const shown = needle ? state.groups.filter((g) => g.name.toLowerCase().includes(needle)) : state.groups;
      list.replaceChildren();
      for (const group of shown) {
        const row = doc.createElement("div");
        row.className = "arkmail-group";
        const expanded = expandedGroups.has(group.name);
        const toggle = doc.createElement("button");
        toggle.className = "arkmail-group-toggle popup-btn popup-btn--control popup-btn--sm";
        toggle.setAttribute("data-group-toggle", "");
        toggle.textContent = `${expanded ? "v" : ">"} ${group.name} (${group.members.length})`;
        toggle.setAttribute(
          "title",
          expanded ? "Zwija grupe." : "Rozwija grupe: edycja nazwy, czlonkowie, pisanie do grupy."
        );
        toggle.addEventListener("click", () => {
          if (expandedGroups.has(group.name)) expandedGroups.delete(group.name);
          else expandedGroups.add(group.name);
          store2.refresh();
        });
        const groupHeader = doc.createElement("div");
        groupHeader.className = "arkmail-group-header";
        groupHeader.appendChild(toggle);
        row.appendChild(groupHeader);
        if (groupAliasConflict(group.name, state.importedAliases)) {
          const warning = doc.createElement("div");
          warning.className = "arkmail-dim arkmail-group-alias-conflict";
          warning.textContent = "Nazwa koliduje z aliasem pocztowym. Grupa nie jest rozwijana w podpowiedziach. Zmien nazwe albo usun grupe.";
          row.appendChild(warning);
        }
        if (expanded) {
          const body = doc.createElement("div");
          body.className = "arkmail-group-body";
          row.appendChild(body);
          const head = doc.createElement("div");
          head.className = "arkmail-group-head arkmail-group-rename arkmail-field-action";
          const groupActions = doc.createElement("div");
          groupActions.className = "arkmail-group-actions arkmail-action-row";
          const rename = doc.createElement("input");
          nativeFieldClass(rename);
          rename.setAttribute("data-group-rename", group.name);
          rename.value = group.name;
          rename.setAttribute("title", "Nazwa grupy - zapisz obok.");
          const renameOk = doc.createElement("button");
          renameOk.className = "popup-btn popup-btn--control";
          renameOk.textContent = "Zapisz nazwe";
          renameOk.setAttribute("data-group-rename-ok", "");
          renameOk.setAttribute("title", "Zapisuje nowa nazwe grupy.");
          renameOk.addEventListener("click", () => {
            const name = rename.value.trim();
            if (!name) {
              showError("Podaj nazwe grupy.");
              return;
            }
            if (nameTaken(name, group.name)) {
              showError(`Grupa "${name}" juz istnieje.`);
              return;
            }
            if (groupAliasConflict(name, state.importedAliases)) {
              showError(`Nazwa grupy "${name}" koliduje z aliasem pocztowym z gry. Wybierz inna nazwe.`);
              return;
            }
            if (expandedGroups.has(group.name)) {
              expandedGroups.delete(group.name);
              expandedGroups.add(name);
            }
            save(state.groups.map((g) => g.name === group.name ? { ...g, name } : g));
          });
          submitOnEnter(rename, () => renameOk.click());
          const del = doc.createElement("button");
          del.className = "popup-btn popup-btn--control popup-btn--danger popup-btn--ghost";
          del.textContent = "Usun grupe";
          del.setAttribute("data-group-delete", "");
          del.setAttribute("title", "Dwuklik: pierwszy klik pyta o potwierdzenie, drugi kasuje grupe.");
          guardDeleteButton(
            del,
            () => save(state.groups.filter((g) => g.name !== group.name)),
            { armedLabel: "Na pewno usunac?" }
          );
          head.appendChild(rename);
          head.appendChild(renameOk);
          groupActions.appendChild(del);
          const write = doc.createElement("button");
          write.className = "popup-btn popup-btn--control";
          write.textContent = "Napisz do grupy";
          write.setAttribute("data-group-write", "");
          if (group.members.length === 0) {
            write.setAttribute("disabled", "1");
            write.setAttribute("title", "Pusta grupa - najpierw dodaj czlonkow.");
          } else {
            write.setAttribute("title", "Otwiera zakladke Napisz list z czlonkami grupy jako adresatami.");
            write.addEventListener("click", () => writeTo(partyLabel(group.members)));
          }
          groupActions.appendChild(write);
          body.appendChild(head);
          body.appendChild(groupActions);
          const members = doc.createElement("div");
          members.className = "arkmail-group-members";
          for (const member of group.members) {
            const chip = doc.createElement("span");
            chip.className = "arkmail-group-member";
            chip.textContent = member;
            const x = doc.createElement("button");
            x.className = "popup-btn popup-btn--control popup-btn--danger popup-btn--ghost popup-btn--sm popup-btn--icon";
            x.textContent = "x";
            x.setAttribute("data-member-remove", "");
            x.setAttribute("title", `Usuwa ${member} z grupy.`);
            guardDeleteButton(
              x,
              () => save(
                state.groups.map(
                  (g) => g.name === group.name ? { ...g, members: g.members.filter((m) => m !== member) } : g
                )
              ),
              { armedTitle: `Kliknij ponownie, aby usunac ${member} z grupy.` }
            );
            chip.appendChild(x);
            members.appendChild(chip);
          }
          body.appendChild(members);
          const addMemberRow = doc.createElement("div");
          addMemberRow.className = "arkmail-group-member-add arkmail-field-action";
          const addMember = doc.createElement("input");
          nativeFieldClass(addMember);
          addMember.setAttribute("data-member-add", group.name);
          addMember.setAttribute("placeholder", "Dodaj osobe");
          const addMemberOk = doc.createElement("button");
          addMemberOk.className = "popup-btn popup-btn--control";
          addMemberOk.textContent = "Dodaj";
          addMemberOk.setAttribute("data-member-add-ok", "");
          addMemberOk.setAttribute("title", "Dodaje osobe do grupy (podpowiedz: strzalka w prawo).");
          addMemberOk.addEventListener("click", () => {
            const name = addMember.value.trim();
            if (!name) return;
            if (!isValidPersonName(name)) {
              showError("Imie: tylko litery.");
              return;
            }
            if (group.members.some((m) => m.toLowerCase() === name.toLowerCase())) {
              showError(`${name} juz jest w tej grupie.`);
              return;
            }
            const error2 = handlers.onAddGroupMember?.(group.name, name);
            if (error2) showError(error2);
          });
          submitOnEnter(addMember, () => addMemberOk.click());
          addMemberRow.appendChild(addMember);
          attachGhost(doc, addMember, personSource);
          addMemberRow.appendChild(addMemberOk);
          body.appendChild(addMemberRow);
        }
        list.appendChild(row);
      }
      if (shown.length === 0 && state.groups.length > 0) {
        const empty = doc.createElement("div");
        empty.className = "arkmail-dim";
        empty.textContent = "Brak grup pasujacych do filtra.";
        list.appendChild(empty);
      }
      if (state.groups.length === 0) {
        const empty = doc.createElement("div");
        empty.className = "arkmail-dim";
        empty.textContent = "Brak grup - utworz pierwsza grupe.";
        list.appendChild(empty);
      }
    };
    paintGroups();
    const ops = doc.createElement("div");
    ops.className = "arkmail-box-ops arkmail-destructive-zone";
    const delAll = doc.createElement("button");
    delAll.className = "popup-btn popup-btn--control popup-btn--danger popup-btn--ghost";
    delAll.textContent = "Usun wszystkie grupy";
    delAll.setAttribute("data-groups-delete-all", "");
    delAll.setAttribute("title", "Dwuklik: pierwszy klik pyta o potwierdzenie, drugi kasuje wszystkie grupy.");
    if (state.groups.length === 0) delAll.setAttribute("disabled", "1");
    guardDeleteButton(delAll, () => save([]), {
      armedLabel: "Na pewno usunac wszystkie?"
    });
    ops.appendChild(delAll);
    pane.appendChild(ops);
    fillButtonTitles(pane);
  };
  const renderKsiazka = (state, pane) => {
    if (bookPeopleRef !== state.people) {
      bookPeopleRef = state.people;
      bookSelection.clear();
    }
    const save = (people) => handlers.onSavePeople?.(people);
    const selectionActions = doc.createElement("div");
    selectionActions.className = "arkmail-book-selection-actions arkmail-action-row";
    pane.appendChild(selectionActions);
    const checkedActions = doc.createElement("div");
    checkedActions.className = "arkmail-book-checked-actions arkmail-action-row";
    pane.appendChild(checkedActions);
    const bulk = doc.createElement("button");
    bulk.className = "popup-btn popup-btn--control popup-btn--danger popup-btn--ghost";
    bulk.textContent = "Usun zaznaczone imiona";
    bulk.setAttribute("data-book-delete-checked", "");
    bulk.setAttribute(
      "title",
      "Dwuklik: pierwszy klik pyta o potwierdzenie, drugi kasuje zaznaczone imiona."
    );
    if (bookSelection.size === 0) bulk.setAttribute("disabled", "1");
    guardDeleteButton(
      bulk,
      () => save(state.people.filter((p) => !bookSelection.has(p))),
      { armedLabel: `Na pewno usunac zaznaczone (${bookSelection.size})?` }
    );
    checkedActions.appendChild(bulk);
    const sorted = [...state.people].sort((a, b) => {
      const la = a.toLowerCase();
      const lb = b.toLowerCase();
      if (la === lb) return 0;
      return la < lb ? -1 : 1;
    });
    const currentVisible = () => {
      const needle = bookFilter.trim().toLowerCase();
      return needle ? sorted.filter((p) => p.toLowerCase().includes(needle)) : sorted;
    };
    const visible = currentVisible();
    const writeBulk = doc.createElement("button");
    writeBulk.className = "popup-btn popup-btn--control";
    writeBulk.textContent = `Napisz list do zaznaczonych (${bookSelection.size})`;
    writeBulk.setAttribute("data-book-write-checked", "");
    writeBulk.setAttribute(
      "title",
      "Otwiera zakladke Napisz list z zaznaczonymi osobami jako adresatami."
    );
    if (bookSelection.size === 0) writeBulk.setAttribute("disabled", "1");
    writeBulk.addEventListener("click", () => {
      if (bookSelection.size === 0) return;
      const party = partyLabel(sorted.filter((p) => bookSelection.has(p)));
      bookSelection.clear();
      writeTo(party);
    });
    checkedActions.appendChild(writeBulk);
    const selectAllBtn = doc.createElement("button");
    selectAllBtn.className = "popup-btn popup-btn--control";
    selectAllBtn.textContent = "Zaznacz wszystkie";
    selectAllBtn.setAttribute("data-book-select-all", "");
    selectAllBtn.setAttribute("title", "Zaznacza wszystkie imiona na liscie.");
    if (visible.length === 0) selectAllBtn.setAttribute("disabled", "1");
    selectAllBtn.addEventListener("click", () => {
      for (const p of visible) bookSelection.add(p);
      store2.refresh();
    });
    selectionActions.appendChild(selectAllBtn);
    const deselectAllBtn = doc.createElement("button");
    deselectAllBtn.className = "popup-btn popup-btn--control";
    deselectAllBtn.textContent = "Odznacz wszystkie";
    deselectAllBtn.setAttribute("data-book-deselect-all", "");
    deselectAllBtn.setAttribute("title", "Czysci zaznaczenie imion.");
    if (visible.length === 0) deselectAllBtn.setAttribute("disabled", "1");
    deselectAllBtn.addEventListener("click", () => {
      bookSelection.clear();
      store2.refresh();
    });
    selectionActions.appendChild(deselectAllBtn);
    const bookAddRow = doc.createElement("div");
    bookAddRow.className = "arkmail-book-add arkmail-field-action";
    const addInput = doc.createElement("input");
    nativeFieldClass(addInput);
    addInput.setAttribute("data-book-new", "");
    addInput.setAttribute("placeholder", "Imie nowej osoby");
    const addBtn = doc.createElement("button");
    addBtn.className = "popup-btn popup-btn--control";
    addBtn.textContent = "Dodaj";
    addBtn.setAttribute("data-book-add", "");
    addBtn.setAttribute("title", "Dodaje imie do ksiazki adresowej.");
    const addErr = doc.createElement("span");
    addErr.className = "arkmail-group-error";
    const showAddError = (msg) => {
      addErr.textContent = msg;
      addErr.setAttribute("data-book-error", "");
    };
    const clearAddError = () => {
      addErr.textContent = "";
      addErr.removeAttribute("data-book-error");
    };
    const tryAdd = () => {
      const name = addInput.value.trim();
      if (!name) {
        showAddError("Podaj imie.");
        return;
      }
      if (!isValidPersonName(name)) {
        showAddError("Imie: tylko litery.");
        return;
      }
      if (state.people.some((p) => p.toLowerCase() === name.toLowerCase())) {
        showAddError("To imie juz jest w ksiazce.");
        return;
      }
      clearAddError();
      addInput.value = "";
      handlers.onSavePeople?.([...state.people, name]);
    };
    addBtn.addEventListener("click", tryAdd);
    addInput.addEventListener("keydown", (ev) => {
      if (ev.key === "Enter") tryAdd();
    });
    bookAddRow.appendChild(addInput);
    bookAddRow.appendChild(addBtn);
    bookAddRow.appendChild(addErr);
    attachGhost(doc, addInput, personSource);
    pane.appendChild(bookAddRow);
    const filterRow = doc.createElement("div");
    filterRow.className = "arkmail-book-filter arkmail-field-action";
    const filterInput = doc.createElement("input");
    nativeFieldClass(filterInput);
    filterInput.setAttribute("data-book-filter", "");
    filterInput.setAttribute("placeholder", "Filtruj imiona");
    filterInput.setAttribute("title", "Pokazuje tylko imiona zawierajace wpisany fragment.");
    filterInput.value = bookFilter;
    const filterClear = doc.createElement("button");
    filterClear.className = filterClearClass();
    filterClear.textContent = "Wyczysc filtr";
    filterClear.setAttribute("data-book-filter-clear", "");
    filterClear.setAttribute("title", "Czysci filtr imion i pokazuje cala ksiazke adresowa.");
    if (!bookFilter) filterClear.setAttribute("disabled", "1");
    filterClear.addEventListener("click", () => {
      bookFilter = "";
      filterInput.value = "";
      filterClear.setAttribute("disabled", "1");
      paintList();
    });
    filterInput.addEventListener("input", () => {
      bookFilter = filterInput.value;
      if (bookFilter) filterClear.removeAttribute("disabled");
      else filterClear.setAttribute("disabled", "1");
      paintList();
    });
    filterRow.appendChild(filterInput);
    filterRow.appendChild(filterClear);
    attachGhost(doc, filterInput, personSource);
    const scroll = doc.createElement("div");
    scroll.className = "arkmail-list-scroll";
    scroll.setAttribute("data-pane-key", "kontakty:ksiazka");
    pane.appendChild(filterRow);
    const count = doc.createElement("div");
    count.className = "arkmail-dim arkmail-book-count";
    count.setAttribute("data-book-count", "");
    pane.appendChild(count);
    const listWrap = doc.createElement("div");
    const paintList = () => {
      const shown = currentVisible();
      listWrap.replaceChildren();
      const lastTwo = sorted.length % 100;
      const last = sorted.length % 10;
      const noun = sorted.length === 1 ? "imie" : last >= 2 && last <= 4 && (lastTwo < 12 || lastTwo > 14) ? "imiona" : "imion";
      count.textContent = `Ksiazka: ${sorted.length} ${noun}` + (bookFilter.trim() ? ` (widoczne: ${shown.length})` : "");
      if (sorted.length === 0) {
        listWrap.appendChild(
          dim("Ksiazka adresowa jest pusta - zaimportuj osoby z gry albo dodaj recznie.")
        );
        return;
      }
      if (shown.length === 0) {
        listWrap.appendChild(dim("Brak imion pasujacych do filtra."));
        return;
      }
      for (const name of shown) {
        const row = doc.createElement("div");
        row.className = "arkmail-book-row";
        row.setAttribute("data-book-row", "");
        const check = doc.createElement("input");
        check.setAttribute("type", "checkbox");
        check.setAttribute("data-book-check", name);
        check.checked = bookSelection.has(name);
        check.addEventListener("change", () => {
          if (check.checked) bookSelection.add(name);
          else bookSelection.delete(name);
          store2.refresh();
        });
        const nameEl = doc.createElement("span");
        nameEl.className = "arkmail-book-name";
        nameEl.setAttribute("data-book-name", "");
        nameEl.textContent = name;
        const remove = doc.createElement("button");
        remove.className = "arkmail-book-remove popup-btn popup-btn--control popup-btn--danger popup-btn--ghost popup-btn--sm popup-btn--icon";
        remove.setAttribute("data-book-remove", "");
        remove.textContent = "x";
        remove.setAttribute("title", `Usuwa ${name} z ksiazki adresowej.`);
        guardDeleteButton(remove, () => save(state.people.filter((p) => p !== name)), {
          armedTitle: `Kliknij ponownie, aby usunac ${name} z ksiazki adresowej.`
        });
        row.appendChild(check);
        row.appendChild(nameEl);
        row.appendChild(remove);
        const write = doc.createElement("button");
        write.className = "arkmail-book-write popup-btn popup-btn--control";
        write.setAttribute("data-book-write", "");
        write.textContent = "Napisz";
        write.setAttribute("title", `Otwiera zakladke Napisz list z adresem: ${name}.`);
        write.addEventListener("click", () => writeTo(name));
        row.appendChild(write);
        listWrap.appendChild(row);
      }
    };
    paintList();
    scroll.appendChild(listWrap);
    pane.appendChild(scroll);
    fillButtonTitles(pane);
  };
  const renderKontakty = (state) => {
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane arkmail-listy";
    pane.setAttribute("data-pane-key", "kontakty");
    const subRow = doc.createElement("div");
    subRow.className = "arkmail-boxes";
    subRow.setAttribute("role", "tablist");
    subRow.setAttribute("aria-label", "Kontakty");
    const SUBPILLS = [
      ["ksiazka", "Ksiazka adresowa"],
      ["aliasy", "Aliasy pocztowe"],
      ["grupy", "Grupy"],
      ["importeksport", "Import i eksport"]
    ];
    const subPanel = doc.createElement("div");
    subPanel.className = contactView.sub === "ksiazka" || contactView.sub === "grupy" ? "arkmail-contact-subpanel arkmail-listy" : "arkmail-contact-subpanel arkmail-contact-subpanel-scroll";
    subPanel.id = `arkmail-contact-panel-${contactView.sub}`;
    subPanel.setAttribute("role", "tabpanel");
    subPanel.setAttribute("aria-labelledby", `arkmail-contact-tab-${contactView.sub}`);
    const buttons = [];
    for (const [sub, label] of SUBPILLS) {
      const pill = doc.createElement("button");
      pill.className = "arkmail-subpill dialog-tab" + (contactView.sub === sub ? " is-active" : "");
      pill.id = `arkmail-contact-tab-${sub}`;
      pill.setAttribute("data-contact-tab", sub);
      pill.setAttribute("role", "tab");
      pill.setAttribute("aria-selected", contactView.sub === sub ? "true" : "false");
      pill.setAttribute("aria-controls", `arkmail-contact-panel-${sub}`);
      pill.tabIndex = contactView.sub === sub ? 0 : -1;
      pill.textContent = label;
      pill.addEventListener("click", () => {
        contactView.sub = sub;
        store2.refresh();
      });
      subRow.appendChild(pill);
      buttons.push(pill);
    }
    wireTabKeyboard(subRow, buttons, (index) => {
      const sub = SUBPILLS[index][0];
      contactView.sub = sub;
      store2.refresh();
      root.querySelector(`[data-contact-tab="${sub}"]`)?.focus();
    });
    pane.appendChild(subRow);
    pane.appendChild(subPanel);
    if (contactView.sub === "grupy") {
      renderGrupy(state, subPanel);
      return pane;
    }
    if (contactView.sub === "aliasy") {
      renderAliasy(state, subPanel);
      return pane;
    }
    if (contactView.sub === "importeksport") {
      renderImportEksport(state, subPanel);
      return pane;
    }
    if (contactView.sub === "ksiazka") {
      renderKsiazka(state, subPanel);
      return pane;
    }
    return pane;
  };
  const renderAliasy = (state, pane) => {
    const aliasSec = doc.createElement("div");
    aliasSec.className = "arkmail-book-aliases";
    aliasSec.setAttribute("data-book-aliases", "");
    const aliasNote = doc.createElement("div");
    aliasNote.className = "arkmail-dim";
    aliasNote.textContent = "Aliasy pocztowe z gry sa w ArkMailu tylko do odczytu. Sa zapisane lokalnie jako lustro, ale nie trafiaja do eksportu JSON. Aliasy edytujesz i usuwasz w grze.";
    aliasSec.appendChild(aliasNote);
    if (state.importedAliases.length === 0) {
      aliasSec.appendChild(dim("Brak zapisanych aliasow. Pobierz je z gry przyciskiem Importuj aliasy pocztowe."));
    } else {
      for (const alias of state.importedAliases) {
        const row = doc.createElement("div");
        row.className = "arkmail-book-alias";
        const text = doc.createElement("span");
        text.className = "arkmail-book-alias-text";
        text.textContent = `${alias.name} -> ${alias.targets.join(", ")}`;
        row.appendChild(text);
        const write = doc.createElement("button");
        write.className = "arkmail-book-write popup-btn popup-btn--control";
        write.setAttribute("data-alias-write", "");
        write.textContent = "Napisz";
        write.setAttribute("title", `Otwiera zakladke Napisz list z adresem: ${alias.name}.`);
        write.addEventListener("click", () => writeTo(alias.name));
        row.appendChild(write);
        aliasSec.appendChild(row);
      }
    }
    const importRow = doc.createElement("div");
    importRow.className = "arkmail-alias-import arkmail-action-row";
    const importAliases = doc.createElement("button");
    importAliases.className = "arkmail-import-btn popup-btn popup-btn--control";
    importAliases.setAttribute("data-import", "aliasy");
    importAliases.textContent = "Importuj aliasy pocztowe";
    importAliases.setAttribute(
      "title",
      "Pobiera z gry aliasy pocztowe i dopisuje ich odbiorcow do ksiazki. W ArkMailu aliasy sa tylko do odczytu; edytujesz i usuwasz je w grze. Rozwija je serwer."
    );
    importAliases.addEventListener("click", () => handlers.onImportAliases?.());
    importRow.appendChild(importAliases);
    aliasSec.appendChild(importRow);
    pane.appendChild(aliasSec);
    const zone = doc.createElement("div");
    zone.className = "arkmail-box-ops arkmail-destructive-zone";
    const clearBtn = doc.createElement("button");
    clearBtn.className = "popup-btn popup-btn--control popup-btn--danger popup-btn--ghost";
    clearBtn.textContent = "Wyczysc zapisane aliasy";
    clearBtn.setAttribute("data-aliases-clear", "");
    clearBtn.setAttribute(
      "title",
      "Usuwa lokalne lustro aliasow. Na serwerze Arkadii nic nie znika. Aliasy pobierzesz z gry ponownie."
    );
    if (state.importedAliases.length === 0) clearBtn.setAttribute("disabled", "1");
    guardDeleteButton(clearBtn, () => handlers.onClearAliases?.(), {
      armedLabel: "Na pewno usunac aliasy?"
    });
    zone.appendChild(clearBtn);
    pane.appendChild(zone);
    fillButtonTitles(pane);
  };
  const renderImportEksport = (state, pane) => {
    const error = doc.createElement("div");
    error.className = "arkmail-dim arkmail-group-error";
    error.setAttribute("data-group-error", "");
    const showError = (msg) => {
      error.textContent = msg;
    };
    const importRow = doc.createElement("div");
    importRow.className = "arkmail-import-row arkmail-book-import-people arkmail-action-row";
    const addAll = doc.createElement("button");
    addAll.className = "popup-btn popup-btn--control";
    addAll.textContent = "Dopisz wszystkie osoby z listow";
    addAll.setAttribute("data-book-add-all-contacts", "");
    addAll.setAttribute(
      "title",
      "Dopisuje do ksiazki wszystkie osoby zebrane z listow. Bez wzgledu na wielkosc liter nic nie duplikuje."
    );
    if (state.contacts.length === 0) addAll.setAttribute("disabled", "1");
    addAll.addEventListener("click", () => handlers.onAddAllContacts?.());
    importRow.appendChild(addAll);
    const IMPORT_BTNS = [
      [
        "zapamietani",
        "Importuj zapamietanych",
        "Pobiera z gry osoby zapamietane i dopisuje nowe do ksiazki adresowej. Istniejacych osob nie usuwa. Grup nie tworzy."
      ],
      [
        "przedstawieni",
        "Importuj przedstawionych",
        "Pobiera z gry osoby, ktore zostaly ci ostatnio przedstawione, i dopisuje nowe do ksiazki adresowej. Istniejacych osob nie usuwa. Grup nie tworzy."
      ]
    ];
    for (const [kind, label, title] of IMPORT_BTNS) {
      const btn = doc.createElement("button");
      btn.className = "arkmail-import-btn popup-btn popup-btn--control";
      btn.setAttribute("data-import", kind);
      btn.textContent = label;
      btn.setAttribute("title", title);
      btn.addEventListener("click", () => {
        handlers.onImportPeople?.(kind);
      });
      importRow.appendChild(btn);
    }
    pane.appendChild(importRow);
    pane.appendChild(doc.createElement("hr"));
    const transferActions = doc.createElement("div");
    transferActions.className = "arkmail-book-transfer-actions arkmail-action-row";
    const expBtn = doc.createElement("button");
    expBtn.className = "popup-btn popup-btn--control popup-btn--solid";
    expBtn.textContent = "Eksportuj ksiazke";
    expBtn.setAttribute("data-book-export", "");
    expBtn.setAttribute("title", "Pobiera plik JSON: imiona i grupy. Aliasy pocztowe nie wchodza do pliku - pobierasz je z gry.");
    expBtn.addEventListener("click", () => handlers.onExportAddressBook?.());
    transferActions.appendChild(expBtn);
    const modeRow = doc.createElement("div");
    modeRow.className = "arkmail-boxes";
    modeRow.setAttribute("data-book-import-mode", "");
    const MODES = [
      [
        "dolacz",
        "Dolacz do ksiazki",
        "Dolacza imiona i nowe grupy z pliku. Grupe o tej samej nazwie scala z istniejaca. Nie usuwa obecnych danych."
      ],
      [
        "zastap",
        "Zastap cala ksiazke",
        "Kasuje obecne imiona i grupy, a na ich miejsce wczytuje zawartosc pliku. Aliasy zostaja bez zmian."
      ]
    ];
    for (const [mode, label, title] of MODES) {
      const lab = doc.createElement("label");
      const radio = doc.createElement("input");
      radio.setAttribute("type", "radio");
      radio.setAttribute("name", "arkmail-import-mode");
      radio.setAttribute("title", title);
      radio.checked = bookImportMode === mode;
      radio.addEventListener("click", () => {
        bookImportMode = mode;
      });
      lab.appendChild(radio);
      lab.appendChild(doc.createTextNode(label));
      modeRow.appendChild(lab);
    }
    const impInput = doc.createElement("input");
    nativeFieldClass(impInput);
    impInput.setAttribute("type", "file");
    impInput.setAttribute("data-book-import", "");
    impInput.setAttribute("accept", ".json,application/json");
    impInput.setAttribute(
      "title",
      "Wczytuje imiona i grupy z pliku JSON. Sposob zalezy od trybu: dolacz albo zastap. Aliasy pobierasz z gry."
    );
    const paintReplaceConfirmation = () => {
      pane.querySelector("[data-book-replace-confirm]")?.remove();
      const pending = pendingBookReplace;
      if (!pending || pending.selection !== bookImportSelection) return;
      const panel = doc.createElement("div");
      panel.className = "arkmail-box-ops arkmail-book-replace-confirm";
      panel.setAttribute("data-book-replace-confirm", "");
      const description = doc.createElement("div");
      description.className = "arkmail-dim";
      description.textContent = `Zastapic cala ksiazke plikiem ${pending.fileName}? Plik: ${pending.data.people.length} imion, ${pending.data.groups.length} grup. Aliasy pocztowe zostana bez zmian.`;
      const confirm = doc.createElement("button");
      confirm.className = "popup-btn popup-btn--control popup-btn--danger";
      confirm.setAttribute("data-book-replace-ok", "");
      confirm.textContent = "Zastap cala ksiazke";
      confirm.addEventListener("click", () => {
        const current = pendingBookReplace;
        if (!current || current.selection !== bookImportSelection) return;
        pendingBookReplace = null;
        handlers.onImportAddressBook?.(current.data, "zastap");
      });
      const cancel = doc.createElement("button");
      cancel.className = "popup-btn popup-btn--control";
      cancel.setAttribute("data-book-replace-cancel", "");
      cancel.textContent = "Anuluj";
      cancel.addEventListener("click", () => {
        pendingBookReplace = null;
        paintReplaceConfirmation();
      });
      panel.appendChild(description);
      panel.appendChild(confirm);
      panel.appendChild(cancel);
      error.before(panel);
    };
    impInput.addEventListener("change", () => {
      const selection = ++bookImportSelection;
      const selectedMode = bookImportMode;
      const file = impInput.files?.[0];
      pendingBookReplace = null;
      paintReplaceConfirmation();
      showError("");
      if (!file) {
        impInput.value = "";
        return;
      }
      void (async () => {
        try {
          const content = await file.text();
          if (selection !== bookImportSelection) return;
          const parsed = parseAddressBookExport(content);
          if (!parsed) {
            showError("Niepoprawny plik ksiazki adresowej.");
            return;
          }
          if (selectedMode === "zastap") {
            pendingBookReplace = { selection, fileName: file.name, data: parsed };
            paintReplaceConfirmation();
          } else {
            handlers.onImportAddressBook?.(parsed, selectedMode);
          }
        } catch {
          if (selection === bookImportSelection) showError("Nie udalo sie odczytac pliku.");
        } finally {
          impInput.value = "";
        }
      })();
    });
    const impBtn = doc.createElement("button");
    impBtn.className = "popup-btn popup-btn--control";
    impBtn.textContent = "Importuj ksiazke";
    impBtn.setAttribute("data-book-import-trigger", "");
    impBtn.setAttribute(
      "title",
      "Wybiera plik JSON z imionami i grupami, a potem wczytuje go w wybranym trybie."
    );
    impBtn.addEventListener("click", () => impInput.click());
    transferActions.appendChild(impBtn);
    pane.appendChild(transferActions);
    pane.appendChild(impInput);
    pane.appendChild(modeRow);
    pane.appendChild(error);
    pane.appendChild(doc.createElement("hr"));
    const clearAll = doc.createElement("button");
    clearAll.className = "popup-btn popup-btn--control popup-btn--danger popup-btn--ghost";
    clearAll.textContent = "Wyczysc cala ksiazke i aliasy";
    clearAll.setAttribute("data-book-clear-all", "");
    clearAll.setAttribute(
      "title",
      "Kasuje lokalnie wszystkie imiona, grupy i aliasy. Na serwerze Arkadii nic nie znika - ksiazke zbudujesz od nowa."
    );
    guardDeleteButton(clearAll, () => handlers.onClearAddressBook?.(), {
      armedLabel: "Na pewno wyczyscic cala ksiazke?"
    });
    const clearZone = doc.createElement("div");
    clearZone.className = "arkmail-box-ops arkmail-destructive-zone";
    clearZone.appendChild(clearAll);
    pane.appendChild(clearZone);
    fillButtonTitles(pane);
  };
  const renderArchPeople = (state) => {
    const panel = doc.createElement("div");
    panel.setAttribute("data-arch-people", "");
    panel.className = "arkmail-arch-people-panel";
    if (!allBoxesIndexed(state.indexMeta) || state.indexRun) {
      panel.appendChild(
        dim("Osoby z listow powstaja z listow zebranych ze wszystkich skrzynek.")
      );
    }
    const gaps = INDEX_BOXES.flatMap(
      (box) => (state.archiveGaps[box] ?? []).map((day) => `${box}: ${day}`)
    );
    if (gaps.length > 0) {
      const gapNote = doc.createElement("div");
      gapNote.className = "arkmail-dim arkmail-index-gaps";
      gapNote.textContent = `Brakuje danych z dni: ${gaps.join(", ")}`;
      panel.appendChild(gapNote);
    }
    const controls = doc.createElement("div");
    controls.className = "arkmail-contact-controls";
    const input = doc.createElement("input");
    input.className = "arkmail-contact-filter popup-input popup-input--control";
    input.setAttribute("data-filter", "kontakty");
    input.setAttribute("placeholder", "Filtr: nazwa lub alias");
    input.value = contactView.filter;
    const sel = doc.createElement("select");
    sel.className = "arkmail-contact-sort popup-input popup-input--control";
    const SORT_OPTS = [
      ["nazwa", "Nazwa A-Z"],
      ["liczba", "Liczba listow"],
      ["ostatni", "Ostatni list"]
    ];
    for (const [value, label] of SORT_OPTS) {
      const o = doc.createElement("option");
      o.setAttribute("value", value);
      o.textContent = label;
      sel.appendChild(o);
    }
    sel.value = contactView.sort;
    controls.appendChild(input);
    controls.appendChild(sel);
    const clearFilters = doc.createElement("button");
    clearFilters.className = filterClearClass("arkmail-arch-clear");
    clearFilters.setAttribute("data-arch-people-clear", "");
    const syncClear = wireArchiveClearButton(clearFilters);
    controls.appendChild(clearFilters);
    panel.appendChild(controls);
    attachGhost(doc, input, personSource);
    const list = doc.createElement("div");
    list.className = "arkmail-arch-people-list";
    panel.appendChild(list);
    const repaint = () => {
      const rows = viewContacts(state.contacts, contactView);
      list.replaceChildren(
        ...rows.map((c) => {
          const row = doc.createElement("div");
          row.className = "arkmail-contact";
          const name = doc.createElement("span");
          name.className = "arkmail-contact-name";
          name.textContent = c.name;
          const jumpTo = (box) => {
            archFilter.osoba = c.name;
            archFilter.skrzynka = box;
            archFilter.temat = void 0;
            archFilter.tresc = void 0;
            archFilter.odDaty = void 0;
            archFilter.doDaty = void 0;
            archView.sub = "listy";
            store2.setTab("archiwum");
            const target = doc.querySelector(".arkmail-arch-list");
            target?.scrollIntoView?.();
          };
          name.setAttribute("title", "Pokaz listy tej osoby w archiwum.");
          makeClickable(name, () => {
            if (c.lettersReceived > 0) jumpTo("odebrane");
            else if (c.lettersSent > 0) jumpTo("wyslane");
          });
          row.appendChild(name);
          const stats = doc.createElement("span");
          stats.className = "arkmail-contact-stats";
          stats.textContent = `(odebrane: ${c.lettersReceived}, wyslane: ${c.lettersSent})` + (c.mailAlias ? ` | alias: ${c.mailAlias}` : "");
          row.appendChild(stats);
          if (c.lastContactRaw) {
            const last = doc.createElement("span");
            last.className = "arkmail-contact-last";
            last.textContent = c.lastContactRaw;
            row.appendChild(last);
          }
          const dirs = doc.createElement("span");
          dirs.className = "arkmail-contact-dirs";
          const DIR_OPTS = [
            ["odebrane", "Odebrane", c.lettersReceived],
            ["wyslane", "Wyslane", c.lettersSent]
          ];
          for (const [box, label, count] of DIR_OPTS) {
            const btn = doc.createElement("button");
            btn.className = "arkmail-contact-dir popup-btn popup-btn--control";
            btn.setAttribute("data-dir", box);
            btn.textContent = label;
            if (count === 0) {
              btn.setAttribute("disabled", "1");
              btn.setAttribute("title", "Brak listow.");
            } else {
              btn.addEventListener("click", () => jumpTo(box));
            }
            dirs.appendChild(btn);
          }
          row.appendChild(dirs);
          const addBook = doc.createElement("button");
          addBook.className = "arkmail-contact-addbook popup-btn popup-btn--control";
          addBook.setAttribute("data-arch-add-book", "");
          addBook.textContent = "Do ksiazki";
          if (state.people.some((p) => p.toLowerCase() === c.name.toLowerCase())) {
            addBook.setAttribute("disabled", "1");
            addBook.setAttribute("title", "Juz w ksiazce.");
          } else {
            addBook.setAttribute("title", `Dopisuje ${c.name} do ksiazki adresowej.`);
            addBook.addEventListener(
              "click",
              () => handlers.onSavePeople?.([...state.people, c.name])
            );
          }
          row.appendChild(addBook);
          return row;
        })
      );
      if (rows.length === 0) {
        list.replaceChildren(
          dim(
            state.contacts.length === 0 ? "Brak osob z listow - pojawia sie po pobraniu skrzynek." : "Zadna osoba nie pasuje do filtra."
          )
        );
      }
      fillButtonTitles(list);
    };
    input.addEventListener("input", () => {
      contactView.filter = input.value;
      repaint();
      syncClear();
    });
    sel.addEventListener("change", () => {
      contactView.sort = sel.value;
      repaint();
      syncClear();
    });
    repaint();
    return panel;
  };
  const renderArchiwum = (state) => {
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane arkmail-listy";
    pane.setAttribute("data-pane-key", "archiwum");
    const subRow = doc.createElement("div");
    subRow.className = "arkmail-boxes";
    subRow.setAttribute("role", "tablist");
    subRow.setAttribute("aria-label", "Archiwum");
    const ARCH_SUBS = [
      ["listy", "Archiwum listow"],
      ["osoby", "Osoby z listow"]
    ];
    const subPanel = doc.createElement("div");
    subPanel.className = "arkmail-subpanel";
    subPanel.id = `arkmail-archive-panel-${archView.sub}`;
    subPanel.setAttribute("role", "tabpanel");
    subPanel.setAttribute("aria-labelledby", `arkmail-archive-tab-${archView.sub}`);
    const buttons = [];
    for (const [sub, label] of ARCH_SUBS) {
      const pill = doc.createElement("button");
      pill.className = "arkmail-subpill dialog-tab" + (archView.sub === sub ? " is-active" : "");
      pill.id = `arkmail-archive-tab-${sub}`;
      pill.setAttribute("data-archive-tab", sub);
      pill.setAttribute("role", "tab");
      pill.setAttribute("aria-selected", archView.sub === sub ? "true" : "false");
      pill.setAttribute("aria-controls", `arkmail-archive-panel-${sub}`);
      pill.tabIndex = archView.sub === sub ? 0 : -1;
      pill.textContent = label;
      pill.addEventListener("click", () => {
        archView.sub = sub;
        store2.refresh();
      });
      subRow.appendChild(pill);
      buttons.push(pill);
    }
    wireTabKeyboard(subRow, buttons, (index) => {
      const sub = ARCH_SUBS[index][0];
      archView.sub = sub;
      store2.refresh();
      root.querySelector(`[data-archive-tab="${sub}"]`)?.focus();
    });
    pane.appendChild(subRow);
    pane.appendChild(subPanel);
    if (archView.sub === "osoby") {
      subPanel.appendChild(renderArchPeople(state));
      return pane;
    }
    const controls = doc.createElement("div");
    controls.className = "arkmail-arch-controls";
    let syncClear = () => {
    };
    const mkText = (key, placeholder, type = "text") => {
      const input = doc.createElement("input");
      nativeFieldClass(input);
      input.setAttribute("data-filter", key);
      input.setAttribute("type", type);
      input.setAttribute("placeholder", placeholder);
      input.value = archFilter[key] ?? "";
      input.addEventListener("input", () => {
        archFilter[key] = input.value === "" ? void 0 : input.value;
        repaint();
        syncClear();
      });
      return input;
    };
    const aOsoba = mkText("osoba", "Osoba (nadawca lub odbiorca)");
    controls.appendChild(aOsoba);
    attachGhost(doc, aOsoba, personSource);
    const skr = doc.createElement("select");
    nativeFieldClass(skr);
    skr.setAttribute("data-filter", "skrzynka");
    const SKR_OPTS = [
      ["", "Wszystkie skrzynki"],
      ["odebrane", "Odebrane"],
      ["nieprzeczytane", "Nieprzeczytane"],
      ["wyslane", "Wyslane"],
      ["niewyslane", "Niewyslane"]
    ];
    for (const [value, label] of SKR_OPTS) {
      const o = doc.createElement("option");
      o.setAttribute("value", value);
      o.textContent = label;
      skr.appendChild(o);
    }
    skr.value = archFilter.skrzynka ?? "";
    skr.addEventListener("change", () => {
      archFilter.skrzynka = skr.value === "" ? void 0 : skr.value;
      repaint();
      syncClear();
    });
    controls.appendChild(skr);
    const aTemat = mkText("temat", "Temat");
    controls.appendChild(aTemat);
    attachGhost(doc, aTemat, subjectSource);
    controls.appendChild(mkText("tresc", "Tresc listu"));
    controls.appendChild(
      mkDateField(doc, mkText("odDaty", "Od dnia", "date"), "Od dnia (wlacznie)", "Archiwum pokaze listy od tego dnia WLACZNIE.")
    );
    controls.appendChild(
      mkDateField(doc, mkText("doDaty", "Do dnia", "date"), "Do dnia (wlacznie)", "Archiwum pokaze listy do tego dnia WLACZNIE.")
    );
    const clearFilters = doc.createElement("button");
    clearFilters.className = filterClearClass("arkmail-arch-clear");
    syncClear = wireArchiveClearButton(clearFilters);
    controls.appendChild(clearFilters);
    const steps = doc.createElement("div");
    steps.className = "arkmail-archive-steps";
    steps.setAttribute("aria-label", "Kolejne kroki pracy z archiwum");
    const makeStep = (title, status, tone) => {
      const step = doc.createElement("section");
      step.className = `arkmail-archive-step arkmail-step-${tone}`;
      const heading = doc.createElement("div");
      heading.className = "arkmail-archive-step-title";
      heading.textContent = title;
      const description = doc.createElement("div");
      description.className = "arkmail-archive-step-status";
      status.forEach(([label, value], index) => {
        if (index > 0) description.appendChild(doc.createTextNode(" "));
        const row = doc.createElement("div");
        row.className = "arkmail-archive-step-status-row";
        const labelElement = doc.createElement("span");
        labelElement.className = "arkmail-archive-step-status-label";
        labelElement.textContent = `${label} `;
        const valueElement = doc.createElement("span");
        valueElement.className = "arkmail-archive-step-status-value";
        valueElement.textContent = value;
        row.appendChild(labelElement);
        row.appendChild(valueElement);
        description.appendChild(row);
      });
      step.appendChild(heading);
      step.appendChild(description);
      steps.appendChild(step);
      return step;
    };
    const indexedCount = INDEX_BOXES.filter((box) => state.indexMeta[box] !== void 0).length;
    const gapCount = Object.values(state.archiveGaps).reduce((sum, days) => sum + days.length, 0);
    const indexDates = INDEX_BOXES.map((box) => state.indexMeta[box]).filter((d) => d !== void 0).sort();
    const earliestIndexDate = indexDates.length > 0 ? indexDates[0].slice(0, 10) : "";
    const gapPhrase = (days) => days === 1 ? "brakuje danych z 1 dnia" : `brakuje danych z ${days} dni`;
    const indexStatus = [];
    if (state.indexRun) {
      indexStatus.push(
        ["Stan:", "W toku."],
        ["Skrzynka:", `${state.indexRun.box}.`],
        ["Liczba stron:", `${state.indexRun.pages}.`]
      );
    } else if (allBoxesIndexed(state.indexMeta)) {
      if (gapCount > 0) {
        indexStatus.push(["Stan:", "Gotowe."], ["Braki:", `${gapPhrase(gapCount)}.`]);
      } else {
        indexStatus.push(
          ["Stan:", "Wszystkie skrzynki zapisane."],
          ["Najstarszy zapis:", `${earliestIndexDate}.`]
        );
      }
    } else if (indexedCount > 0 || gapCount > 0) {
      indexStatus.push(["Stan:", `Czesciowo: ${indexedCount} z ${INDEX_BOXES.length} skrzynek.`]);
      if (gapCount > 0) indexStatus.push(["Braki:", `${gapPhrase(gapCount)}.`]);
    } else {
      indexStatus.push(["Stan:", "Jeszcze nie zaczeto."]);
    }
    const archiveGroups = liveArchiveGroups(state.archive);
    let withBody = 0;
    let pendingBody = 0;
    let undatedBody = 0;
    for (const letter of state.archive) {
      if (letter.body.length > 0) {
        withBody += 1;
        continue;
      }
      const dateRaw = letter.dateRaw;
      if (dateRaw !== null && parseMailDate(dateRaw) !== null) pendingBody += 1;
      else undatedBody += 1;
    }
    const downloadStatus = [];
    if (state.archiveDownload) {
      downloadStatus.push(["Pobieram tresci:", `${state.archiveDownload.done} z ${state.archiveDownload.total}.`]);
    } else if (state.archive.length === 0) {
      downloadStatus.push(["Stan:", "Jeszcze nie pobrano."]);
    } else if (pendingBody > 0) {
      downloadStatus.push(
        ["Stan:", "Czesciowo."],
        ["Liczba listow z trescia:", `${withBody}.`],
        ["Do pobrania:", `${pendingBody}.`],
        ["Bez tresci i bez prawidlowej daty:", `${undatedBody}.`]
      );
    } else {
      downloadStatus.push(
        ["Liczba listow z trescia:", `${withBody}.`],
        ["Do pobrania nie nadaja sie:", `${undatedBody} (brak prawidlowej daty).`]
      );
    }
    const exportable = archiveExportStats(state.archive);
    const exportStatus = exportable.count === 0 ? [["Stan:", "Brak listow z trescia - nie ma czego zapisywac."]] : [
      ["Do zapisu:", `${exportable.count}.`],
      ["Pominiete bez tresci:", `${exportable.skipped}.`]
    ];
    let countsStrip = null;
    if (archiveGroups.length > 0) {
      countsStrip = doc.createElement("p");
      countsStrip.className = "arkmail-dim arkmail-arch-counts";
      countsStrip.textContent = `Liczba listow w bazie: ${totalLive(state.archive)}.`;
    }
    const indexStep = makeStep("1. Indeksacja", indexStatus, state.indexRun ? "active" : allBoxesIndexed(state.indexMeta) ? gapCount > 0 ? "warning" : "done" : indexedCount > 0 || gapCount > 0 ? "incomplete" : "idle");
    const downloadStep = makeStep("2. Pobranie tresci", downloadStatus, state.archiveDownload ? "active" : pendingBody > 0 ? "incomplete" : undatedBody > 0 ? "warning" : withBody > 0 ? "done" : "idle");
    const exportStep = makeStep("3. Zapis ZIP", exportStatus, exportable.count > 0 ? exportable.skipped > 0 ? "warning" : "done" : "idle");
    const idxBtn = doc.createElement("button");
    idxBtn.className = "arkmail-index-all popup-btn popup-btn--control";
    idxBtn.textContent = state.indexRun ? `Przerwij indeksowanie (${state.indexRun.boxIndex + 1}/${INDEX_BOXES.length})` : "Indeksuj wszystkie skrzynki";
    idxBtn.addEventListener("click", () => handlers.onIndexAll?.());
    indexStep.appendChild(idxBtn);
    const dlBtn = doc.createElement("button");
    dlBtn.className = "arkmail-arch-download popup-btn popup-btn--control";
    dlBtn.textContent = state.archiveDownload ? `Przerwij (${state.archiveDownload.done}/${state.archiveDownload.total})` : "Pobierz tresci do archiwum";
    if (state.archiveDownload) {
      dlBtn.addEventListener("click", () => handlers.onDownloadArchiveBodies?.());
    } else {
      dlBtn.setAttribute("title", "Pobiera brakujace tresci listow do archiwum. Moze potrwac dlugo.");
      guardDeleteButton(dlBtn, () => handlers.onDownloadArchiveBodies?.(), {
        armedLabel: "Potwierdz dlugie pobieranie",
        armedTitle: "Kliknij ponownie, aby rozpoczac pobieranie."
      });
    }
    downloadStep.appendChild(dlBtn);
    const expBtn = doc.createElement("button");
    expBtn.className = "arkmail-arch-export popup-btn popup-btn--control popup-btn--solid";
    expBtn.textContent = "Zapisz wszystkie (ZIP)";
    expBtn.addEventListener("click", () => handlers.onExportArchive?.());
    exportStep.appendChild(expBtn);
    subPanel.appendChild(steps);
    subPanel.appendChild(controls);
    if (countsStrip) subPanel.appendChild(countsStrip);
    const list = doc.createElement("div");
    list.className = "arkmail-arch-list";
    list.setAttribute("data-pane-key", "archiwum:listy");
    subPanel.appendChild(list);
    const repaint = () => {
      const datesInvalid = archFilter.odDaty !== void 0 && fromISODate(archFilter.odDaty) === null || archFilter.doDaty !== void 0 && fromISODate(archFilter.doDaty) === null;
      const datesClash = !datesInvalid && archFilter.odDaty !== void 0 && archFilter.doDaty !== void 0 && archFilter.odDaty > archFilter.doDaty;
      const effFilter = datesInvalid || datesClash ? { ...archFilter, odDaty: void 0, doDaty: void 0 } : archFilter;
      const oldErr = subPanel.querySelector(".arkmail-dates-error");
      if (oldErr) oldErr.remove();
      if (datesInvalid || datesClash) {
        const err = doc.createElement("div");
        err.className = "arkmail-dates-error";
        err.textContent = datesInvalid ? "Nieprawidlowa data - oba filtry dat zostaly pominiete." : "Data 'Od dnia' jest pozniejsza niz 'Do dnia' - oba filtry dat zostaly pominiete.";
        subPanel.insertBefore(err, list);
      }
      const rows = filterVisibleArchive(state.archive, effFilter);
      const oldNote = subPanel.querySelector(".arkmail-tresc-note");
      if (oldNote) oldNote.remove();
      if (archFilter.tresc !== void 0) {
        const base = filterVisibleArchive(state.archive, { ...effFilter, tresc: void 0 });
        const withBody2 = base.filter((l) => l.body.length > 0).length;
        const note = doc.createElement("div");
        note.className = "arkmail-dim arkmail-tresc-note";
        note.textContent = `Filtr tresci obejmuje tylko listy z pobrana trescia (${withBody2} z ${base.length}).`;
        subPanel.insertBefore(note, list);
      }
      list.replaceChildren(
        ...rows.flatMap((l, idx) => {
          const row = doc.createElement("div");
          row.className = "arkmail-arch-entry";
          const subj = doc.createElement("span");
          subj.className = "arkmail-arch-subject";
          subj.setAttribute("title", l.subject);
          subj.textContent = `${idx + 1}. ${l.subject}`;
          row.appendChild(subj);
          const meta = doc.createElement("span");
          meta.className = "arkmail-arch-meta";
          const dir = l.box === "odebrane" || l.box === "nieprzeczytane" ? "od" : "do";
          meta.textContent = `${dir} ${l.party} | ${l.box}`;
          row.appendChild(meta);
          const date = doc.createElement("span");
          date.className = "arkmail-arch-date";
          date.textContent = l.dateRaw && l.dateRaw.trim().length > 0 ? l.dateRaw : "brak daty";
          row.appendChild(date);
          makeClickable(row, () => handlers.onOpenArchiveLetter?.(l));
          return [row];
        })
      );
      if (rows.length === 0) {
        list.replaceChildren(dim("Archiwum jest puste albo zaden list nie pasuje do filtra."));
      }
    };
    repaint();
    return pane;
  };
  const dim = (text) => {
    const el = doc.createElement("div");
    el.className = "arkmail-dim";
    el.textContent = text;
    return el;
  };
  const mkDateField = (docRef, input, label, tooltip) => {
    const field = docRef.createElement("label");
    field.className = "arkmail-date-field";
    const caption = docRef.createElement("span");
    caption.className = "arkmail-date-label";
    caption.textContent = label;
    input.setAttribute("title", tooltip);
    field.appendChild(caption);
    field.appendChild(input);
    return field;
  };
  const off = store2.subscribe(render);
  render(store2.state);
  const onEscape = (event) => {
    if (event.key !== "Escape") return;
    const wasArmed = armedButtons.size > 0 || store2.state.deletion.armedAt !== 0;
    if (!wasArmed) return;
    event.preventDefault();
    event.stopPropagation();
    disarmAllButtons();
    if (store2.state.deletion.armedAt !== 0) store2.disarmDeletionConfirm();
  };
  const canListen = typeof doc.addEventListener === "function";
  if (canListen) doc.addEventListener("keydown", onEscape);
  return () => {
    off();
    if (canListen) doc.removeEventListener("keydown", onEscape);
    container.replaceChildren();
  };
}

// src/arkmail/ui/themeColors.ts
var BLACK = { r: 0, g: 0, b: 0, a: 1 };
var WHITE = { r: 1, g: 1, b: 1, a: 1 };
var NUMBER = /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i;
function numeric(value) {
  const token = value.trim();
  if (!NUMBER.test(token)) return null;
  const parsed = Number(token);
  return Number.isFinite(parsed) ? parsed : null;
}
function clamp01(value) {
  return Math.min(1, Math.max(0, value));
}
function alpha(value) {
  if (value === void 0) return 1;
  const token = value.trim();
  if (token.endsWith("%")) {
    const parsed2 = numeric(token.slice(0, -1));
    return parsed2 === null ? null : clamp01(parsed2 / 100);
  }
  const parsed = numeric(token);
  return parsed === null ? null : clamp01(parsed);
}
function channel(value, maximum) {
  const token = value.trim();
  if (token.endsWith("%")) {
    const parsed2 = numeric(token.slice(0, -1));
    return parsed2 === null ? null : clamp01(parsed2 / 100);
  }
  const parsed = numeric(token);
  return parsed === null ? null : clamp01(parsed / maximum);
}
function splitFunction(body) {
  const slash = body.split("/");
  if (slash.length > 2) return null;
  const channels = slash[0].trim().split(/\s+/).filter(Boolean);
  if (channels.length === 0) return null;
  return { channels, alpha: slash[1]?.trim() };
}
function parseRgb(body) {
  let parts;
  if (body.includes(",")) {
    if (body.includes("/")) return null;
    parts = body.split(",").map((part) => part.trim());
  } else {
    const split = splitFunction(body);
    if (!split) return null;
    parts = [...split.channels];
    if (split.alpha !== void 0) parts.push(split.alpha);
  }
  if (parts.length !== 3 && parts.length !== 4) return null;
  const rgb = parts.slice(0, 3).map((part) => channel(part, 255));
  if (rgb.some((part) => part === null)) return null;
  const a = alpha(parts[3]);
  return a === null ? null : { r: rgb[0], g: rgb[1], b: rgb[2], a };
}
function parseSrgb(body) {
  const match = body.match(/^srgb\s+([\s\S]+)$/i);
  if (!match) return null;
  const split = splitFunction(match[1]);
  if (!split || split.channels.length !== 3) return null;
  const rgb = split.channels.map((part) => channel(part, 1));
  if (rgb.some((part) => part === null)) return null;
  const a = alpha(split.alpha);
  return a === null ? null : { r: rgb[0], g: rgb[1], b: rgb[2], a };
}
function oklabPart(value) {
  const token = value.trim();
  if (token.endsWith("%")) {
    const parsed = numeric(token.slice(0, -1));
    return parsed === null ? null : parsed / 100 * 0.4;
  }
  return numeric(token);
}
function parseOklab(body) {
  const split = splitFunction(body);
  if (!split || split.channels.length !== 3) return null;
  const lightness = split.channels[0].endsWith("%") ? numeric(split.channels[0].slice(0, -1)) : numeric(split.channels[0]);
  if (lightness === null) return null;
  const l = split.channels[0].endsWith("%") ? lightness / 100 : lightness;
  const a = oklabPart(split.channels[1]);
  const b = oklabPart(split.channels[2]);
  const opacity = alpha(split.alpha);
  if (a === null || b === null || opacity === null) return null;
  const lRoot = l + 0.3963377774 * a + 0.2158037573 * b;
  const mRoot = l - 0.1055613458 * a - 0.0638541728 * b;
  const sRoot = l - 0.0894841775 * a - 1.291485548 * b;
  const l3 = lRoot ** 3;
  const m3 = mRoot ** 3;
  const s3 = sRoot ** 3;
  const r = 4.0767416621 * l3 - 3.3077115913 * m3 + 0.2309699292 * s3;
  const g = -1.2684380046 * l3 + 2.6097574011 * m3 - 0.3413193965 * s3;
  const blue = -0.0041960863 * l3 - 0.7034186147 * m3 + 1.707614701 * s3;
  return { r: clamp01(r), g: clamp01(g), b: clamp01(blue), a: opacity };
}
function parseCssColor(value) {
  const match = value.trim().match(/^(rgba?|color|oklab)\(\s*([\s\S]*?)\s*\)$/i);
  if (!match) return null;
  const kind = match[1].toLowerCase();
  const body = match[2];
  if (kind === "rgb" || kind === "rgba") return parseRgb(body);
  if (kind === "color") return parseSrgb(body);
  return parseOklab(body);
}
function compositeOver(foreground, background) {
  const a = foreground.a + background.a * (1 - foreground.a);
  if (a === 0) return { r: 0, g: 0, b: 0, a: 0 };
  const mix = (front, back) => (front * foreground.a + back * background.a * (1 - foreground.a)) / a;
  return {
    r: mix(foreground.r, background.r),
    g: mix(foreground.g, background.g),
    b: mix(foreground.b, background.b),
    a
  };
}
function luminance(value) {
  const linear = (channelValue) => channelValue <= 0.04045 ? channelValue / 12.92 : ((channelValue + 0.055) / 1.055) ** 2.4;
  return 0.2126 * linear(value.r) + 0.7152 * linear(value.g) + 0.0722 * linear(value.b);
}
function contrastRatio(first, second) {
  const a = luminance(first);
  const b = luminance(second);
  return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
}
function onAccentColor(accentValue, backgroundValue) {
  const accent = parseCssColor(accentValue);
  const background = parseCssColor(backgroundValue);
  if (!accent || !background) return null;
  const actualAccent = compositeOver(accent, background);
  if (actualAccent.a < 1) return null;
  return contrastRatio(actualAccent, BLACK) >= contrastRatio(actualAccent, WHITE) ? "rgb(0, 0, 0)" : "rgb(255, 255, 255)";
}
function installThemeColors(root) {
  const document2 = root.ownerDocument;
  const view = document2.defaultView;
  if (!view) return () => {
  };
  const refresh = () => {
    if (!root.isConnected) return false;
    const probe = document2.createElement("span");
    probe.style.position = "absolute";
    probe.style.visibility = "hidden";
    probe.style.pointerEvents = "none";
    probe.style.color = "var(--popup-accent)";
    probe.style.backgroundColor = "var(--popup-bg)";
    root.appendChild(probe);
    try {
      const computed = view.getComputedStyle(probe);
      const selected = onAccentColor(computed.color, computed.backgroundColor);
      if (!selected) return false;
      root.style.setProperty("--arkmail-on-accent", selected);
      return true;
    } finally {
      probe.remove();
    }
  };
  let frame = null;
  if (!refresh() && view.requestAnimationFrame) {
    let attempts = 0;
    const retry = () => {
      frame = null;
      attempts++;
      if (refresh() || attempts >= 60) return;
      frame = view.requestAnimationFrame(retry);
    };
    frame = view.requestAnimationFrame(retry);
  }
  const MutationObserver = view.MutationObserver;
  if (!MutationObserver) {
    return () => {
      if (frame !== null) view.cancelAnimationFrame(frame);
    };
  }
  const observer = new MutationObserver(refresh);
  const options = { attributes: true, attributeFilter: ["class", "style", "data-theme"] };
  observer.observe(document2.documentElement, options);
  observer.observe(document2.body, options);
  return () => {
    observer.disconnect();
    if (frame !== null) view.cancelAnimationFrame(frame);
  };
}

// src/arkmail/ui/animalHeader.ts
function createAnimalHeader(onSend) {
  const element = document.createElement("button");
  element.type = "button";
  element.className = "arkmail-animal-send popup-header-btn";
  element.addEventListener("click", onSend);
  return {
    element,
    update(wide, flying) {
      const accessibleName = flying ? "Zwierze w drodze..." : "Wyslij zwierze";
      element.textContent = flying ? wide ? "Zwierze w drodze..." : "W drodze..." : wide ? "Wyslij zwierze" : "Zwierze";
      element.disabled = flying;
      element.title = accessibleName;
      element.setAttribute("aria-label", accessibleName);
    }
  };
}

// src/arkmail/core/bulkDelete.ts
var compressRange = (numbers) => {
  const parts = [];
  for (let i = 0; i < numbers.length; ) {
    const from = numbers[i];
    let to = from;
    while (i + 1 < numbers.length && numbers[i + 1] === to + 1) to = numbers[++i];
    parts.push(from === to ? String(from) : `${from}-${to}`);
    i++;
  }
  return parts.join(",");
};
function matchSelectionOnFreshListing(selected, fresh) {
  if (selected.length === 0) return null;
  const available = /* @__PURE__ */ new Map();
  for (const entry of fresh) {
    const key = entryKey(entry);
    const entries = available.get(key);
    if (entries) entries.push(entry);
    else available.set(key, [entry]);
  }
  const matched = [];
  for (const entry of selected) {
    const candidate = available.get(entryKey(entry))?.shift();
    if (!candidate) return null;
    matched.push(candidate);
  }
  matched.sort((a, b) => a.number - b.number);
  const numbers = matched.map((entry) => entry.number);
  return { entries: matched, numbers, range: compressRange(numbers) };
}
function applyConfirmedDeletions(archive, box, fresh, confirmedNumbers) {
  const changedIds = /* @__PURE__ */ new Set();
  const changedBoxes = /* @__PURE__ */ new Set();
  if (confirmedNumbers.length === 0) return { letters: archive, changedIds, changedBoxes };
  const confirmed = new Set(confirmedNumbers);
  const remaining = /* @__PURE__ */ new Map();
  for (const entry of fresh) {
    const key = entryKey(entry);
    remaining.set(key, (remaining.get(key) ?? 0) + 1);
  }
  const removedContentKeys = /* @__PURE__ */ new Set();
  for (const entry of fresh) {
    if (!confirmed.has(entry.number)) continue;
    const key = entryKey(entry);
    const count = (remaining.get(key) ?? 1) - 1;
    remaining.set(key, count);
    if (count === 0) removedContentKeys.add(contentKeyOf(fromMailboxEntry(box, entry)));
  }
  if (removedContentKeys.size === 0) return { letters: archive, changedIds, changedBoxes };
  const incomingTwin = box === "odebrane" || box === "nieprzeczytane";
  const letters = archive.filter((letter) => {
    const samePhysicalLetter = letter.box === box || incomingTwin && (letter.box === "odebrane" || letter.box === "nieprzeczytane");
    if (!samePhysicalLetter || !removedContentKeys.has(contentKeyOf(letter))) {
      return true;
    }
    changedIds.add(letter.id);
    changedBoxes.add(letter.box);
    return false;
  });
  if (changedIds.size === 0) return { letters: archive, changedIds, changedBoxes };
  return { letters, changedIds, changedBoxes };
}

// src/arkmail/index.ts
var POPUP_ID = "arkmail";
var FOOTER_BUTTON_ID = "arkmail";
var FOOTER_STATE = "arkmail-poczta";
var ALIAS_REGEX = /^\/arkmail$/i;
var SESSION_OPTS = { timeoutMs: 8e3, idleMs: 400 };
var WIDE_MIN_WIDTH = 900;
var shouldUseWideLayout = (width, fontScale) => {
  const scale = Number.isFinite(fontScale) && fontScale > 0 ? fontScale : 1;
  return width >= WIDE_MIN_WIDTH * scale;
};
var readWindowFontScale = (root) => {
  const view = root.ownerDocument.defaultView;
  if (!view) return 1;
  const raw = view.getComputedStyle(root).getPropertyValue("--window-font-scale").trim();
  const direct = Number(raw);
  if (Number.isFinite(direct) && direct > 0) return direct;
  const probe = root.ownerDocument.createElement("span");
  probe.style.position = "absolute";
  probe.style.visibility = "hidden";
  probe.style.pointerEvents = "none";
  probe.style.width = "calc(1px * var(--window-font-scale, 1))";
  root.appendChild(probe);
  try {
    const measured = Number.parseFloat(view.getComputedStyle(probe).width);
    return Number.isFinite(measured) && measured > 0 ? measured : 1;
  } finally {
    probe.remove();
  }
};
var LOAD_ALL_PACE_MS = PAGE_PACE_MS;
var INDEX_PACE_MS = PAGE_PACE_MS;
var INDEX_ANCHOR_RETRY_WAITS_MS = ANCHOR_RETRY_WAITS_MS;
var PLAYER_MAIL_MODE_IDLE_MS = 18e4;
var INDEX_FULL_SWEEP_AGE_MS = 7 * 24 * 60 * 60 * 1e3;
var indexSweepMode = (meta, box, now) => {
  const stamp = meta[box];
  if (stamp === void 0) return "full";
  const t = Date.parse(stamp);
  if (Number.isNaN(t)) return "full";
  return now - t > INDEX_FULL_SWEEP_AGE_MS ? "full" : "incremental";
};
var SESSION_BUSY_MSG = "Poczekaj, az skoncze biezaca operacje.";
var OPERATION_TIMEOUT_MSG = "Serwer nie odpowiedzial na czas. Sprobuj ponownie.";
var SEND_FAILURE_MSG = "Nie udalo sie wyslac listu. Sprobuj ponownie.";
var FORWARD_FAILURE_MSG = "Nie udalo sie przekazac listu. Sprobuj ponownie.";
var mailErrorText = (error) => {
  if (error.kind === "brak-adresata") return `Nie ma takiego adresata: ${error.adresat}.`;
  if (error.kind === "zly-numer") return `Zly numer listu: ${error.numer}.`;
  return "Zadne listy nie zostaly wybrane.";
};
var isPagerTimeout = (error) => error instanceof Error && /^timeout: pager session list \d+$/.test(error.message);
var MAIL_ENTRY_CMD_RE = /^\s*(?:list\b|listy\b|przec\w*|poczt\w*)/i;
var ANIMAL_TIMING = { flightTimeoutMs: 6e4, sluchamWindowMs: 2e3 };
var listingCtxSeq = 0;
var listingCtx = null;
var NOTIFY_KEY = "powiadomienia";
var AUTO_REFRESH_KEY = "automatyczne-odswiezanie";
var COMPOSE_KEY = "compose";
var INDEX_KEY = "indeks";
var ARCHIVE_GAPS_KEY = "luki-archiwum";
var expandLocalGroup = (value, state) => {
  const key = value.toLowerCase();
  const group = state.groups.find((candidate) => candidate.name.toLowerCase() === key && candidate.members.length > 0 && !groupAliasConflict(candidate.name, state.importedAliases));
  return group ? group.members.join(", ") : value;
};
var apiRef = null;
var storageRef = null;
var popup = null;
var menuHandle = null;
var footerHandle = null;
var aliasId = null;
var transport = null;
var store = null;
var unmount = null;
var unsubBadge = null;
var unsubAnimalHeader = null;
var animalHeader = null;
var wideObserver = null;
var scaleProbe = null;
var themeColorCleanup = null;
var animalTimer = null;
var sluchamTimer = null;
var unsentFlashTimer = null;
var delayedInboxTimers = [];
var DELAYED_INBOX_RETRY_MS = [1e4, 25e3];
var playerMailModeTimer = null;
var deactivateActiveCharacter = null;
var unsubscribeCharacter = null;
var lifecycleDestroyed = false;
function createContent() {
  const root = document.createElement("div");
  root.style.height = "100%";
  root.style.minHeight = "0";
  themeColorCleanup?.();
  themeColorCleanup = null;
  if (unmount) {
    unmount();
    unmount = null;
  }
  if (wideObserver) {
    wideObserver.disconnect();
    wideObserver = null;
  }
  scaleProbe?.remove();
  scaleProbe = null;
  if (store && handlersRef) {
    unmount = mountMailUi(root, store, handlersRef);
    const themedRoot = root.querySelector(".arkmail-root");
    if (themedRoot) themeColorCleanup = installThemeColors(themedRoot);
    if (typeof ResizeObserver !== "undefined") {
      const s = store;
      let rootWidth = 0;
      let measuredScale = 1;
      wideObserver = new ResizeObserver((entries) => {
        for (const entry of entries) {
          if (entry.target === scaleProbe) measuredScale = entry.contentRect.width;
          else if (entry.target === root || entry.target === void 0) rootWidth = entry.contentRect.width;
        }
        if (!scaleProbe && root.parentElement) {
          const probe = root.ownerDocument.createElement("span");
          probe.setAttribute("data-arkmail-scale-probe", "");
          probe.setAttribute("aria-hidden", "true");
          probe.style.position = "absolute";
          probe.style.visibility = "hidden";
          probe.style.pointerEvents = "none";
          probe.style.width = "calc(1px * var(--window-font-scale, 1))";
          probe.style.height = "0";
          probe.style.padding = "0";
          probe.style.border = "0";
          root.parentElement.appendChild(probe);
          scaleProbe = probe;
          const initial = Number.parseFloat(
            root.ownerDocument.defaultView?.getComputedStyle(probe).width ?? ""
          );
          if (Number.isFinite(initial) && initial > 0) measuredScale = initial;
          wideObserver?.observe(probe);
        } else if (!scaleProbe) {
          measuredScale = readWindowFontScale(root);
        }
        s.setWide(shouldUseWideLayout(rootWidth, measuredScale));
      });
      wideObserver.observe(root);
    }
  }
  return root;
}
var handlersRef = null;
async function init(api) {
  apiRef = api;
  lifecycleDestroyed = false;
  cleanupLegacyStorage();
  animalHeader = createAnimalHeader(() => handlersRef?.onSendAnimal?.());
  popup = await api.ui.registerPersistentPopup({
    id: POPUP_ID,
    title: PLUGIN_NAME,
    headerActions: animalHeader.element,
    // Start: szeroki dwupanelowy na normalnym ekranie, waski na komorce
    // (85vw). Rozmiar ustawiony przez gracza zawsze wygrywa z tymi
    // wartosciami - po zmianie domyslnego pomocny jest reset rozmiaru.
    initialWidth: "min(1400px, 85vw)",
    initialHeight: "min(850px, 80vh)",
    createContent
  });
  popup.onClose(() => store?.resetDeletion());
  const toggle = () => {
    if (!popup) return true;
    if (popup.isOpen) popup.close();
    else void popup.open();
    return true;
  };
  aliasId = api.aliases.register(ALIAS_REGEX, toggle);
  menuHandle = api.ui.addPopupMenuEntry(PLUGIN_NAME, () => {
    if (popup && !popup.isOpen) void popup.open();
  });
  footerHandle = api.ui.registerFooterButton(FOOTER_BUTTON_ID, {
    label: PLUGIN_NAME,
    command: "/arkmail",
    state: FOOTER_STATE
  });
  let requestedName = api.character.getName();
  let activeName = null;
  let switchQueue = Promise.resolve();
  const refreshPopup = () => {
    if (popup?.isOpen) popup.setBody(createContent());
  };
  const deactivateCurrent = async () => {
    const deactivate = deactivateActiveCharacter;
    deactivateActiveCharacter = null;
    if (deactivate) await deactivate();
    activeName = null;
    refreshPopup();
  };
  const activateCharacter = async (character) => {
    const storage = await openCharStorage(character, () => notify(api, STORAGE_WRITE_ERROR, { level: "error" }));
    if (lifecycleDestroyed || character.trim().toLowerCase() !== requestedName?.trim().toLowerCase()) {
      await storage.close();
      return false;
    }
    storageRef = storage;
    transport = new DargothTransport(api);
    const lock = new SessionLock();
    const tasks = /* @__PURE__ */ new Set();
    const trackTask = (task) => {
      const tracked = task.finally(() => tasks.delete(tracked));
      tasks.add(tracked);
      return tracked;
    };
    const runExclusive = (operation) => trackTask(lock.runExclusive(operation));
    let connectionGeneration = 0;
    let archiveDownloadEta = null;
    const cancelListeners = /* @__PURE__ */ new Set();
    const sessionOpts = {
      ...SESSION_OPTS,
      onCancel: (cb) => {
        cancelListeners.add(cb);
        return () => cancelListeners.delete(cb);
      }
    };
    let composeVisible = false;
    transport.setGagPredicate(() => lock.locked && !composeVisible);
    const archive = normalizeArchive(storage.getLetters()).filter(
      (l) => l.missingOnServer !== true
    );
    storage.setLetters(archive);
    const composePrefs = storage.getJSON(COMPOSE_KEY);
    store = new MailUiStore({
      characterName: character,
      notifyEnabled: storage.getJSON(NOTIFY_KEY) ?? true,
      autoRefreshEnabled: storage.getJSON(AUTO_REFRESH_KEY) ?? true,
      archive,
      composeTemplate: composePrefs?.template ?? "plain",
      composeWidth: composePrefs?.width ?? 60,
      // Fala 18c: flagi kompletnej indeksacji skrzynek (brama Kontaktow).
      indexMeta: storage.getJSON(INDEX_KEY) ?? {},
      archiveGaps: storage.getJSON(ARCHIVE_GAPS_KEY) ?? {},
      // Fala UI-2: ksiazka adresowa (osobne klucze; wipe jej nie tyka).
      // Imiona: migracja ze starego klucza pul jest jednorazowa i
      // zostawia stary klucz nietkniety (bezpieczny rollback).
      people: migratePeople(storage),
      importedAliases: loadImportedAliases(storage),
      groups: loadGroups(storage)
    });
    const ui = store;
    unsubAnimalHeader?.();
    unsubAnimalHeader = ui.subscribe((state) => {
      animalHeader?.update(state.wide, state.animalFlying);
    });
    animalHeader?.update(ui.state.wide, ui.state.animalFlying);
    const mailbox = new MailboxSession(transport, sessionOpts);
    const pager = new PagerSession(transport, sessionOpts);
    const editor = new EditorSession(transport, sessionOpts);
    const importer = new ImportSession(transport, sessionOpts);
    const rebuildContacts = () => {
      ui.setContacts(
        contactsFromArchiveWithAliases(ui.state.archive, ui.state.importedAliases)
      );
    };
    rebuildContacts();
    const importPeople = (kind) => {
      if (lock.locked) {
        notify(api, SESSION_BUSY_MSG, { level: "warning" });
        return;
      }
      const label = kind === "zapamietani" ? "zapamietanych" : "przedstawionych";
      const generation = connectionGeneration;
      ui.setBusy(`Importuje ${label}...`);
      void runExclusive(async () => {
        const names = await importer.fetchPeople(kind);
        if (generation !== connectionGeneration) return;
        const before = ui.state.people.length;
        const people = unionPeople(ui.state.people, names);
        savePeople(storage, people);
        ui.setPeople(people);
        notify(api, `Liczba pobranych osob: ${names.length}. Liczba nowych osob w ksiazce: ${people.length - before}.`, { level: "success" });
      }).catch((err) => {
        if (!isOperationCancelled(err)) {
          notify(api, "Nie udalo sie zaimportowac osob z gry.", { level: "error" });
        }
      }).finally(() => {
        if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
      });
    };
    const importAliases = () => {
      if (lock.locked) {
        notify(api, SESSION_BUSY_MSG, { level: "warning" });
        return;
      }
      const generation = connectionGeneration;
      ui.setBusy("Importuje aliasy pocztowe...");
      void runExclusive(async () => {
        const aliases = await importer.fetchAliases();
        if (generation !== connectionGeneration) return;
        const oldConflicts = new Set(
          findGroupAliasConflicts(ui.state.groups, ui.state.importedAliases).map((group) => group.name.trim().toLowerCase())
        );
        const newConflicts = findGroupAliasConflicts(ui.state.groups, aliases).filter((group) => !oldConflicts.has(group.name.trim().toLowerCase()));
        saveImportedAliases(storage, aliases);
        ui.setImportedAliases(aliases);
        const before = ui.state.people.length;
        const people = unionPeople(
          ui.state.people,
          aliases.flatMap((a) => a.targets)
        );
        savePeople(storage, people);
        ui.setPeople(people);
        rebuildContacts();
        notify(api, `Zaimportowano aliasy. Liczba aliasow: ${aliases.length}. Liczba osob dopisanych do ksiazki: ${people.length - before}.`, { level: "success" });
        if (newConflicts.length > 0) {
          notify(api, `Nowe konflikty grup z aliasami: ${newConflicts.map((group) => group.name).join(", ")}.`, { level: "warning" });
        }
      }).catch((err) => {
        if (!isOperationCancelled(err)) {
          notify(api, "Nie udalo sie zaimportowac aliasow z gry.", { level: "error" });
        }
      }).finally(() => {
        if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
      });
    };
    const flashUnsent = () => {
      ui.setUnsentFlash(true);
      if (unsentFlashTimer !== null) clearTimeout(unsentFlashTimer);
      unsentFlashTimer = setTimeout(() => {
        unsentFlashTimer = null;
        ui.setUnsentFlash(false);
      }, 3e3);
    };
    const fetchBoxes = async (boxes, mode, source, automatic = false) => {
      const autoDisabled = () => automatic && !ui.state.autoRefreshEnabled;
      for (let index = 0; index < boxes.length; index++) {
        const box = boxes[index];
        const parkRemaining = () => {
          if (source !== "auto" || !playerMailMode) return;
          for (const pending of boxes.slice(index)) pendingRefresh.add(pending);
        };
        if (autoDisabled()) throw new Error("operacja anulowana");
        if (playerMailMode) {
          parkRemaining();
          throw new Error("operacja anulowana");
        }
        ui.setBusy(`Pobieram skrzynke ${box}...`);
        let res;
        try {
          res = await mailbox.fetch(box);
        } catch (error) {
          if (isOperationCancelled(error)) parkRemaining();
          throw error;
        }
        if (autoDisabled()) throw new Error("operacja anulowana");
        if (playerMailMode) {
          parkRemaining();
          throw new Error("operacja anulowana");
        }
        const boundaryDay = (() => {
          if (res.kind !== "lista") return void 0;
          const oldest = oldestEntry(res.entries);
          if (!oldest?.date) return void 0;
          const p = (n) => String(n).padStart(2, "0");
          return `${oldest.date.year}-${p(oldest.date.month)}-${p(oldest.date.day)}`;
        })();
        let resolvedIds;
        if (res.kind === "lista") {
          const listingRecords = recordsOfListing(box, res.entries);
          if (!res.header.truncated && res.confirmed !== false) {
            const replaced = replaceBoxLetters(ui.state.archive, box, listingRecords);
            ui.setArchive(replaced.letters);
            resolvedIds = replaced.resolvedIds;
            if (replaced.removedIds.size > 0) pruneGoneFromView(box, replaced.removedIds);
            clearArchiveGaps(box);
            ui.setIndexMeta({ ...ui.state.indexMeta, [box]: (/* @__PURE__ */ new Date()).toISOString() });
            persistIndexMeta();
          } else {
            const merged = mergeListingPage(ui.state.archive, box, listingRecords);
            ui.setArchive(merged.letters);
            resolvedIds = merged.resolvedIds;
            if (res.confirmed !== false && boundaryDay !== void 0) {
              markGoneFromServerNewerThan(box, merged.freshIds, boundaryDay);
            }
          }
        } else if (res.kind === "pusta" && res.reason === "puste") {
          const replaced = replaceBoxLetters(ui.state.archive, box, []);
          ui.setArchive(replaced.letters);
          if (replaced.removedIds.size > 0) pruneGoneFromView(box, replaced.removedIds);
          clearArchiveGaps(box);
          ui.setIndexMeta({ ...ui.state.indexMeta, [box]: (/* @__PURE__ */ new Date()).toISOString() });
          persistIndexMeta();
        }
        if (res.kind === "lista") stampEntries(box, res.entries, resolvedIds);
        else bumpCtx(box);
        if (res.kind === "lista" && mode === "sync" && res.confirmed !== false) {
          const synced = ui.syncMailboxPage(box, res.entries, res.header.truncated, boundaryDay);
          if (!synced) ui.applyMailbox(box, res);
        } else {
          ui.applyMailbox(box, res);
        }
        finalizeArchiveChange();
      }
    };
    const pruneGoneFromView = (box, removedIds) => {
      ui.pruneMailboxEntries(box, removedIds);
    };
    const markGoneFromServerNewerThan = (box, freshIds, boundaryDay) => {
      const purged = purgeGoneLettersNewerThan(ui.state.archive, box, freshIds, boundaryDay);
      if (purged.removedIds.size === 0) return;
      ui.setArchive(purged.letters);
      pruneGoneFromView(box, purged.removedIds);
    };
    const refreshBoxes = (boxes, mode = "sync", source = "auto", automatic = false) => {
      if (automatic && !ui.state.autoRefreshEnabled) return;
      if (ui.state.tab === "usuwanie") ui.resetDeletion();
      ui.clearSearchBoxes(boxes);
      const generation = connectionGeneration;
      let cancelled = false;
      void runExclusive(async () => {
        await fetchBoxes(boxes, mode, source, automatic);
      }).catch((err) => {
        cancelled = isOperationCancelled(err);
        if (source === "manual" && !cancelled) {
          notify(api, humanizeMailError(err instanceof Error ? err.message : String(err)), {
            title: "Blad odswiezania",
            level: "error"
          });
        }
      }).finally(() => {
        if (generation !== connectionGeneration) return;
        ui.setBusy(null);
        if (cancelled && source === "auto" && pendingRefresh.size > 0) scheduleRefresh([]);
      });
    };
    const cancelConnectionOperations = (resetMailState = true) => {
      connectionGeneration++;
      listingCtx = null;
      if (resetMailState) lastMailState = null;
      clearPagerOrphan();
      transport.setOnline(false);
      lock.cancelWaiting();
      for (const cancel of [...cancelListeners]) cancel();
      if (loadAllFlag) cancelFlag(loadAllFlag);
      if (indexFlag) cancelFlag(indexFlag);
      if (archiveDownloadFlag) cancelFlag(archiveDownloadFlag);
      archiveDownloadEta = null;
      loadAllFlag = null;
      indexFlag = null;
      archiveDownloadFlag = null;
      pendingRefresh.clear();
      drainScheduled = false;
      ui.setBusy(null);
      ui.setLoadAll(null);
      ui.setIndexRun(null);
      ui.setArchiveDownload(null);
      ui.resetDeletion();
    };
    let lastUpstreamClosed = false;
    const onClientConnect = () => {
      lastUpstreamClosed = false;
      cancelConnectionOperations(false);
    };
    const armGameTransport = () => {
      transport.setOnline(true);
    };
    const onGamePresence = () => {
      if (lastUpstreamClosed) return;
      armGameTransport();
    };
    const onAnyGmcp = () => {
      if (lastUpstreamClosed) return;
      armGameTransport();
    };
    const onProxySession = (session) => {
      const s = session;
      if (s?.resumed === true && !s?.upstreamClosed) {
        lastUpstreamClosed = false;
        armGameTransport();
        refreshBoxes(["odebrane", "nieprzeczytane", "wyslane", "niewyslane"], "sync", "auto", true);
      } else if (s?.upstreamClosed === true) {
        lastUpstreamClosed = true;
        onClientDisconnect();
      } else {
        lastUpstreamClosed = false;
      }
    };
    const onClientDisconnect = () => {
      cancelConnectionOperations();
      playerMailMode = false;
      awaitingPlayerMailPrompt = false;
      clearPlayerMailModeTimer();
    };
    const onSystemLogin = () => {
      onClientDisconnect();
    };
    api.events.on("client.connect", onClientConnect);
    api.events.on("client.disconnect", onClientDisconnect);
    api.events.on("gmcp", onAnyGmcp);
    api.events.on("gmcp.char.info", onGamePresence);
    api.events.on("gmcp.char.name", onGamePresence);
    api.events.on("gmcp.mail.state", onGamePresence);
    api.events.on("gmcp_msg.room.long", onGamePresence);
    api.events.on("proxy.session", onProxySession);
    api.events.on("gmcp_msg.system.login", onSystemLogin);
    const pendingRefresh = /* @__PURE__ */ new Set();
    let drainScheduled = false;
    let playerMailMode = false;
    let awaitingPlayerMailPrompt = false;
    const scheduleRefresh = (boxes) => {
      if (!ui.state.autoRefreshEnabled) return;
      for (const b of boxes) pendingRefresh.add(b);
      if (playerMailMode) return;
      if (drainScheduled) return;
      drainScheduled = true;
      const generation = connectionGeneration;
      void runExclusive(async () => {
        if (!ui.state.autoRefreshEnabled) {
          pendingRefresh.clear();
          return;
        }
        const batch = [...pendingRefresh];
        pendingRefresh.clear();
        ui.clearSearchBoxes(batch);
        await fetchBoxes(batch, "sync", "auto", true);
      }).catch(() => {
      }).finally(() => {
        if (generation !== connectionGeneration) return;
        ui.setBusy(null);
        drainScheduled = false;
        if (pendingRefresh.size > 0) scheduleRefresh([]);
      });
    };
    const clearPlayerMailModeTimer = () => {
      if (playerMailModeTimer !== null) {
        clearTimeout(playerMailModeTimer);
        playerMailModeTimer = null;
      }
    };
    const exitPlayerMailMode = () => {
      if (!playerMailMode) return;
      playerMailMode = false;
      awaitingPlayerMailPrompt = false;
      clearPlayerMailModeTimer();
      scheduleRefresh(["odebrane", "nieprzeczytane"]);
    };
    const armPlayerMailModeIdle = () => {
      clearPlayerMailModeTimer();
      playerMailModeTimer = setTimeout(() => {
        playerMailModeTimer = null;
        exitPlayerMailMode();
      }, PLAYER_MAIL_MODE_IDLE_MS);
    };
    const enterPlayerMailMode = () => {
      if (playerMailMode) {
        if (!awaitingPlayerMailPrompt) armPlayerMailModeIdle();
        return;
      }
      playerMailMode = true;
      awaitingPlayerMailPrompt = false;
      armPlayerMailModeIdle();
      lock.cancelWaiting();
      for (const cancel of [...cancelListeners]) cancel();
      if (loadAllFlag) cancelFlag(loadAllFlag);
      if (indexFlag) cancelFlag(indexFlag);
      if (archiveDownloadFlag) cancelFlag(archiveDownloadFlag);
      archiveDownloadEta = null;
      for (const timer of delayedInboxTimers) clearTimeout(timer);
      delayedInboxTimers = [];
      ui.setBusy(null);
      ui.setLoadAll(null);
      ui.setIndexRun(null);
      ui.setArchiveDownload(null);
    };
    const awaitPlayerMailPrompt = () => {
      if (!playerMailMode) return;
      awaitingPlayerMailPrompt = true;
      clearPlayerMailModeTimer();
    };
    const beginPagerModal = () => {
      transport.beginModal({
        pager: {
          onUserCommand: (command) => {
            enterPlayerMailMode();
            if (/^(?:q|x)$/i.test(command.trim())) awaitPlayerMailPrompt();
          },
          onCommandDropped: () => notify(
            api,
            "Nie wykonano komendy pocztowej, poniewaz tryb czytania poczty zostal juz zamkniety. Otworz poczte recznie i powtorz komende.",
            { level: "warning" }
          )
        }
      });
    };
    const scheduleDelayedInboxRefresh = () => {
      for (const t of delayedInboxTimers) clearTimeout(t);
      delayedInboxTimers = [];
      if (!ui.state.autoRefreshEnabled) return;
      delayedInboxTimers = DELAYED_INBOX_RETRY_MS.map(
        (ms) => setTimeout(() => scheduleRefresh(["odebrane", "nieprzeczytane"]), ms)
      );
    };
    let lastMailState = null;
    const onMailState = (d) => {
      if (!d || typeof d !== "object") return;
      const s = d;
      if (typeof s.unread !== "boolean" || typeof s.unreceived !== "boolean" || typeof s.unsent !== "boolean") {
        return;
      }
      const cur = { unread: s.unread, unreceived: s.unreceived, unsent: s.unsent };
      const prev = lastMailState;
      if (prev && cur.unread === prev.unread && cur.unreceived === prev.unreceived && cur.unsent === prev.unsent) {
        return;
      }
      lastMailState = cur;
      const boxes = /* @__PURE__ */ new Set();
      const inboxTouched = prev ? cur.unread !== prev.unread || cur.unreceived !== prev.unreceived : cur.unread || cur.unreceived;
      if (inboxTouched) {
        boxes.add("odebrane");
        boxes.add("nieprzeczytane");
      }
      if (prev ? cur.unsent !== prev.unsent : cur.unsent) {
        boxes.add("niewyslane");
        boxes.add("wyslane");
      }
      if (boxes.size > 0) scheduleRefresh([...boxes]);
    };
    api.events.on("gmcp.mail.state", onMailState);
    const persistArchive = () => {
      storage.setLetters(ui.state.archive);
    };
    const persistArchiveConfirmed = async (letters) => {
      await storage.setLettersConfirmed(letters);
    };
    const finalizeArchiveChange = () => {
      persistArchive();
      rebuildContacts();
    };
    const persistIndexMeta = () => {
      storage.setJSON(INDEX_KEY, ui.state.indexMeta);
    };
    const persistArchiveGaps = () => {
      storage.setJSON(ARCHIVE_GAPS_KEY, ui.state.archiveGaps);
    };
    const recordArchiveGap = (box, day) => {
      const days = [.../* @__PURE__ */ new Set([...ui.state.archiveGaps[box] ?? [], day])].sort();
      ui.setArchiveGaps({ ...ui.state.archiveGaps, [box]: days });
      persistArchiveGaps();
      if (ui.state.indexMeta[box] !== void 0) {
        const meta = { ...ui.state.indexMeta };
        delete meta[box];
        ui.setIndexMeta(meta);
        persistIndexMeta();
      }
    };
    const clearArchiveGaps = (box) => {
      if (ui.state.archiveGaps[box] === void 0) return;
      const gaps = { ...ui.state.archiveGaps };
      delete gaps[box];
      ui.setArchiveGaps(gaps);
      persistArchiveGaps();
    };
    const bumpCtx = (box) => {
      listingCtxSeq += 1;
      listingCtx = { box, stamp: listingCtxSeq };
    };
    const stampEntries = (box, entries, ids) => {
      bumpCtx(box);
      for (let i = 0; i < entries.length; i++) {
        entries[i].ctx = { box, stamp: listingCtxSeq };
        const id = ids?.[i];
        if (id !== void 0) entries[i].archiveId = id;
      }
    };
    const recordsOfListing = (box, entries) => {
      const scanKey = scanKeyOfEntries(entries);
      return entries.map((e, i) => fromMailboxEntry(box, e, scanKey, i));
    };
    const snapshotRecords = (box) => {
      const byId = new Map(ui.state.archive.map((l) => [l.id, l]));
      const out = [];
      for (const e of ui.state.boxes[box]?.entries ?? []) {
        const rec = e.archiveId !== void 0 ? byId.get(e.archiveId) : void 0;
        if (rec) out.push(rec);
      }
      return out;
    };
    const resolveEntry = async (box, entry) => {
      if (entry.ctx !== void 0 && listingCtx !== null && entry.ctx.stamp === listingCtx.stamp && entry.ctx.box === listingCtx.box) {
        return entry;
      }
      if (!entry.date) {
        notify(api, "Nie mozna odnalezc tego listu - odswiez skrzynke.", { level: "warning" });
        return null;
      }
      const generation = connectionGeneration;
      const flag = { cancelled: false };
      const offCancel = sessionOpts.onCancel(() => {
        cancelFlag(flag);
      });
      let fresh = null;
      try {
        const scan = await scanMailboxPages({
          box,
          initialCommand: olderListingCommand(box, nextDay(entry.date)),
          cancelled: () => flag.cancelled || generation !== connectionGeneration,
          fetchPage: (command) => mailbox.fetch(box, command),
          wait: (ms) => sleepOrCancel(ms, flag, "skan"),
          onBaseRefresh: () => bumpCtx(box),
          onEmpty: () => bumpCtx(box),
          onGap: (day) => recordArchiveGap(box, day),
          onPage: (res) => {
            const records = recordsOfListing(box, res.entries);
            const merged = mergeListingPage(ui.state.archive, box, records);
            ui.setArchive(merged.letters);
            persistArchive();
            stampEntries(box, res.entries, merged.resolvedIds);
            if (entry.archiveId !== void 0) {
              fresh = res.entries.find((item) => item.archiveId === entry.archiveId) ?? null;
            } else {
              fresh = res.entries.find(
                (item) => entryKey(item) === entryKey(entry) && item.number === entry.number
              ) ?? null;
            }
            return { stop: fresh !== null };
          }
        });
        if (fresh) return fresh;
        if (scan.end === "cancelled") throw new Error("operacja anulowana");
        if (scan.end === "incomplete") {
          throw new Error("Nie mozna sprawdzic calej listy - sprobuj ponownie.");
        }
      } finally {
        offCancel();
      }
      notify(api, "Nie mozna odnalezc tego listu - odswiez skrzynke.", { level: "warning" });
      return null;
    };
    const loadOlder = (box) => {
      const generation = connectionGeneration;
      const flag = { cancelled: false };
      ui.setBusy("Wczytuje starsze listy...");
      void runExclusive(async () => {
        const view = ui.state.boxes[box];
        const oldest = oldestEntry(view?.entries ?? []);
        if (!oldest?.date) {
          notify(api, "Nie mozna wczytac starszych - najpierw pobierz skrzynke.", { level: "warning" });
          return;
        }
        const scan = await scanMailboxPages({
          box,
          initialCommand: olderListingCommand(box, nextDay(oldest.date)),
          singlePage: true,
          cancelled: () => flag.cancelled || generation !== connectionGeneration,
          fetchPage: (command) => mailbox.fetch(box, command),
          wait: (ms) => sleepOrCancel(ms, flag, "skan"),
          onBaseRefresh: () => bumpCtx(box),
          onGap: (day) => recordArchiveGap(box, day),
          onEmpty: () => bumpCtx(box),
          onPage: (res) => {
            const records = recordsOfListing(box, res.entries);
            const merged = mergeListingPage(ui.state.archive, box, records);
            ui.setArchive(merged.letters);
            persistArchive();
            stampEntries(box, res.entries, merged.resolvedIds);
            const addedToView = ui.appendMailboxPage(box, res.entries, res.header.truncated);
            return { addedToView, archiveAdded: merged.added };
          }
        });
        if (scan.end === "cancelled") return;
        if (scan.end === "complete" && scan.pages === 0 && scan.unconfirmedPages === 0) {
          ui.appendMailboxPage(box, [], false);
          clearArchiveGaps(box);
          ui.setIndexMeta({ ...ui.state.indexMeta, [box]: (/* @__PURE__ */ new Date()).toISOString() });
          persistIndexMeta();
          notify(api, "Brak starszych listow.");
        } else if (scan.end === "incomplete") {
          notify(
            api,
            `W widoku: ${ui.state.boxes[box]?.entries.length ?? 0} (dodano: ${scan.addedToView}). ${scan.skipWhy ?? "Sprobuj ponownie za chwile"}.`,
            { title: "Wczytano dostepne listy", level: "warning" }
          );
        } else {
          const confirmationNote = scan.unconfirmedPages > 0 ? ` Nie potwierdzono zamkniecia odpowiedzi: ${scan.unconfirmedPages}. Archiwum zachowano bez usuwania wpisow.` : "";
          notify(
            api,
            `W widoku: ${ui.state.boxes[box]?.entries.length ?? 0} (dodano: ${scan.addedToView}).${confirmationNote}`,
            { title: "Wczytano starsze listy", level: scan.unconfirmedPages > 0 ? "warning" : "success" }
          );
        }
      }).catch((err) => {
        if (!isOperationCancelled(err)) {
          notify(
            api,
            humanizeMailError(err instanceof Error ? err.message : String(err)),
            { title: "Blad wczytywania starszych", level: "error" }
          );
        }
      }).finally(() => {
        if (generation !== connectionGeneration) return;
        ui.setBusy(null);
        rebuildContacts();
      });
    };
    let loadAllFlag = null;
    const sleepOrCancel = async (ms, flag, stage) => waitOrCancel(ms, flag, stage, sessionOpts.onCancel);
    const loadAll = (box) => {
      if (loadAllFlag) {
        cancelFlag(loadAllFlag);
        return;
      }
      if (lock.locked) {
        notify(api, SESSION_BUSY_MSG, { level: "warning" });
        return;
      }
      const flag = { cancelled: false };
      loadAllFlag = flag;
      ui.setLoadAll({ box, pages: 0 });
      const generation = connectionGeneration;
      void runExclusive(async () => {
        try {
          const view = ui.state.boxes[box];
          const oldest = oldestEntry(view?.entries ?? []);
          if (!view?.truncated || !oldest?.date) return;
          const scan = await scanMailboxPages({
            box,
            initialCommand: olderListingCommand(box, nextDay(oldest.date)),
            cancelled: () => flag.cancelled || generation !== connectionGeneration,
            fetchPage: (command) => mailbox.fetch(box, command),
            wait: (ms) => sleepOrCancel(ms, flag, "skan"),
            onBaseRefresh: () => bumpCtx(box),
            onGap: (day) => recordArchiveGap(box, day),
            onEmpty: () => bumpCtx(box),
            onPage: (res, pages) => {
              const records = recordsOfListing(box, res.entries);
              const merged = mergeListingPage(ui.state.archive, box, records);
              ui.setArchive(merged.letters);
              persistArchive();
              stampEntries(box, res.entries, merged.resolvedIds);
              const addedToView = ui.appendMailboxPage(box, res.entries, res.header.truncated);
              ui.setLoadAll({ box, pages });
              ui.setBusy(`Wczytuje wszystkie (${box}): strona ${pages}...`);
              return { addedToView, archiveAdded: merged.added };
            }
          });
          if (scan.end === "cancelled") {
            notify(
              api,
              `Dodano do widoku: ${scan.addedToView}.`,
              { title: "Przerwano wczytywanie", level: "warning" }
            );
            return;
          }
          if (scan.end === "complete") {
            ui.appendMailboxPage(box, [], false);
            if (scan.unconfirmedPages === 0) {
              clearArchiveGaps(box);
              const done = ui.state.boxes[box];
              if (done && !done.truncated) {
                const replaced = replaceBoxLetters(ui.state.archive, box, snapshotRecords(box));
                ui.setArchive(replaced.letters);
                if (replaced.removedIds.size > 0) pruneGoneFromView(box, replaced.removedIds);
                ui.setIndexMeta({ ...ui.state.indexMeta, [box]: (/* @__PURE__ */ new Date()).toISOString() });
                persistIndexMeta();
              }
              notify(
                api,
                `W widoku: ${ui.state.boxes[box]?.entries.length ?? 0} (dodano: ${scan.addedToView}).`,
                { title: "Wczytano wszystkie", level: "success" }
              );
            } else {
              notify(
                api,
                `W widoku: ${ui.state.boxes[box]?.entries.length ?? 0} (dodano: ${scan.addedToView}). Nie potwierdzono zamkniecia odpowiedzi: ${scan.unconfirmedPages}. Archiwum zachowano bez usuwania wpisow.`,
                { title: "Wczytano wszystkie strony", level: "warning" }
              );
            }
          } else {
            notify(
              api,
              `W widoku: ${ui.state.boxes[box]?.entries.length ?? 0} (dodano: ${scan.addedToView}). ${scan.skipWhy ?? "Sprobuj ponownie za chwile"}.`,
              { title: "Wczytano dostepne listy", level: "warning" }
            );
          }
        } finally {
          if (generation !== connectionGeneration) return;
          loadAllFlag = null;
          ui.setLoadAll(null);
        }
      }).catch((err) => {
        if (!isOperationCancelled(err)) {
          notify(
            api,
            humanizeMailError(err instanceof Error ? err.message : String(err)),
            { title: "Blad wczytywania", level: "error" }
          );
        }
      }).finally(() => {
        if (generation !== connectionGeneration) return;
        ui.setBusy(null);
        rebuildContacts();
      });
    };
    let indexFlag = null;
    const indexAllBoxes = () => {
      if (indexFlag) {
        cancelFlag(indexFlag);
        return;
      }
      if (lock.locked) {
        notify(api, SESSION_BUSY_MSG, { level: "warning" });
        return;
      }
      const flag = { cancelled: false };
      indexFlag = flag;
      let done = 0;
      const generation = connectionGeneration;
      const skipped = [];
      void runExclusive(async () => {
        try {
          for (let i = 0; i < INDEX_BOXES.length; i++) {
            const box = INDEX_BOXES[i];
            if (flag.cancelled || generation !== connectionGeneration) break;
            ui.setIndexRun({ boxIndex: i, box, pages: 0 });
            ui.setBusy(`Indeksuje skrzynke ${box} (${i + 1}/${INDEX_BOXES.length})...`);
            const collectedFreshIds = /* @__PURE__ */ new Set();
            const sweepMode = indexSweepMode(ui.state.indexMeta, box, Date.now());
            const mergeIndexPage = (res) => {
              const records = recordsOfListing(box, res.entries);
              const merged = mergeListingPage(ui.state.archive, box, records);
              ui.setArchive(merged.letters);
              persistArchive();
              for (const id of merged.freshIds) collectedFreshIds.add(id);
              return merged;
            };
            const applyFirstIndexPage = (res, resolvedIds) => {
              stampEntries(box, res.entries, resolvedIds);
              const oldest = oldestEntry(res.entries);
              const boundaryDay = oldest?.date ? `${oldest.date.year}-${String(oldest.date.month).padStart(2, "0")}-${String(oldest.date.day).padStart(2, "0")}` : void 0;
              const synced = ui.syncMailboxPage(
                box,
                res.entries,
                res.header.truncated,
                boundaryDay
              );
              if (!synced) ui.applyMailbox(box, res);
            };
            const scan = await scanMailboxPages({
              box,
              cancelled: () => flag.cancelled || generation !== connectionGeneration,
              fetchPage: (command) => mailbox.fetch(box, command),
              wait: (ms) => sleepOrCancel(ms, flag, "skan"),
              onGap: (day) => recordArchiveGap(box, day),
              onBaseRefresh: (res) => {
                if (res.kind === "lista") {
                  const merged = mergeIndexPage(res);
                  applyFirstIndexPage(res, merged.resolvedIds);
                } else {
                  bumpCtx(box);
                  ui.applyMailbox(box, res);
                }
                rebuildContacts();
              },
              onEmpty: (res) => {
                bumpCtx(box);
                if (collectedFreshIds.size === 0) {
                  ui.applyMailbox(box, res);
                  rebuildContacts();
                }
              },
              onPage: (res, pages) => {
                ui.setIndexRun({ boxIndex: i, box, pages });
                const merged = mergeIndexPage(res);
                if (pages === 1) {
                  applyFirstIndexPage(res, merged.resolvedIds);
                } else {
                  stampEntries(box, res.entries, merged.resolvedIds);
                  ui.appendMailboxPage(box, res.entries, res.header.truncated);
                }
                rebuildContacts();
                return {
                  archiveAdded: merged.added,
                  // Fala 41: strona bez ani jednego nowego rekordu =
                  // klamra doszla do znanego materialu - przeglad
                  // inkrementalny moze stac.
                  stop: sweepMode === "incremental" && merged.added === 0
                };
              }
            });
            if ((scan.end === "complete" || scan.end === "clamped") && scan.unconfirmedPages === 0 && !flag.cancelled) {
              if (scan.end === "complete" && collectedFreshIds.size > 0) {
                ui.appendMailboxPage(box, [], false);
              }
              if (scan.end === "clamped") {
                markGoneFromServerNewerThan(
                  box,
                  collectedFreshIds,
                  scan.oldestSeenDay ?? ""
                );
                restoreArchiveTail(box);
              } else {
                const replaced = replaceBoxLetters(ui.state.archive, box, snapshotRecords(box));
                ui.setArchive(replaced.letters);
                persistArchive();
                if (replaced.removedIds.size > 0) pruneGoneFromView(box, replaced.removedIds);
                clearArchiveGaps(box);
                ui.setIndexMeta({ ...ui.state.indexMeta, [box]: (/* @__PURE__ */ new Date()).toISOString() });
                persistIndexMeta();
              }
              done += 1;
            } else if (scan.end === "cancelled" || flag.cancelled) {
              break;
            } else {
              const why = scan.skipWhy ?? (scan.unconfirmedPages > 0 ? `nie potwierdzono zamkniecia odpowiedzi: ${scan.unconfirmedPages}` : "niekompletne");
              skipped.push(`${box} (${why})`);
            }
          }
          if (flag.cancelled) {
            notify(
              api,
              `Zapisane skrzynki: ${done} z ${INDEX_BOXES.length}.`,
              { title: "Przerwano indeksowanie", level: "warning" }
            );
          } else if (skipped.length === 0) {
            rebuildContacts();
            notify(
              api,
              `${formatListCount(totalLive(ui.state.archive))} w bazie.`,
              { title: "Zindeksowano skrzynki", level: "success" }
            );
          } else {
            rebuildContacts();
            notify(
              api,
              `Pominiete: ${skipped.join(", ")}. Pozostale skrzynki zapisane.`,
              { title: "Indeksowanie niekompletne", level: "warning" }
            );
          }
        } finally {
          if (generation !== connectionGeneration) return;
          indexFlag = null;
          ui.setIndexRun(null);
          ui.setBusy(null);
        }
      }).catch((err) => {
        if (!isOperationCancelled(err)) {
          notify(
            api,
            humanizeMailError(err instanceof Error ? err.message : String(err)),
            { title: "Blad indeksowania", level: "error" }
          );
        }
      });
    };
    let animalFlight = false;
    let animalSendPending = false;
    let animalSendSerial = 0;
    let sluchamArmed = false;
    const disarmSlucham = () => {
      sluchamArmed = false;
      if (sluchamTimer !== null) {
        clearTimeout(sluchamTimer);
        sluchamTimer = null;
      }
    };
    const armSluchamWindow = () => {
      sluchamArmed = true;
      if (sluchamTimer !== null) clearTimeout(sluchamTimer);
      sluchamTimer = setTimeout(() => {
        sluchamTimer = null;
        sluchamArmed = false;
      }, ANIMAL_TIMING.sluchamWindowMs);
    };
    const endAnimalFlight = () => {
      animalFlight = false;
      if (animalTimer !== null) {
        clearTimeout(animalTimer);
        animalTimer = null;
      }
      ui.setAnimalFlying(false);
    };
    const startAnimalFlight = () => {
      animalFlight = true;
      if (animalTimer !== null) clearTimeout(animalTimer);
      animalTimer = setTimeout(() => {
        animalTimer = null;
        if (animalFlight) endAnimalFlight();
      }, ANIMAL_TIMING.flightTimeoutMs);
      ui.setAnimalFlying(true);
    };
    const openWithResolve = async (box, entry) => {
      for (let attempt = 0; attempt < 2; attempt++) {
        const fresh = await resolveEntry(box, entry);
        if (!fresh) return;
        beginPagerModal();
        try {
          const res = await pager.readLetter(fresh.number);
          ui.openLetter(box, res.letter, fresh);
          const merged = upsertLetters(ui.state.archive, [
            fromOpenedLetter(box, res.letter, fresh)
          ]);
          ui.setArchive(merged.letters);
          persistArchive();
          if (ui.state.search?.box !== box) refreshBoxes([box]);
          return;
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          const listingGone = /nie zostaly wybrane|Zly numer listu/.test(msg);
          if (attempt === 0 && listingGone) {
            bumpCtx(box);
            continue;
          }
          throw err;
        } finally {
          transport.endModal();
        }
      }
    };
    const archivePseudoEntry = (letter, box) => ({
      number: letter.number,
      isRead: letter.read,
      subject: letter.subject,
      forwarded: letter.forwarded === true,
      party: letter.party,
      partyKind: (box ?? letter.box) === "odebrane" || (box ?? letter.box) === "nieprzeczytane" ? "nadawca" : "odbiorcy",
      date: letter.dateRaw ? parseMailDate(letter.dateRaw) : null,
      // Fala 41: tozsamosc rekordu niesie pseudo-wpis - re-kotwica strony
      // wybiera wpis PO archiveId (blizniak o identycznych metadanych ma
      // wlasne id i wlasny wiersz listingu), a tresc z pagera laduje
      // dokladnie w tym rekordzie.
      archiveId: letter.id
    });
    const restoreArchiveTail = (box) => {
      const entries = ui.state.archive.filter((letter) => letter.box === box).sort((a, b) => {
        if (a.sortKey !== b.sortKey) return a.sortKey < b.sortKey ? -1 : 1;
        return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
      }).map((letter) => archivePseudoEntry(letter, box));
      ui.appendMailboxPage(box, entries, false);
    };
    const fetchArchiveBody = async (letter, opts) => {
      const box = opts?.box ?? letter.box;
      const pseudo = archivePseudoEntry(letter, box);
      let stage = "kotwiczenie";
      const aborted = () => opts?.shouldAbort?.() === true || playerMailMode;
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          stage = "kotwiczenie";
          if (aborted()) return { kind: "anulowano", stage };
          const fresh = await resolveEntry(box, pseudo);
          if (aborted()) return { kind: "anulowano", stage };
          if (!fresh) return { kind: "nie_ma_w_skrzynce", stage: "kotwiczenie" };
          stage = "odczyt";
          beginPagerModal();
          try {
            const res = await pager.readLetter(fresh.number, opts?.shouldAbort);
            if (res.letter.body.every((line) => line.trim().length === 0)) {
              return { kind: "pusta_tresc", stage: "odczyt" };
            }
            stage = "zapis";
            const previousArchive = ui.state.archive;
            const merged = upsertLetters(previousArchive, [
              fromOpenedLetter(box, res.letter, fresh)
            ]);
            ui.setArchive(merged.letters);
            try {
              await persistArchiveConfirmed(merged.letters);
            } catch (error) {
              if (ui.state.archive === merged.letters) {
                ui.setArchive(previousArchive);
                persistArchive();
              }
              throw error;
            }
            if (aborted()) return { kind: "anulowano", stage: "zapis" };
            return { kind: "pobrano", stage: "zapis", body: res.letter.body };
          } finally {
            transport.endModal();
          }
        } catch (err) {
          if (aborted()) return { kind: "anulowano", stage };
          const msg = err instanceof Error ? err.message : String(err);
          const listingGone = /nie zostaly wybrane|Zly numer listu/.test(msg);
          if (attempt === 0 && listingGone && opts?.retry !== false) {
            bumpCtx(box);
            continue;
          }
          if (stage === "zapis") {
            notify(
              api,
              "Nie udalo sie zapisac pobranej tresci w IndexedDB. Rekord pozostal do ponowienia.",
              { title: "Blad zapisu archiwum", level: "error" }
            );
            return { kind: "blad_zapisu", stage: "zapis" };
          }
          if (err instanceof AmbiguousResponseError) {
            return { kind: "niejednoznaczna_odpowiedz", stage };
          }
          if (stage === "kotwiczenie") {
            return { kind: "blad_kotwiczenia", stage: "kotwiczenie" };
          }
          return { kind: "blad_odczytu", stage: "odczyt" };
        }
      }
      return { kind: "blad_kotwiczenia", stage: "kotwiczenie" };
    };
    let archiveDownloadFlag = null;
    let archiveDownloadOperationCounter = 0;
    const onVisibilityChange = () => {
      const eta = archiveDownloadEta;
      const progress = ui.state.archiveDownload;
      if (!eta || !progress) return;
      eta.reset(Date.now());
      ui.setArchiveDownload({ done: progress.done, total: progress.total, etaMs: null });
    };
    document.addEventListener("visibilitychange", onVisibilityChange);
    const DOWNLOAD_BREAKER_LIMIT = 3;
    const runArchiveDownload = () => {
      if (archiveDownloadFlag) {
        cancelFlag(archiveDownloadFlag);
        return;
      }
      if (lock.locked) {
        notify(api, SESSION_BUSY_MSG, { level: "warning" });
        return;
      }
      if (playerMailMode) {
        notify(
          api,
          "Przed pobieraniem tresci zamknij poczte otwarta w grze (komenda q).",
          { level: "warning" }
        );
        return;
      }
      const noBody = ui.state.archive.filter((l) => l.body.length === 0);
      const candidates = noBody.filter(
        (l) => l.dateRaw !== null && parseMailDate(l.dateRaw) !== null
      );
      if (candidates.length === 0) {
        notify(
          api,
          ui.state.archive.length === 0 ? "Archiwum jest puste - nie ma czego pobierac." : noBody.length > 0 ? `Nie mozna pobrac tresci. Liczba listow bez prawidlowej daty: ${noBody.length}.` : "Wszystkie listy w bazie maja tresci.",
          { level: "warning" }
        );
        return;
      }
      const flag = { cancelled: false };
      archiveDownloadFlag = flag;
      const total = candidates.length;
      const eta = new DownloadEta(Date.now());
      archiveDownloadEta = eta;
      ui.setArchiveDownload({ done: 0, total, etaMs: null });
      ui.setBusy(`Pobieram tresci do archiwum (0/${total})...`);
      const generation = connectionGeneration;
      const operationId = ++archiveDownloadOperationCounter;
      void runExclusive(async () => {
        let done = 0;
        let failed = 0;
        let missing = 0;
        let consecutiveErrors = 0;
        let breakerTripped = false;
        let playerEntry = false;
        const reportProgress = () => {
          const processed = done + failed + missing;
          const etaMs = eta.sample(Date.now(), processed, total);
          ui.setArchiveDownload({ done: processed, total, etaMs });
          ui.setBusy(`Pobieram tresci do archiwum (${processed}/${total})...`);
        };
        try {
          for (const [candidateIndex, record] of candidates.entries()) {
            if (flag.cancelled || breakerTripped) break;
            if (playerMailMode) {
              playerEntry = true;
              break;
            }
            const order = [record.box, "odebrane", "nieprzeczytane", "wyslane", "niewyslane"].filter((b, i, arr) => arr.indexOf(b) === i);
            let result = { kind: "anulowano", stage: "kotwiczenie" };
            let attempted = false;
            for (const box of order) {
              if (flag.cancelled || playerMailMode) break;
              attempted = true;
              result = await fetchArchiveBody(record, {
                shouldAbort: () => flag.cancelled,
                box
              });
              if (result.kind === "pobrano") break;
              if (result.kind !== "nie_ma_w_skrzynce") break;
            }
            if (playerMailMode && !attempted) {
              playerEntry = true;
              break;
            }
            if (playerMailMode) playerEntry = true;
            if ((flag.cancelled || playerMailMode) && result.kind !== "pobrano") {
              result = { kind: "anulowano", stage: result.stage };
            }
            if (result.kind === "pobrano") {
              done += 1;
              consecutiveErrors = 0;
            } else if (result.kind === "nie_ma_w_skrzynce") {
              missing += 1;
              consecutiveErrors = 0;
            } else if (result.kind === "blad_zapisu") {
              failed += 1;
            } else if (result.kind !== "anulowano") {
              failed += 1;
              consecutiveErrors += 1;
              if (consecutiveErrors >= DOWNLOAD_BREAKER_LIMIT) breakerTripped = true;
            }
            recordArchiveDownloadDiagnostic({
              operationId,
              generation,
              recordAlias: `rekord-${candidateIndex + 1}`,
              outcome: result,
              consecutiveErrors
            });
            if (result.kind === "nie_ma_w_skrzynce") {
              ui.setArchive(ui.state.archive.filter((l) => l.id !== record.id));
              persistArchive();
              for (const b of ["odebrane", "nieprzeczytane", "wyslane", "niewyslane"]) {
                pruneGoneFromView(b, /* @__PURE__ */ new Set([record.id]));
              }
            }
            reportProgress();
            if (breakerTripped) break;
            if (flag.cancelled) break;
            if (playerEntry) break;
            await sleepOrCancel(LOAD_ALL_PACE_MS, flag, "pobieranie");
          }
          const remaining = Math.max(0, total - done - failed - missing);
          const summary = buildDownloadSummary({ done, total, failed, missing, remaining });
          if (playerEntry) {
            notify(
              api,
              `Poczta zostala otwarta w grze. ${summary.text}`,
              { title: "Przerwano pobieranie", level: "warning" }
            );
          } else if (breakerTripped) {
            notify(
              api,
              `Serwer poczty nie odpowiada. ${summary.text} Sprobuj ponownie pozniej.`,
              { title: "Przerwano pobieranie", level: "warning" }
            );
          } else if (flag.cancelled) {
            notify(
              api,
              summary.text,
              { title: "Przerwano pobieranie", level: "warning" }
            );
          } else {
            notify(
              api,
              summary.text,
              summary.level === "warning" ? { title: "Pobrano tresci", level: summary.level } : { level: summary.level }
            );
          }
        } finally {
          if (archiveDownloadEta === eta) archiveDownloadEta = null;
          if (generation !== connectionGeneration) return;
          if (archiveDownloadFlag === flag) archiveDownloadFlag = null;
          ui.setArchiveDownload(null);
          ui.setBusy(null);
        }
      }).catch((err) => {
        if (!isOperationCancelled(err)) notify(api, "Blad pobierania tresci do archiwum.", { level: "error" });
      });
    };
    const runExportArchive = () => {
      const { entries, skipped } = archiveExportEntries(ui.state.archive);
      if (entries.length === 0) {
        notify(
          api,
          ui.state.archive.length === 0 ? "Archiwum jest puste - nie ma czego zapisywac." : "Brak listow z trescia w archiwum - najpierw pobierz tresci.",
          { level: "warning" }
        );
        return;
      }
      const enc = new TextEncoder();
      const zip = buildZip(entries.map((e) => ({ name: e.name, data: enc.encode(e.txt) })));
      const now = /* @__PURE__ */ new Date();
      const p22 = (n) => String(n).padStart(2, "0");
      const name = `arkmail_listy_${now.getFullYear()}-${p22(now.getMonth() + 1)}-${p22(now.getDate())}_${p22(now.getHours())}${p22(now.getMinutes())}.zip`;
      const ok = downloadBlob(name, new Blob([zip.buffer], { type: "application/zip" }));
      const summary = buildExportSummary(
        entries.length,
        skipped,
        archiveExportHeaderGaps(ui.state.archive)
      );
      notify(
        api,
        ok ? summary.text : "Nie udalo sie zapisac pliku - klient nie obsluguje pobierania.",
        { title: "Zapis do ZIP", level: ok ? summary.level : "error" }
      );
    };
    const deletionSelectionKey = (numbers) => [...numbers].sort((a, b) => a - b).join(",");
    const searchForDeletion = (box, command) => {
      if (lock.locked) {
        notify(api, SESSION_BUSY_MSG, { level: "warning" });
        return;
      }
      if (ui.state.tab !== "usuwanie") return;
      const revision = ui.state.deletion.revision;
      const generation = connectionGeneration;
      ui.setBusy(`Szukam w skrzynce ${box}...`);
      void runExclusive(async () => {
        const result = await mailbox.fetch(box, command);
        if (generation !== connectionGeneration) return;
        if (revision !== ui.state.deletion.revision || ui.state.tab !== "usuwanie" || ui.state.deletion.box !== box) {
          bumpCtx(box);
          return;
        }
        if (result.kind === "lista") stampEntries(box, result.entries);
        else bumpCtx(box);
        ui.applyDeletionResult(box, command, result);
      }).catch((err) => {
        if (isOperationCancelled(err) || generation !== connectionGeneration) return;
        if (revision === ui.state.deletion.revision && ui.state.tab === "usuwanie") {
          ui.clearDeletionResult("Blad wyszukiwania. Sprobuj ponownie.");
        }
      }).finally(() => {
        if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
      });
    };
    const deleteSelectedLetters = () => {
      if (lock.locked) {
        notify(api, SESSION_BUSY_MSG, { level: "warning" });
        return;
      }
      const current = ui.state.deletion;
      if (ui.state.tab !== "usuwanie" || current.result?.kind !== "lista" || current.command === null) {
        return;
      }
      const selected = current.result.entries.filter((entry) => current.selected.includes(entry.number));
      if (selected.length === 0) return;
      const box = current.box;
      const command = current.command;
      const revision = current.revision;
      const selectionKey = deletionSelectionKey(current.selected);
      const generation = connectionGeneration;
      let deleteStarted = false;
      ui.setBusy("Sprawdzam zaznaczone listy...");
      void runExclusive(async () => {
        beginPagerModal();
        try {
          const fresh = await mailbox.fetch(box, command);
          if (generation !== connectionGeneration) return;
          if (revision !== ui.state.deletion.revision || ui.state.tab !== "usuwanie" || ui.state.deletion.command !== command || deletionSelectionKey(ui.state.deletion.selected) !== selectionKey) {
            bumpCtx(box);
            return;
          }
          if (fresh.kind === "lista") stampEntries(box, fresh.entries);
          else bumpCtx(box);
          if (fresh.kind !== "lista") {
            ui.clearDeletionResult("Zaznaczone listy zmienily sie. Wyszukaj je ponownie.");
            return;
          }
          const match = matchSelectionOnFreshListing(selected, fresh.entries);
          if (!match) {
            ui.clearDeletionResult("Zaznaczone listy zmienily sie. Wyszukaj je ponownie.");
            return;
          }
          ui.setBusy("Usuwam zaznaczone listy...");
          deleteStarted = true;
          const result = await pager.deleteLetters(match.numbers[0], match.range);
          const confirmed = [.../* @__PURE__ */ new Set([...result.deletedNumbers, ...result.unexpectedNumbers])].sort((a, b) => a - b);
          const updated = applyConfirmedDeletions(ui.state.archive, box, fresh.entries, confirmed);
          if (updated.changedIds.size > 0) {
            ui.setArchive(updated.letters);
            persistArchive();
            rebuildContacts();
            for (const changedBox of updated.changedBoxes) {
              pruneGoneFromView(changedBox, updated.changedIds);
            }
          }
          let message;
          if (result.status === "complete") {
            message = `Usunieto: ${formatListCount(result.deletedNumbers.length)}.`;
          } else if (confirmed.length > 0) {
            message = `Usunieto: ${formatListCount(confirmed.length)}. Wynik pozostalych jest nieznany. Odswiez przed kolejna proba.`;
            if (result.unexpectedNumbers.length > 0) {
              message += " Potwierdzono tez usuniecie listow spoza zaznaczenia.";
            }
          } else if (result.status === "none") {
            message = "Nie usunieto listow.";
          } else {
            message = "Brak potwierdzenia usuniecia. Odswiez przed kolejna proba.";
          }
          if (revision === ui.state.deletion.revision && ui.state.tab === "usuwanie") {
            ui.clearDeletionResult(message);
          }
        } finally {
          transport.endModal();
        }
      }).catch((err) => {
        if (isOperationCancelled(err) || generation !== connectionGeneration) return;
        if (revision === ui.state.deletion.revision && ui.state.tab === "usuwanie") {
          ui.clearDeletionResult(
            deleteStarted ? "Wynik usuwania jest nieznany. Odswiez przed kolejna proba." : "Nie udalo sie sprawdzic listow. Sprobuj ponownie."
          );
        }
      }).finally(() => {
        if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
      });
    };
    const openArchiveFromServer = (letter) => {
      if (lock.locked) {
        notify(api, SESSION_BUSY_MSG, { level: "warning" });
        return;
      }
      ui.setBusy(`Czytam list: ${letter.subject}...`);
      const pseudo = archivePseudoEntry(letter);
      const generation = connectionGeneration;
      void runExclusive(() => openWithResolve(letter.box, pseudo)).catch((err) => {
        if (!isOperationCancelled(err)) notify(api, "Nie udalo sie odczytac listu.", { level: "error" });
      }).finally(() => {
        if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
      });
    };
    handlersRef = {
      onDeletionSearch: (box, query) => {
        const validationError = validateListingSearch(query);
        if (validationError) {
          notify(api, validationError, { level: "error" });
          return;
        }
        searchForDeletion(box, searchListingCommand(box, query));
      },
      onDeletionDelete: () => deleteSelectedLetters(),
      onSendAnimal: () => {
        if (lock.locked) {
          notify(api, SESSION_BUSY_MSG, { level: "warning" });
          return;
        }
        if (animalFlight) {
          notify(api, "Zwierze jest juz w drodze - poczekaj na jego powrot.", { level: "warning" });
          return;
        }
        if (animalSendPending) {
          notify(api, "Trwa wysylanie zwierzecia - poczekaj na przyjecie komendy.", { level: "warning" });
          return;
        }
        const serial = ++animalSendSerial;
        const generation = connectionGeneration;
        animalSendPending = true;
        armSluchamWindow();
        void Promise.resolve().then(() => transport.send("wyslij zwierze", true)).then(() => {
          if (serial !== animalSendSerial) return;
          animalSendPending = false;
          if (generation !== connectionGeneration || lifecycleDestroyed) return;
          if (!animalFlight) startAnimalFlight();
        }).catch((err) => {
          if (serial !== animalSendSerial) return;
          animalSendPending = false;
          disarmSlucham();
          if (generation !== connectionGeneration || lifecycleDestroyed || isOperationCancelled(err)) return;
          notify(api, "Nie udalo sie wyslac komendy. Sprobuj ponownie.", {
            title: "Blad wysylania zwierzecia",
            level: "error"
          });
        });
      },
      onOpenLetter: (box, entry) => {
        if (lock.locked) {
          notify(api, SESSION_BUSY_MSG, { level: "warning" });
          return;
        }
        ui.setBusy(`Czytam list: ${entry.subject}...`);
        const generation = connectionGeneration;
        void runExclusive(() => openWithResolve(box, entry)).catch((err) => {
          if (!isOperationCancelled(err)) notify(api, "Nie udalo sie odczytac listu.", { level: "error" });
        }).finally(() => {
          if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
        });
      },
      onOpenArchiveLetter: (letter) => {
        if (letter.body.length > 0) {
          ui.openLetter(letter.box, archiveLetterContent(letter), void 0, letter.id);
          return;
        }
        openArchiveFromServer(letter);
      },
      onDownloadArchiveBodies: () => runArchiveDownload(),
      onReplyAllArchive: (archiveId, scope, apply) => {
        const applyRecord = (record) => {
          const prefill = buildReplyAllPrefill(
            { ...archiveLetterContent(record), box: record.box },
            ui.state.characterName,
            knownRecipientNames(ui.state),
            scope
          );
          if (!prefill) {
            notify(
              api,
              "Nie mozna przygotowac odpowiedzi wszystkim, poniewaz lista odbiorcow jest pusta.",
              { level: "warning" }
            );
            return;
          }
          if (!apply(prefill)) {
            notify(
              api,
              "Nie ustawiono odpowiedzi, poniewaz formularz zostal zmieniony w trakcie odczytu.",
              { level: "warning" }
            );
          }
        };
        const letter = ui.state.archive.find((record) => record.id === archiveId);
        if (!letter) {
          notify(api, "Nie znaleziono rekordu Archiwum. Formularz nie zostal zmieniony.", {
            level: "error"
          });
          return;
        }
        if (letter.headers) {
          applyRecord(letter);
          return;
        }
        if (lock.locked) {
          notify(api, SESSION_BUSY_MSG, { level: "warning" });
          return;
        }
        if (!letter.dateRaw || !parseMailDate(letter.dateRaw)) {
          notify(
            api,
            "Nie mozna odzyskac naglowkow bez poprawnej daty listu. Formularz nie zostal zmieniony.",
            { level: "warning" }
          );
          return;
        }
        const generation = connectionGeneration;
        ui.setBusy(`Odzyskuje naglowki listu: ${letter.subject}...`);
        void runExclusive(() => fetchArchiveBody(letter, {
          retry: false,
          shouldAbort: () => generation !== connectionGeneration || lifecycleDestroyed
        })).then((result) => {
          if (generation !== connectionGeneration || lifecycleDestroyed) return;
          if (result.kind === "pobrano") {
            const current = ui.state.archive.find((record) => record.id === archiveId);
            if (current?.headers) applyRecord(current);
            else {
              notify(
                api,
                "Nie mozna odzyskac pelnych naglowkow listu. Formularz nie zostal zmieniony.",
                { level: "error" }
              );
            }
            return;
          }
          if (result.kind === "blad_zapisu") return;
          if (result.kind === "anulowano") {
            notify(api, "Odzyskiwanie naglowkow przerwano. Formularz nie zostal zmieniony.", {
              level: "warning"
            });
            return;
          }
          if (result.kind === "nie_ma_w_skrzynce") {
            notify(
              api,
              "Listu nie ma w skrzynce. Nie odzyskano naglowkow i nie zmieniono formularza.",
              { level: "warning" }
            );
            return;
          }
          notify(
            api,
            "Nie mozna odzyskac pelnych naglowkow listu. Formularz nie zostal zmieniony.",
            { level: "error" }
          );
        }).catch((err) => {
          if (generation !== connectionGeneration || lifecycleDestroyed) return;
          if (!isOperationCancelled(err)) {
            notify(
              api,
              "Nie mozna odzyskac pelnych naglowkow listu. Formularz nie zostal zmieniony.",
              { level: "error" }
            );
          }
        }).finally(() => {
          if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
        });
      },
      onReplyAllEmpty: () => notify(
        api,
        "Nie mozna przygotowac odpowiedzi wszystkim, poniewaz lista odbiorcow jest pusta.",
        { level: "warning" }
      ),
      // Indeksacja wszystkich skrzynek jako osobna operacja.
      onIndexAll: () => indexAllBoxes(),
      // Fala UI-2: import bazy osob i aliasow z gry (pule ksiazki
      // adresowej; wipe "Wyczysc zapisane dane" ich nie tyka).
      onImportPeople: (kind) => importPeople(kind),
      onImportAliases: () => importAliases(),
      // Fala UI-2 krok 3: CRUD grup recznych - kazda mutacja zapisu
      // trwa w tym samym przebiegu (storage + stan UI).
      onSaveGroups: (groups) => {
        const oldConflicts = new Set(
          findGroupAliasConflicts(ui.state.groups, ui.state.importedAliases).map((group) => group.name.trim().toLowerCase())
        );
        const introduced = findGroupAliasConflicts(groups, ui.state.importedAliases).find((group) => !oldConflicts.has(group.name.trim().toLowerCase()));
        if (introduced) {
          notify(api, `Nazwa grupy "${introduced.name}" koliduje z aliasem pocztowym z gry. Wybierz inna nazwe.`, { level: "error" });
          return;
        }
        saveGroups(storage, groups);
        ui.setGroups(groups);
      },
      onAddGroupMember: (groupName, rawName) => {
        const name = rawName.trim();
        if (!isValidPersonName(name)) return "Imie: tylko litery.";
        const group = ui.state.groups.find((candidate) => candidate.name === groupName);
        if (!group) return "Grupa nie istnieje.";
        if (group.members.some((member) => member.toLowerCase() === name.toLowerCase())) {
          return `${name} juz jest w tej grupie.`;
        }
        const groups = ui.state.groups.map(
          (candidate) => candidate.name === groupName ? { ...candidate, members: [...candidate.members, name] } : candidate
        );
        const people = unionPeople(ui.state.people, [name]);
        saveGroups(storage, groups);
        savePeople(storage, people);
        ui.setAddressBook(people, groups);
        rebuildContacts();
        return null;
      },
      // Fala UI-2 krok 3: zapis plaskiej ksiazki imion po mutacji CRUD
      // (dodanie, usuniecie pojedyncze, usuniecie zaznaczonych) - storage
      // + stan UI w jednym przebiegu (jak onSaveGroups).
      onSavePeople: (people) => {
        savePeople(storage, people);
        ui.setPeople(people);
        rebuildContacts();
      },
      // Fala UI-2 krok 3: import ksiazki z pliku JSON (format v2; v1
      // czytany wstecz). Tryb "dolacz" scala grupy o tej samej nazwie i
      // uzupelnia ksiazke o czlonkow grup; "zastap" podmienia imiona i
      // grupy zawartoscia pliku (niezmiennik kompletnosci czlonkow i tak
      // obowiazuje). Aliasy sa lustrem z gry - import pliku ich nie rusza.
      onImportAddressBook: (data, mode = "dolacz") => {
        const oldConflicts = new Set(
          findGroupAliasConflicts(ui.state.groups, ui.state.importedAliases).map((group) => group.name.trim().toLowerCase())
        );
        const { data: merged, stats } = applyBookImport(
          { people: ui.state.people, groups: ui.state.groups },
          data,
          mode
        );
        const newConflicts = findGroupAliasConflicts(merged.groups, ui.state.importedAliases).filter((group) => !oldConflicts.has(group.name.trim().toLowerCase()));
        saveGroups(storage, merged.groups);
        savePeople(storage, merged.people);
        ui.setGroups(merged.groups);
        ui.setPeople(merged.people);
        rebuildContacts();
        notify(api, mode === "zastap" ? `Ksiazka adresowa zastapiona. Liczba grup: ${merged.groups.length}. Liczba imion: ${merged.people.length}.` : `Z pliku: liczba grup ${data.groups.length} (dodano: ${stats.addedGroups}, scalono: ${stats.mergedGroups}). W ksiazce: liczba imion ${merged.people.length} (dodano: ${stats.addedPeople}).`, { level: "success" });
        if (newConflicts.length > 0) {
          notify(api, `Nowe konflikty grup z aliasami: ${newConflicts.map((group) => group.name).join(", ")}.`, { level: "warning" });
        }
      },
      // Zgloszenie 2026-11-05: wyczyszczenie lokalnego lustra aliasow
      // (przycisk w pigulce "Aliasy Pocztowe"). Kasuje wylacznie lokalny
      // storage; na serwerze Arkadii nic nie znika - aliasy pobiera sie
      // z gry ponownie.
      onClearAliases: () => {
        saveImportedAliases(storage, []);
        ui.setImportedAliases([]);
        rebuildContacts();
        notify(api, "Wyczyszczono lokalne lustro aliasow. Aliasy na serwerze zostaly bez zmian.", { level: "success" });
      },
      // Zgloszenie 2026-11-05: wyczyszczenie calej ksiazki adresowej
      // (imiona + grupy + aliasy) z guardem dwukliku w pigulce
      // "Import-Eksport". Kasuje wylacznie lokalny storage; na serwerze
      // Arkadii nic nie znika.
      onClearAddressBook: () => {
        savePeople(storage, []);
        saveGroups(storage, []);
        saveImportedAliases(storage, []);
        ui.setPeople([]);
        ui.setGroups([]);
        ui.setImportedAliases([]);
        rebuildContacts();
        notify(api, "Wyczyszczono cala ksiazke adresowa (imiona, grupy, aliasy).", { level: "success" });
      },
      // Zgloszenie 2026-11-05 (K7): eksport ksiazki do pliku JSON przez
      // handler - pobranie pliku + status + toast (jak eksport listu);
      // UI nie pobiera pliku bez potwierdzenia w pasku statusu.
      onExportAddressBook: () => {
        const json = buildAddressBookExport({
          people: ui.state.people,
          groups: ui.state.groups
        });
        const ok = downloadBlob(
          "arkmail-adresy.json",
          new Blob([json], { type: "application/json" })
        );
        notify(
          api,
          ok ? `Ksiazka adresowa zapisana do pliku. Liczba imion: ${ui.state.people.length}. Liczba grup: ${ui.state.groups.length}.` : "Nie udalo sie zapisac pliku - klient nie obsluguje pobierania.",
          { level: ok ? "success" : "error" }
        );
      },
      // Zgloszenie 2026-11-05: dopisanie wszystkich osob zebranych z
      // listow do ksiazki adresowej jednym klikiem. Dedup bez wielkosci
      // liter robi unionPeople; przycisk aktywny tylko gdy baza istnieje.
      onAddAllContacts: () => {
        const names = ui.state.contacts.map((c) => c.name);
        const before = ui.state.people.length;
        const people = unionPeople(ui.state.people, names);
        savePeople(storage, people);
        ui.setPeople(people);
        const added = people.length - before;
        notify(
          api,
          added === 0 ? "Brak nowych osob do dopisania." : `Dopisano nowe osoby do ksiazki. Liczba dodanych: ${added}. Liczba osob w ksiazce: ${people.length}.`,
          { level: added === 0 ? "info" : "success" }
        );
      },
      // Fala 17g: eksporty TXT/ZIP - operacje czysto lokalne (dane
      // z cache), bez locka i bez komend do serwera.
      onExportLetter: () => {
        const l = ui.state.letter;
        if (!l) return;
        const sender = l.box === "odebrane" || l.box === "nieprzeczytane";
        const party = sender ? l.from : l.to || l.cc || "";
        const txt = letterTxt({
          subject: l.subject,
          from: l.from,
          to: l.to,
          cc: l.cc,
          date: l.date,
          box: l.box,
          body: l.body
        });
        const blob = new Blob([txt], { type: "text/plain" });
        const ok = downloadBlob(txtFileName(party, l.subject, l.date), blob);
        notify(
          api,
          ok ? "Zapisano list do pliku TXT." : "Nie udalo sie zapisac pliku - klient nie obsluguje pobierania.",
          { level: ok ? "success" : "error" }
        );
      },
      onExportArchive: () => {
        runExportArchive();
      },
      onSendCompose: (input) => {
        const validationError = validateCompose(input);
        if (validationError) {
          notify(api, validationError, { level: "error" });
          return;
        }
        if (lock.locked) {
          notify(api, SESSION_BUSY_MSG, { level: "warning" });
          return;
        }
        const recipients = {
          adresat: expandLocalGroup(input.adresat, ui.state),
          dw: expandLocalGroup(input.dw, ui.state)
        };
        const unknown = unknownRecipients(recipients, knownRecipientNames(ui.state));
        if (unknown.length > 0) {
          notify(api, `Odbiorcy spoza zapisanej bazy: ${unknown.join(", ")}. Wysylka bedzie kontynuowana, a serwer zweryfikuje ich nazwy.`, { level: "warning" });
        }
        ui.setBusy("Wysylam list...");
        const generation = connectionGeneration;
        void runExclusive(async () => {
          transport.beginModal();
          composeVisible = true;
          try {
            const out = await editor.send({
              adresat: recipients.adresat,
              temat: input.temat,
              dw: recipients.dw.trim() === "" ? void 0 : recipients.dw,
              linie: input.linie
            });
            if (out.result === "wyslany") {
              notify(api, "List zostal wyslany.", { level: "success" });
              refreshBoxes(["wyslane", "niewyslane"]);
              ui.clearCompose();
            } else if (out.result === "gotowy") {
              notify(api, "List zapisany w niewyslanych.", { level: "success" });
              refreshBoxes(["niewyslane"]);
              flashUnsent();
              ui.clearCompose();
            } else if (out.result === "zaniechany") {
              notify(api, "Przerwano wysylke listu.", { level: "info" });
            } else if (out.result === "blad") {
              notify(
                api,
                out.error.kind === "timeout" ? OPERATION_TIMEOUT_MSG : mailErrorText(out.error),
                { level: "error" }
              );
            }
          } finally {
            composeVisible = false;
            transport.endModal();
          }
        }).catch((err) => {
          if (!isOperationCancelled(err)) notify(api, SEND_FAILURE_MSG, { level: "error" });
        }).finally(() => {
          if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
        });
      },
      onCloseLetter: () => ui.closeLetter(),
      // Fala 20e: guardy w handlerach, NIE w refreshBoxes - wewnetrzny
      // refresh po wysylce/kasowaniu kolejkuje celowo (wolany z wnetrza
      // sesji). Klik gracza przy zajetej blokadzie: odmowa z toastem,
      // zero cichego kolejkowania komend (audyt race 2026-10-21).
      onRefreshBox: (box) => {
        if (lock.locked) {
          notify(api, SESSION_BUSY_MSG, { level: "warning" });
          return;
        }
        refreshBoxes([box], "sync", "manual");
      },
      onLoadOlder: (box) => {
        if (lock.locked) {
          notify(api, SESSION_BUSY_MSG, { level: "warning" });
          return;
        }
        loadOlder(box);
      },
      onLoadAll: (box) => loadAll(box),
      onSearch: (box, query) => {
        const validationError = validateListingSearch(query);
        if (validationError) {
          notify(api, validationError, { level: "error" });
          return;
        }
        if (lock.locked) {
          notify(api, SESSION_BUSY_MSG, { level: "warning" });
          return;
        }
        ui.setBusy(`Szukam w skrzynce ${box}...`);
        const generation = connectionGeneration;
        void runExclusive(async () => {
          const res = await mailbox.fetch(box, searchListingCommand(box, query));
          const searchRecords = res.kind === "lista" ? recordsOfListing(box, res.entries) : void 0;
          if (res.kind !== "lista") bumpCtx(box);
          ui.setSearch({ box, label: searchDescription(box, query) });
          ui.applySearchResults(box, res);
          if (res.kind === "lista" && searchRecords !== void 0) {
            const merged = mergeListingPage(ui.state.archive, box, searchRecords);
            ui.setArchive(merged.letters);
            stampEntries(box, res.entries, merged.resolvedIds);
            finalizeArchiveChange();
            notify(api, `Wyniki szukania (${formatListCount(res.entries.length)}).`, { level: "success" });
          } else {
            notify(api, "Brak pasujacych listow.");
          }
        }).catch((err) => {
          if (!isOperationCancelled(err)) {
            notify(
              api,
              humanizeMailError(err instanceof Error ? err.message : String(err)),
              { title: "Blad szukania", level: "error" }
            );
          }
        }).finally(() => {
          if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
        });
      },
      onClearSearch: (box) => ui.clearSearch(box),
      // Fala 12e: czyszczenie pamieci podrecznej na zadanie gracza.
      // Kasuje archiwum (storage + RAM), widoki skrzynek i kontakty;
      // ZACHOWUJE ustawienia (powiadomienia, szablon compose) - one nie
      // sa cache, tylko preferencje.
      onClearCache: () => {
        if (lock.locked) {
          notify(api, SESSION_BUSY_MSG, { level: "warning" });
          return;
        }
        const generation = connectionGeneration;
        ui.setBusy("Czyszcze zapisane dane...");
        void runExclusive(async () => {
          await storage.clearMailData([INDEX_KEY, ARCHIVE_GAPS_KEY]);
          if (generation !== connectionGeneration) return;
          ui.clearCacheData();
          notify(api, "Zapisane dane wyczyszczone.", { level: "success" });
        }).catch((err) => {
          if (!isOperationCancelled(err)) {
            notify(api, "Nie udalo sie wyczyscic zapisanych danych.", { level: "error" });
          }
        }).finally(() => {
          if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
        });
      },
      onDeleteLetter: (box, entry) => {
        if (lock.locked) {
          notify(api, SESSION_BUSY_MSG, { level: "warning" });
          return;
        }
        ui.setBusy(`Usuwam list: ${entry.subject}...`);
        const generation = connectionGeneration;
        void runExclusive(async () => {
          const fresh = await resolveEntry(box, entry);
          if (!fresh) return;
          beginPagerModal();
          try {
            const res = await pager.deleteLetters(fresh.number, String(fresh.number));
            if (res.deleted) {
              notify(api, "List zostal usuniety.", { level: "success" });
              ui.closeLetter();
              refreshBoxes([box], "replace");
            } else {
              notify(api, "Nie udalo sie skasowac listu.", { level: "error" });
            }
          } finally {
            transport.endModal();
          }
        }).catch((err) => {
          if (!isOperationCancelled(err)) notify(api, "Blad kasowania listu.", { level: "error" });
        }).finally(() => {
          if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
        });
      },
      onForwardLetter: (box, entry, adresat) => {
        if (lock.locked) {
          notify(api, SESSION_BUSY_MSG, { level: "warning" });
          return;
        }
        ui.setBusy(`Przekazuje list: ${entry.subject}...`);
        const generation = connectionGeneration;
        void runExclusive(async () => {
          const fresh = await resolveEntry(box, entry);
          if (!fresh) return;
          beginPagerModal();
          try {
            const res = await pager.forwardLetter(fresh.number, adresat);
            if (res.queued) {
              notify(api, "Przekazany list zapisany w niewyslanych.", { level: "success" });
              refreshBoxes(["niewyslane"]);
              flashUnsent();
            } else {
              notify(
                api,
                res.error ? mailErrorText(res.error) : FORWARD_FAILURE_MSG,
                { level: "error" }
              );
            }
          } finally {
            transport.endModal();
          }
        }).catch((err) => {
          if (!isOperationCancelled(err)) {
            notify(api, isPagerTimeout(err) ? OPERATION_TIMEOUT_MSG : FORWARD_FAILURE_MSG, { level: "error" });
          }
        }).finally(() => {
          if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
        });
      }
    };
    let lastWatchdogQ = 0;
    transport.subscribe((line) => {
      if (line.cls === "command" || isEchoLine(line.text)) {
        const cmd = isEchoLine(line.text) ? line.text.replace(/^→\s*/, "") : line.text;
        if (MAIL_ENTRY_CMD_RE.test(cmd)) {
          clearPagerOrphan();
          if (!line.own) enterPlayerMailMode();
        } else if (playerMailMode && !line.own && /^(?:q|x)$/i.test(cmd.trim())) {
          awaitPlayerMailPrompt();
        }
        return;
      }
      if (awaitingPlayerMailPrompt) {
        if (line.cls === "prompt" || isPromptLine(line.text)) exitPlayerMailMode();
        return;
      }
      if (!extractPagerPrompt(line.text)) return;
      if (playerMailMode) armPlayerMailModeIdle();
      if (lock.locked) return;
      if (!isPagerOrphanSuspected()) return;
      const now = Date.now();
      if (now - lastWatchdogQ < 2e3) return;
      lastWatchdogQ = now;
      void Promise.resolve(transport.send("q")).then(() => clearPagerOrphan()).catch(() => {
      });
    });
    transport.subscribe((line) => {
      const n = parseNotification(line.text);
      if (!n) return;
      if (n.kind === "nowa-poczte") {
        if (ui.state.notifyEnabled) notify(api, `Masz nowa poczte od ${n.nadawca}.`);
        scheduleRefresh(["odebrane", "nieprzeczytane"]);
        scheduleDelayedInboxRefresh();
      } else if (n.kind === "wysylasz") {
        if (!animalFlight) startAnimalFlight();
        disarmSlucham();
      } else if (n.kind === "slucham") {
        if (sluchamArmed) {
          animalSendSerial++;
          animalSendPending = false;
          disarmSlucham();
          endAnimalFlight();
          notify(api, "Arkadia nie rozpoznala komendy wyslania zwierzecia. Sprawdz, czy masz zwierze pocztowe.", { level: "warning" });
        }
      } else if (n.kind === "powrot-zwierzecia") {
        disarmSlucham();
        endAnimalFlight();
        scheduleRefresh(["odebrane", "nieprzeczytane", "niewyslane", "wyslane"]);
      } else if (n.kind === "list-wyslany") {
        if (!lock.locked) scheduleRefresh(["niewyslane", "wyslane"]);
      } else if (n.kind === "kasowanie") {
        if (!lock.locked)
          scheduleRefresh(["odebrane", "nieprzeczytane", "wyslane", "niewyslane"]);
      }
    });
    let previousAutoRefreshEnabled = ui.state.autoRefreshEnabled;
    unsubBadge = ui.subscribe((s) => {
      if (previousAutoRefreshEnabled && !s.autoRefreshEnabled) {
        pendingRefresh.clear();
        for (const timer of delayedInboxTimers) clearTimeout(timer);
        delayedInboxTimers = [];
      }
      previousAutoRefreshEnabled = s.autoRefreshEnabled;
      footerHandle?.update({ label: PLUGIN_NAME + formatBadgeSuffix(s.badge, s.badgeUnsent) });
      api.ui.setFooterButtonState(FOOTER_STATE, s.badge > 0 || s.badgeUnsent > 0);
      storage.setJSON(COMPOSE_KEY, { template: s.composeTemplate, width: s.composeWidth });
      storage.setJSON(NOTIFY_KEY, s.notifyEnabled);
      storage.setJSON(AUTO_REFRESH_KEY, s.autoRefreshEnabled);
    });
    refreshPopup();
    deactivateActiveCharacter = async () => {
      cancelConnectionOperations();
      document.removeEventListener("visibilitychange", onVisibilityChange);
      api.events.off("client.connect", onClientConnect);
      api.events.off("client.disconnect", onClientDisconnect);
      api.events.off("gmcp.mail.state", onMailState);
      api.events.off("gmcp", onAnyGmcp);
      api.events.off("gmcp.char.info", onGamePresence);
      api.events.off("gmcp.char.name", onGamePresence);
      api.events.off("gmcp_msg.room.long", onGamePresence);
      api.events.off("proxy.session", onProxySession);
      api.events.off("gmcp_msg.system.login", onSystemLogin);
      api.events.off("gmcp.mail.state", onGamePresence);
      for (const timer of [animalTimer, sluchamTimer, unsentFlashTimer, playerMailModeTimer]) {
        if (timer !== null) clearTimeout(timer);
      }
      animalTimer = null;
      sluchamTimer = null;
      unsentFlashTimer = null;
      playerMailModeTimer = null;
      for (const timer of delayedInboxTimers) clearTimeout(timer);
      delayedInboxTimers = [];
      await Promise.allSettled([...tasks]);
      if (unsubAnimalHeader) {
        unsubAnimalHeader();
        unsubAnimalHeader = null;
      }
      if (unsubBadge) {
        unsubBadge();
        unsubBadge = null;
      }
      if (unmount) {
        unmount();
        unmount = null;
      }
      if (wideObserver) {
        wideObserver.disconnect();
        wideObserver = null;
      }
      scaleProbe?.remove();
      scaleProbe = null;
      themeColorCleanup?.();
      themeColorCleanup = null;
      handlersRef = null;
      store = null;
      if (transport) {
        transport.dispose();
        transport = null;
      }
      if (storageRef === storage) storageRef = null;
      await storage.close();
    };
    return true;
  };
  const switchCharacter = async (name) => {
    const normalized = name?.trim() || null;
    const key = normalized?.toLowerCase() ?? null;
    if (key === activeName) return;
    await deactivateCurrent();
    if (lifecycleDestroyed || key !== (requestedName?.trim().toLowerCase() || null)) return;
    if (!normalized) return;
    if (await activateCharacter(normalized)) activeName = key;
  };
  unsubscribeCharacter = api.character.onChange((name) => {
    requestedName = name;
    switchQueue = switchQueue.then(() => switchCharacter(name)).catch(() => {
    });
  });
  await switchCharacter(requestedName);
  return {
    name: PLUGIN_NAME,
    version: PLUGIN_VERSION,
    // Literal wymagany przez katalog dargoth-plugins (metadata.test.mjs
    // czyta author regexem, nie rozwinie const-ref); zgodnosc z meta.ts
    // pilnuje tests/version.test.mjs (Fala 22a).
    author: "Isithunzi000",
    description: PLUGIN_DESCRIPTION
  };
}
async function destroy() {
  lifecycleDestroyed = true;
  if (unsubscribeCharacter) {
    unsubscribeCharacter();
    unsubscribeCharacter = null;
  }
  if (deactivateActiveCharacter) {
    const deactivate = deactivateActiveCharacter;
    deactivateActiveCharacter = null;
    await deactivate();
  }
  if (animalTimer !== null) {
    clearTimeout(animalTimer);
    animalTimer = null;
  }
  if (sluchamTimer !== null) {
    clearTimeout(sluchamTimer);
    sluchamTimer = null;
  }
  if (unsentFlashTimer !== null) {
    clearTimeout(unsentFlashTimer);
    unsentFlashTimer = null;
  }
  for (const t of delayedInboxTimers) clearTimeout(t);
  delayedInboxTimers = [];
  if (playerMailModeTimer !== null) {
    clearTimeout(playerMailModeTimer);
    playerMailModeTimer = null;
  }
  if (unsubAnimalHeader) {
    unsubAnimalHeader();
    unsubAnimalHeader = null;
  }
  if (unsubBadge) {
    unsubBadge();
    unsubBadge = null;
  }
  if (unmount) {
    unmount();
    unmount = null;
  }
  if (wideObserver) {
    wideObserver.disconnect();
    wideObserver = null;
  }
  scaleProbe?.remove();
  scaleProbe = null;
  themeColorCleanup?.();
  themeColorCleanup = null;
  if (transport) {
    transport.dispose();
    transport = null;
  }
  handlersRef = null;
  store = null;
  if (aliasId !== null && apiRef) {
    apiRef.aliases.remove(aliasId);
    aliasId = null;
  }
  if (footerHandle) {
    footerHandle.remove();
    footerHandle = null;
  }
  if (menuHandle) {
    menuHandle.remove();
    menuHandle = null;
  }
  if (popup) {
    popup.close();
    popup = null;
  }
  animalHeader = null;
  if (storageRef) {
    const storage = storageRef;
    storageRef = null;
    await storage.close();
  }
  apiRef = null;
}
export {
  ANIMAL_TIMING,
  INDEX_ANCHOR_RETRY_WAITS_MS,
  INDEX_FULL_SWEEP_AGE_MS,
  INDEX_PACE_MS,
  LOAD_ALL_PACE_MS,
  PLAYER_MAIL_MODE_IDLE_MS,
  WIDE_MIN_WIDTH,
  destroy,
  indexSweepMode,
  init,
  shouldUseWideLayout
};
