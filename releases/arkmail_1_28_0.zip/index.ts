var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

// src/arkmail/meta.ts
const PLUGIN_VERSION = "1.28.0";
var PLUGIN_BUILD_DATE = "04-11-2026";
var PLUGIN_NAME = "ArkMail";
var PLUGIN_DESCRIPTION = "ArkMail to kompleksowy system pocztowy: skrzynki, kontakty, archiwum i pisanie list\xF3w (alias /arkmail).";

// src/arkmail/core/protocol/parser.ts
var CLIENT_PREFIX_RE = /^\s*\[ POCZTA \]\s+/;
function stripClientPrefix(text) {
  return text.replace(CLIENT_PREFIX_RE, "").trim();
}
var MONTHS = {
  I: 1,
  II: 2,
  III: 3,
  IV: 4,
  V: 5,
  VI: 6,
  VII: 7,
  VIII: 8,
  IX: 9,
  X: 10,
  XI: 11,
  XII: 12
};
var DATE_RE = /^([A-Za-z]+), (\d{1,2}) (XII|XI|IX|VIII|VII|VI|IV|V|III|II|I|X) (\d{4}), (\d{2}:\d{2}:\d{2})$/;
function parseMailDate(raw) {
  const m = raw.match(DATE_RE);
  if (!m) return null;
  return {
    raw,
    weekday: m[1],
    day: Number(m[2]),
    month: MONTHS[m[3]],
    year: Number(m[4]),
    time: m[5]
  };
}
var LISTING_HEADER_RE = /^(?:Wybrane )?[Ll]isty (nieprzeczytane|odebrane|wyslane|niewyslane)(?: \(([^)]*)\))?:$/;
var LISTING_LIMIT_RE = /\bpierwsz\w*\s+(\d+)\b/;
var SERVER_LISTING_LIMIT = 50;
function parseListingHeader(text) {
  const m = text.match(LISTING_HEADER_RE);
  if (!m) return null;
  const limit = m[2]?.match(LISTING_LIMIT_RE);
  return {
    box: m[1],
    truncated: limit != null && Number(limit[1]) >= SERVER_LISTING_LIMIT
  };
}
var LISTING_ENTRY_RE = /^\s*(\d+)\.\s+(?:(\*R\*)\s+)?Temat: (.+)$/;
var FORWARDED_SUFFIX = " (forwardowany)";
function parseListingEntry(text) {
  const m = text.match(LISTING_ENTRY_RE);
  if (!m) return null;
  let subject = m[3];
  let forwarded = false;
  if (subject.endsWith(FORWARDED_SUFFIX)) {
    forwarded = true;
    subject = subject.slice(0, -FORWARDED_SUFFIX.length);
  }
  return { number: Number(m[1]), isRead: m[2] === "*R*", subject, forwarded };
}
var LISTING_PARTY_RE = /^(Nadawca|Odbiorc[ay]): (.+)$/;
var LISTING_DATE_SUFFIX_RE = /\s+([A-Za-z]+, \d{1,2} (?:XII|XI|IX|VIII|VII|VI|IV|V|III|II|I|X) \d{4}, \d{2}:\d{2}:\d{2})$/;
function parseListingParty(text) {
  const m = text.match(LISTING_PARTY_RE);
  if (!m) return null;
  const suffix = m[2].match(LISTING_DATE_SUFFIX_RE);
  const names = suffix ? m[2].slice(0, suffix.index).trimEnd() : m[2];
  return {
    kind: m[1] === "Nadawca" ? "nadawca" : "odbiorcy",
    names,
    date: suffix ? parseMailDate(suffix[1]) : null
  };
}
var EMPTY_LISTING_RE = /^Nie masz zadnych (nieprzeczytanych|odebranych|wyslanych|niewyslanych|otrzymanych) listow\.$/;
var FILTERED_EMPTY_RE = /^Nie znaleziono zadnych takich (nieprzeczytanych|odebranych|wyslanych|niewyslanych|otrzymanych) listow\.$/;
var BOXES_FROM_GENITIVE = {
  nieprzeczytanych: ["nieprzeczytane"],
  odebranych: ["odebrane"],
  wyslanych: ["wyslane"],
  niewyslanych: ["niewyslane"],
  otrzymanych: ["odebrane", "nieprzeczytane"]
};
var LISTS_LOADING_RE = /^Listy sa w tej chwili ladowane\.$/;
function parseEmptyListing(text) {
  const puste = text.match(EMPTY_LISTING_RE);
  if (puste) return { boxes: BOXES_FROM_GENITIVE[puste[1]], reason: "puste" };
  const filtr = text.match(FILTERED_EMPTY_RE);
  if (filtr) return { boxes: BOXES_FROM_GENITIVE[filtr[1]], reason: "filtr" };
  return null;
}
var LETTER_HEADER_RES = [
  { re: /^List\s*: ?(\d+)$/, field: "numer" },
  { re: /^Od\s*: ?(.+)$/, field: "od" },
  { re: /^Temat\s*: ?(.+)$/, field: "temat" },
  { re: /^Do\s*: ?(.*)$/, field: "do" },
  { re: /^DW\s*: ?(.+)$/, field: "dw" },
  { re: /^Data\s*: ?(.+)$/, field: "data" }
];
function parseLetterHeaderLine(text) {
  for (const { re, field } of LETTER_HEADER_RES) {
    const m = text.match(re);
    if (m) return { field, value: m[1] };
  }
  return null;
}
var PAGER_PROMPT_ANYWHERE_RE = /\[(\d+)-(\d+) [a-zA-Z.!?+<>\-]+\] \(aktualny: (\d+)\) --/;
function extractPagerPrompt(text) {
  const m = text.match(PAGER_PROMPT_ANYWHERE_RE);
  if (!m) return null;
  return { lo: Number(m[1]), hi: Number(m[2]), current: Number(m[3]) };
}
var ALIASES_HEADER = "Posiadasz nastepujace zdefiniowane aliasy pocztowe:";
var ALIAS_ENTRY_RE = /^\s*(\S+): (.+)$/;
function parseAliasesBlock(lines) {
  if (!lines.length || lines[0] !== ALIASES_HEADER) return [];
  const out = [];
  for (let i = 1; i < lines.length; i++) {
    const m = lines[i].match(ALIAS_ENTRY_RE);
    if (!m) break;
    out.push({ name: m[1], targets: m[2].split(",").map((s) => s.trim()).filter(Boolean) });
  }
  return out;
}
var IMPORT_PREFIX_RE = /^\[\d+\]\s*/;
function splitImportedNames(raw) {
  return raw.split(/\s*,\s*|\s+i\s+/).map((s) => s.trim()).filter(Boolean);
}
function parseRememberedLine(text) {
  const t = text.replace(IMPORT_PREFIX_RE, "").trim();
  const m = t.match(/^Zapamietane przez ciebie imiona to (.+)\.$/);
  if (!m) return null;
  return splitImportedNames(m[1]);
}
function parseIntroducedLine(text) {
  const t = text.replace(IMPORT_PREFIX_RE, "").trim();
  const m = t.match(/^Osoby, ktore zostaly ci ostatnio przedstawione, to (.+)\.$/);
  if (!m) return null;
  return splitImportedNames(m[1]);
}
function parseNotification(text) {
  const t = stripClientPrefix(text);
  const nowa = t.match(/^Masz nowa poczte od ([A-Za-z]+)\.$/);
  if (nowa) return { kind: "nowa-poczte", nadawca: nowa[1] };
  const wysylasz = t.match(/^Wysylasz ([A-Za-z]+) na poczte\.$/);
  if (wysylasz) return { kind: "wysylasz", zwierze: wysylasz[1] };
  const powrot = t.match(/^Wsrod trzepotu skrzydel ([A-Za-z]+) laduje na (?:twoim|twojej) \w+(?: \w+)?\.$/);
  if (powrot) return { kind: "powrot-zwierzecia", zwierze: powrot[1] };
  if (t === "List zostal pomyslnie wyslany.") return { kind: "list-wyslany" };
  if (t === "Kasuje listy...") return { kind: "kasowanie" };
  if (t === "Slucham?") return { kind: "slucham" };
  return null;
}
function parseMailError(text) {
  const zly = text.match(/^Zly numer listu: (\d+)\.$/);
  if (zly) return { kind: "zly-numer", numer: Number(zly[1]) };
  const adresat = text.match(/^(?:Adresat: |DW: |Temat: )?Nie ma takiego adresata \(gracza, aliasu\): (.+)\.$/);
  if (adresat) return { kind: "brak-adresata", adresat: adresat[1] };
  if (text === "Zadne listy nie zostaly wybrane.") return { kind: "brak-wyboru" };
  return null;
}
var COMPOSE_ECHO_RE = /^(?:(Adresat|Temat|DW): )+$/;
function parseComposeEcho(text) {
  if (!COMPOSE_ECHO_RE.test(text)) return null;
  const out = [];
  for (const m of text.matchAll(/(Adresat|Temat|DW): /g)) {
    out.push(m[1] === "Adresat" ? "adresat" : m[1] === "Temat" ? "temat" : "dw");
  }
  return out.length ? out : null;
}
var EDITOR_READY_RE = /Wpisz ~\?, zeby uzyskac pomoc, lub \*\*, by zakonczyc edycje\./;
var EDITOR_ECHO_RE = /^(\s*\d+\])+/;
var RESULT_WYSLANY = "List zostal pomyslnie wyslany.";
function isEditorReady(text) {
  return EDITOR_READY_RE.test(text);
}
var RESULT_GOTOWY = "List jest gotowy do wyslania.";
function parseEditorEcho(text) {
  const m = text.match(EDITOR_ECHO_RE);
  if (!m) return null;
  const numbers = [...m[0].matchAll(/(\d+)\]/g)].map((x) => Number(x[1]));
  const rest = text.slice(m[0].length);
  let result = null;
  if (rest === RESULT_WYSLANY) result = "wyslany";
  else if (rest === RESULT_GOTOWY) result = "gotowy";
  else if (rest !== "") return null;
  return { consumed: Math.max(...numbers), result };
}
function parseComposeResult(text) {
  if (text === RESULT_WYSLANY) return "wyslany";
  if (text === RESULT_GOTOWY) return "gotowy";
  return null;
}

// src/arkmail/core/session/lines.ts
function isEchoLine(text) {
  return text.startsWith("\u2192 ") || text === "\u2192";
}
function isPromptLine(text) {
  return /^>+\s*$/.test(text);
}

// src/arkmail/core/session/orphanPager.ts
var suspected = false;
function suspectPagerOrphan() {
  suspected = true;
}
function clearPagerOrphan() {
  suspected = false;
}
function isPagerOrphanSuspected() {
  return suspected;
}

// src/arkmail/core/protocol/commands.ts
var ROMAN_MONTHS = [
  "I",
  "II",
  "III",
  "IV",
  "V",
  "VI",
  "VII",
  "VIII",
  "IX",
  "X",
  "XI",
  "XII"
];
var SEARCH_DATE_ERROR = "Podaj prawidlowa date w formacie RRRR-MM-DD.";
var SEARCH_RANGE_ERROR = "Od dnia pozniej niz Do dnia.";
function isValidDateYMD(date) {
  if (!Number.isInteger(date.day) || !Number.isInteger(date.month) || !Number.isInteger(date.year)) {
    return false;
  }
  if (date.year < 1 || date.month < 1 || date.month > 12 || date.day < 1) return false;
  const leap = date.year % 4 === 0 && (date.year % 100 !== 0 || date.year % 400 === 0);
  const monthDays = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  return date.day <= monthDays[date.month - 1];
}
function assertValidDateYMD(date) {
  if (!isValidDateYMD(date)) throw new RangeError(SEARCH_DATE_ERROR);
}
function compareDates(a, b) {
  return a.year - b.year || a.month - b.month || a.day - b.day;
}
function hasPreviousDay(date) {
  return date.year > 1 || date.month > 1 || date.day > 1;
}
function olderListingCommand(box, date) {
  assertValidDateYMD(date);
  const roman = ROMAN_MONTHS[date.month - 1];
  return `listy ${box} przed ${date.day} ${roman} ${date.year}`;
}
function nextDay(date) {
  assertValidDateYMD(date);
  const leap = date.year % 4 === 0 && (date.year % 100 !== 0 || date.year % 400 === 0);
  const monthDays = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const max = monthDays[date.month - 1];
  if (date.day < max) return { day: date.day + 1, month: date.month, year: date.year };
  if (date.month < 12) return { day: 1, month: date.month + 1, year: date.year };
  return { day: 1, month: 1, year: date.year + 1 };
}
function prevDay(date) {
  assertValidDateYMD(date);
  if (!hasPreviousDay(date)) throw new RangeError(SEARCH_DATE_ERROR);
  const leap = date.year % 4 === 0 && (date.year % 100 !== 0 || date.year % 400 === 0);
  const monthDays = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (date.day > 1) return { day: date.day - 1, month: date.month, year: date.year };
  if (date.month > 1) {
    return { day: monthDays[date.month - 2], month: date.month - 1, year: date.year };
  }
  return { day: 31, month: 12, year: date.year - 1 };
}
function validateSearchText(query) {
  if (query.osoba && !/^[a-zA-Z]+$/.test(query.osoba)) {
    return "Osoba: tylko litery a-zA-Z.";
  }
  if (query.temat && /[;#]/.test(query.temat)) {
    return "Temat nie moze zawierac znakow ; ani #.";
  }
  if (query.tresc && /[;#]/.test(query.tresc)) {
    return "Tresc nie moze zawierac znakow ; ani #.";
  }
  return null;
}
function validateListingSearch(query) {
  const textError = validateSearchText(query);
  if (textError) return textError;
  if (query.odDaty && (!isValidDateYMD(query.odDaty) || !hasPreviousDay(query.odDaty))) {
    return SEARCH_DATE_ERROR;
  }
  if (query.doDaty && !isValidDateYMD(query.doDaty)) return SEARCH_DATE_ERROR;
  if (query.odDaty && query.doDaty && compareDates(query.odDaty, query.doDaty) > 0) {
    return SEARCH_RANGE_ERROR;
  }
  return null;
}
function validateSearchDraft(draft) {
  const textError = validateSearchText(draft);
  if (textError) return textError;
  const odDaty = draft.odDaty === "" ? null : fromISODate(draft.odDaty);
  const doDaty = draft.doDaty === "" ? null : fromISODate(draft.doDaty);
  if (draft.odDaty !== "" && !odDaty || draft.doDaty !== "" && !doDaty) {
    return SEARCH_DATE_ERROR;
  }
  if (odDaty && !hasPreviousDay(odDaty)) return SEARCH_DATE_ERROR;
  if (odDaty && doDaty && compareDates(odDaty, doDaty) > 0) return SEARCH_RANGE_ERROR;
  return null;
}
var SENDER_BOXES = /* @__PURE__ */ new Set(["odebrane", "nieprzeczytane"]);
var datePart = (d) => `${d.day} ${ROMAN_MONTHS[d.month - 1]} ${d.year}`;
function searchListingCommand(box, q) {
  const validationError = validateListingSearch(q);
  if (validationError) throw new RangeError(validationError);
  const parts = [`listy ${box}`];
  if (q.osoba) {
    const osoba = q.osoba.toLowerCase();
    parts.push(SENDER_BOXES.has(box) ? `od ${osoba}` : `do ${osoba}`);
  }
  if (q.odDaty) parts.push(`po ${datePart(prevDay(q.odDaty))}`);
  if (q.doDaty) parts.push(`przed ${datePart(nextDay(q.doDaty))}`);
  if (q.tresc) parts.push(`o tresci ${q.tresc}`);
  if (q.temat) parts.push(`o temacie ${q.temat}`);
  return parts.join(" ");
}
var ISO_RE = /^(\d{4})-(\d{2})-(\d{2})$/;
function fromISODate(iso) {
  const m = iso.match(ISO_RE);
  if (!m) return null;
  const date = { year: Number(m[1]), month: Number(m[2]), day: Number(m[3]) };
  try {
    nextDay(date);
  } catch {
    return null;
  }
  return date;
}
var isoOf = (d) => `${d.year}-${String(d.month).padStart(2, "0")}-${String(d.day).padStart(2, "0")}`;
function searchDescription(box, q) {
  const parts = [box];
  if (q.osoba) parts.push(`${SENDER_BOXES.has(box) ? "nadawca" : "adresat"}: ${q.osoba}`);
  if (q.odDaty) parts.push(`od dnia: ${isoOf(q.odDaty)}`);
  if (q.doDaty) parts.push(`do dnia: ${isoOf(q.doDaty)}`);
  if (q.temat) parts.push(`temat: "${q.temat}"`);
  if (q.tresc) parts.push(`tresc: "${q.tresc}"`);
  return parts.join(", ");
}

// src/arkmail/core/composeValidation.ts
function validRecipients(value, required) {
  const trimmed = value.trim();
  if (!trimmed) return !required;
  if (/[^a-zA-Z, ]/.test(value)) return false;
  return trimmed.split(",").every((part) => {
    const names = part.trim();
    return /^[a-zA-Z]+(?: +[a-zA-Z]+)*$/.test(names);
  });
}
function validateCompose(input) {
  if (!/\S/.test(input.tresc)) return "Brak tresci listu.";
  if (/[;#]/.test(input.tresc)) return "Tresc nie moze zawierac znakow ; ani #.";
  if (!input.adresat.trim()) return "Podaj adresata.";
  if (!validRecipients(input.adresat, true)) {
    return "Adresat: tylko litery a-zA-Z, przecinki i spacje.";
  }
  if (!input.temat.trim()) return "Podaj temat.";
  if (/[;#]/.test(input.temat)) return "Temat nie moze zawierac znakow ; ani #.";
  if (!validRecipients(input.dw, false)) {
    return "DW: tylko litery a-zA-Z, przecinki i spacje.";
  }
  return null;
}
function splitRecipients(value) {
  return value.split(",").map((part) => part.trim()).filter((part) => part.length > 0);
}
function unknownRecipients(input, known) {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const name of [...splitRecipients(input.adresat), ...splitRecipients(input.dw)]) {
    const key = name.toLowerCase();
    if (known.has(key) || seen.has(key)) continue;
    seen.add(key);
    out.push(name);
  }
  return out;
}

// src/arkmail/core/archive.ts
var SENDER_BOXES2 = /* @__PURE__ */ new Set(["odebrane", "nieprzeczytane"]);
var RECIPIENT_BOXES = /* @__PURE__ */ new Set(["wyslane", "niewyslane"]);
function fnv1a(input) {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16).padStart(8, "0");
}
function sortKeyOf(date) {
  if (!date) return "0000-00-00 00:00:00";
  const p = (n) => String(n).padStart(2, "0");
  return `${date.year}-${p(date.month)}-${p(date.day)} ${date.time}`;
}
function letterId(box, party, subject, forwarded, dateRaw) {
  return fnv1a([box, party, subject, forwarded ? "f" : "", dateRaw ?? ""].join("|"));
}
function scanKeyOfEntries(entries) {
  return fnv1a(
    entries.map(
      (e) => [
        e.number,
        e.isRead ? "R" : "N",
        e.forwarded ? "F" : "",
        e.party,
        e.subject,
        e.date?.raw ?? ""
      ].join("|")
    ).join("\n")
  );
}
function recordId(box, scanKey, position) {
  return fnv1a([box, scanKey, String(position)].join("|"));
}
function contentKeyOf(letter) {
  return fnv1a(
    [letter.party, letter.subject, letter.forwarded === true ? "f" : "", letter.dateRaw ?? ""].join(
      "|"
    )
  );
}
function fromMailboxEntry(box, entry, scanKey, position) {
  const dateRaw = entry.date?.raw ?? null;
  return {
    id: scanKey !== void 0 && position !== void 0 ? recordId(box, scanKey, position) : letterId(box, entry.party, entry.subject, entry.forwarded, dateRaw),
    box,
    number: entry.number,
    party: entry.party,
    subject: entry.subject,
    forwarded: entry.forwarded,
    dateRaw,
    sortKey: sortKeyOf(entry.date),
    read: entry.isRead,
    body: []
  };
}
function fromOpenedLetter(box, letter, entry) {
  if (entry) {
    const base = entry.archiveId ? {
      ...fromMailboxEntry(box, entry),
      id: entry.archiveId
    } : fromMailboxEntry(box, entry);
    return { ...base, read: true, body: letter.body };
  }
  const party = SENDER_BOXES2.has(box) ? letter.from : letter.to;
  const dateRaw = letter.date;
  const parsed = dateRaw ? parseMailDate(dateRaw) : null;
  return {
    id: letterId(box, party, letter.subject, false, dateRaw),
    box,
    number: letter.number,
    party,
    subject: letter.subject,
    forwarded: false,
    dateRaw,
    sortKey: sortKeyOf(parsed),
    read: true,
    body: letter.body
  };
}
var ARCHIVE_DATE_SUFFIX_RE = /\s+([A-Za-z]+, \d{1,2} (?:XII|XI|IX|VIII|VII|VI|IV|V|III|II|I|X) \d{4}, \d{2}:\d{2}:\d{2})$/;
var ARCHIVE_SORT_KEY_RE = /^(\d{4})-(\d{2})-(\d{2}) ((?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d)$/;
var ARCHIVE_WEEKDAYS = ["N", "Pn", "Wt", "Sr", "Cz", "Pt", "So"];
var ARCHIVE_MONTHS = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"];
function dateFromSortKey(sortKey2) {
  const match = sortKey2.match(ARCHIVE_SORT_KEY_RE);
  if (!match) return null;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const calendar = /* @__PURE__ */ new Date(0);
  calendar.setUTCFullYear(year, month - 1, day);
  calendar.setUTCHours(0, 0, 0, 0);
  if (calendar.getUTCFullYear() !== year || calendar.getUTCMonth() !== month - 1 || calendar.getUTCDate() !== day) {
    return null;
  }
  const raw = `${ARCHIVE_WEEKDAYS[calendar.getUTCDay()]}, ${day} ${ARCHIVE_MONTHS[month - 1]} ${year}, ${match[4]}`;
  return parseMailDate(raw);
}
function compareText(a, b) {
  return a < b ? -1 : a > b ? 1 : 0;
}
function mergeArchiveDuplicates(group) {
  if (group.length === 1) return group[0];
  const ordered = [...group].sort((a, b) => compareText(JSON.stringify(a), JSON.stringify(b)));
  const bodies = /* @__PURE__ */ new Map();
  for (const letter of ordered) {
    const key = JSON.stringify(letter.body);
    if (!bodies.has(key)) bodies.set(key, letter.body);
  }
  const orderedBodies = [...bodies.values()].sort(
    (a, b) => b.length - a.length || compareText(JSON.stringify(a), JSON.stringify(b))
  );
  const body = [...orderedBodies[0] ?? []];
  for (const candidate of orderedBodies.slice(1)) {
    for (const line of candidate) {
      if (!body.includes(line)) body.push(line);
    }
  }
  const merged = {
    ...ordered[0],
    number: Math.max(...group.map((letter) => letter.number)),
    read: group.some((letter) => letter.read),
    body
  };
  return merged;
}
function normalizeArchive(letters) {
  const groups = /* @__PURE__ */ new Map();
  for (const letter of letters) {
    const suffix = letter.party.match(ARCHIVE_DATE_SUFFIX_RE);
    const suffixDate = suffix ? parseMailDate(suffix[1]) : null;
    const directDate = letter.dateRaw ? parseMailDate(letter.dateRaw) : null;
    const date = directDate ?? suffixDate ?? dateFromSortKey(letter.sortKey);
    const party = suffixDate ? letter.party.slice(0, suffix.index).trimEnd() : letter.party;
    const dateRaw = date?.raw ?? letter.dateRaw;
    const normalized = {
      ...letter,
      party,
      dateRaw,
      sortKey: date ? sortKeyOf(date) : letter.sortKey,
      body: [...letter.body]
    };
    const group = groups.get(normalized.id);
    if (group) group.push(normalized);
    else groups.set(normalized.id, [normalized]);
  }
  return [...groups.values()].map(mergeArchiveDuplicates).sort(byNewest);
}
function byNewest(a, b) {
  if (a.sortKey !== b.sortKey) return a.sortKey < b.sortKey ? 1 : -1;
  if (a.number !== b.number) return b.number - a.number;
  return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
}
function insertLetters(existing, incoming) {
  const map = new Map(existing.map((l) => [l.id, l]));
  let added = 0;
  for (const inc of incoming) {
    if (map.has(inc.id)) continue;
    map.set(inc.id, inc);
    added++;
  }
  return { letters: [...map.values()].sort(byNewest), added };
}
function mergeListingPage(existing, box, incoming) {
  const pool = /* @__PURE__ */ new Map();
  for (const l of existing) {
    if (l.box !== box) continue;
    const key = contentKeyOf(l);
    const arr = pool.get(key);
    if (arr) arr.push(l);
    else pool.set(key, [l]);
  }
  const resolvedIds = [];
  const freshIds = /* @__PURE__ */ new Set();
  const toInsert = [];
  for (const rec of incoming) {
    const candidates = pool.get(contentKeyOf(rec));
    if (candidates && candidates.length > 0) {
      const matched = candidates.shift();
      resolvedIds.push(matched.id);
      freshIds.add(matched.id);
    } else {
      resolvedIds.push(rec.id);
      freshIds.add(rec.id);
      toInsert.push(rec);
    }
  }
  const inserted = insertLetters(existing, toInsert);
  return { letters: inserted.letters, added: inserted.added, resolvedIds, freshIds };
}
function replaceBoxLetters(existing, box, incoming) {
  const merged = mergeListingPage(existing, box, incoming);
  const removedIds = /* @__PURE__ */ new Set();
  const letters = merged.letters.filter((letter) => {
    if (letter.box !== box || merged.freshIds.has(letter.id)) return true;
    removedIds.add(letter.id);
    return false;
  });
  if (removedIds.size === 0 && merged.added === 0) {
    return { letters: [...existing], removedIds, resolvedIds: merged.resolvedIds };
  }
  return { letters, removedIds, resolvedIds: merged.resolvedIds };
}
function upsertLetters(existing, incoming) {
  const map = new Map(existing.map((l) => [l.id, l]));
  let added = 0;
  let updated = 0;
  for (const inc of incoming) {
    const prev = map.get(inc.id);
    if (!prev) {
      map.set(inc.id, inc);
      added++;
      continue;
    }
    map.set(inc.id, {
      ...prev,
      ...inc,
      body: inc.body.length > 0 ? inc.body : prev.body
    });
    updated++;
  }
  return { letters: [...map.values()].sort(byNewest), added, updated };
}
function purgeGoneLettersNewerThan(existing, box, freshIds, boundaryDay) {
  const removedIds = /* @__PURE__ */ new Set();
  const letters = existing.filter((letter) => {
    if (letter.box !== box || freshIds.has(letter.id)) return true;
    if (letter.sortKey.slice(0, 10) <= boundaryDay) return true;
    removedIds.add(letter.id);
    return false;
  });
  if (removedIds.size === 0) return { letters: [...existing], removedIds };
  return { letters, removedIds };
}
var validArchiveDate = (value) => value !== void 0 && fromISODate(value) !== null ? value : void 0;
function filterVisibleArchive(letters, filter) {
  const odDaty = validArchiveDate(filter.odDaty);
  const doDaty = validArchiveDate(filter.doDaty);
  const out = [];
  for (const l of letters) {
    if (filter.skrzynka !== void 0 && l.box !== filter.skrzynka) continue;
    if (filter.tresc !== void 0 && !norm(l.body.join("\n")).includes(norm(filter.tresc)))
      continue;
    if (filter.od !== void 0) {
      if (!SENDER_BOXES2.has(l.box)) continue;
      if (!norm(l.party).includes(norm(filter.od))) continue;
    }
    if (filter.do !== void 0) {
      if (!RECIPIENT_BOXES.has(l.box)) continue;
      if (!norm(l.party).includes(norm(filter.do))) continue;
    }
    if (filter.osoba !== void 0 && !norm(l.party).includes(norm(filter.osoba))) continue;
    if (filter.temat !== void 0 && !norm(l.subject).includes(norm(filter.temat))) continue;
    if (odDaty !== void 0 && l.sortKey.slice(0, 10) < odDaty) continue;
    if (doDaty !== void 0 && l.sortKey.slice(0, 10) > doDaty) continue;
    out.push(l);
  }
  return out.sort(byNewest);
}
var norm = (s) => s.toLowerCase();

// src/arkmail/core/pagination.ts
var PAGE_PACE_MS = 400;
var ANCHOR_RETRY_WAITS_MS = [2500, 4e3, 4e3];
var entryKey = (entry) => [entry.party, entry.subject, entry.forwarded ? "f" : "", entry.date?.raw ?? ""].join("|");
function oldestEntry(entries) {
  let oldest = null;
  for (const entry of entries) {
    if (!entry.date) continue;
    if (!oldest || sortKey(entry) < sortKey(oldest)) oldest = entry;
  }
  return oldest;
}
var sortKey = (entry) => {
  const d = entry.date;
  const p = (n) => String(n).padStart(2, "0");
  return `${d.year}-${p(d.month)}-${p(d.day)} ${d.time}`;
};
var isoDay = (entry) => entry.date ? sortKey(entry).slice(0, 10) : null;
var oneDayOf = (entries) => {
  if (entries.length === 0) return null;
  const first = isoDay(entries[0]);
  if (first === null) return null;
  return entries.every((entry) => isoDay(entry) === first) ? first : null;
};
var gapReason = (day) => `ponad 50 listow z dnia ${day} - serwer nie pokazuje reszty`;
async function scanMailboxPages(options) {
  const { box } = options;
  const seenCounts = /* @__PURE__ */ new Map();
  const all = [];
  const gapDays = [];
  let pages = 0;
  let addedToView = 0;
  let archiveAdded = 0;
  let oldestSeenDay = null;
  let anchorRetries = 0;
  let wallProbed = false;
  let probePending = false;
  let probeDay = null;
  let result = await options.fetchPage(options.initialCommand);
  const finish = (end, skipWhy = null) => ({
    end,
    pages,
    addedToView,
    archiveAdded,
    all,
    oldestSeenDay,
    gapDays: [...gapDays],
    skipWhy
  });
  const addGap = (day) => {
    if (gapDays.includes(day)) return;
    gapDays.push(day);
    gapDays.sort();
    options.onGap?.(day);
  };
  const incompleteWithGaps = () => finish("incomplete", gapDays.map(gapReason).join("; "));
  for (; ; ) {
    if (options.cancelled()) return finish("cancelled");
    if (result.kind !== "lista") {
      options.onEmpty?.(result);
      if (probePending && probeDay !== null) addGap(probeDay);
      if (gapDays.length > 0) return incompleteWithGaps();
      return finish("complete");
    }
    const rowsPerKey = /* @__PURE__ */ new Map();
    for (const entry of result.entries) {
      const k = fnv1a(entryKey(entry));
      rowsPerKey.set(k, (rowsPerKey.get(k) ?? 0) + 1);
      const day = isoDay(entry);
      if (day !== null && (oldestSeenDay === null || day < oldestSeenDay)) oldestSeenDay = day;
    }
    let freshCount = 0;
    for (const [k, n] of rowsPerKey) {
      if ((seenCounts.get(k) ?? 0) !== n) {
        seenCounts.set(k, n);
        freshCount += n;
      }
    }
    all.push(...result.entries);
    if (probePending && probeDay !== null) {
      const excludedDay = probeDay;
      const reachedOlderDay = result.entries.some((entry) => {
        const day = isoDay(entry);
        return day !== null && day < excludedDay;
      });
      if (!reachedOlderDay) {
        return finish("incomplete", "serwer chwilowo odpowiada wolno - sprobuj ponownie za chwile");
      }
      addGap(probeDay);
    }
    pages += 1;
    const visit = await options.onPage(result, pages);
    addedToView += visit.addedToView ?? 0;
    archiveAdded += visit.archiveAdded ?? 0;
    if (options.cancelled()) return finish("cancelled");
    if (!result.header.truncated) {
      if (gapDays.length > 0) return incompleteWithGaps();
      return finish("complete");
    }
    if (options.singlePage && freshCount > 0) {
      if (gapDays.length > 0) return incompleteWithGaps();
      return finish("partial");
    }
    if (freshCount === 0) {
      const oldestDuplicate = oldestEntry(all);
      if (!oldestDuplicate?.date) return finish("incomplete", "brak daty w wpisach");
      const attempt = anchorRetries;
      if (attempt < ANCHOR_RETRY_WAITS_MS.length) {
        anchorRetries += 1;
        await options.wait(ANCHOR_RETRY_WAITS_MS[attempt]);
        if (options.cancelled()) return finish("cancelled");
        const base = await options.fetchPage();
        options.onBaseRefresh?.(base);
        if (options.cancelled()) return finish("cancelled");
        result = await options.fetchPage(olderListingCommand(box, nextDay(oldestDuplicate.date)));
        continue;
      }
      if (!wallProbed) {
        wallProbed = true;
        probePending = true;
        probeDay = oneDayOf(result.entries);
        result = await options.fetchPage(olderListingCommand(box, oldestDuplicate.date));
        continue;
      }
      return finish("incomplete", "serwer chwilowo odpowiada wolno - sprobuj ponownie za chwile");
    }
    anchorRetries = 0;
    wallProbed = false;
    probePending = false;
    probeDay = null;
    if (visit.stop) {
      if (gapDays.length > 0) return incompleteWithGaps();
      return finish("clamped");
    }
    const oldest = oldestEntry(all);
    if (!oldest?.date) return finish("incomplete", "brak daty w wpisach");
    await options.wait(PAGE_PACE_MS);
    if (options.cancelled()) return finish("cancelled");
    result = await options.fetchPage(olderListingCommand(box, nextDay(oldest.date)));
  }
}

// src/arkmail/core/contacts.ts
var CONTACT_NAME_RE = /^[A-Za-z]+$/;
var WEEKDAYS = /* @__PURE__ */ new Set([
  "n",
  "nd",
  "nie",
  "niedziela",
  "pn",
  "pon",
  "poniedzialek",
  "wt",
  "wto",
  "wtorek",
  "sr",
  "sro",
  "sroda",
  "cz",
  "czw",
  "czwartek",
  "pt",
  "pi",
  "piatek",
  "so",
  "sob",
  "sobota"
]);
function splitParty(party) {
  const out = [];
  for (const part of party.split(/, | i /)) {
    const name = part.trim();
    if (!CONTACT_NAME_RE.test(name) || WEEKDAYS.has(name.toLowerCase())) continue;
    if (!out.includes(name)) out.push(name);
  }
  return out;
}
var directionOf = (box) => box === "odebrane" || box === "nieprzeczytane" ? "in" : "out";
function korespondencjaFromLetters(letters) {
  const byDedupKey = /* @__PURE__ */ new Map();
  for (const l of letters) {
    if (!l.party) continue;
    for (const name of splitParty(l.party)) {
      const dedupKey = [
        l.direction,
        name.toLowerCase(),
        l.subject,
        l.forwarded ? "f" : "",
        l.dateRaw ?? ""
      ].join("|");
      const n = l.count ?? 1;
      let entry = byDedupKey.get(dedupKey);
      if (!entry) {
        entry = {
          name,
          direction: l.direction,
          dateRaw: l.dateRaw ?? void 0,
          dateKey: l.dateKey,
          perBox: /* @__PURE__ */ new Map()
        };
        byDedupKey.set(dedupKey, entry);
      }
      entry.perBox.set(l.box, (entry.perBox.get(l.box) ?? 0) + n);
      if (entry.dateKey === void 0 && l.dateKey !== void 0) entry.dateKey = l.dateKey;
    }
  }
  return [...byDedupKey.values()].map((entry) => ({
    name: entry.name,
    direction: entry.direction,
    dateRaw: entry.dateRaw,
    dateKey: entry.dateKey,
    // Miedzy skrzynkami MAX - replika to ten sam fizyczny list.
    count: Math.max(...entry.perBox.values())
  }));
}
function archiveToLetterLike(l) {
  const digits = Number(l.sortKey.replace(/\D/g, ""));
  return {
    direction: directionOf(l.box),
    party: l.party,
    subject: l.subject,
    forwarded: l.forwarded === true,
    dateRaw: l.dateRaw,
    dateKey: digits > 0 ? digits : void 0,
    box: l.box
  };
}
function contactsFromArchiveWithAliases(letters, aliases) {
  return mergeContacts({
    people: [],
    // Fala 18b: szkice (niewyslane) to nie wyslana korespondencja.
    korespondencja: korespondencjaFromLetters(
      letters.filter((l) => l.box !== "niewyslane").map((l) => ({ ...archiveToLetterLike(l), count: l.occurrences ?? 1 }))
    ),
    aliasy: aliases.map((a) => ({ name: a.name, targets: [...a.targets] }))
  });
}
var SOURCE_ORDER = ["people", "korespondencja", "alias"];
function mergeContacts(input) {
  const byKey = /* @__PURE__ */ new Map();
  const get = (name) => {
    const key = name.toLowerCase();
    let c = byKey.get(key);
    if (!c) {
      c = { name, sources: [], lettersReceived: 0, lettersSent: 0 };
      byKey.set(key, c);
    }
    return c;
  };
  const addSource = (c, s) => {
    if (!c.sources.includes(s)) c.sources.push(s);
  };
  for (const p of input.people) {
    const c = get(p.name);
    c.name = p.name;
    addSource(c, "people");
    if (p.description) c.description = p.description;
    if (p.guild) c.guild = p.guild;
  }
  for (const k of input.korespondencja) {
    const c = get(k.name);
    addSource(c, "korespondencja");
    const n = k.count ?? 1;
    if (k.direction === "in") c.lettersReceived += n;
    else c.lettersSent += n;
    if (k.dateKey !== void 0) {
      if (c.lastContactKey === void 0 || k.dateKey > c.lastContactKey) {
        c.lastContactKey = k.dateKey;
        if (k.dateRaw) c.lastContactRaw = k.dateRaw;
      }
    } else if (k.dateRaw && c.lastContactKey === void 0) {
      if (!c.lastContactRaw || k.dateRaw > c.lastContactRaw) {
        c.lastContactRaw = k.dateRaw;
      }
    }
  }
  for (const a of input.aliasy) {
    for (const target of a.targets) {
      const c = get(target);
      addSource(c, "alias");
      if (!c.mailAlias) c.mailAlias = a.name;
    }
  }
  const out = [...byKey.values()];
  for (const c of out) {
    c.sources.sort((x, y) => SOURCE_ORDER.indexOf(x) - SOURCE_ORDER.indexOf(y));
  }
  out.sort((a, b) => a.name.localeCompare(b.name, "pl"));
  return out;
}
function viewContacts(contacts, opts = {}) {
  const f = (opts.filter ?? "").trim().toLowerCase();
  const filtered = f === "" ? [...contacts] : contacts.filter(
    (c) => c.name.toLowerCase().includes(f) || c.mailAlias !== void 0 && c.mailAlias.toLowerCase().includes(f)
  );
  const byName = (a, b) => a.name.localeCompare(b.name, "pl");
  switch (opts.sort ?? "nazwa") {
    case "liczba":
      filtered.sort(
        (a, b) => b.lettersReceived + b.lettersSent - (a.lettersReceived + a.lettersSent) || byName(a, b)
      );
      break;
    case "ostatni":
      filtered.sort(
        (a, b) => (b.lastContactKey ?? -1) - (a.lastContactKey ?? -1) || byName(a, b)
      );
      break;
    default:
      filtered.sort(byName);
  }
  return filtered;
}

// src/arkmail/core/addressBook.ts
var GROUPS_KEY = "grupy-kontaktow";
var PEOPLE_KEY = "osoby";
var LEGACY_PEOPLE_KEY = "osoby-importowane";
var ALIASES_KEY = "aliasy-importowane";
function cleanNames(value) {
  if (!Array.isArray(value)) return [];
  const out = [];
  for (const item of value) {
    if (typeof item !== "string") continue;
    const name = item.trim();
    if (name && !out.includes(name)) out.push(name);
  }
  return out;
}
function cleanBookNames(value) {
  if (!Array.isArray(value)) return [];
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  for (const item of value) {
    if (typeof item !== "string") continue;
    const name = item.trim();
    if (!name) continue;
    const key = name.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(name);
  }
  return out;
}
function cleanGroups(value) {
  if (!Array.isArray(value)) return [];
  const out = [];
  for (const item of value) {
    if (typeof item !== "object" || item === null) continue;
    const candidate = item;
    if (typeof candidate.name !== "string") continue;
    const name = candidate.name.trim();
    if (!name) continue;
    if (!Array.isArray(candidate.members)) continue;
    const members = cleanNames(candidate.members);
    const existing = out.find((g) => g.name === name);
    if (existing) {
      for (const member of members) {
        if (!existing.members.includes(member)) existing.members.push(member);
      }
    } else {
      out.push({ name, members });
    }
  }
  return out;
}
function cleanAliases(value) {
  if (!Array.isArray(value)) return [];
  const out = [];
  for (const item of value) {
    if (typeof item !== "object" || item === null) continue;
    const candidate = item;
    if (typeof candidate.name !== "string") continue;
    const name = candidate.name.trim();
    if (!name) continue;
    if (!Array.isArray(candidate.targets)) continue;
    const targets = cleanNames(candidate.targets);
    const existing = out.find((a) => a.name === name);
    if (existing) {
      for (const target of targets) {
        if (!existing.targets.includes(target)) existing.targets.push(target);
      }
    } else {
      out.push({ name, targets });
    }
  }
  return out;
}
function loadGroups(io) {
  return cleanGroups(io.getJSON(GROUPS_KEY));
}
function saveGroups(io, groups) {
  io.setJSON(GROUPS_KEY, cleanGroups(groups));
}
function savePeople(io, people) {
  io.setJSON(PEOPLE_KEY, cleanBookNames(people));
}
function unionPeople(existing, incoming) {
  return cleanBookNames([...existing, ...incoming]);
}
function migratePeople(io) {
  const current = io.getJSON(PEOPLE_KEY);
  if (current !== null) return cleanBookNames(current);
  const legacy = io.getJSON(
    LEGACY_PEOPLE_KEY
  );
  const names = cleanBookNames([
    ...legacy && typeof legacy === "object" ? cleanNames(legacy.zapamietani) : [],
    ...legacy && typeof legacy === "object" ? cleanNames(legacy.przedstawieni) : []
  ]);
  savePeople(io, names);
  return names;
}
function withGroupMembers(people, groups) {
  return unionPeople(people, groups.flatMap((g) => g.members));
}
function mergeAddressBook(existing, incoming) {
  const groups = cleanGroups(existing.groups).map((g) => ({
    ...g,
    members: [...g.members]
  }));
  let addedGroups = 0;
  let mergedGroups = 0;
  for (const group of cleanGroups(incoming.groups)) {
    const found = groups.find((g) => g.name.toLowerCase() === group.name.toLowerCase());
    if (found) {
      mergedGroups += 1;
      for (const member of group.members) {
        if (!found.members.some((m) => m.toLowerCase() === member.toLowerCase())) {
          found.members.push(member);
        }
      }
    } else {
      addedGroups += 1;
      groups.push(group);
    }
  }
  const before = cleanBookNames(existing.people);
  const people = withGroupMembers(unionPeople(before, incoming.people), groups);
  return {
    data: { people, groups },
    stats: {
      addedGroups,
      mergedGroups,
      addedPeople: Math.max(0, people.length - before.length)
    }
  };
}
function applyBookImport(existing, incoming, mode = "dolacz") {
  if (mode === "dolacz") return mergeAddressBook(existing, incoming);
  const groups = cleanGroups(incoming.groups);
  const before = cleanBookNames(existing.people);
  const people = withGroupMembers(cleanBookNames(incoming.people), groups);
  return {
    data: { people, groups },
    stats: {
      addedGroups: groups.length,
      mergedGroups: 0,
      addedPeople: Math.max(0, people.length - before.length)
    }
  };
}
function loadImportedAliases(io) {
  return cleanAliases(io.getJSON(ALIASES_KEY));
}
function saveImportedAliases(io, aliases) {
  io.setJSON(ALIASES_KEY, cleanAliases(aliases));
}
var ADDRESSBOOK_FORMAT = "arkmail-addressbook";
var ADDRESSBOOK_VERSION = 2;
function parseAddressBookExport(json) {
  let raw;
  try {
    raw = JSON.parse(json);
  } catch {
    return null;
  }
  if (typeof raw !== "object" || raw === null) return null;
  const candidate = raw;
  if (candidate.format !== ADDRESSBOOK_FORMAT) return null;
  if (typeof candidate.version !== "number") return null;
  if (candidate.version === 1) {
    const pools = typeof candidate.importedPeople === "object" && candidate.importedPeople !== null ? candidate.importedPeople : {};
    return {
      people: cleanBookNames([
        ...cleanNames(pools.zapamietani),
        ...cleanNames(pools.przedstawieni)
      ]),
      groups: cleanGroups(candidate.groups)
    };
  }
  return {
    people: cleanBookNames(candidate.people),
    groups: cleanGroups(candidate.groups)
  };
}
function buildAddressBookExport(book) {
  return JSON.stringify(
    {
      format: ADDRESSBOOK_FORMAT,
      version: ADDRESSBOOK_VERSION,
      people: cleanBookNames(book.people),
      groups: cleanGroups(book.groups)
    },
    null,
    2
  );
}

// src/arkmail/core/session/importer.ts
var IMPORT_COMMANDS = {
  zapamietani: "zapamietani",
  przedstawieni: "przedstawieni"
};
var ImportSession = class {
  constructor(transport2, opts) {
    __publicField(this, "transport", transport2);
    __publicField(this, "opts", opts);
  }
  collect(command) {
    return new Promise((resolve, reject) => {
      const lines = [];
      let done = false;
      const finish = () => {
        if (done) return;
        done = true;
        clearTimeout(timeout);
        if (idle !== void 0) clearTimeout(idle);
        unsubscribe();
        resolve(lines);
      };
      const fail = (err) => {
        if (done) return;
        done = true;
        clearTimeout(timeout);
        if (idle !== void 0) clearTimeout(idle);
        unsubscribe();
        reject(err);
      };
      const unsubscribe = this.transport.subscribe((line) => {
        if (done) return;
        const text = line.text;
        if (isPromptLine(text) || isEchoLine(text) && !line.own) {
          finish();
          return;
        }
        lines.push(text);
        if (this.opts.idleMs !== void 0) {
          if (idle !== void 0) clearTimeout(idle);
          idle = setTimeout(finish, this.opts.idleMs);
        }
      });
      let idle;
      const timeout = setTimeout(() => {
        fail(new Error(`import ${command}: timeout`));
      }, this.opts.timeoutMs);
      const cancelUnsub = this.opts.onCancel?.(() => {
        fail(new Error(`import ${command}: przerwano`));
      });
      void Promise.resolve(this.transport.send(command)).catch((err) => {
        cancelUnsub?.();
        fail(err instanceof Error ? err : new Error(String(err)));
      });
    });
  }
  /** Osoby zapamietane lub ostatnio przedstawione; pula pusta = []. */
  async fetchPeople(kind) {
    const lines = await this.collect(IMPORT_COMMANDS[kind]);
    const parse = kind === "zapamietani" ? parseRememberedLine : parseIntroducedLine;
    for (const line of lines) {
      const names = parse(line);
      if (names !== null) return names;
    }
    return [];
  }
  /** Alias pocztowe z gry (tylko odczyt; rozstrzyga je serwer). */
  async fetchAliases() {
    const lines = await this.collect("aliasy pocztowe");
    const start = lines.findIndex((l) => l.startsWith("Posiadasz nastepujace"));
    return parseAliasesBlock(start === -1 ? [] : lines.slice(start));
  }
};

// src/arkmail/core/archiveStats.ts
function liveArchiveGroups(letters) {
  const groups = /* @__PURE__ */ new Map();
  for (const letter of letters) {
    const key = contentKeyOf(letter);
    const group = groups.get(key);
    if (group) group.push(letter);
    else groups.set(key, [letter]);
  }
  return [...groups.values()];
}
function totalLive(letters) {
  const byKey = /* @__PURE__ */ new Map();
  for (const letter of letters) {
    const key = contentKeyOf(letter);
    let perBox = byKey.get(key);
    if (!perBox) {
      perBox = /* @__PURE__ */ new Map();
      byKey.set(key, perBox);
    }
    perBox.set(letter.box, (perBox.get(letter.box) ?? 0) + 1);
  }
  let total = 0;
  for (const perBox of byKey.values()) {
    total += Math.max(...perBox.values());
  }
  return total;
}
function perBoxCounts(letters) {
  const counts = /* @__PURE__ */ new Map();
  for (const letter of letters) {
    counts.set(letter.box, (counts.get(letter.box) ?? 0) + 1);
  }
  return counts;
}

// src/arkmail/core/session/mailbox.ts
var MAIL_ERROR_RE = /^Data zostala podana w zlym formacie\./;
var MailboxSession = class {
  constructor(transport2, opts) {
    __publicField(this, "transport", transport2);
    __publicField(this, "opts", opts);
  }
  /**
   * Pobiera listing skrzynki. command: wlasna komenda (paginacja wstecz
   * "listy <skrzynka> przed <data>", patrz protocol/commands.ts);
   * domyslnie "listy <skrzynka>".
   */
  fetch(box, command) {
    return new Promise((resolve, reject) => {
      const cmd = command ?? `listy ${box}`;
      let header = null;
      const entries = [];
      let done = false;
      let loadRetried = false;
      let loadRetryTimer = null;
      let pagerRetried = false;
      let awaitingPromptAfterQ = false;
      const idleMs = this.opts.idleMs ?? 600;
      let idleTimer = null;
      let cancelUnsub = () => {
      };
      const cleanup = () => {
        done = true;
        clearTimeout(timer);
        if (idleTimer) clearTimeout(idleTimer);
        if (loadRetryTimer) clearTimeout(loadRetryTimer);
        cancelUnsub();
        unsub();
      };
      const finish = (r) => {
        cleanup();
        clearPagerOrphan();
        resolve(r);
      };
      const armIdle = () => {
        if (idleTimer) clearTimeout(idleTimer);
        idleTimer = setTimeout(() => {
          if (done || !header) return;
          finish({ kind: "lista", header, entries });
        }, idleMs);
      };
      const timer = setTimeout(() => {
        if (awaitingPromptAfterQ) suspectPagerOrphan();
        cleanup();
        reject(new Error(`timeout: mailbox fetch ${box}`));
      }, this.opts.timeoutMs);
      const unsub = this.transport.subscribe((line) => {
        if (done) return;
        if (MAIL_ERROR_RE.test(line.text)) {
          cleanup();
          reject(new Error(line.text.trim()));
          return;
        }
        if (LISTS_LOADING_RE.test(line.text)) {
          if (loadRetried) {
            cleanup();
            reject(new Error("Listy sa w tej chwili ladowane."));
            return;
          }
          loadRetried = true;
          loadRetryTimer = setTimeout(() => {
            if (!done) this.transport.send(cmd);
          }, 2e3);
          return;
        }
        if (!header) {
          if (line.cls === "command" || isEchoLine(line.text)) return;
          if (awaitingPromptAfterQ) {
            if (line.cls === "prompt" || isPromptLine(line.text)) {
              awaitingPromptAfterQ = false;
              this.transport.send(cmd);
            }
            return;
          }
          if (extractPagerPrompt(line.text)) {
            if (pagerRetried) {
              suspectPagerOrphan();
              cleanup();
              reject(new Error(`sierocy pager podczas fetch ${box}`));
              return;
            }
            pagerRetried = true;
            awaitingPromptAfterQ = true;
            this.transport.send("q");
            return;
          }
          const empty = parseEmptyListing(line.text);
          if (empty) {
            if (!empty.boxes.includes(box)) {
              cleanup();
              reject(new Error(`pusta ${empty.boxes.join("/")} podczas fetch ${box}`));
              return;
            }
            finish({ kind: "pusta", box, reason: empty.reason });
            return;
          }
          const h = parseListingHeader(line.text);
          if (h) {
            if (h.box !== box) {
              cleanup();
              reject(new Error(`listing ${h.box} podczas fetch ${box}`));
              return;
            }
            if (loadRetryTimer) {
              clearTimeout(loadRetryTimer);
              loadRetryTimer = null;
            }
            header = h;
            armIdle();
          }
          return;
        }
        if (line.cls === "prompt" || line.cls === "command" || isPromptLine(line.text) || isEchoLine(line.text)) {
          finish({ kind: "lista", header, entries });
          return;
        }
        armIdle();
        const entry = parseListingEntry(line.text);
        if (entry) {
          entries.push({ ...entry, party: "", partyKind: null, date: null });
          return;
        }
        const party = parseListingParty(line.text);
        if (party && entries.length > 0) {
          const last = entries[entries.length - 1];
          last.party = party.names;
          last.partyKind = party.kind;
          last.date = party.date;
        }
      });
      cancelUnsub = this.opts.onCancel?.(() => {
        cleanup();
        reject(new Error("operacja anulowana"));
      }) ?? (() => {
      });
      if (!done) this.transport.send(cmd);
    });
  }
};

// src/arkmail/core/errors.ts
var isOperationCancelled = (error) => error instanceof Error && error.message === "operacja anulowana";
var RULES = [
  {
    re: /^timeout: mailbox fetch /,
    msg: "Serwer nie odpowiedzial na czas - sprobuj ponownie."
  },
  {
    re: /^timeout: pager session list \d+$/,
    msg: "Odczyt listu trwal za dlugo - sprobuj ponownie."
  },
  {
    re: /^pager session list \d+: przerwano$/,
    msg: "Przerwano odczyt listu."
  },
  {
    // Sierocy pager serwera (17a domyka, ale porazka moze sie zdarzyc).
    // Fala 21b: bez slowa "pager" - gracz nie zna tego pojecia.
    re: /odrzucono przez sierocy pager$|^sierocy pager podczas fetch /,
    msg: "Poczta sie zawiesila - sprobuj ponownie."
  },
  {
    re: /Listy sa w tej chwili ladowane\.$/,
    msg: "Serwer jeszcze laduje listy - sprobuj ponownie za chwile."
  },
  {
    // Straznik desynchronizacji (Fala 14d/17b): surowy format
    // "pusta <skrzynka> podczas fetch <skrzynka>" / "listing ...".
    re: /^(?:pusta|listing) (\S+) podczas fetch (\S+)$/,
    msg: (m) => `Serwer odpowiedzial za inna skrzynke (${m[1]} zamiast ${m[2]}) - sprobuj ponownie.`
  },
  {
    // "pager session list N: <linia serwera>" - linia serwera jest
    // juz po polsku ("Zly numer listu: 5."), tniemy tylko prefiks.
    re: /^pager session list \d+: (.+)$/,
    msg: (m) => m[1]
  }
];
var SERVER_LINE_RE = /^[A-Z][^]*\.$/;
function humanizeMailError(raw) {
  const text = raw.trim();
  for (const rule of RULES) {
    const m = text.match(rule.re);
    if (m) return typeof rule.msg === "string" ? rule.msg : rule.msg(m);
  }
  if (SERVER_LINE_RE.test(text)) return text;
  return "Operacja nie powiodla sie - sprobuj ponownie.";
}

// src/arkmail/core/exportTxt.ts
var ANSI_RE = /\[[0-9;]*m/g;
function stripAnsi(s) {
  return s.replace(ANSI_RE, "");
}
function letterTxt(l) {
  const meta = [];
  if (l.from) meta.push(`Od: ${stripAnsi(l.from)}`);
  if (l.to) meta.push(`Do: ${stripAnsi(l.to)}`);
  if (l.cc) meta.push(`DW: ${stripAnsi(l.cc)}`);
  if (l.date) meta.push(stripAnsi(l.date));
  meta.push(`skrzynka: ${l.box}`);
  const lines = [stripAnsi(l.subject), meta.join(" | "), "", ...l.body.map(stripAnsi)];
  return lines.join("\n") + "\n";
}
var SENDER_BOXES3 = /* @__PURE__ */ new Set(["odebrane", "nieprzeczytane"]);
function archiveLetterTxt(l) {
  const sender = SENDER_BOXES3.has(l.box);
  return letterTxt({
    subject: l.subject,
    from: sender ? l.party : "",
    to: sender ? "" : l.party,
    date: l.dateRaw,
    box: l.box,
    body: l.body
  });
}
function slugAscii(s, max = 40) {
  const slug = s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
  return (slug || "list").slice(0, max);
}
var p2 = (n) => String(n).padStart(2, "0");
function txtFileName(party, subject, dateRaw) {
  const d = dateRaw ? parseMailDate(dateRaw) : null;
  const stamp = d ? `${d.year}-${p2(d.month)}-${p2(d.day)}_${d.time.replace(/:/g, "-")}` : "0000-00-00_00-00-00";
  return `${stamp}_${slugAscii(party, 24)}_${slugAscii(subject, 40)}.txt`;
}
function archiveExportEntries(letters) {
  let skipped = 0;
  const withBody = [];
  for (const l of letters) {
    if (l.body.length > 0) withBody.push(l);
    else skipped += 1;
  }
  const sorted = [...withBody].sort((a, b) => {
    if (a.sortKey !== b.sortKey) return a.sortKey < b.sortKey ? 1 : -1;
    return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
  });
  const used = /* @__PURE__ */ new Map();
  const entries = sorted.map((letter) => {
    const base = `${letter.box}/${txtFileName(letter.party, letter.subject, letter.dateRaw)}`;
    const n = (used.get(base) ?? 0) + 1;
    used.set(base, n);
    const name = n === 1 ? base : base.replace(/\.txt$/, `-${n}.txt`);
    return { name, txt: archiveLetterTxt(letter) };
  });
  return { entries, skipped };
}

// src/arkmail/core/zipStore.ts
var CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(data) {
  let c = 4294967295;
  for (let i = 0; i < data.length; i++) c = CRC_TABLE[(c ^ data[i]) & 255] ^ c >>> 8;
  return (c ^ 4294967295) >>> 0;
}
function nameBytes(name) {
  const out = new Uint8Array(name.length);
  for (let i = 0; i < name.length; i++) out[i] = name.charCodeAt(i) & 127;
  return out;
}
var ByteSink = class {
  constructor() {
    __publicField(this, "chunks", []);
    __publicField(this, "len", 0);
  }
  push(b) {
    this.chunks.push(b);
    this.len += b.length;
  }
  u16(v) {
    this.push(new Uint8Array([v & 255, v >>> 8 & 255]));
  }
  u32(v) {
    this.push(new Uint8Array([v & 255, v >>> 8 & 255, v >>> 16 & 255, v >>> 24 & 255]));
  }
  get length() {
    return this.len;
  }
  concat() {
    const out = new Uint8Array(this.len);
    let off = 0;
    for (const c of this.chunks) {
      out.set(c, off);
      off += c.length;
    }
    return out;
  }
};
var DOS_TIME = 0;
var DOS_DATE = 33;
function buildZip(files) {
  const local = new ByteSink();
  const central = new ByteSink();
  for (const f of files) {
    const name = nameBytes(f.name);
    const crc = crc32(f.data);
    const offset = local.length;
    local.u32(67324752);
    local.u16(20);
    local.u16(0);
    local.u16(0);
    local.u16(DOS_TIME);
    local.u16(DOS_DATE);
    local.u32(crc);
    local.u32(f.data.length);
    local.u32(f.data.length);
    local.u16(name.length);
    local.u16(0);
    local.push(name);
    local.push(f.data);
    central.u32(33639248);
    central.u16(20);
    central.u16(20);
    central.u16(0);
    central.u16(0);
    central.u16(DOS_TIME);
    central.u16(DOS_DATE);
    central.u32(crc);
    central.u32(f.data.length);
    central.u32(f.data.length);
    central.u16(name.length);
    central.u16(0);
    central.u16(0);
    central.u16(0);
    central.u16(0);
    central.u32(0);
    central.u32(offset);
    central.push(name);
  }
  const cd = central.concat();
  const body = local.concat();
  const eocd = new ByteSink();
  eocd.u32(101010256);
  eocd.u16(0);
  eocd.u16(0);
  eocd.u16(files.length);
  eocd.u16(files.length);
  eocd.u32(cd.length);
  eocd.u32(body.length);
  eocd.u16(0);
  const out = new Uint8Array(body.length + cd.length + eocd.length);
  out.set(body, 0);
  out.set(cd, body.length);
  out.set(eocd.concat(), body.length + cd.length);
  return out;
}

// src/arkmail/ui/download.ts
var impl = null;
function downloadBlob(name, data) {
  try {
    if (impl) {
      impl(name, data);
      return true;
    }
    const g = globalThis;
    const doc = g.document;
    if (!doc?.body || !g.URL) return false;
    const a = doc.createElement("a");
    const url = g.URL.createObjectURL(data);
    a.href = url;
    a.download = name;
    doc.body.appendChild(a);
    a.click();
    a.remove();
    g.URL.revokeObjectURL(url);
    return true;
  } catch {
    return false;
  }
}

// src/arkmail/core/session/pager.ts
var numbersInRange = (range) => {
  const out = /* @__PURE__ */ new Set();
  for (const part of range.split(",")) {
    const m = part.trim().match(/^(\d+)(?:-(\d+))?$/);
    if (!m) continue;
    const from = Number(m[1]);
    const to = m[2] === void 0 ? from : Number(m[2]);
    const step = from <= to ? 1 : -1;
    for (let n = from; step > 0 ? n <= to : n >= to; n += step) out.add(n);
  }
  return [...out].sort((a, b) => a - b);
};
var rangeOf = (numbers) => {
  const sorted = [...new Set(numbers)].sort((a, b) => a - b);
  const parts = [];
  for (let i = 0; i < sorted.length; ) {
    const from = sorted[i];
    let to = from;
    while (i + 1 < sorted.length && sorted[i + 1] === to + 1) to = sorted[++i];
    parts.push(from === to ? String(from) : `${from}-${to}`);
    i++;
  }
  return parts.join(",");
};
var sameNumbers = (a, b) => a.length === b.length && a.every((n, i) => n === b[i]);
var numbersOfConfirmation = (text) => [...text.matchAll(/\d+/g)].map((m) => Number(m[0]));
var PAGER_REJECTION_RE = /Nie ma takiej komendy\./;
var ADVANCE_MAX_TRIES = 3;
var PagerSession = class {
  constructor(transport2, opts) {
    __publicField(this, "transport", transport2);
    __publicField(this, "opts", opts);
  }
  /**
   * Odczyt listu. shouldAbort (Fala 17a, zgloszenie pkt 4): Przerwij
   * petli pobierania w trakcie odczytu - sesja domyka pager od razu
   * ("q" tylko gdy pager faktycznie otwarty albo naglowki kompletne;
   * przed otwarciem zadnego smieciowego "q") i odrzuca "przerwano",
   * zamiast wisiec do timeoutu z otwartym pagerem serwera.
   */
  readLetter(numer, shouldAbort) {
    return this.run(numer, () => null, (letter, pager) => ({ letter, pager }), shouldAbort);
  }
  deleteLetters(numer, zakres, shouldAbort) {
    const requested = numbersInRange(zakres);
    let selectedNumbers = [];
    let confirmed = [];
    let deleteSent = false;
    let selectionAccepted = false;
    let uncertain = false;
    const build = () => {
      const deletedNumbers = [...new Set(confirmed)].filter((n) => requested.includes(n)).sort((a, b) => a - b);
      const unexpectedNumbers = [...new Set(confirmed)].filter((n) => !requested.includes(n)).sort((a, b) => a - b);
      const complete = requested.length > 0 && unexpectedNumbers.length === 0 && requested.every((n) => deletedNumbers.includes(n));
      const status = complete ? "complete" : deletedNumbers.length > 0 ? "partial" : uncertain || selectionAccepted ? "unknown" : "none";
      return { status, deleted: deletedNumbers.length > 0, deletedNumbers, selectedNumbers, unexpectedNumbers };
    };
    return this.run(
      numer,
      (ctx) => {
        const withdraw = () => {
          if (deleteSent && !selectionAccepted) ctx.send(`u ${rangeOf([...requested, ...selectedNumbers])}`);
        };
        return {
          onPager: () => {
            deleteSent = true;
            ctx.send(`d ${zakres}`);
          },
          onLine: (line) => {
            const m = line.text.match(/^Zaznaczono do skasowania: (.+)\.$/);
            if (m) {
              selectedNumbers = [...new Set(numbersOfConfirmation(m[1]))].sort((a, b) => a - b);
              if (!sameNumbers(selectedNumbers, requested)) {
                withdraw();
                return "close";
              }
              selectionAccepted = true;
              return "close";
            }
            return parseMailError(line.text) ? "close" : void 0;
          },
          onClosingLine: (line) => {
            const m = line.text.match(/^Kasuje: (.+)\.$/);
            if (m) {
              for (const n of numbersOfConfirmation(m[1])) confirmed.push(n);
            }
          },
          onAbort: withdraw,
          onTimeout: withdraw,
          onCancel: () => {
            if (!deleteSent) return;
            withdraw();
            ctx.send("q");
          }
        };
      },
      build,
      shouldAbort
    ).catch((error) => {
      if (!deleteSent) throw error;
      uncertain = true;
      return build();
    });
  }
  forwardLetter(numer, adresat) {
    let queued = false;
    let error = null;
    let dwAnswered = false;
    return this.run(
      numer,
      (ctx) => ({
        onPager: () => ctx.send(`f ${adresat}`),
        onLine: (line) => {
          const err = parseMailError(line.text);
          if (err && err.kind === "brak-adresata") {
            if (!error) error = err;
            return void 0;
          }
          if (/^DW: *$/.test(line.text)) {
            if (!dwAnswered) {
              dwAnswered = true;
              ctx.send("");
            }
            return void 0;
          }
          if (line.text === "List jest gotowy do wyslania.") {
            queued = true;
            return "close";
          }
          return void 0;
        }
      }),
      () => ({ queued, error })
    );
  }
  /**
   * Otwiera pager na liscie `numer`, wykonuje akcje, zamyka "q".
   * onPager: odpalane przy pierwszym pager prompt (wyslij akcje).
   * onLine: moze zwrocic 'close' -> wysylamy "q" przy najblizszym
   * pager prompcie. Konczy sie na linii promptu (klasa albo tresc)
   * albo idle-flush po "q".
   */
  run(numer, makeActions, build, shouldAbort) {
    return new Promise((resolve, reject) => {
      const letter = {
        number: numer,
        from: "",
        subject: "",
        to: "",
        cc: null,
        date: null,
        body: []
      };
      let pager = { lo: 0, hi: 0, current: numer };
      let state = "letter";
      let headersDone = false;
      let wantClose = false;
      let pagerFired = false;
      let idleOpened = false;
      let retried = false;
      let loadRetried = false;
      let loadRetryTimer = null;
      let done = false;
      let advances = 0;
      const idleMs = this.opts.idleMs ?? 600;
      let idleTimer = null;
      let quietTimer = null;
      let graceTimer = null;
      let cancelUnsub = () => {
      };
      const actions = makeActions({ send: (l) => this.transport.send(l) });
      const cleanup = () => {
        done = true;
        clearTimeout(timer);
        if (idleTimer) clearTimeout(idleTimer);
        if (quietTimer) clearTimeout(quietTimer);
        if (graceTimer) clearTimeout(graceTimer);
        if (loadRetryTimer) clearTimeout(loadRetryTimer);
        cancelUnsub();
        unsub();
      };
      let aborted = false;
      const finish = () => {
        cleanup();
        if (aborted) {
          reject(new Error(`pager session list ${numer}: przerwano`));
          return;
        }
        clearPagerOrphan();
        resolve(build(letter, pager));
      };
      const checkAbort = () => {
        if (done || aborted || !shouldAbort || !shouldAbort()) return;
        aborted = true;
        actions?.onAbort?.();
        if (state === "pager" || pagerFired || idleOpened || headersDone) {
          if (state !== "closing") enterClosing();
          return;
        }
        cleanup();
        reject(new Error(`pager session list ${numer}: przerwano`));
      };
      const armIdle = () => {
        if (idleTimer) clearTimeout(idleTimer);
        idleTimer = setTimeout(() => {
          if (!done && state === "closing") finish();
        }, idleMs);
      };
      const onQuiet = () => {
        if (done) return;
        checkAbort();
        if (done || aborted) return;
        if (state === "letter" && headersDone) {
          if (advances < ADVANCE_MAX_TRIES) {
            advances++;
            try {
              this.transport.send("");
            } catch {
            }
            armQuiet();
            return;
          }
          state = "pager";
          pagerFired = true;
          idleOpened = true;
          if (actions && actions.onPager) {
            actions.onPager();
            armQuiet();
          } else {
            enterClosing();
          }
          return;
        }
        if (state === "pager" && (wantClose || idleOpened)) enterClosing();
      };
      const armQuiet = () => {
        if (quietTimer) clearTimeout(quietTimer);
        quietTimer = setTimeout(onQuiet, idleMs);
      };
      const timer = setTimeout(() => {
        actions?.onTimeout?.();
        if (state === "closing") {
          suspectPagerOrphan();
          cleanup();
          reject(new Error(`timeout: pager session list ${numer}`));
          return;
        }
        state = "closing";
        wantClose = false;
        idleOpened = false;
        try {
          this.transport.send("q");
        } catch {
        }
        graceTimer = setTimeout(() => {
          suspectPagerOrphan();
          cleanup();
          reject(new Error(`timeout: pager session list ${numer}`));
        }, Math.max(idleMs, 400));
      }, this.opts.timeoutMs);
      const enterClosing = () => {
        wantClose = false;
        idleOpened = false;
        state = "closing";
        if (quietTimer) clearTimeout(quietTimer);
        this.transport.send("q");
        armIdle();
      };
      const unsub = this.transport.subscribe((line) => {
        if (done || line.cls === "command" || isEchoLine(line.text)) return;
        checkAbort();
        if (done) return;
        if (state === "closing") {
          if (line.cls === "prompt" || isPromptLine(line.text)) {
            finish();
            return;
          }
          actions?.onClosingLine?.(line);
          armIdle();
          return;
        }
        if (state === "recovering") {
          if (line.cls === "prompt" || isPromptLine(line.text)) {
            state = "letter";
            this.transport.send(`przeczytaj list ${numer}`);
          }
          return;
        }
        if (state === "letter" && !headersDone && PAGER_REJECTION_RE.test(line.text)) {
          this.transport.send("q");
          if (retried) {
            suspectPagerOrphan();
            cleanup();
            reject(new Error(`pager session list ${numer}: odrzucono przez sierocy pager`));
            return;
          }
          retried = true;
          state = "recovering";
          return;
        }
        if (state === "letter" && !headersDone) {
          if (LISTS_LOADING_RE.test(line.text)) {
            if (loadRetried) {
              cleanup();
              reject(new Error(`pager session list ${numer}: Listy sa w tej chwili ladowane.`));
              return;
            }
            loadRetried = true;
            loadRetryTimer = setTimeout(() => {
              if (!done && state === "letter") {
                this.transport.send(`przeczytaj list ${numer}`);
              }
            }, 2e3);
            return;
          }
          const mailErr = parseMailError(line.text);
          if (mailErr) {
            cleanup();
            reject(new Error(`pager session list ${numer}: ${line.text.trim()}`));
            return;
          }
        }
        const pp = extractPagerPrompt(line.text);
        if (pp) {
          advances = 0;
          if (quietTimer) clearTimeout(quietTimer);
          pager = pp;
          state = "pager";
          if (pagerFired && wantClose) {
            enterClosing();
            return;
          }
          if (!pagerFired) {
            pagerFired = true;
            if (actions && actions.onPager) {
              actions.onPager();
              return;
            }
            enterClosing();
            return;
          }
          return;
        }
        if (state === "letter" && !headersDone) {
          const h = parseLetterHeaderLine(line.text);
          if (h) {
            if (h.field === "numer") letter.number = Number(h.value);
            else if (h.field === "od") letter.from = h.value;
            else if (h.field === "temat") letter.subject = h.value;
            else if (h.field === "do") letter.to = h.value;
            else if (h.field === "dw") letter.cc = h.value;
            else if (h.field === "data") {
              letter.date = h.value;
              headersDone = true;
              armQuiet();
            }
            return;
          }
          return;
        }
        if (state === "letter") {
          letter.body.push(line.text);
          advances = 0;
          armQuiet();
          return;
        }
        if (actions && actions.onLine) {
          const verdict = actions.onLine(line);
          if (verdict === "close") wantClose = true;
        }
        armQuiet();
      });
      cancelUnsub = this.opts.onCancel?.(() => {
        actions?.onCancel?.();
        cleanup();
        reject(new Error("operacja anulowana"));
      }) ?? (() => {
      });
      if (!done) this.transport.send(`przeczytaj list ${numer}`);
    });
  }
};

// src/arkmail/core/session/editor.ts
var EditorSession = class {
  constructor(transport2, opts) {
    __publicField(this, "transport", transport2);
    __publicField(this, "opts", opts);
  }
  send(input) {
    return new Promise((resolve, reject) => {
      let stage = "adresat";
      let done = false;
      let editorReady = false;
      let bodyStarted = false;
      const dw = input.dw ?? "";
      let cancelUnsub = () => {
      };
      let transition = Promise.resolve();
      const cleanup = () => {
        done = true;
        clearTimeout(timer);
        cancelUnsub();
        unsub();
      };
      const finish = (r) => {
        cleanup();
        resolve(r);
      };
      const fail = (error) => {
        if (done) return;
        cleanup();
        reject(error);
      };
      const enqueue = (job) => {
        transition = transition.then(job);
        transition.catch(fail);
      };
      const sendLine = async (line) => {
        if (!done) await this.transport.send(line, true);
      };
      const timer = setTimeout(() => {
        cleanup();
        resolve({ result: "blad", error: { kind: "timeout" } });
      }, this.opts.timeoutMs);
      const flush = async (confirmed) => {
        const order = ["adresat", "temat", "dw"];
        for (const c of confirmed) {
          if (done) return;
          const idx = order.indexOf(c);
          const cur = order.indexOf(stage);
          if (idx < cur) continue;
          stage = order[idx + 1] ?? "tresc";
          if (c === "temat") await sendLine(input.temat);
          else if (c === "dw") await sendLine(dw);
        }
      };
      const sendBody = async () => {
        if (done || bodyStarted || stage !== "tresc" || !editorReady) return;
        bodyStarted = true;
        stage = "tresc-wyslana";
        for (const linia of input.linie) {
          if (done) return;
          await sendLine(linia);
        }
        if (!done) await sendLine("**");
      };
      const unsub = this.transport.subscribe((line) => {
        if (done || line.cls === "command" || isEchoLine(line.text)) return;
        if (line.text === "Zaniechane.") {
          finish({ result: "zaniechany" });
          return;
        }
        const err = parseMailError(line.text);
        if (err) {
          finish({ result: "blad", error: err });
          return;
        }
        const standalone = parseComposeResult(line.text);
        if (standalone) {
          finish({ result: standalone });
          return;
        }
        const echo = parseEditorEcho(line.text);
        if (echo?.result) {
          finish({ result: echo.result });
          return;
        }
        if (stage === "tresc-wyslana") return;
        if (isEditorReady(line.text)) editorReady = true;
        const prompts = parseComposeEcho(line.text);
        if (prompts) {
          enqueue(async () => {
            await flush(prompts);
            await sendBody();
          });
        } else if (editorReady) {
          enqueue(sendBody);
        }
      });
      cancelUnsub = this.opts.onCancel?.(() => {
        cleanup();
        reject(new Error("operacja anulowana"));
      }) ?? (() => {
      });
      if (!done) {
        const first = this.transport.send("napisz list", true);
        const second = this.transport.send(input.adresat, true);
        transition = Promise.all([first, second]).then(() => {
        });
        transition.catch(fail);
      }
    });
  }
};

// src/arkmail/core/sessionLock.ts
var SessionLock = class {
  constructor() {
    __publicField(this, "tail", Promise.resolve());
    __publicField(this, "active", 0);
    __publicField(this, "waiting", /* @__PURE__ */ new Set());
  }
  get locked() {
    return this.active > 0;
  }
  async acquire() {
    this.active++;
    let releaseNext;
    const next = new Promise((resolve) => {
      releaseNext = resolve;
    });
    const prev = this.tail;
    this.tail = prev.then(() => next);
    return new Promise((resolve, reject) => {
      let settled = false;
      let released = false;
      const cancel = () => {
        if (settled) return;
        settled = true;
        this.active--;
        this.waiting.delete(cancel);
        reject(new Error("operacja anulowana"));
      };
      this.waiting.add(cancel);
      void prev.then(() => {
        this.waiting.delete(cancel);
        if (settled) {
          releaseNext();
          return;
        }
        settled = true;
        resolve(() => {
          if (released) return;
          released = true;
          this.active--;
          releaseNext();
        });
      });
    });
  }
  /** Odrzuca operacje oczekujace; aktywna konczy sie przez swoja sesje. */
  cancelWaiting() {
    for (const cancel of [...this.waiting]) cancel();
  }
  async runExclusive(fn) {
    const release = await this.acquire();
    try {
      return await fn();
    } finally {
      release();
    }
  }
};

// src/arkmail/adapters/dargothTransport.ts
var MODAL_HOOK_PRIORITY = 100;
var PENDING_ECHO_CAP = 10;
var DargothTransport = class {
  constructor(api) {
    __publicField(this, "api", api);
    __publicField(this, "subscribers", /* @__PURE__ */ new Set());
    __publicField(this, "triggerArmed", false);
    __publicField(this, "modalActive", false);
    __publicField(this, "hookId", null);
    __publicField(this, "queue", []);
    __publicField(this, "commandQueue", Promise.resolve());
    __publicField(this, "connectionGeneration", 0);
    __publicField(this, "sendingOwn", false);
    /** Fala 42: teksty wysylek z echem (echo=true) czekajacych na
     *  linie-echo w strumieniu. FIFO z limitem. Wysylka bez echa NIE
     *  rejestruje sie - identyczny tekst wpisany recznie przez gracza
     *  nigdy nie dostanie znacznika own. */
    __publicField(this, "pendingEchoSends", []);
    // Fala 25 (blad 3): transport startuje ROZBROJONY. Brama otwiera
    // wylacznie sygnal obecnosci w grze (gmcp.char.info / char.name /
    // mail.state / room.long albo proxy.session z faktycznym wznowieniem
    // sesji); client.connect sam w sobie NIE uzbraja, bo odpala tez na
    // ekranie logowania - komenda "listy ..." na prompcie nazwy postaci
    // zabijala logowanie ("Nie ma takiej postaci").
    __publicField(this, "online", false);
    /** Fala 16j: kiedy tlumic linie pocztowe (index.ts: blokada sesji). */
    __publicField(this, "gagWhen", null);
  }
  /**
   * Fala 16j: predykat gagowania linii pocztowych (cls 'mail'). Linie
   * przychodzace podczas operacji pluginowej (listingi, tresci listow)
   * nie smieca glownego okna gry; poza operacja wszystko przechodzi
   * bez zmian (reczne "listy" gracza, powiadomienie POCZTA).
   */
  setGagPredicate(pred) {
    this.gagWhen = pred;
  }
  send(line, echo = false) {
    return this.enqueue(line, echo);
  }
  /** Jedna komenda czeka na zakonczenie przetwarzania poprzedniej. */
  enqueue(line, echo) {
    if (!this.online) return Promise.resolve();
    const generation = this.connectionGeneration;
    const task = this.commandQueue.then(async () => {
      if (!this.online || generation !== this.connectionGeneration) return;
      let pending;
      if (echo) {
        this.pendingEchoSends.push(line);
        if (this.pendingEchoSends.length > PENDING_ECHO_CAP) this.pendingEchoSends.shift();
      }
      this.sendingOwn = true;
      try {
        pending = this.api.command.send(line, echo, { preserveCase: true });
      } finally {
        this.sendingOwn = false;
      }
      await pending;
    });
    this.commandQueue = task.catch(() => {
    });
    return task;
  }
  subscribe(cb) {
    this.armTrigger();
    this.subscribers.add(cb);
    return () => {
      this.subscribers.delete(cb);
    };
  }
  /** Liczba komend gracza odlozonych w trakcie sesji modalnej. */
  get modalQueueLength() {
    return this.queue.length;
  }
  beginModal() {
    if (this.modalActive) return;
    this.modalActive = true;
    this.hookId = this.api.commandHooks.register((command) => {
      if (this.sendingOwn) return void 0;
      this.queue.push(command);
      return null;
    }, MODAL_HOOK_PRIORITY);
  }
  endModal() {
    if (!this.modalActive) return;
    this.modalActive = false;
    if (this.hookId !== null) {
      this.api.commandHooks.unregister(this.hookId);
      this.hookId = null;
    }
    const pending = this.queue.splice(0);
    if (!this.online) return;
    for (const command of pending) {
      void this.enqueue(command, true).catch(() => {
      });
    }
  }
  /** Odcina stare wysylki i porzuca kolejke bez drenowania. */
  setOnline(online) {
    this.online = online;
    if (online) return;
    this.connectionGeneration++;
    this.commandQueue = Promise.resolve();
    this.pendingEchoSends = [];
    if (this.hookId !== null) {
      this.api.commandHooks.unregister(this.hookId);
      this.hookId = null;
    }
    this.modalActive = false;
    this.queue = [];
  }
  /** Zdejmuje trigger i modal-guard; do wywolania w destroy() pluginu. */
  dispose() {
    this.endModal();
    if (this.triggerArmed) {
      this.api.triggers.removeByTag("arkmail");
      this.triggerArmed = false;
    }
    this.subscribers.clear();
    this.queue = [];
    this.pendingEchoSends = [];
    this.connectionGeneration++;
    this.commandQueue = Promise.resolve();
  }
  armTrigger() {
    if (this.triggerArmed) return;
    this.triggerArmed = true;
    this.api.triggers.register(
      /^/,
      // 4. argument (originalLine) niesie dziewiczy tekst linii z gry -
      // system triggerow Dargoth przekazuje kolejnym callbackom buffer
      // po cudzych modyfikacjach (np. newMail klienta dokleja prefix
      // "\n[ POCZTA ] " i suffix "\n\n"), co lamalo dopasowania
      // (Fala 8a, dowod: Triggers.ts TriggerCallback + newMail.ts).
      (line, _matches, type, originalLine) => {
        const proto = { text: originalLine ?? line.text, cls: type ?? "" };
        if (this.pendingEchoSends.length > 0) {
          const echoed = proto.text.startsWith("\u2192 ") ? proto.text.slice(2) : proto.cls === "command" ? proto.text : null;
          if (echoed !== null) {
            const i = this.pendingEchoSends.indexOf(echoed);
            if (i >= 0) {
              this.pendingEchoSends.splice(i, 1);
              proto.own = true;
            }
          }
        }
        for (const cb of [...this.subscribers]) cb(proto);
        if (type === "mail" && this.gagWhen?.()) return null;
        return line;
      },
      "arkmail"
    );
  }
};

// src/arkmail/adapters/storageDriver.ts
var MemoryStorageDriver = class {
  constructor() {
    __publicField(this, "values", /* @__PURE__ */ new Map());
    __publicField(this, "letters", /* @__PURE__ */ new Map());
  }
  async loadAll() {
    return Object.fromEntries(this.values);
  }
  async loadAllLetters() {
    return Object.fromEntries(
      [...this.letters].map(([character, values]) => [character, Object.fromEntries(values)])
    );
  }
  async put(key, value) {
    this.values.set(key, value);
  }
  async putMany(values) {
    for (const [key, value] of Object.entries(values)) this.values.set(key, value);
  }
  async putLetters(character, values) {
    const current = this.letters.get(character) ?? /* @__PURE__ */ new Map();
    this.letters.set(character, current);
    for (const [id, value] of Object.entries(values)) current.set(id, value);
  }
  async deleteLetters(character, ids) {
    const current = this.letters.get(character);
    if (!current) return;
    for (const id of ids) current.delete(id);
  }
  async delete(key) {
    this.values.delete(key);
  }
  async clearLetters(character) {
    await this.clearMailData(character, []);
  }
  async clearMailData(character, keys) {
    this.letters.delete(character);
    for (const key of keys) this.values.delete(key);
  }
  async close() {
  }
};
var STATE_STORE = "state";
var LETTERS_STORE = "letters";
var LEGACY_STORE = "dane";
var DATABASE_VERSION = 2;
var IndexedDbStorageDriver = class {
  constructor(factory, databaseName = "arkmail") {
    __publicField(this, "databaseName", databaseName);
    __publicField(this, "databasePromise", null);
    __publicField(this, "database", null);
    __publicField(this, "factory");
    this.factory = factory ?? globalThis.indexedDB;
  }
  async loadAll() {
    const database = await this.openDatabase();
    return new Promise((resolve, reject) => {
      const values = {};
      const transaction = database.transaction(STATE_STORE, "readonly");
      const request = transaction.objectStore(STATE_STORE).openCursor();
      request.onsuccess = () => {
        const cursor = request.result;
        if (!cursor) return;
        values[String(cursor.key)] = String(cursor.value);
        cursor.continue();
      };
      transaction.oncomplete = () => resolve(values);
      transaction.onerror = () => reject(transaction.error ?? new Error("Blad odczytu IndexedDB."));
      transaction.onabort = () => reject(transaction.error ?? new Error("Odczyt IndexedDB przerwany."));
    });
  }
  async loadAllLetters() {
    const database = await this.openDatabase();
    return new Promise((resolve, reject) => {
      const result = {};
      const transaction = database.transaction(LETTERS_STORE, "readonly");
      const request = transaction.objectStore(LETTERS_STORE).openCursor();
      request.onsuccess = () => {
        var _a;
        const cursor = request.result;
        if (!cursor) return;
        const record = cursor.value;
        (result[_a = record.character] ?? (result[_a] = {}))[record.id] = record.value;
        cursor.continue();
      };
      transaction.oncomplete = () => resolve(result);
      transaction.onerror = () => reject(transaction.error ?? new Error("Blad odczytu listow."));
      transaction.onabort = () => reject(transaction.error ?? new Error("Odczyt listow przerwany."));
    });
  }
  async put(key, value) {
    await this.writeState("put", key, value);
  }
  async putMany(values) {
    const database = await this.openDatabase();
    await new Promise((resolve, reject) => {
      const transaction = database.transaction(STATE_STORE, "readwrite");
      const store2 = transaction.objectStore(STATE_STORE);
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error ?? new Error("Blad zapisu IndexedDB."));
      transaction.onabort = () => reject(transaction.error ?? new Error("Zapis IndexedDB przerwany."));
      try {
        for (const [key, value] of Object.entries(values)) store2.put(value, key);
      } catch (error) {
        transaction.abort();
        reject(error);
      }
    });
  }
  async putLetters(character, values) {
    if (Object.keys(values).length === 0) return;
    const database = await this.openDatabase();
    await new Promise((resolve, reject) => {
      const transaction = database.transaction(LETTERS_STORE, "readwrite");
      const store2 = transaction.objectStore(LETTERS_STORE);
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error ?? new Error("Blad zapisu listow."));
      transaction.onabort = () => reject(transaction.error ?? new Error("Zapis listow przerwany."));
      try {
        for (const [id, value] of Object.entries(values)) store2.put({ character, id, value });
      } catch (error) {
        transaction.abort();
        reject(error);
      }
    });
  }
  async deleteLetters(character, ids) {
    if (ids.length === 0) return;
    const database = await this.openDatabase();
    await new Promise((resolve, reject) => {
      const transaction = database.transaction(LETTERS_STORE, "readwrite");
      const store2 = transaction.objectStore(LETTERS_STORE);
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error ?? new Error("Blad kasowania listow."));
      transaction.onabort = () => reject(transaction.error ?? new Error("Kasowanie listow przerwane."));
      try {
        for (const id of ids) store2.delete([character, id]);
      } catch (error) {
        transaction.abort();
        reject(error);
      }
    });
  }
  async delete(key) {
    await this.writeState("delete", key);
  }
  async clearLetters(character) {
    await this.clearMailData(character, []);
  }
  async clearMailData(character, keys) {
    const database = await this.openDatabase();
    await new Promise((resolve, reject) => {
      const transaction = database.transaction([LETTERS_STORE, STATE_STORE], "readwrite");
      const request = transaction.objectStore(LETTERS_STORE).index("character").openCursor(character);
      request.onsuccess = () => {
        const cursor = request.result;
        if (!cursor) return;
        cursor.delete();
        cursor.continue();
      };
      try {
        const state = transaction.objectStore(STATE_STORE);
        for (const key of keys) state.delete(key);
      } catch (error) {
        transaction.abort();
        reject(error);
      }
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error ?? new Error("Blad usuwania danych."));
      transaction.onabort = () => reject(transaction.error ?? new Error("Usuwanie danych przerwane."));
    });
  }
  async close() {
    const pending = this.databasePromise;
    if (pending) {
      try {
        await pending;
      } catch {
        return;
      }
    }
    this.database?.close();
    this.database = null;
    this.databasePromise = null;
  }
  openDatabase() {
    if (this.databasePromise) return this.databasePromise;
    const opening = new Promise((resolve, reject) => {
      if (!this.factory) {
        reject(new Error("Baza w przegladarce nie dziala - zapis bedzie tylko w pamieci."));
        return;
      }
      let request;
      try {
        request = this.factory.open(this.databaseName, DATABASE_VERSION);
      } catch (error) {
        reject(error);
        return;
      }
      let failed = false;
      request.onupgradeneeded = () => {
        const database = request.result;
        if (database.objectStoreNames.contains(LEGACY_STORE)) {
          database.deleteObjectStore(LEGACY_STORE);
        }
        if (!database.objectStoreNames.contains(STATE_STORE)) {
          database.createObjectStore(STATE_STORE);
        }
        if (!database.objectStoreNames.contains(LETTERS_STORE)) {
          const letters = database.createObjectStore(LETTERS_STORE, {
            keyPath: ["character", "id"]
          });
          letters.createIndex("character", "character", { unique: false });
        }
      };
      request.onerror = () => {
        failed = true;
        reject(request.error ?? new Error("Nie mozna otworzyc IndexedDB."));
      };
      request.onblocked = () => {
        failed = true;
        reject(new Error("Otwarcie IndexedDB jest zablokowane."));
      };
      request.onsuccess = () => {
        if (failed) {
          request.result.close();
          return;
        }
        this.database = request.result;
        resolve(request.result);
      };
    });
    this.databasePromise = opening;
    void opening.catch(() => {
      if (this.databasePromise === opening) this.databasePromise = null;
    });
    return opening;
  }
  async writeState(operation, key, value) {
    const database = await this.openDatabase();
    await new Promise((resolve, reject) => {
      const transaction = database.transaction(STATE_STORE, "readwrite");
      const store2 = transaction.objectStore(STATE_STORE);
      if (operation === "put") store2.put(value, key);
      else store2.delete(key);
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error ?? new Error("Blad zapisu IndexedDB."));
      transaction.onabort = () => reject(transaction.error ?? new Error("Zapis IndexedDB przerwany."));
    });
  }
};

// src/arkmail/adapters/writeThroughStorage.ts
var STORAGE_WRITE_ERROR = "Nie udalo sie zapisac danych archiwum";
var WriteThroughStorage = class _WriteThroughStorage {
  constructor(driver, initialValues, initialLetters, onError) {
    __publicField(this, "driver", driver);
    __publicField(this, "onError", onError);
    __publicField(this, "values");
    __publicField(this, "letters", /* @__PURE__ */ new Map());
    __publicField(this, "pendingLetters", /* @__PURE__ */ new Map());
    __publicField(this, "queue", Promise.resolve());
    __publicField(this, "errorReported", false);
    this.values = new Map(Object.entries(initialValues));
    for (const [character, letters] of Object.entries(initialLetters)) {
      this.letters.set(character, new Map(Object.entries(letters)));
    }
  }
  static async open(driver, onError) {
    const [values, letters] = await Promise.all([
      driver.loadAll(),
      driver.loadAllLetters ? driver.loadAllLetters() : Promise.resolve({})
    ]);
    return new _WriteThroughStorage(driver, values, letters, onError);
  }
  get(key) {
    return this.values.get(key) ?? null;
  }
  getLetters(character) {
    return Object.fromEntries(this.letters.get(character) ?? []);
  }
  set(key, value) {
    this.values.set(key, value);
    this.enqueue(() => this.driver.put(key, value));
  }
  setMany(values) {
    const batch = { ...values };
    for (const [key, value] of Object.entries(batch)) this.values.set(key, value);
    this.enqueue(() => this.driver.putMany(batch));
  }
  setLetters(character, letters) {
    const current = this.letters.get(character) ?? /* @__PURE__ */ new Map();
    this.letters.set(character, current);
    let changed = false;
    for (const letter of letters) {
      const value = JSON.stringify(letter);
      if (current.get(letter.id) === value) continue;
      current.set(letter.id, value);
      const key = JSON.stringify([character, letter.id]);
      this.pendingLetters.set(key, { character, id: letter.id, value });
      changed = true;
    }
    const alive = new Set(letters.map((letter) => letter.id));
    const removed = [];
    for (const id of current.keys()) {
      if (alive.has(id)) continue;
      removed.push(id);
      this.pendingLetters.delete(JSON.stringify([character, id]));
    }
    for (const id of removed) current.delete(id);
    if (changed) this.enqueue(() => this.flushPendingLetters());
    if (removed.length > 0) {
      const batch = removed;
      this.enqueue(() => this.driver.deleteLetters(character, batch));
    }
  }
  delete(key) {
    this.values.delete(key);
    this.enqueue(() => this.driver.delete(key));
  }
  clearLetters(character) {
    this.letters.delete(character);
    for (const [key, letter] of this.pendingLetters) {
      if (letter.character === character) this.pendingLetters.delete(key);
    }
    this.enqueue(() => this.driver.clearLetters(character));
  }
  async clearMailData(character, keys) {
    const operation = this.queue.then(async () => {
      await this.driver.clearMailData(character, keys);
      this.letters.delete(character);
      for (const [key, letter] of this.pendingLetters) {
        if (letter.character === character) this.pendingLetters.delete(key);
      }
      for (const key of keys) this.values.delete(key);
    });
    this.queue = operation.catch(() => {
      if (this.errorReported) return;
      this.errorReported = true;
      this.onError();
    });
    await operation;
  }
  async flush() {
    await this.queue;
  }
  async close() {
    await this.flush();
    await this.driver.close();
  }
  async flushPendingLetters() {
    if (this.pendingLetters.size === 0) return;
    const pending = [...this.pendingLetters.values()];
    this.pendingLetters.clear();
    const byCharacter = /* @__PURE__ */ new Map();
    for (const letter of pending) {
      let values = byCharacter.get(letter.character);
      if (!values) {
        values = {};
        byCharacter.set(letter.character, values);
      }
      values[letter.id] = letter.value;
    }
    for (const [character, values] of byCharacter) {
      await this.driver.putLetters(character, values);
    }
  }
  enqueue(operation) {
    this.queue = this.queue.then(operation).catch(() => {
      if (this.errorReported) return;
      this.errorReported = true;
      this.onError();
    });
  }
};
async function openWriteThroughStorage(onError, factory) {
  const persistent = new IndexedDbStorageDriver(factory);
  try {
    return await WriteThroughStorage.open(persistent, onError);
  } catch {
    await persistent.close();
    onError();
    return WriteThroughStorage.open(new MemoryStorageDriver(), onError);
  }
}

// src/arkmail/adapters/storage.ts
var CharStorage = class _CharStorage {
  constructor(char, storage) {
    __publicField(this, "char", char);
    __publicField(this, "storage", storage);
  }
  static async open(character, driver, onError) {
    const normalized = character.trim().toLowerCase();
    if (!normalized) throw new Error("Brak nazwy postaci dla magazynu.");
    return new _CharStorage(normalized, await WriteThroughStorage.open(driver, onError));
  }
  static fromWriteThrough(character, storage) {
    const normalized = character.trim().toLowerCase();
    if (!normalized) throw new Error("Brak nazwy postaci dla magazynu.");
    return new _CharStorage(normalized, storage);
  }
  get character() {
    return this.char;
  }
  getLetters() {
    const letters = [];
    for (const raw of Object.values(this.storage.getLetters(this.char))) {
      try {
        letters.push(JSON.parse(raw));
      } catch {
      }
    }
    return letters;
  }
  setLetters(letters) {
    this.storage.setLetters(this.char, letters);
  }
  clearLetters() {
    this.storage.clearLetters(this.char);
  }
  async clearMailData(keys) {
    await this.storage.clearMailData(this.char, keys.map((key) => this.scoped(key)));
  }
  getJSON(key) {
    const raw = this.storage.get(this.scoped(key));
    if (raw === null) return null;
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }
  setJSON(key, value) {
    this.storage.set(this.scoped(key), JSON.stringify(value));
  }
  setJSONBatch(values) {
    const batch = {};
    for (const [key, value] of Object.entries(values)) {
      batch[this.scoped(key)] = JSON.stringify(value);
    }
    this.storage.setMany(batch);
  }
  remove(key) {
    this.storage.delete(this.scoped(key));
  }
  async flush() {
    await this.storage.flush();
  }
  async close() {
    await this.storage.close();
  }
  scoped(key) {
    return `arkmail.${this.char}.${key}`;
  }
};
async function openCharStorage(character, onError, factory) {
  const storage = await openWriteThroughStorage(onError, factory);
  return CharStorage.fromWriteThrough(character, storage);
}
function cleanupLegacyStorage() {
  try {
    const legacy = globalThis.localStorage;
    const keys = [];
    for (let i = 0; i < legacy.length; i++) {
      const key = legacy.key(i);
      if (key?.startsWith("arkmail.")) keys.push(key);
    }
    for (const key of keys) legacy.removeItem(key);
  } catch {
  }
}

// src/arkmail/adapters/notify.ts
var DEFAULT_NOTIFY_TIME_MS = 8e3;
function notify(api, text, opts = {}) {
  api.notifications.show({
    text,
    ...opts.title !== void 0 ? { title: opts.title } : {},
    level: opts.level ?? "info",
    time: opts.time ?? DEFAULT_NOTIFY_TIME_MS
  });
}

// src/arkmail/ui/deletion.ts
function emptyDeletionFilters() {
  return { osoba: "", temat: "", tresc: "", odDaty: "", doDaty: "" };
}
function formatListCount(count) {
  const lastTwo = count % 100;
  const last = count % 10;
  const form = count === 1 ? "list" : last >= 2 && last <= 4 && (lastTwo < 12 || lastTwo > 14) ? "listy" : "listow";
  return `${count} ${form}`;
}

// src/arkmail/ui/store.ts
function contentKeyOfEntry(e) {
  return [e.party, e.subject, e.forwarded ? "f" : "", e.date?.raw ?? ""].join("|");
}
function deletionState(revision) {
  return {
    box: "odebrane",
    filters: emptyDeletionFilters(),
    command: null,
    result: null,
    selected: [],
    message: null,
    revision,
    armedAt: 0
  };
}
var INDEX_BOXES = ["odebrane", "nieprzeczytane", "wyslane", "niewyslane"];
var allBoxesIndexed = (meta) => INDEX_BOXES.every((b) => meta[b] !== void 0);
var DEFAULT_STATE = {
  tab: "listy",
  wide: false,
  activeBox: "odebrane",
  boxes: {},
  badge: 0,
  badgeUnsent: 0,
  busy: null,
  loadAll: null,
  archiveDownload: null,
  search: null,
  letter: null,
  contacts: [],
  people: [],
  importedAliases: [],
  groups: [],
  archive: [],
  notifyEnabled: true,
  animalFlying: false,
  unsentFlash: false,
  composeTemplate: "plain",
  composeWidth: 60,
  composeClearSeq: 0,
  indexMeta: {},
  archiveGaps: {},
  indexRun: null,
  deletion: deletionState(0)
};
var MailUiStore = class {
  constructor(initial) {
    __publicField(this, "current");
    __publicField(this, "listeners", /* @__PURE__ */ new Set());
    /** Schowek pelnych widokow skrzynek na czas trybu wynikow szukania. */
    __publicField(this, "stashedViews", {});
    /**
     * Zakladka, do ktorej wraca Zamknij list (Fala 17d, zgloszenie
     * pkt 2): list otwarty z Archiwum zamyka sie DO Archiwum, nie na
     * Listy. Zapisywana przy openLetter z zakladki innej niz 'list'
     * (openLetter nad otwartym listem nie nadpisuje pierwszego zrodla).
     */
    __publicField(this, "letterReturnTab", null);
    this.current = { ...DEFAULT_STATE, ...initial };
  }
  get state() {
    return this.current;
  }
  subscribe(cb) {
    this.listeners.add(cb);
    return () => {
      this.listeners.delete(cb);
    };
  }
  setTab(tab) {
    const patch = { tab };
    if (this.current.tab === "usuwanie" && tab !== "usuwanie") {
      patch.deletion = deletionState(this.current.deletion.revision + 1);
    }
    this.update(patch);
  }
  /**
   * Flip szerokosci w trakcie czytania nie gubi listu (Fala 10):
   * wide->waski przenosi otwarty list do pelnego panelu (zakladka
   * 'list'), waski->wide wraca do podzialu (zakladka 'listy').
   * Bez otwartego listu zakladka zostaje jak jest.
   */
  setWide(wide) {
    const patch = { wide };
    if (this.current.letter) {
      if (!wide && this.current.tab === "listy") patch.tab = "list";
      else if (wide && this.current.tab === "list") patch.tab = "listy";
    }
    this.update(patch);
  }
  setActiveBox(box) {
    this.update({ activeBox: box });
  }
  applyMailbox(box, result) {
    const view = result.kind === "lista" ? (
      // Fala 34: listing 1:1 - para blizniakow (identyczne
      // metadane, rozne numery) to DWA wiersze. Cala strona =
      // blok glowy (sync paruje z nim, nie ze starszymi stronami).
      {
        entries: result.entries,
        truncated: result.header.truncated,
        empty: null,
        headCount: result.entries.length
      }
    ) : { entries: [], truncated: false, empty: result.reason, headCount: 0 };
    const boxes = { ...this.current.boxes, [box]: view };
    const b = computeBadges(boxes);
    this.update({ boxes, badge: b.unread, badgeUnsent: b.unsent });
  }
  /**
   * Dokleja strone starszych listow (paginacja "Wybrane listy") PRZED
   * istniejace wpisy - widok trzyma kolejnosc serwera (najstarszy
   * pierwszy). Fala 34: w obrebie strony NIC nie deduplikujemy;
   * zdejmujemy jedynie wpisy juz widoczne (sonda sciany paginacji
   * odpytuje ponownie dzien graniczny - to te same fizyczne listy).
   * Tozsamosc wpisu = archiveId rekordu archiwum (Fala 41): blizniak
   * o identycznych metadanych ma WLASNE archiveId i zostaje wlasnym
   * wierszem, nawet gdy drugi blizniak juz jest widoczny. Klucz
   * tresci zostaje filtrem WYLACZNIE dla wpisow bez archiveId (zapisy
   * legacy sprzed stemplowania). truncated=false oznacza koniec
   * starszych (przycisk znika).
   */
  /** Dokleja strone starszych wpisow; zwraca liczbe NOWYCH wierszy. */
  appendMailboxPage(box, entries, truncated) {
    const view = this.current.boxes[box];
    if (!view) return 0;
    const knownIds = /* @__PURE__ */ new Set();
    const knownKeys = /* @__PURE__ */ new Set();
    for (const e of view.entries) {
      if (e.archiveId !== void 0) knownIds.add(e.archiveId);
      else knownKeys.add(contentKeyOfEntry(e));
    }
    const fresh = entries.filter(
      (e) => e.archiveId !== void 0 ? !knownIds.has(e.archiveId) : !knownKeys.has(contentKeyOfEntry(e))
    );
    const next = {
      entries: [...fresh, ...view.entries],
      truncated,
      empty: null,
      headCount: view.headCount
    };
    const boxes = { ...this.current.boxes, [box]: next };
    const b = computeBadges(boxes);
    this.update({ boxes, badge: b.unread, badgeUnsent: b.unsent });
    return fresh.length;
  }
  /**
   * Sync najnowszej strony z widokiem (Fala 12b; zastepuje "replace"
   * z Fali 11e jako domyslny tryb odswiezania). Wczytane starsze strony
   * ("Wczytaj starsze" / "Wczytaj wszystkie") NIE znikaja przy
   * odswiezeniu - gracz nie wraca do domyslnych 50 wpisow.
   *
   * - Fala 34: parowanie wielozbiorowe (multiset) W OBREBIE bloku
   *   glowy - wpisy swiezej strony parowane po kluczu tresci ze
   *   starymi wpisami bloku glowy i aktualizowane W MIEJSCU (np.
   *   znacznik *R*); drugi blizniak na swiezej stronie = DOKLADANY
   *   wiersz (blizniaki nigdy nie sa sklejane);
   * - nowe listy doklejane sa NA KONCU tablicy (koniec najnowszy; UI
   *   renderuje odwrotnie, wiec laduja na gorze ekranu);
   * - znacznik uciecia odpowiada najswiezszemu listingowi: komplet go
   *   zdejmuje, a pozniejszy limit ustawia go ponownie;
   * - usuwanie wpisow TYLKO gdy swiezy listing jest kompletny (bez
   *   uciecia): wtedy serwer raportuje pelna prawde (np. przeczytany
   *   list znika z 'nieprzeczytane'). Przy ucietych listingach brak
   *   wpisu moze byc wypchnieciem poza pierwsza strone - nic nie
   *   usuwamy.
   *
   * Fala 30b: przy UCIETYM listingu opcjonalna granica dnia
   * (pruneNewerThan, ISO YYYY-MM-DD = najstarszy dzien swiezej strony).
   * Strona jest ciagla od najnowszego, wiec wpis SCISELE NOWSZY niz
   * granica, nieobecny na stronie, na pewno nie ma go juz w skrzynce -
   * usuwamy. Dzien graniczny, starsze i wpisy bez daty zostaja
   * (strona moze byc ucieta w polowie dnia).
   *
   * Zwraca null, gdy brak widoku lub widok pusty - caller powinien
   * zrobic applyMailbox. Zwraca liczby {updated, added, removed}.
   */
  syncMailboxPage(box, entries, truncated, pruneNewerThan) {
    const view = this.current.boxes[box];
    if (!view || view.empty !== null) return null;
    const key = contentKeyOfEntry;
    const isoDay2 = (e) => {
      if (!e.date) return null;
      const p = (n) => String(n).padStart(2, "0");
      return `${e.date.year}-${p(e.date.month)}-${p(e.date.day)}`;
    };
    const all = view.entries;
    const headCount = Math.min(view.headCount, all.length);
    const older = all.slice(0, all.length - headCount);
    const head = all.slice(all.length - headCount);
    const headSlots = /* @__PURE__ */ new Map();
    head.forEach((e, i) => {
      const k = key(e);
      const list = headSlots.get(k);
      if (list) list.push(i);
      else headSlots.set(k, [i]);
    });
    const used = /* @__PURE__ */ new Set();
    const newHead = head.map(() => null);
    let updated = 0;
    let added = 0;
    for (const e of entries) {
      const free = headSlots.get(key(e))?.find((i) => !used.has(i));
      if (free === void 0) {
        newHead.push(e);
        added += 1;
      } else {
        used.add(free);
        newHead[free] = e;
        updated += 1;
      }
    }
    let removed = 0;
    let keptHead;
    if (!truncated) {
      removed += newHead.filter((e) => e === null).length;
      keptHead = newHead.filter((e) => e !== null);
    } else if (pruneNewerThan !== void 0) {
      keptHead = [];
      for (let i = 0; i < newHead.length; i++) {
        const slot = newHead[i];
        if (slot === null) {
          const day = isoDay2(head[i]);
          if (day !== null && day > pruneNewerThan) {
            removed += 1;
            continue;
          }
          keptHead.push(head[i]);
        } else {
          keptHead.push(slot);
        }
      }
    } else {
      keptHead = newHead.map((e, i) => e ?? head[i]);
    }
    let next = [...older, ...keptHead];
    if (!truncated) {
      const freshCounts = /* @__PURE__ */ new Map();
      for (const e of entries) {
        const k = key(e);
        freshCounts.set(k, (freshCounts.get(k) ?? 0) + 1);
      }
      const keptOlder = older.filter((e) => {
        const c = freshCounts.get(key(e)) ?? 0;
        if (c > 0) {
          freshCounts.set(key(e), c - 1);
          return true;
        }
        return false;
      });
      removed += older.length - keptOlder.length;
      next = [...keptOlder, ...keptHead];
    }
    const nextView = {
      entries: next,
      truncated,
      empty: null,
      headCount: keptHead.length
    };
    const boxes = { ...this.current.boxes, [box]: nextView };
    const b = computeBadges(boxes);
    this.update({ boxes, badge: b.unread, badgeUnsent: b.unsent });
    return { updated, added, removed };
  }
  /**
   * Usuwa z widoku skrzynki wpisy, ktorych rekord archiwum oznaczono
   * jako nieobecny na serwerze (Fala 30c). Gone-marking dotyka archiwum;
   * bez tego widoku martwy wpis zostawal klikalny ("Nie ma tego listu
   * na liscie"). Lokalne, zero komend; zwraca liczbe usunietych.
   */
  pruneMailboxEntries(box, goneIds) {
    const view = this.current.boxes[box];
    if (!view || view.empty !== null || goneIds.size === 0) return 0;
    const id = (e) => e.archiveId ?? letterId(box, e.party, e.subject, e.forwarded, e.date?.raw ?? null);
    const kept = view.entries.filter((e) => !goneIds.has(id(e)));
    const removed = view.entries.length - kept.length;
    if (removed === 0) return 0;
    const headCount = Math.min(view.headCount, view.entries.length);
    const removedFromHead = view.entries.slice(view.entries.length - headCount).filter((e) => goneIds.has(id(e))).length;
    const boxes = {
      ...this.current.boxes,
      [box]: { ...view, entries: kept, headCount: Math.max(0, headCount - removedFromHead) }
    };
    const b = computeBadges(boxes);
    this.update({ boxes, badge: b.unread, badgeUnsent: b.unsent });
    return removed;
  }
  setDeletionBox(box) {
    this.update({
      deletion: {
        ...this.current.deletion,
        box,
        command: null,
        result: null,
        selected: [],
        message: null,
        revision: this.current.deletion.revision + 1,
        armedAt: 0
      }
    });
  }
  // Commit filtrow z ekranu (przycisk 'Szukaj / Odswiez'). Celowo NIE kasuje
  // wyniku / zaznaczenia / polecenia: wpisanie litery w pole nie jest
  // 'szukaj', a repaint po kazdym znaku skasowalby liste pod palcem.
  // Stare wyniki nadal wisza az do skonczonego wyszukiwania
  // (applyDeletionResult / clearDeletionResult z osobna garda rewizji).
  // armedAt: 0 - nowy draft = nowa intencja, zamknieta potwierdzanie.
  setDeletionFilters(filters) {
    this.update({
      deletion: {
        ...this.current.deletion,
        filters: { ...filters },
        revision: this.current.deletion.revision + 1,
        armedAt: 0
      }
    });
  }
  applyDeletionResult(box, command, result) {
    const limited = result.kind === "lista" ? { ...result, entries: result.entries.slice(0, 50) } : result;
    this.update({
      deletion: {
        ...this.current.deletion,
        box,
        command,
        result: limited,
        selected: [],
        message: null,
        revision: this.current.deletion.revision + 1,
        armedAt: 0
      }
    });
  }
  /** Uzbrojenie potwierdzenia usuwania (zgloszenie 2026-10-30). Bez
   *  podbicia revision: to stan czysto UI, nie sygnal nieaktualnosci
   *  wynikow - guardy sesji usuwania maja zostac nietknięte. */
  armDeletionConfirm() {
    this.update({ deletion: { ...this.current.deletion, armedAt: Date.now() } });
  }
  disarmDeletionConfirm() {
    if (this.current.deletion.armedAt === 0) return;
    this.update({ deletion: { ...this.current.deletion, armedAt: 0 } });
  }
  toggleDeletionEntry(number) {
    const current = this.current.deletion;
    if (current.result?.kind !== "lista") return;
    if (!current.result.entries.some((entry) => entry.number === number)) return;
    const selected = current.selected.includes(number) ? current.selected.filter((value) => value !== number) : [...current.selected, number];
    this.update({ deletion: { ...current, selected } });
  }
  selectAllDeletionEntries() {
    const current = this.current.deletion;
    if (current.result?.kind !== "lista") return;
    this.update({
      deletion: {
        ...current,
        selected: current.result.entries.map((entry) => entry.number)
      }
    });
  }
  clearDeletionSelection() {
    const current = this.current.deletion;
    if (current.selected.length === 0) return;
    this.update({ deletion: { ...current, selected: [] } });
  }
  clearDeletionResult(message) {
    const current = this.current.deletion;
    this.update({
      deletion: {
        ...current,
        result: null,
        selected: [],
        message,
        revision: current.revision + 1,
        armedAt: 0
      }
    });
  }
  resetDeletion() {
    this.update({ deletion: deletionState(this.current.deletion.revision + 1) });
  }
  setBusy(label) {
    this.update({ busy: label });
  }
  setLoadAll(loadAll) {
    this.update({ loadAll });
  }
  setArchiveDownload(archiveDownload) {
    this.update({ archiveDownload });
  }
  setIndexMeta(indexMeta) {
    this.update({ indexMeta });
  }
  setIndexRun(indexRun) {
    this.update({ indexRun });
  }
  setArchiveGaps(archiveGaps) {
    this.update({ archiveGaps });
  }
  setSearch(search) {
    this.update({ search });
  }
  /**
   * Wpisy wynikow szukania ZASTEPUJA widok skrzynki; pelny widok
   * chowany jest do schowka (pierwszy raz na skrzynke - powtorne
   * szukanie nie nadpisuje schowka wynikami). Przywrocenie przez
   * clearSearch - bez strzalu do serwera.
   */
  applySearchResults(box, result) {
    if (!(box in this.stashedViews)) {
      const current = this.current.boxes[box];
      if (current) this.stashedViews[box] = current;
    }
    this.applyMailbox(box, result);
  }
  /** Przywraca schowany pelny widok skrzynki i konczy tryb szukania. */
  clearSearch(box) {
    const stashed = this.stashedViews[box];
    delete this.stashedViews[box];
    const patch = { search: null };
    if (stashed) {
      const boxes = { ...this.current.boxes, [box]: stashed };
      patch.boxes = boxes;
      const b = computeBadges(boxes);
      patch.badge = b.unread;
      patch.badgeUnsent = b.unsent;
    }
    this.update(patch);
  }
  /**
   * Kasuje tryb szukania BEZ przywracania schowka - dla swiezego
   * refresha skrzynki (nowy listing i tak nadpisze widok).
   */
  clearSearchBoxes(boxes) {
    for (const b of boxes) delete this.stashedViews[b];
    if (this.current.search && boxes.includes(this.current.search.box)) {
      this.update({ search: null });
    }
  }
  /**
   * Otwiera list i ZAWSZE go pokazuje (Fala 17d): waski -> zakladka
   * 'list', szeroki -> 'listy' (split: listing + list obok). Stary
   * kod w trybie szerokim zostawial zakladke bez zmian - klik w wpis
   * archiwum ladowal list niewidoczny dla gracza (zgloszenie pkt 2).
   */
  openLetter(box, letter, source) {
    if (this.current.tab !== "list") this.letterReturnTab = this.current.tab;
    const next = { letter: { ...letter, box, source } };
    next.tab = this.current.wide ? "listy" : "list";
    this.update(next);
  }
  closeLetter() {
    const tab = this.letterReturnTab ?? "listy";
    this.letterReturnTab = null;
    this.update({ letter: null, tab });
  }
  /**
   * Czysci pamiec podreczna pluginu (Fala 12e): widoki skrzynek,
   * archiwum (RAM; storage kasuje caller), kontakty, schowek wynikow
   * szukania i tryb szukania. ZACHOWUJE ustawienia (powiadomienia,
   * szablon/szerokosc compose) i otwarty list.
   */
  clearCacheData() {
    for (const b of Object.keys(this.stashedViews)) {
      delete this.stashedViews[b];
    }
    this.update({
      boxes: {},
      archive: [],
      contacts: [],
      badge: 0,
      badgeUnsent: 0,
      indexMeta: {},
      archiveGaps: {},
      search: null,
      unsentFlash: false
    });
  }
  setContacts(contacts) {
    this.update({ contacts });
  }
  /** Ksiazka adresowa (Fala UI-2): podmiana puli osob importowanych. */
  setPeople(people) {
    this.update({ people });
  }
  /** Ksiazka adresowa (Fala UI-2): podmiana puli aliasow importowanych. */
  setImportedAliases(importedAliases) {
    this.update({ importedAliases });
  }
  /** Ksiazka adresowa (Fala UI-2): podmiana listy grup recznych. */
  setGroups(groups) {
    this.update({ groups });
  }
  setArchive(archive) {
    this.update({ archive });
  }
  setNotifyEnabled(notifyEnabled) {
    this.update({ notifyEnabled });
  }
  setAnimalFlying(animalFlying) {
    this.update({ animalFlying });
  }
  setUnsentFlash(unsentFlash) {
    this.update({ unsentFlash });
  }
  setCompose(prefs) {
    const patch = {};
    if (prefs.template !== void 0) patch.composeTemplate = prefs.template;
    if (prefs.width !== void 0) patch.composeWidth = prefs.width;
    this.update(patch);
  }
  /** Fala 16e: wyczyszczenie formularza compose po udanym zapisie/
   *  wyslaniu (render zeruje draft przy najblizszym renderze). */
  clearCompose() {
    this.update({ composeClearSeq: this.current.composeClearSeq + 1 });
  }
  /** Render-on-demand bez zmiany stanu (np. pod-pigulki Kontaktow). */
  refresh() {
    this.update({});
  }
  update(patch) {
    this.current = { ...this.current, ...patch };
    for (const cb of [...this.listeners]) cb(this.current);
  }
};
function computeBadges(boxes) {
  const unreadBox = boxes.nieprzeczytane;
  const unread = unreadBox ? unreadBox.entries.length : boxes.odebrane?.entries.filter((e) => !e.isRead).length ?? 0;
  const unsent = boxes.niewyslane?.entries.length ?? 0;
  return { unread, unsent };
}
function formatBadgeSuffix(unread, unsent) {
  if (unread <= 0 && unsent <= 0) return "";
  return unsent > 0 ? ` (${unread}/${unsent})` : ` (${unread})`;
}

// src/arkmail/core/letterRender.ts
var MIN_LINE_WIDTH = 20;
var MAX_LINE_WIDTH = 120;
var DEFAULT_LINE_WIDTH = 60;
function clampLineWidth(width) {
  const rounded = Math.round(width);
  return Math.min(MAX_LINE_WIDTH, Math.max(MIN_LINE_WIDTH, rounded));
}
function normalizeLine(line) {
  return line.replace(/\s+/g, " ").trim();
}
function splitLongWord(word, width) {
  const parts = [];
  for (let i = 0; i < word.length; i += width) {
    parts.push(word.slice(i, i + width));
  }
  return parts;
}
var DEFAULT_LETTER_ALIGNMENT = "justify";
function justifyWords(words, lettersLength, width) {
  if (words.length === 1) {
    return words[0];
  }
  const gaps = words.length - 1;
  const totalSpaces = width - lettersLength;
  const baseSpace = Math.max(1, Math.floor(totalSpaces / gaps));
  let extra = totalSpaces - baseSpace * gaps;
  let line = words[0];
  for (let i = 1; i < words.length; i += 1) {
    let spaces = baseSpace;
    if (extra > 0) {
      spaces += 1;
      extra -= 1;
    }
    line += " ".repeat(spaces) + words[i];
  }
  return line;
}
function alignWords(words, width, alignment, isLastLine) {
  if (alignment === "justify" && !isLastLine) {
    return justifyWords(words, words.reduce((sum, word) => sum + word.length, 0), width);
  }
  const text = words.join(" ");
  if (alignment === "right") {
    return text.padStart(width, " ");
  }
  if (alignment === "center") {
    return " ".repeat(Math.max(0, Math.floor((width - text.length) / 2))) + text;
  }
  return text;
}
function wrapWords(normalizedLine, width) {
  if (!normalizedLine) {
    return [];
  }
  const groups = [];
  let currentWords = [];
  let lettersLength = 0;
  const flush = () => {
    if (currentWords.length) {
      groups.push(currentWords);
    }
    currentWords = [];
    lettersLength = 0;
  };
  normalizedLine.split(" ").forEach((word) => {
    if (word.length > width) {
      flush();
      const parts = splitLongWord(word, width);
      const lastPart = parts.pop();
      parts.forEach((part) => groups.push([part]));
      if (lastPart) {
        currentWords = [lastPart];
        lettersLength = lastPart.length;
      }
      return;
    }
    const minimalSpaces = currentWords.length;
    if (lettersLength + word.length + minimalSpaces > width && currentWords.length) {
      flush();
    }
    currentWords.push(word);
    lettersLength += word.length;
  });
  flush();
  return groups;
}
function wrapLine(line, width, letterAlignment) {
  const alignRight = line.startsWith(">");
  const alignment = alignRight ? "right" : letterAlignment;
  const groups = wrapWords(normalizeLine(alignRight ? line.slice(1) : line), width);
  return groups.map((words, index) => alignWords(words, width, alignment, index === groups.length - 1));
}
function formatContent(content, width, alignment) {
  const rawLines = content.split(/\r?\n/);
  const result = [];
  let pendingBlankLine = false;
  let hasContent = false;
  rawLines.forEach((line) => {
    const wrapped = wrapLine(normalizeLine(line), width, alignment);
    if (!wrapped.length) {
      if (hasContent) {
        pendingBlankLine = true;
      }
      return;
    }
    if (pendingBlankLine && result.length) {
      result.push("");
      pendingBlankLine = false;
    }
    result.push(...wrapped);
    hasContent = true;
  });
  return result;
}
var FILL_PATTERN = /\{([^{}]+)\}/g;
function expandFillLine(line, width) {
  return line.replace(FILL_PATTERN, (_match, pattern) => pattern.repeat(Math.ceil(width / pattern.length)).slice(0, width));
}
function splitBodyPattern(pattern) {
  const lines = pattern.split(/\r?\n/);
  while (lines.length > 1 && lines[lines.length - 1] === "") {
    lines.pop();
  }
  return lines;
}
function longestLength(lines) {
  return lines.reduce((max, line) => Math.max(max, line.length), 0);
}
function getLayoutBodyWidth(layout, totalWidth) {
  if (layout.raw) {
    return Infinity;
  }
  const prefixWidth = longestLength(splitBodyPattern(layout.bodyPrefix));
  const suffixWidth = longestLength(splitBodyPattern(layout.bodySuffix));
  return Math.max(1, totalWidth - prefixWidth - suffixWidth);
}
function formatBody(layout, lines, width) {
  if (layout.raw) {
    return [...lines];
  }
  const prefixes = splitBodyPattern(layout.bodyPrefix);
  const suffixes = splitBodyPattern(layout.bodySuffix);
  const prefixWidth = longestLength(prefixes);
  const framed = prefixWidth > 0 || longestLength(suffixes) > 0;
  return lines.map((line, index) => {
    const trimmed = line.length > width ? line.slice(0, width) : line;
    if (!framed) {
      return trimmed.trimEnd();
    }
    const prefix = prefixes[index % prefixes.length].padEnd(prefixWidth, " ");
    const suffix = suffixes[index % suffixes.length];
    return `${prefix}${trimmed.padEnd(width, " ")}${suffix}`;
  });
}
var BUILTIN_LETTER_LAYOUTS = {
  none: {
    header: [],
    footer: [],
    bodyPrefix: "",
    bodySuffix: ""
  },
  plain: {
    header: [
      " +--{-}--+ ",
      " |  { }  | ",
      " |  { }  | "
    ],
    footer: [
      " |  { }  | ",
      " |  { }  | ",
      " +--{-}--+ "
    ],
    bodyPrefix: " |  ",
    bodySuffix: "  | "
  },
  parchment: {
    header: [
      "  ____{_}___  ",
      "/ \\   { }   \\.",
      "|  |  { }   |.",
      "\\_ |  { }   |.",
      "   |  { }   |."
    ],
    footer: [
      "   |  { }   |.   ",
      "   |   {_}__|___ ",
      "   |  /{ }     /.",
      "   \\_/_{_}____/. "
    ],
    bodyPrefix: "   |   ",
    bodySuffix: "  |."
  },
  parchment2: {
    header: [
      " ______{_}_____  ",
      " / _\\  { }     \\ ",
      "|/ >|  { }     | ",
      " |\\_/__{_}______/",
      " \\.    { }   ./  ",
      " |     { }   |   "
    ],
    footer: [
      " |  ___{_}___|   ",
      " |/\\   { }     \\ ",
      " \\_|   { }      |",
      "  \\_/_ {_}_____/ "
    ],
    bodyPrefix: " |     ",
    bodySuffix: "   |   "
  },
  parchment3: {
    header: [
      "             { }  .---.   ",
      "             { } /  .  \\ ",
      "             { }|\\_/|   |",
      "             { }|   |  /| ",
      "   .---------{-}-------'|",
      "  /  .-.     { }        | ",
      " |  /   \\   { }         |",
      " | |\\_.  |  { }         |",
      " |\\|  | /|  { }         |",
      " | `---' |  { }         |"
    ],
    footer: [
      " |       |   { }        /   ",
      " |       |---{-}--------' ",
      " \\       |  { }            ",
      " \\.___./    { }            "
    ],
    bodyPrefix: " |       |   ",
    bodySuffix: "        | "
  },
  raw: {
    header: [],
    footer: [],
    bodyPrefix: "",
    bodySuffix: "",
    raw: true
  }
};
function renderLetterLayout(content, layout, lineWidth = DEFAULT_LINE_WIDTH, alignment = DEFAULT_LETTER_ALIGNMENT) {
  const bodyWidth = getLayoutBodyWidth(layout, lineWidth);
  const baseLines = layout.raw ? content.split(/\r?\n/) : formatContent(content, bodyWidth, alignment);
  const bodySource = baseLines.length ? baseLines : [""];
  const lines = [
    ...layout.header.map((line) => expandFillLine(line, bodyWidth)),
    ...formatBody(layout, bodySource, bodyWidth),
    ...layout.footer.map((line) => expandFillLine(line, bodyWidth))
  ];
  const hasContent = baseLines.some((line) => line.trim().length > 0);
  return { lines, hasContent };
}
function renderLetter(content, template, lineWidth = DEFAULT_LINE_WIDTH, alignment = DEFAULT_LETTER_ALIGNMENT) {
  return renderLetterLayout(content, BUILTIN_LETTER_LAYOUTS[template], lineWidth, alignment);
}

// src/arkmail/ui/styles.ts
var BG = "#1e1f24";
var BG_PANEL = "#26272e";
var BG_RAISED = "#31333c";
var BG_INPUT = "#141519";
var FG = "#e6e6ea";
var FG_DIM = "#9a9da8";
var BORDER = "#787e8f";
var ACCENT = "#4a7de0";
var ACCENT_SOFT = "#7ea2ee";
var ACCENT_DEEP = "#3a63b8";
var ACCENT_DEEPER = "#2f4f94";
var ACCENT_FG = "#ffffff";
var DANGER = "#b04a42";
var DANGER_TEXT = "#d4736c";
var BG_UNREAD = "#313a4e";
var STYLES = `
.arkmail-root {
  display: flex;
  flex-direction: column;
  height: 100%;
  /* Fala 11c: panele scrolluja sie niezaleznie (overflow:auto na
     .arkmail-pane); root nie rosnie poza popup i nie scrolluje calosci. */
  overflow: hidden;
  box-sizing: border-box;
  padding: calc(10px * var(--window-font-scale, 1));
  gap: calc(8px * var(--window-font-scale, 1));
  background: ${BG};
  color: ${FG};
  color-scheme: dark;
  line-height: 1.45;
}
.arkmail-version-footer {
  flex: 0 0 auto;
  color: ${FG_DIM};
  font-size: calc(11px * var(--window-font-scale, 1));
  line-height: 1.3;
  text-align: right;
}
.arkmail-root *, .arkmail-root *::before, .arkmail-root *::after {
  box-sizing: border-box;
}

/* --- kontrolki bazowe: JAWNE kolory (bug bialy-na-bialym) --- */
.arkmail-root button {
  background: ${BG_RAISED};
  color: ${FG};
  border: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
  border-radius: calc(6px * var(--window-font-scale, 1));
  padding: calc(4px * var(--window-font-scale, 1)) calc(12px * var(--window-font-scale, 1));
  font: inherit;
  cursor: pointer;
  /* Fala 16k: etykiety przyciskow nie lamia sie w waskim popupie. */
  white-space: nowrap;
  /* Fala 17e: jednolita wysokosc i centrowanie etykiety niezaleznie
   * od jej dlugosci (zgloszenie pkt 1: obwodka spojna wielkosciowo). */
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: calc(26px * var(--window-font-scale, 1));
}
.arkmail-root button:hover { background: #454a58; }

/* --- Fala 30: cztery poziomy przyciskow (jeden jezyk calego UI) --- */
.arkmail-root .arkmail-btn-primary {
  background: ${ACCENT_DEEP};
  border-color: ${ACCENT_DEEP};
  color: ${ACCENT_FG};
}
.arkmail-root .arkmail-btn-primary:hover { background: ${ACCENT_DEEPER}; border-color: ${ACCENT_DEEPER}; }
.arkmail-root .arkmail-btn-action {
  background: ${BG_RAISED};
  border: calc(1px * var(--window-font-scale, 1)) solid ${ACCENT};
  color: ${ACCENT_SOFT};
}
.arkmail-root .arkmail-btn-action:hover { background: #454a58; border-color: #6b93ea; color: #6b93ea; }
.arkmail-root .arkmail-btn-danger {
  background: ${DANGER};
  border-color: ${DANGER};
  color: ${ACCENT_FG};
}
.arkmail-root .arkmail-btn-danger:hover { background: #c2564d; border-color: #c2564d; }
/* Zgloszenie 2026-11-05: uzbrojony guard dwukliku (pierwszy klik)
   dostaje czerwone tlo niezaleznie od bazowej klasy klawisza - stan
   "drugi klik kasuje" widac z daleka, bez zmiany szerokosci przycisku. */
.arkmail-root button[data-armed="1"] { background: ${DANGER}; border-color: ${DANGER}; color: ${ACCENT_FG}; }
.arkmail-root .arkmail-btn-reset {
  background: ${BG_PANEL};
  border-color: ${BORDER};
  color: ${FG_DIM};
}
.arkmail-root .arkmail-btn-reset:hover { background: #2b2d34; }
.arkmail-root input, .arkmail-root textarea, .arkmail-root select {
  background: ${BG_INPUT};
  color: ${FG};
  border: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
  border-radius: calc(6px * var(--window-font-scale, 1));
  padding: calc(5px * var(--window-font-scale, 1)) calc(8px * var(--window-font-scale, 1));
  font: inherit;
}
.arkmail-root input:focus, .arkmail-root textarea:focus, .arkmail-root select:focus {
  outline: none;
  border-color: ${ACCENT};
}
.arkmail-root input[type='checkbox'] { accent-color: ${ACCENT}; }
.arkmail-root input::placeholder, .arkmail-root textarea::placeholder {
  color: ${FG_DIM};
  font-size: calc(12px * var(--window-font-scale, 1));
  opacity: 1;
}

/* --- zakladki: segmentowana belka --- */
.arkmail-tabs {
  display: flex;
  gap: calc(2px * var(--window-font-scale, 1));
  flex-wrap: wrap;
  background: ${BG_PANEL};
  border: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
  border-radius: calc(8px * var(--window-font-scale, 1));
  padding: calc(3px * var(--window-font-scale, 1));
}
.arkmail-root .arkmail-tab {
  border: calc(1px * var(--window-font-scale, 1)) solid ${BG_PANEL};
  border-radius: calc(6px * var(--window-font-scale, 1));
  background: ${BG_PANEL};
  color: ${FG_DIM};
  padding: calc(4px * var(--window-font-scale, 1)) calc(12px * var(--window-font-scale, 1));
}
.arkmail-root .arkmail-tab:hover { color: ${FG}; background: ${BG_RAISED}; }
.arkmail-root .arkmail-tab-active {
  background: ${ACCENT};
  border-color: ${ACCENT};
  color: ${ACCENT_FG};
  font-weight: 600;
}
.arkmail-root .arkmail-tab-active:hover { background: ${ACCENT}; color: ${ACCENT_FG}; }

/* --- pasek operacji --- */
.arkmail-busy {
  padding: calc(5px * var(--window-font-scale, 1)) calc(10px * var(--window-font-scale, 1));
  border: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
  border-left: calc(3px * var(--window-font-scale, 1)) solid ${ACCENT};
  border-radius: calc(6px * var(--window-font-scale, 1));
  background: ${BG_PANEL};
  color: ${FG_DIM};
  font-size: calc(12px * var(--window-font-scale, 1));
  white-space: normal;
  overflow-wrap: anywhere;
}
/* Fala UI-1: wspolny pasek na dole okna - status (lewo) + wersja
   (prawo). Zawsze zamontowany: wysokosc layoutu stala niezaleznie
   od tego, czy status jest pokazany. */
.arkmail-status {
  flex: 0 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  gap: calc(8px * var(--window-font-scale, 1));
}
.arkmail-status .arkmail-busy { flex: 1 1 auto; min-width: 0; }
.arkmail-busy-empty { visibility: hidden; }
/* Fala 18d (zgloszenie pkt 2): pasek postepu pod tekstem busy przy
   masowym pobieraniu tresci (jedyna petla ze znanym total). */
.arkmail-busy-track {
  margin-top: calc(4px * var(--window-font-scale, 1));
  height: calc(6px * var(--window-font-scale, 1));
  border-radius: calc(3px * var(--window-font-scale, 1));
  background: ${BG};
  overflow: hidden;
}
.arkmail-busy-bar {
  height: 100%;
  border-radius: calc(3px * var(--window-font-scale, 1));
  background: ${ACCENT};
  transition: width 200ms ease-out;
}

/* --- panele --- */
.arkmail-pane {
  flex: 1;
  overflow: auto;
  min-height: 0;
  background: ${BG_PANEL};
  border: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
  border-radius: calc(8px * var(--window-font-scale, 1));
  padding: calc(8px * var(--window-font-scale, 1));
}
/* Fala UI-1 (zgloszenie 2026-11-03): zakladka Listy - panel kolumnowy,
   scrolluje sie wylacznie .arkmail-list-scroll; naglowek (skrzynki,
   operacje, szukajka) widoczny zawsze (sugestia 3 z Discorda). */
.arkmail-listy {
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.arkmail-list-scroll {
  flex: 1 1 auto;
  min-height: 0;
  overflow: auto;
}
.arkmail-pane::-webkit-scrollbar,
.arkmail-list-scroll::-webkit-scrollbar { width: calc(8px * var(--window-font-scale, 1)); }
.arkmail-pane::-webkit-scrollbar-thumb,
.arkmail-list-scroll::-webkit-scrollbar-thumb { background: ${BORDER}; border-radius: calc(4px * var(--window-font-scale, 1)); }

/* --- skrzynki: pigulki --- */
.arkmail-boxes { display: flex; gap: calc(4px * var(--window-font-scale, 1)); margin-bottom: calc(8px * var(--window-font-scale, 1)); flex-wrap: wrap; }
.arkmail-root .arkmail-box {
  border-radius: calc(999px * var(--window-font-scale, 1));
  padding: calc(3px * var(--window-font-scale, 1)) calc(12px * var(--window-font-scale, 1));
  background: ${BG};
  color: ${FG_DIM};
  border: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
}
.arkmail-root .arkmail-box:hover { color: ${FG}; background: ${BG_RAISED}; }
.arkmail-root .arkmail-box-active {
  background: ${ACCENT};
  border-color: ${ACCENT};
  color: ${ACCENT_FG};
  font-weight: 600;
}
.arkmail-root .arkmail-box-active:hover { background: ${ACCENT}; color: ${ACCENT_FG}; }
/* Fala 16f: trwaly akcent (obwodka) na skrzynce z licznikiem > 0 -
   Nieprzeczytane/Niewyslane widac z daleka (zgloszenie pkt 5/8). */
.arkmail-root .arkmail-box-attention {
  border-color: ${ACCENT};
  color: ${FG};
}

/* Fala 11e: zbiorcze operacje na aktywnej skrzynce (zamiast \u21BB per box). */
.arkmail-box-ops { display: flex; flex-wrap: wrap; gap: calc(6px * var(--window-font-scale, 1)); margin-bottom: calc(8px * var(--window-font-scale, 1)); }
.arkmail-box-ops button { flex: 1 1 calc(140px * var(--window-font-scale, 1)); }
.arkmail-root button:disabled { opacity: 0.45; cursor: default; }
.arkmail-root button:disabled:hover { background: ${BG_RAISED}; }

/* --- wiersze listow: nadawca | temat | data --- */
.arkmail-entry {
  display: flex;
  align-items: baseline;
  gap: calc(8px * var(--window-font-scale, 1));
  padding: calc(6px * var(--window-font-scale, 1)) calc(8px * var(--window-font-scale, 1));
  border-radius: calc(6px * var(--window-font-scale, 1));
  border-bottom: calc(1px * var(--window-font-scale, 1)) solid ${BG};
  cursor: pointer;
}
.arkmail-entry:hover { background: ${BG_RAISED}; }
.arkmail-entry-num { color: ${FG_DIM}; font-size: calc(11px * var(--window-font-scale, 1)); min-width: calc(26px * var(--window-font-scale, 1)); text-align: right; }
.arkmail-entry-party {
  min-width: calc(110px * var(--window-font-scale, 1));
  max-width: calc(180px * var(--window-font-scale, 1));
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: ${FG};
}
.arkmail-entry-subject {
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: ${FG_DIM};
}
.arkmail-entry-date { color: ${FG_DIM}; font-size: calc(11px * var(--window-font-scale, 1)); white-space: nowrap; }
/* Fala 16f: nieprzeczytany wiersz dodatkowo JA\u015ANIEJSZY (pkt 8: kropka +
   pogrubienie + rozjasnienie; po odczyciu listing daje *R* i wiersz
   wraca do normalnego). */
.arkmail-unread { background: ${BG_UNREAD}; box-shadow: inset calc(3px * var(--window-font-scale, 1)) 0 0 ${ACCENT}; }
.arkmail-unread .arkmail-entry-party, .arkmail-unread .arkmail-entry-subject {
  color: ${FG};
  font-weight: 700;
}
.arkmail-unread::before {
  content: '';
  align-self: center;
  width: calc(7px * var(--window-font-scale, 1));
  height: calc(7px * var(--window-font-scale, 1));
  border-radius: 50%;
  background: ${ACCENT};
  flex: none;
}

.arkmail-root .arkmail-older { margin-top: calc(8px * var(--window-font-scale, 1)); width: 100%; }
.arkmail-older-row { display: flex; gap: calc(6px * var(--window-font-scale, 1)); margin-top: calc(8px * var(--window-font-scale, 1)); }
/* Fala 11a: szukajka stosowo (2 kolumny), nie 5 w linii - w waskiej
   kolumnie splitu pola tekstowe zachowuja sensowna szerokosc. */
.arkmail-search-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: calc(6px * var(--window-font-scale, 1));
  margin: calc(8px * var(--window-font-scale, 1)) 0;
  align-items: center;
}
.arkmail-search-row .arkmail-search-go { grid-column: 1 / -1; }
/* Fala 30a: Tresc pelna szerokosc, dzieki temu pola dat laduja para
   Od|Do w jednym rzedzie (lewo-prawo, jak czyta sie zakres). */
.arkmail-search-row .arkmail-search-wide { grid-column: 1 / -1; }
.arkmail-search-row input[type='date'] { color-scheme: dark; }
/* Pole daty z widoczna etykieta (placeholder na date nie dziala). */
.arkmail-date-field { display: flex; flex-direction: column; gap: calc(2px * var(--window-font-scale, 1)); min-width: 0; }
.arkmail-date-field input { width: 100%; box-sizing: border-box; }
.arkmail-date-label { color: ${FG_DIM}; font-size: calc(11px * var(--window-font-scale, 1)); }
.arkmail-dates-error { color: ${DANGER_TEXT}; font-size: calc(12px * var(--window-font-scale, 1)); margin-bottom: calc(6px * var(--window-font-scale, 1)); }
.arkmail-search-banner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: calc(8px * var(--window-font-scale, 1));
  background: ${BG_RAISED};
  border: calc(1px * var(--window-font-scale, 1)) solid ${ACCENT};
  border-radius: calc(8px * var(--window-font-scale, 1));
  padding: calc(6px * var(--window-font-scale, 1)) calc(10px * var(--window-font-scale, 1));
  margin-bottom: calc(8px * var(--window-font-scale, 1));
  color: ${FG};
  font-size: calc(12px * var(--window-font-scale, 1));
}
.arkmail-root .arkmail-search-clear { flex: none; padding: calc(2px * var(--window-font-scale, 1)) calc(10px * var(--window-font-scale, 1)); }
.arkmail-older-row .arkmail-older { margin-top: 0; flex: 1; }
.arkmail-root .arkmail-older-all { flex: 1; }
.arkmail-root button.arkmail-older-all { margin-top: calc(8px * var(--window-font-scale, 1)); width: 100%; }
.arkmail-older-row button.arkmail-older-all { margin-top: 0; width: auto; }
/* Fala 17e: "Wczytaj wszystkie" w box-ops - regula paginacji wyzej
 * (margin-top: 8px; width: 100%) lapala go specyficznoscia 0,2,1 i
 * przycisk odjezdzal od sasiadow (zgloszenie pkt 1). */
.arkmail-box-ops button.arkmail-older-all { margin-top: 0; width: auto; }

/* --- widok listu --- */
.arkmail-letter-head {
  position: relative;
  background: ${BG};
  border: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
  border-radius: calc(8px * var(--window-font-scale, 1));
  padding: calc(8px * var(--window-font-scale, 1)) calc(12px * var(--window-font-scale, 1));
  margin-bottom: calc(8px * var(--window-font-scale, 1));
}
.arkmail-letter-subject { font-size: calc(15px * var(--window-font-scale, 1)); font-weight: 700; color: ${FG}; }
.arkmail-letter-meta { color: ${FG_DIM}; font-size: calc(12px * var(--window-font-scale, 1)); margin-top: calc(2px * var(--window-font-scale, 1)); }
.arkmail-letter-body {
  white-space: pre-wrap;
  font-family: var(--output-font-family, 'IBM Plex Mono', ui-monospace, monospace);
  font-size: var(--output-font-size, calc(12px * var(--window-font-scale, 1)));
  background: ${BG};
  border: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
  border-radius: calc(8px * var(--window-font-scale, 1));
  padding: calc(10px * var(--window-font-scale, 1)) calc(12px * var(--window-font-scale, 1));
  color: ${FG};
}
.arkmail-letter-ops { display: flex; flex-wrap: wrap; gap: calc(6px * var(--window-font-scale, 1)); margin-top: calc(8px * var(--window-font-scale, 1)); align-items: center; }
.arkmail-letter-ops input { flex: 1; }
.arkmail-root .arkmail-del {
  background: ${DANGER};
  border-color: ${DANGER};
  color: ${ACCENT_FG};
}
.arkmail-root .arkmail-del:hover { background: #c2564d; }
.arkmail-fwd { flex: none; }

/* --- formularz compose --- */
.arkmail-form label { display: block; margin: calc(6px * var(--window-font-scale, 1)) 0 calc(3px * var(--window-font-scale, 1)); color: ${FG_DIM}; font-size: calc(12px * var(--window-font-scale, 1)); }
.arkmail-form input, .arkmail-form textarea, .arkmail-form select {
  width: 100%;
}
.arkmail-form textarea { min-height: calc(120px * var(--window-font-scale, 1)); resize: vertical; }
.arkmail-preview {
  margin: 0;
  padding: calc(8px * var(--window-font-scale, 1)) calc(10px * var(--window-font-scale, 1));
  background: ${BG_INPUT};
  color: ${FG_DIM};
  border: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
  border-radius: calc(6px * var(--window-font-scale, 1));
  font-family: var(--output-font-family, 'IBM Plex Mono', ui-monospace, monospace);
  font-size: var(--output-font-size, calc(12px * var(--window-font-scale, 1)));
  white-space: pre;
  overflow: auto;
  max-height: calc(220px * var(--window-font-scale, 1));
}
/* Fala 12d: podglad compose bez obcinania. W split (wide) pre rozciaga
   sie na pelna wysokosc prawego panelu; tryb "Pelne okno" to ten sam
   pre na calym popupie. Belka z przyciskiem nad podgladem. */
.arkmail-preview-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: calc(8px * var(--window-font-scale, 1));
  margin-bottom: calc(4px * var(--window-font-scale, 1));
}
.arkmail-preview-bar label { margin: 0; }
.arkmail-split-compose .arkmail-pane { display: flex; flex-direction: column; }
.arkmail-split-compose .arkmail-preview { flex: 1; max-height: none; }
.arkmail-preview-full-pane { display: flex; flex-direction: column; }
.arkmail-preview-full-pane .arkmail-preview { flex: 1; max-height: none; }
.arkmail-root .arkmail-send {
  margin-top: calc(10px * var(--window-font-scale, 1));
  padding: calc(6px * var(--window-font-scale, 1)) calc(18px * var(--window-font-scale, 1));
  background: ${ACCENT};
  border-color: ${ACCENT};
  color: ${ACCENT_FG};
  font-weight: 600;
}
.arkmail-root .arkmail-send:hover { background: #5a8ae6; }

/* --- usuwanie listow --- */
.arkmail-deletion-intro, .arkmail-deletion-message, .arkmail-deletion-summary,
.arkmail-deletion-limit, .arkmail-deletion-selected { margin: 0 0 calc(8px * var(--window-font-scale, 1)); }
.arkmail-deletion-intro, .arkmail-deletion-limit { color: ${FG_DIM}; }
.arkmail-deletion-controls, .arkmail-deletion-selection-ops {
  display: flex;
  flex-wrap: wrap;
  gap: calc(6px * var(--window-font-scale, 1));
  margin-bottom: calc(8px * var(--window-font-scale, 1));
}
.arkmail-root .arkmail-deletion-box { flex: 1 1 calc(140px * var(--window-font-scale, 1)); min-width: 0; }
.arkmail-deletion-filters {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(calc(150px * var(--window-font-scale, 1)), 1fr));
  gap: calc(6px * var(--window-font-scale, 1));
  margin-bottom: calc(10px * var(--window-font-scale, 1));
}
.arkmail-deletion-filter { min-width: 0; color: ${FG_DIM}; font-size: calc(12px * var(--window-font-scale, 1)); }
.arkmail-deletion-filter span { display: block; margin-bottom: calc(2px * var(--window-font-scale, 1)); }
.arkmail-root .arkmail-deletion-filter input { width: 100%; min-width: 0; }
.arkmail-deletion-results { border-top: calc(1px * var(--window-font-scale, 1)) solid ${BORDER}; }
.arkmail-deletion-entry {
  display: flex;
  align-items: flex-start;
  gap: calc(8px * var(--window-font-scale, 1));
  padding: calc(7px * var(--window-font-scale, 1)) calc(4px * var(--window-font-scale, 1));
  border-bottom: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
  cursor: pointer;
}
.arkmail-deletion-entry input { flex: none; margin-top: calc(3px * var(--window-font-scale, 1)); }
.arkmail-deletion-entry span { min-width: 0; overflow-wrap: anywhere; }
.arkmail-root .arkmail-deletion-delete {
  background: ${DANGER};
  border-color: ${DANGER};
  color: ${ACCENT_FG};
}
.arkmail-root .arkmail-deletion-delete:disabled { background: ${BG_RAISED}; color: ${FG_DIM}; }

/* --- kontakty i archiwum --- */
.arkmail-contact, .arkmail-arch-entry {
  display: flex;
  gap: calc(8px * var(--window-font-scale, 1));
  padding: calc(5px * var(--window-font-scale, 1)) calc(8px * var(--window-font-scale, 1));
  border-radius: calc(6px * var(--window-font-scale, 1));
  border-bottom: calc(1px * var(--window-font-scale, 1)) solid ${BG};
}
/* Fala 12c: klikalne jest IMIE (kierunek domyslny) + przyciski kierunku. */
.arkmail-contact:hover, .arkmail-arch-entry:hover { background: ${BG_RAISED}; }
.arkmail-contact-name { color: ${FG}; font-weight: 600; cursor: pointer; }
.arkmail-contact-name:hover { text-decoration: underline; }
.arkmail-contact-dirs { margin-left: auto; display: flex; gap: calc(4px * var(--window-font-scale, 1)); }
.arkmail-root .arkmail-contact-dir, .arkmail-root .arkmail-contact-addbook, .arkmail-root .arkmail-arch-people-toggle {
  background: ${BG_RAISED};
  color: ${FG};
  border: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
  border-radius: calc(4px * var(--window-font-scale, 1));
  padding: calc(1px * var(--window-font-scale, 1)) calc(8px * var(--window-font-scale, 1));
  font-size: calc(11px * var(--window-font-scale, 1));
  cursor: pointer;
}
.arkmail-root .arkmail-contact-dir:hover, .arkmail-root .arkmail-contact-addbook:hover, .arkmail-root .arkmail-arch-people-toggle:hover { border-color: ${FG_DIM}; }
.arkmail-root .arkmail-contact-dir:disabled, .arkmail-root .arkmail-contact-addbook:disabled {
  opacity: 0.4;
  cursor: default;
}
/* Fala UI-2 krok 4: naglowek zwijanego panelu "Osoby z listow". */
.arkmail-arch-people-head { margin: calc(8px * var(--window-font-scale, 1)) 0 calc(4px * var(--window-font-scale, 1)); }
/* Waski popup: wiersz ksiazki trzyma checkbox, imie i oba przyciski
 * w jednej linii; imie sie skraca (wielokropek), nie wypycha przyciskow.
 * Head grupy zawija kontrolki zamiast je ucinac. */
.arkmail-root .arkmail-book-row {
  display: flex;
  align-items: center;
  gap: calc(6px * var(--window-font-scale, 1));
}
.arkmail-root .arkmail-book-name {
  flex: 1 1 auto;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.arkmail-root .arkmail-group-head {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: calc(6px * var(--window-font-scale, 1));
}
.arkmail-contact-stats, .arkmail-arch-meta { color: ${FG_DIM}; font-size: calc(12px * var(--window-font-scale, 1)); }
.arkmail-arch-expand { margin-left: calc(8px * var(--window-font-scale, 1)); }
.arkmail-arch-occ-list { margin: calc(2px * var(--window-font-scale, 1)) 0 calc(6px * var(--window-font-scale, 1)) calc(18px * var(--window-font-scale, 1)); }
.arkmail-arch-occ { color: ${FG_DIM}; font-size: calc(12px * var(--window-font-scale, 1)); cursor: pointer; }
.arkmail-arch-occ:hover { color: ${FG}; }
.arkmail-contact-controls {
  display: flex;
  flex-wrap: wrap;
  gap: calc(6px * var(--window-font-scale, 1));
  margin-bottom: calc(8px * var(--window-font-scale, 1));
}
.arkmail-archive-steps {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(calc(220px * var(--window-font-scale, 1)), 1fr));
  gap: calc(18px * var(--window-font-scale, 1));
  margin: calc(10px * var(--window-font-scale, 1)) 0 calc(12px * var(--window-font-scale, 1));
}
.arkmail-archive-step {
  position: relative;
  min-width: 0;
  padding: calc(10px * var(--window-font-scale, 1));
  border: calc(1px * var(--window-font-scale, 1)) solid ${BORDER};
  border-left: calc(4px * var(--window-font-scale, 1)) solid ${FG_DIM};
  border-radius: calc(6px * var(--window-font-scale, 1));
  background: ${BG_RAISED};
}
.arkmail-archive-step-title { font-weight: 700; margin-bottom: calc(5px * var(--window-font-scale, 1)); }
.arkmail-archive-step-status {
  min-height: calc(34px * var(--window-font-scale, 1));
  margin-bottom: calc(9px * var(--window-font-scale, 1));
  color: ${FG_DIM};
  font-size: calc(12px * var(--window-font-scale, 1));
  line-height: 1.4;
}
.arkmail-archive-step button { width: 100%; margin: 0; }
.arkmail-step-active { border-left-color: ${ACCENT}; }
.arkmail-step-done { border-left-color: #55aa77; }
.arkmail-step-warning, .arkmail-step-incomplete { border-left-color: #cc9944; }
.arkmail-arch-controls {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: calc(6px * var(--window-font-scale, 1));
  margin-bottom: calc(8px * var(--window-font-scale, 1));
}
.arkmail-arch-controls .arkmail-arch-clear { grid-column: 1 / -1; }
.arkmail-arch-controls input[type='date'] { color-scheme: dark; }
.arkmail-root .arkmail-contact-filter { flex: 1 1 calc(140px * var(--window-font-scale, 1)); min-width: 0; }
.arkmail-root .arkmail-contact-sort { max-width: 100%; }
.arkmail-contact-last { color: ${FG_DIM}; font-size: calc(11px * var(--window-font-scale, 1)); white-space: nowrap; }

.arkmail-notify-toggle { margin-right: calc(4px * var(--window-font-scale, 1)); }
.arkmail-dim { color: ${FG_DIM}; }

/* --- ghost-podpowiedzi (Fala 9g): wyszarzona sugestia za kursorem --- */
.arkmail-root .arkmail-ghost-wrap { position: relative; display: block; min-width: 0; }
.arkmail-root .arkmail-ghost-wrap > input { width: 100%; box-sizing: border-box; }
/* Pole przekazania moze zmniejszyc szerokosc albo przejsc do nowego rzedu. */
.arkmail-root .arkmail-letter-ops .arkmail-ghost-wrap { flex: 1 1 calc(180px * var(--window-font-scale, 1)); min-width: 0; }
.arkmail-root .arkmail-ghost {
  position: absolute;
  inset: 0;
  /* padding inputu (5px 8px) + jego border (1px) = tekst 1:1 nad polem */
  padding: calc(6px * var(--window-font-scale, 1)) calc(9px * var(--window-font-scale, 1));
  overflow: hidden;
  pointer-events: none;
  white-space: pre;
}
.arkmail-root .arkmail-ghost-typed { visibility: hidden; white-space: pre; }
.arkmail-root .arkmail-ghost-rest { color: ${FG_DIM}; white-space: pre; }

/* --- podzial lista|list na szerokim popupie (Fala 10) ---
   Uklad sterowany WYLACZNIE klasa .arkmail-wide z JS (ResizeObserver,
   prog 900px) - zero @container, jedno zrodlo prawdy, testowalne. */
.arkmail-wide .arkmail-split {
  display: grid;
  grid-template-columns: minmax(calc(280px * var(--window-font-scale, 1)), 2fr) minmax(0, 3fr);
  gap: calc(10px * var(--window-font-scale, 1));
  flex: 1;
  min-height: 0;
}
/* Fala 11d: compose - formularz szerszy, podglad wezszy. */
.arkmail-wide .arkmail-split-compose {
  grid-template-columns: minmax(0, 3fr) minmax(calc(280px * var(--window-font-scale, 1)), 2fr);
}
.arkmail-root .arkmail-letter-close {
  position: absolute;
  top: calc(6px * var(--window-font-scale, 1));
  right: calc(10px * var(--window-font-scale, 1));
  padding: calc(2px * var(--window-font-scale, 1)) calc(10px * var(--window-font-scale, 1));
}

/* Fala 14b: pulsowanie Listy/Niewyslane po odlozeniu listu w kolejce.
   Kontrakt uiStyles: jawne hex (bez transparent/inherit). */
@keyframes arkmailFlash {
  0%, 100% { background: ${BG_RAISED}; color: ${FG}; }
  50% { background: ${ACCENT}; color: ${ACCENT_FG}; }
}
.arkmail-root .arkmail-flash {
  animation: arkmailFlash 0.6s ease-in-out 5;
}
`;

// src/arkmail/ui/ghost.ts
function attachGhost(doc, input, source, opts) {
  const wrap = doc.createElement("span");
  wrap.className = "arkmail-ghost-wrap";
  input.parentNode?.insertBefore(wrap, input);
  wrap.appendChild(input);
  const ghost = doc.createElement("span");
  ghost.className = "arkmail-ghost";
  ghost.style.display = "none";
  const typed = doc.createElement("span");
  typed.className = "arkmail-ghost-typed";
  const rest = doc.createElement("span");
  rest.className = "arkmail-ghost-rest";
  ghost.appendChild(typed);
  ghost.appendChild(rest);
  wrap.appendChild(ghost);
  let candidate = null;
  let escapeHidden = false;
  const hide = () => {
    candidate = null;
    ghost.style.display = "none";
  };
  const splitHead = (value) => {
    if (!opts?.segment) return "";
    const idx = value.lastIndexOf(",");
    if (idx === -1) return "";
    let end = idx + 1;
    while (value[end] === " ") end += 1;
    return value.slice(0, end);
  };
  const update = () => {
    escapeHidden = false;
    const value = input.value;
    const atEnd = input.selectionStart === value.length && input.selectionEnd === value.length;
    const head = atEnd ? splitHead(value) : "";
    const segment = value.slice(head.length);
    candidate = segment.length > 0 && atEnd ? source().map((c) => typeof c === "string" ? { text: c } : c).find(
      (c) => c.text.length > segment.length && c.text.toLowerCase().startsWith(segment.toLowerCase())
    ) ?? null : null;
    if (!candidate) {
      ghost.style.display = "none";
      return;
    }
    typed.textContent = value;
    rest.textContent = candidate.text.slice(segment.length);
    ghost.style.display = "";
  };
  input.addEventListener("input", update);
  input.addEventListener("focus", update);
  input.addEventListener("blur", hide);
  input.addEventListener("keydown", (ev) => {
    if (ev.key === "ArrowRight" && candidate && !escapeHidden) {
      const value = input.value;
      if (input.selectionStart === value.length && input.selectionEnd === value.length) {
        ev.preventDefault();
        const head = splitHead(value);
        const insert = candidate.expand ?? candidate.text;
        input.value = head + insert;
        input.selectionStart = input.value.length;
        input.selectionEnd = input.value.length;
        const view = doc.defaultView;
        input.dispatchEvent(
          view ? new view.Event("input", { bubbles: true }) : new Event("input", { bubbles: true })
        );
        hide();
      }
    } else if (ev.key === "Escape" && candidate) {
      escapeHidden = true;
      ghost.style.display = "none";
    }
  });
}

// src/arkmail/ui/render.ts
var TEMPLATES = [
  ["none", "Bez ramki"],
  ["plain", "Prosta ramka"],
  ["parchment", "Pergamin"],
  ["parchment2", "Pergamin II"],
  ["parchment3", "Pergamin III"],
  ["raw", "Surowy (jak wpisane)"]
];
var TABS = [
  ["listy", "Listy"],
  ["napisz", "Napisz list"],
  ["kontakty", "Kontakty"],
  ["archiwum", "Archiwum"],
  ["usuwanie", "Usuwanie listow"]
];
var BOXES = [
  ["odebrane", "Odebrane"],
  ["nieprzeczytane", "Nieprzeczytane"],
  ["wyslane", "Wyslane"],
  ["niewyslane", "Niewyslane"]
];
var DELETION_ARM_MS = 5e3;
function mountMailUi(container, store2, handlers) {
  const doc = container.ownerDocument;
  const style = doc.createElement("style");
  style.textContent = STYLES;
  container.appendChild(style);
  const root = doc.createElement("div");
  container.appendChild(root);
  const archFilter = {};
  const contactView = {
    filter: "",
    sort: "nazwa",
    sub: "ksiazka"
  };
  let archPeopleOpen = true;
  let bookImportMode = "dolacz";
  const bookSelection = /* @__PURE__ */ new Set();
  let bookPeopleRef = null;
  let bookFilter = "";
  let groupFilter = "";
  const expandedGroups = /* @__PURE__ */ new Set();
  let previewFull = false;
  const searchDraft = { osoba: "", temat: "", tresc: "", odDaty: "", doDaty: "" };
  const deletionDraft = emptyDeletionFilters();
  const setButtonLabel = (button, label, title = label) => {
    button.textContent = label;
    button.setAttribute("title", title);
  };
  const SEARCH_GO_LABEL = "Szukaj / Odswiez";
  const SEARCH_GO_TITLE = "Szuka po wpisanych filtrach; przy pustych filtrach odswieza skrzynke";
  const GUARD_ARM_MS = 3e3;
  const armedButtons = /* @__PURE__ */ new Set();
  const disarmButton = (g) => {
    if (g.timer !== null) clearTimeout(g.timer);
    g.timer = null;
    g.el.removeAttribute("data-armed");
    if (g.el.isConnected) {
      g.el.textContent = g.baseText;
      g.el.setAttribute("title", g.baseTitle);
    }
    armedButtons.delete(g);
  };
  const disarmAllButtons = () => {
    for (const g of [...armedButtons]) disarmButton(g);
  };
  const guardDeleteButton = (btn, onConfirm, opts = {}) => {
    const g = {
      el: btn,
      timer: null,
      baseText: btn.textContent ?? "",
      baseTitle: btn.getAttribute("title") ?? ""
    };
    btn.addEventListener("click", () => {
      if (g.timer === null) {
        g.timer = setTimeout(() => disarmButton(g), GUARD_ARM_MS);
        btn.setAttribute("data-armed", "1");
        if (opts.armedLabel !== void 0) btn.textContent = opts.armedLabel;
        btn.setAttribute("title", opts.armedTitle ?? "Kliknij ponownie, aby usunac.");
        armedButtons.add(g);
        return;
      }
      disarmButton(g);
      onConfirm();
    });
  };
  const fillButtonTitles = (scope) => {
    scope.querySelectorAll("button").forEach((element) => {
      const button = element;
      if ((button.getAttribute("title") ?? "").trim()) return;
      const label = (button.textContent ?? "").trim();
      if (label) button.setAttribute("title", label);
    });
  };
  const focusKeyOf = (el) => {
    if (!el || typeof el.getAttribute !== "function") return null;
    if (!root.contains(el)) return null;
    for (const attr of ["data-search", "data-field", "data-filter", "data-deletion-filter"]) {
      const v = el.getAttribute(attr);
      if (v !== null) return `[${attr}="${v}"]`;
    }
    return null;
  };
  const snapshotView = () => {
    const snap = { focusKey: null, focusValue: null, caret: null, scroll: {} };
    const active = doc.activeElement;
    const key = focusKeyOf(active);
    if (key) {
      snap.focusKey = key;
      snap.focusValue = active.value ?? null;
      const inp = active;
      try {
        if (typeof inp.selectionStart === "number") {
          snap.caret = [inp.selectionStart, inp.selectionEnd ?? inp.selectionStart];
        }
      } catch {
      }
    }
    for (const pane of Array.from(root.querySelectorAll("[data-pane-key]"))) {
      const k = pane.getAttribute("data-pane-key");
      if (k !== null) snap.scroll[k] = pane.scrollTop;
    }
    return snap;
  };
  const restoreView = (snap) => {
    for (const pane of Array.from(root.querySelectorAll("[data-pane-key]"))) {
      const k = pane.getAttribute("data-pane-key");
      if (k !== null && snap.scroll[k] !== void 0) {
        pane.scrollTop = snap.scroll[k];
      }
    }
    if (snap.focusKey) {
      const el = root.querySelector(snap.focusKey);
      if (el) {
        if (snap.focusValue !== null) el.value = snap.focusValue;
        el.focus();
        if (snap.caret) {
          try {
            el.setSelectionRange(snap.caret[0], snap.caret[1]);
          } catch {
          }
        }
      }
    }
  };
  const personSource = () => {
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    const push = (v) => {
      if (!v) return;
      const k = v.toLowerCase();
      if (seen.has(k)) return;
      seen.add(k);
      out.push(v);
    };
    const contacts = [...store2.state.contacts].sort(
      (a, b) => (b.lastContactKey ?? -1) - (a.lastContactKey ?? -1)
    );
    for (const c of contacts) {
      push(c.name);
      push(c.mailAlias);
    }
    for (const name of store2.state.people) push(name);
    for (const alias of store2.state.importedAliases) push(alias.name);
    return out;
  };
  const adresatSource = () => [
    ...personSource(),
    ...store2.state.groups.filter((g) => g.members.length > 0).map((g) => ({ text: g.name, expand: g.members.join(", ") }))
  ];
  const subjectSource = () => {
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const l of store2.state.archive) {
      if (!l.subject) continue;
      const k = l.subject.toLowerCase();
      if (seen.has(k)) continue;
      seen.add(k);
      out.push(l.subject);
    }
    return out;
  };
  const renderStatusFooter = (state) => {
    const footer = doc.createElement("footer");
    footer.className = "arkmail-status";
    const busyEl = doc.createElement("div");
    busyEl.className = "arkmail-busy" + (state.busy !== null ? "" : " arkmail-busy-empty");
    const label = doc.createElement("span");
    const dl = state.archiveDownload;
    label.textContent = `${state.busy ?? ""}` + (dl !== null && dl.etaMs !== null ? ` (${formatEta(dl.etaMs)})` : "");
    busyEl.appendChild(label);
    if (dl !== null && dl.total > 0) {
      const track = doc.createElement("div");
      track.className = "arkmail-busy-track";
      const bar = doc.createElement("div");
      bar.className = "arkmail-busy-bar";
      const pct = Math.min(100, Math.round(dl.done / dl.total * 100));
      bar.style.width = `${pct}%`;
      track.appendChild(bar);
      busyEl.appendChild(track);
    }
    footer.appendChild(busyEl);
    const version = doc.createElement("span");
    version.className = "arkmail-version-footer";
    version.textContent = `v${PLUGIN_VERSION} | ${PLUGIN_BUILD_DATE}`;
    footer.appendChild(version);
    return footer;
  };
  const render = (state) => {
    const snap = snapshotView();
    root.className = "arkmail-root" + (state.wide ? " arkmail-wide" : "");
    composePreview = null;
    if (state.tab !== "napisz") previewFull = false;
    const nodes = [renderTabs(state)];
    if (state.tab === "napisz" && previewFull) {
      nodes.push(renderPreviewFull());
    } else if (state.wide && state.tab === "listy") {
      const split = doc.createElement("div");
      split.className = "arkmail-split";
      split.appendChild(renderListy(state));
      split.appendChild(renderList(state));
      nodes.push(split);
    } else if (state.wide && state.tab === "napisz") {
      const split = doc.createElement("div");
      split.className = "arkmail-split arkmail-split-compose";
      split.appendChild(renderNapisz(state));
      split.appendChild(renderComposePreview());
      nodes.push(split);
    } else {
      nodes.push(renderPane(state));
    }
    nodes.push(renderStatusFooter(state));
    root.replaceChildren(...nodes);
    fillButtonTitles(root);
    restoreView(snap);
  };
  const renderTabs = (state) => {
    const bar = doc.createElement("div");
    bar.className = "arkmail-tabs";
    for (const [id, label] of TABS) {
      const btn = doc.createElement("button");
      btn.className = "arkmail-tab" + (state.tab === id ? " arkmail-tab-active" : "") + // Fala 14b: flash po odlozeniu listu w niewyslanych (compose
      // poza poczta zawsze kolejkuje) - gracz widzi, gdzie kliknac.
      (state.unsentFlash && id === "listy" ? " arkmail-flash" : "");
      btn.setAttribute("data-tab", id);
      btn.textContent = id === "listy" ? label + formatBadgeSuffix(state.badge, state.badgeUnsent) : label;
      btn.addEventListener("click", () => store2.setTab(id));
      bar.appendChild(btn);
    }
    return bar;
  };
  const formatEta = (ms) => ms < 45e3 ? `zostalo ok. ${Math.max(1, Math.round(ms / 1e3))} s` : `zostalo ok. ${Math.max(1, Math.round(ms / 6e4))} min`;
  const renderPane = (state) => {
    switch (state.tab) {
      case "listy":
        return renderListy(state);
      case "list":
        return renderList(state);
      case "napisz":
        return renderNapisz(state);
      case "kontakty":
        return renderKontakty(state);
      case "archiwum":
        return renderArchiwum(state);
      case "usuwanie":
        return renderUsuwanie(state);
    }
  };
  const renderUsuwanie = (state) => {
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane arkmail-deletion";
    pane.setAttribute("data-pane-key", "usuwanie");
    const intro = doc.createElement("p");
    intro.className = "arkmail-deletion-intro";
    intro.textContent = "Wybierz skrzynke i kliknij Szukaj / Odswiez. Zaznacz listy, ktore chcesz usunac, i potwierdz operacje. Wyniki nie odswiezaja sie automatycznie. Wyjscie z zakladki czysci wyniki i zaznaczenie.";
    pane.appendChild(intro);
    const controls = doc.createElement("div");
    controls.className = "arkmail-deletion-controls";
    const box = doc.createElement("select");
    box.className = "arkmail-deletion-box";
    box.setAttribute("title", "Wybierz skrzynke");
    for (const [id, label] of BOXES) {
      const option = doc.createElement("option");
      option.value = id;
      option.textContent = label;
      option.selected = state.deletion.box === id;
      box.appendChild(option);
    }
    box.value = state.deletion.box;
    controls.appendChild(box);
    const search = doc.createElement("button");
    search.className = "arkmail-deletion-search arkmail-btn-primary";
    setButtonLabel(search, SEARCH_GO_LABEL, SEARCH_GO_TITLE);
    let searchErrorTimer = null;
    const showSearchError = (message) => {
      if (searchErrorTimer) clearTimeout(searchErrorTimer);
      setButtonLabel(search, message);
      searchErrorTimer = setTimeout(
        () => setButtonLabel(search, SEARCH_GO_LABEL, SEARCH_GO_TITLE),
        3e3
      );
    };
    const fireSearch = () => {
      const current = store2.state.deletion;
      const osoba = deletionDraft.osoba.trim();
      const temat = deletionDraft.temat.trim();
      const tresc = deletionDraft.tresc.trim();
      const validationError = validateSearchDraft({
        osoba,
        temat,
        tresc,
        odDaty: deletionDraft.odDaty,
        doDaty: deletionDraft.doDaty
      });
      if (validationError) {
        showSearchError(validationError);
        return;
      }
      if (searchErrorTimer) clearTimeout(searchErrorTimer);
      setButtonLabel(search, SEARCH_GO_LABEL, SEARCH_GO_TITLE);
      store2.setDeletionFilters({ ...deletionDraft });
      const query = {};
      if (osoba) query.osoba = osoba;
      if (temat) query.temat = temat;
      if (tresc) query.tresc = tresc;
      const odDaty = fromISODate(deletionDraft.odDaty);
      const doDaty = fromISODate(deletionDraft.doDaty);
      if (odDaty) query.odDaty = odDaty;
      if (doDaty) query.doDaty = doDaty;
      handlers.onDeletionSearch?.(current.box, query);
    };
    search.addEventListener("click", fireSearch);
    box.addEventListener("change", () => {
      store2.setDeletionBox(box.value);
      fireSearch();
    });
    controls.appendChild(search);
    const clearFilters = doc.createElement("button");
    clearFilters.className = "arkmail-deletion-clear-filters arkmail-btn-danger";
    clearFilters.textContent = "Wyczysc filtry";
    clearFilters.addEventListener("click", () => {
      for (const key of ["osoba", "temat", "tresc", "odDaty", "doDaty"]) {
        deletionDraft[key] = "";
      }
      filterRow.querySelectorAll("[data-deletion-filter]").forEach((el) => {
        el.value = "";
      });
      store2.setDeletionFilters(emptyDeletionFilters());
      handlers.onDeletionSearch?.(store2.state.deletion.box, {});
    });
    controls.appendChild(clearFilters);
    pane.appendChild(controls);
    const filterRow = doc.createElement("div");
    filterRow.className = "arkmail-deletion-filters";
    const fields = [
      ["osoba", "Osoba (kogo? czego?)", "Wpisz imie w dopelniaczu"],
      ["temat", "Temat", "Fragment tematu"],
      ["tresc", "Tresc", "Fragment tresci"],
      ["odDaty", "Od daty", ""],
      ["doDaty", "Do daty", ""]
    ];
    for (const [key, label, placeholder] of fields) {
      const wrap = doc.createElement("label");
      wrap.className = "arkmail-deletion-filter";
      const caption = doc.createElement("span");
      caption.textContent = label;
      wrap.appendChild(caption);
      const field = doc.createElement("input");
      field.type = key === "odDaty" || key === "doDaty" ? "date" : "text";
      field.value = deletionDraft[key];
      field.setAttribute("data-deletion-filter", key);
      if (placeholder) field.setAttribute("placeholder", placeholder);
      field.addEventListener("input", () => {
        deletionDraft[key] = field.value;
      });
      wrap.appendChild(field);
      filterRow.appendChild(wrap);
    }
    pane.appendChild(filterRow);
    if (state.deletion.message !== null) {
      const message = doc.createElement("p");
      message.className = "arkmail-deletion-message";
      message.textContent = state.deletion.message;
      pane.appendChild(message);
    }
    const result = state.deletion.result;
    const entries = result?.kind === "lista" ? result.entries : [];
    if (result !== null) {
      const summary = doc.createElement("p");
      summary.className = "arkmail-deletion-summary";
      summary.textContent = result.kind === "lista" ? `Wyniki: ${formatListCount(entries.length)}.` : "Brak listow dla podanych filtrow.";
      pane.appendChild(summary);
      if (result.kind === "lista" && result.header.truncated) {
        const limit = doc.createElement("p");
        limit.className = "arkmail-dim arkmail-deletion-limit";
        limit.textContent = "Serwer pokazuje maksymalnie 50 wynikow.";
        pane.appendChild(limit);
      }
    }
    const selectionOps = doc.createElement("div");
    selectionOps.className = "arkmail-deletion-selection-ops";
    const selectAll = doc.createElement("button");
    selectAll.className = "arkmail-deletion-select-all";
    selectAll.textContent = "Zaznacz wszystkie";
    if (entries.length === 0) selectAll.setAttribute("disabled", "");
    selectAll.addEventListener("click", () => store2.selectAllDeletionEntries());
    selectionOps.appendChild(selectAll);
    const clearSelection = doc.createElement("button");
    clearSelection.className = "arkmail-deletion-clear-selection";
    clearSelection.textContent = "Odznacz wszystkie";
    if (state.deletion.selected.length === 0) clearSelection.setAttribute("disabled", "");
    clearSelection.addEventListener("click", () => store2.clearDeletionSelection());
    selectionOps.appendChild(clearSelection);
    const remove = doc.createElement("button");
    remove.className = "arkmail-deletion-delete arkmail-btn-danger";
    const selectedCount = state.deletion.selected.length;
    const armedAt = state.deletion.armedAt;
    const armed = armedAt !== 0 && Date.now() - armedAt < DELETION_ARM_MS;
    if (armed) {
      setButtonLabel(
        remove,
        `Potwierdz usuniecie: ${formatListCount(selectedCount)}`,
        `Usunac zaznaczone listy (liczba: ${selectedCount})? Tej operacji nie mozna cofnac. Kliknij ponownie, aby potwierdzic. ESC anuluje.`
      );
    } else {
      setButtonLabel(remove, "Usun zaznaczone", "Usun zaznaczone listy. Tej operacji nie mozna cofnac.");
    }
    if (selectedCount === 0) remove.setAttribute("disabled", "");
    remove.addEventListener("click", () => {
      if (!armed) {
        store2.armDeletionConfirm();
        const armedStamp = store2.state.deletion.armedAt;
        setTimeout(() => {
          if (store2.state.deletion.armedAt === armedStamp) store2.disarmDeletionConfirm();
        }, DELETION_ARM_MS);
        return;
      }
      store2.disarmDeletionConfirm();
      handlers.onDeletionDelete?.();
    });
    selectionOps.appendChild(remove);
    pane.appendChild(selectionOps);
    if (selectedCount > 0) {
      const selected = doc.createElement("p");
      selected.className = "arkmail-deletion-selected";
      selected.textContent = `Zaznaczono: ${formatListCount(selectedCount)}.`;
      pane.appendChild(selected);
    }
    if (entries.length > 0) {
      const list = doc.createElement("div");
      list.className = "arkmail-deletion-results";
      for (const entry of [...entries].reverse()) {
        const row = doc.createElement("label");
        row.className = "arkmail-deletion-entry";
        const checkbox = doc.createElement("input");
        checkbox.type = "checkbox";
        checkbox.checked = state.deletion.selected.includes(entry.number);
        checkbox.setAttribute("data-deletion-number", String(entry.number));
        checkbox.addEventListener("change", () => store2.toggleDeletionEntry(entry.number));
        row.appendChild(checkbox);
        const text = doc.createElement("span");
        const date = entry.date?.raw ? ` | ${entry.date.raw}` : "";
        text.textContent = `${entry.party} | ${entry.subject}${date}`;
        row.appendChild(text);
        list.appendChild(row);
      }
      pane.appendChild(list);
    }
    return pane;
  };
  const renderListy = (state) => {
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane arkmail-listy";
    const boxes = doc.createElement("div");
    boxes.className = "arkmail-boxes";
    for (const [box, label] of BOXES) {
      const btn = doc.createElement("button");
      btn.className = "arkmail-box" + (state.activeBox === box ? " arkmail-box-active" : "") + // Fala 14b: flash celu kolejki niewyslanych (jak zakladka Listy).
      (state.unsentFlash && box === "niewyslane" ? " arkmail-flash" : "") + // Fala 16f: trwala obwodka akcentu, gdy licznik skrzynki > 0
      // (zgloszenie pkt 5/8: "zaznaczone, ze cos jest w niewyslanych").
      (state.badge > 0 && box === "nieprzeczytane" ? " arkmail-box-attention" : "") + (state.badgeUnsent > 0 && box === "niewyslane" ? " arkmail-box-attention" : "");
      btn.setAttribute("data-box", box);
      btn.textContent = label;
      btn.addEventListener("click", () => {
        store2.setActiveBox(box);
        handlers.onRefreshBox(box);
      });
      boxes.appendChild(btn);
    }
    pane.appendChild(boxes);
    const ops = doc.createElement("div");
    ops.className = "arkmail-box-ops";
    const animalBtn = doc.createElement("button");
    animalBtn.className = "arkmail-animal-send arkmail-btn-action";
    animalBtn.textContent = state.animalFlying ? "Zwierze w drodze..." : "Wyslij zwierze";
    if (state.animalFlying) animalBtn.setAttribute("disabled", "");
    animalBtn.addEventListener("click", () => handlers.onSendAnimal?.());
    ops.appendChild(animalBtn);
    const view0 = state.boxes[state.activeBox];
    const searchMode0 = state.search && state.search.box === state.activeBox ? state.search : null;
    const loopHere = state.loadAll !== null && state.loadAll.box === state.activeBox;
    const loadAllBtn = doc.createElement("button");
    loadAllBtn.className = "arkmail-older-all arkmail-btn-action";
    loadAllBtn.textContent = loopHere ? `Przerwij (${state.loadAll.pages})` : "Wczytaj wszystkie";
    const nothingToLoad = !loopHere && (searchMode0 !== null || !view0 || view0.empty !== null || !view0.truncated || state.loadAll !== null);
    if (nothingToLoad) loadAllBtn.setAttribute("disabled", "");
    loadAllBtn.addEventListener("click", () => handlers.onLoadAll(state.activeBox));
    ops.appendChild(loadAllBtn);
    const clearBtn = doc.createElement("button");
    clearBtn.className = "arkmail-cache-clear arkmail-btn-danger";
    clearBtn.textContent = "Wyczysc zapisane dane";
    const clearTitle = "Kasuje lokalnie listy, archiwum, kontakty i indeksy. Na serwerze Arkadii nic nie znika - skrzynki pobierzesz od nowa. Ustawienia, grupy i ksiazka adresowa zostaja. Aliasy pobierzesz z gry ponownie.";
    clearBtn.setAttribute("title", clearTitle);
    let clearArmed = false;
    let clearTimer = null;
    clearBtn.addEventListener("click", () => {
      if (!clearArmed) {
        clearArmed = true;
        setButtonLabel(clearBtn, "Na pewno? Kliknij ponownie");
        clearTimer = setTimeout(() => {
          clearArmed = false;
          setButtonLabel(clearBtn, "Wyczysc zapisane dane", clearTitle);
        }, 3e3);
        return;
      }
      if (clearTimer) clearTimeout(clearTimer);
      clearArmed = false;
      setButtonLabel(clearBtn, "Wyczysc zapisane dane", clearTitle);
      handlers.onClearCache?.();
    });
    ops.appendChild(clearBtn);
    pane.appendChild(ops);
    const notifyRow = doc.createElement("label");
    notifyRow.className = "arkmail-dim";
    const chk = doc.createElement("input");
    chk.setAttribute("type", "checkbox");
    chk.className = "arkmail-notify-toggle";
    chk.checked = state.notifyEnabled;
    chk.addEventListener("click", () => store2.setNotifyEnabled(!store2.state.notifyEnabled));
    notifyRow.appendChild(chk);
    notifyRow.appendChild(doc.createTextNode(" Powiadom o nowej poczcie"));
    pane.appendChild(notifyRow);
    const searchRow = doc.createElement("div");
    searchRow.className = "arkmail-search-row";
    const mkSearch = (key, placeholder, type = "text") => {
      const input = doc.createElement("input");
      input.setAttribute("data-search", key);
      input.setAttribute("type", type);
      input.setAttribute("placeholder", placeholder);
      input.value = searchDraft[key] ?? "";
      input.addEventListener("input", () => {
        searchDraft[key] = input.value;
      });
      return input;
    };
    const sOsoba = mkSearch("osoba", "Osoba (kogo? czego?)");
    sOsoba.setAttribute("title", "Wpisz imie w dopelniaczu.");
    const sTemat = mkSearch("temat", "Temat");
    const sTresc = mkSearch("tresc", "Tresc");
    sTresc.className = "arkmail-search-wide";
    const sOd = mkSearch("odDaty", "Od dnia", "date");
    const sDo = mkSearch("doDaty", "Do dnia", "date");
    const sOdF = mkDateField(doc, sOd, "Od dnia (wlacznie)", "Szukanie zwroci listy wyslane od tego dnia WLACZNIE.");
    const sDoF = mkDateField(doc, sDo, "Do dnia (wlacznie)", "Szukanie zwroci listy wyslane do tego dnia WLACZNIE.");
    const go = doc.createElement("button");
    go.className = "arkmail-search-go arkmail-btn-primary";
    setButtonLabel(go, SEARCH_GO_LABEL, SEARCH_GO_TITLE);
    let searchErrorTimer = null;
    const showSearchError = (message) => {
      if (searchErrorTimer) clearTimeout(searchErrorTimer);
      setButtonLabel(go, message);
      searchErrorTimer = setTimeout(() => setButtonLabel(go, SEARCH_GO_LABEL, SEARCH_GO_TITLE), 3e3);
    };
    const fireSearch = () => {
      const osoba = sOsoba.value.trim();
      const temat = sTemat.value.trim();
      const tresc = sTresc.value.trim();
      const isoOd = sOd.value;
      const isoDo = sDo.value;
      const validationError = validateSearchDraft({
        osoba,
        temat,
        tresc,
        odDaty: isoOd,
        doDaty: isoDo
      });
      if (validationError) {
        showSearchError(validationError);
        return;
      }
      if (searchErrorTimer) clearTimeout(searchErrorTimer);
      setButtonLabel(go, SEARCH_GO_LABEL, SEARCH_GO_TITLE);
      const odDaty = fromISODate(isoOd) ?? void 0;
      const doDaty = fromISODate(isoDo) ?? void 0;
      const query = {
        ...osoba !== "" ? { osoba } : {},
        ...odDaty ? { odDaty } : {},
        ...doDaty ? { doDaty } : {},
        ...temat !== "" ? { temat } : {},
        ...tresc !== "" ? { tresc } : {}
      };
      if (Object.keys(query).length === 0) {
        handlers.onRefreshBox(state.activeBox);
        return;
      }
      handlers.onSearch(state.activeBox, query);
    };
    go.addEventListener("click", fireSearch);
    for (const el of [sOsoba, sTemat, sTresc, sOd, sDo]) {
      el.addEventListener("keydown", (ev) => {
        if (ev.key === "Enter") {
          ev.preventDefault();
          fireSearch();
        }
      });
    }
    searchRow.appendChild(sOsoba);
    searchRow.appendChild(sTemat);
    searchRow.appendChild(sTresc);
    searchRow.appendChild(sOdF);
    searchRow.appendChild(sDoF);
    searchRow.appendChild(go);
    pane.appendChild(searchRow);
    attachGhost(doc, sTemat, subjectSource);
    const scroll = doc.createElement("div");
    scroll.className = "arkmail-list-scroll";
    scroll.setAttribute("data-pane-key", `listy:${state.activeBox}`);
    pane.appendChild(scroll);
    const searchMode = state.search && state.search.box === state.activeBox ? state.search : null;
    if (searchMode) {
      const banner = doc.createElement("div");
      banner.className = "arkmail-search-banner";
      banner.appendChild(doc.createTextNode(`Wyniki szukania: ${searchMode.label}`));
      const clear = doc.createElement("button");
      clear.className = "arkmail-search-clear arkmail-btn-danger";
      clear.textContent = "Wyczysc";
      clear.addEventListener("click", () => {
        for (const key of ["osoba", "temat", "tresc", "odDaty", "doDaty"]) searchDraft[key] = "";
        for (const el of [sOsoba, sTemat, sTresc, sOd, sDo]) el.value = "";
        handlers.onClearSearch(state.activeBox);
      });
      banner.appendChild(clear);
      scroll.appendChild(banner);
    }
    const view = state.boxes[state.activeBox];
    if (!view) {
      scroll.appendChild(dim("Skrzynka nie zaladowana - kliknij jej nazwe, aby pobrac."));
      return pane;
    }
    if (view.empty !== null) {
      scroll.appendChild(dim(view.empty === "puste" ? "Skrzynka pusta." : "Brak pasujacych listow."));
      return pane;
    }
    const displayed = [...view.entries].reverse();
    for (const [idx, e] of displayed.entries()) {
      const row = doc.createElement("div");
      const unreadMark = !e.isRead && (state.activeBox === "odebrane" || state.activeBox === "nieprzeczytane");
      row.className = "arkmail-entry" + (unreadMark ? " arkmail-unread" : "");
      row.setAttribute("data-number", String(e.number));
      const num = doc.createElement("span");
      num.className = "arkmail-entry-num";
      num.textContent = `${idx + 1}.`;
      row.appendChild(num);
      const party = doc.createElement("span");
      party.className = "arkmail-entry-party";
      party.textContent = e.party || "(brak)";
      row.appendChild(party);
      const subject = doc.createElement("span");
      subject.className = "arkmail-entry-subject";
      subject.textContent = e.subject + (e.forwarded ? " (przekazany)" : "");
      row.appendChild(subject);
      const date = doc.createElement("span");
      date.className = "arkmail-entry-date";
      date.textContent = e.date ? e.date.raw : "";
      row.appendChild(date);
      row.addEventListener("click", () => handlers.onOpenLetter(state.activeBox, e));
      scroll.appendChild(row);
    }
    if (searchMode) {
    } else if (view.truncated && !state.loadAll) {
      const btn = doc.createElement("button");
      btn.className = "arkmail-older arkmail-btn-action";
      btn.textContent = "Wczytaj starsze";
      btn.addEventListener("click", () => handlers.onLoadOlder(state.activeBox));
      scroll.appendChild(btn);
    }
    return pane;
  };
  const renderList = (state) => {
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane";
    const l = state.letter;
    pane.setAttribute("data-pane-key", l ? `list:${l.box}:${l.number}` : "list:brak");
    if (!l) {
      pane.appendChild(
        dim(state.wide ? "Wybierz list, aby go przeczytac." : "Nie otwarto zadnego listu.")
      );
      return pane;
    }
    const head = doc.createElement("div");
    head.className = "arkmail-letter-head";
    if (state.wide) {
      const close = doc.createElement("button");
      close.className = "arkmail-letter-close";
      close.textContent = "Zamknij";
      close.addEventListener("click", () => handlers.onCloseLetter());
      head.appendChild(close);
    }
    const subj = doc.createElement("div");
    subj.className = "arkmail-letter-subject";
    subj.textContent = l.subject;
    head.appendChild(subj);
    const meta = doc.createElement("div");
    meta.className = "arkmail-letter-meta";
    const parts = [`Od: ${l.from}`];
    if (l.to) parts.push(`Do: ${l.to}`);
    if (l.cc) parts.push(`DW: ${l.cc}`);
    if (l.date) parts.push(l.date);
    meta.textContent = parts.join(" | ");
    head.appendChild(meta);
    pane.appendChild(head);
    const body = doc.createElement("div");
    body.className = "arkmail-letter-body";
    body.textContent = l.body.join("\n");
    pane.appendChild(body);
    const ops = doc.createElement("div");
    ops.className = "arkmail-letter-ops";
    const source = l.source;
    const replyTo = (all) => {
      const received = l.box === "odebrane" || l.box === "nieprzeczytane";
      composeDraft.adresat = received ? l.from : l.to || l.cc || "";
      composeDraft.dw = all && l.cc ? l.cc : "";
      composeDraft.temat = "";
      composeDraft.tresc = "";
      store2.setTab("napisz");
    };
    const reply = doc.createElement("button");
    reply.className = "arkmail-reply";
    reply.textContent = "Odpowiedz";
    reply.addEventListener("click", () => replyTo(false));
    ops.appendChild(reply);
    const replyAll = doc.createElement("button");
    replyAll.className = "arkmail-reply-all";
    replyAll.textContent = "Odpowiedz wszystkim";
    replyAll.addEventListener("click", () => replyTo(true));
    ops.appendChild(replyAll);
    const replyQuote = doc.createElement("button");
    replyQuote.className = "arkmail-reply-quote";
    replyQuote.textContent = "Odpowiedz z cytowaniem";
    if (l.body.some((line) => line.trim() !== "")) {
      replyQuote.addEventListener("click", () => {
        const received = l.box === "odebrane" || l.box === "nieprzeczytane";
        composeDraft.adresat = received ? l.from : l.to || l.cc || "";
        composeDraft.dw = "";
        composeDraft.temat = `Odp: ${l.subject}`;
        composeDraft.tresc = `

---
${l.body.join("\n")}
---`;
        store2.setTab("napisz");
      });
    } else {
      replyQuote.setAttribute("disabled", "");
      replyQuote.setAttribute("title", "List bez tresci - nie ma czego cytowac.");
    }
    ops.appendChild(replyQuote);
    const del = doc.createElement("button");
    del.className = "arkmail-del arkmail-btn-danger";
    del.textContent = "Usun";
    if (source) {
      let delArmed = false;
      let delTimer = null;
      del.addEventListener("click", () => {
        if (!delArmed) {
          delArmed = true;
          setButtonLabel(del, "Na pewno? Kliknij ponownie");
          delTimer = setTimeout(() => {
            delArmed = false;
            setButtonLabel(del, "Usun");
          }, 3e3);
          return;
        }
        if (delTimer) clearTimeout(delTimer);
        delArmed = false;
        setButtonLabel(del, "Usun");
        handlers.onDeleteLetter(l.box, source);
      });
    } else {
      del.setAttribute("disabled", "");
      del.setAttribute("title", "Otworz list z zakladki Listy, aby go usunac.");
    }
    ops.appendChild(del);
    const fwdInput = doc.createElement("input");
    fwdInput.setAttribute("data-field", "forward");
    fwdInput.setAttribute("placeholder", "Przekaz do (gracz lub alias)");
    if (!source) fwdInput.setAttribute("disabled", "");
    ops.appendChild(fwdInput);
    attachGhost(doc, fwdInput, personSource);
    const fwd = doc.createElement("button");
    fwd.className = "arkmail-fwd";
    fwd.textContent = "Przekaz";
    if (source) {
      fwd.addEventListener("click", () => {
        const adresat = fwdInput.value.trim();
        if (adresat) handlers.onForwardLetter(l.box, source, adresat);
      });
    } else {
      fwd.setAttribute("disabled", "");
      fwd.setAttribute("title", "Otworz list z zakladki Listy, aby go przekazac.");
    }
    ops.appendChild(fwd);
    const exp = doc.createElement("button");
    exp.className = "arkmail-export-letter";
    exp.textContent = "Zapisz list TXT";
    exp.addEventListener("click", () => handlers.onExportLetter?.());
    ops.appendChild(exp);
    pane.appendChild(ops);
    if (!state.wide) {
      const back = doc.createElement("button");
      back.className = "arkmail-older arkmail-btn-action";
      back.textContent = "Zamknij list";
      back.addEventListener("click", () => handlers.onCloseLetter());
      pane.appendChild(back);
    }
    return pane;
  };
  const composeDraft = { adresat: "", temat: "", dw: "", tresc: "" };
  const writeTo = (adresat) => {
    composeDraft.adresat = adresat;
    composeDraft.dw = "";
    composeDraft.temat = "";
    composeDraft.tresc = "";
    store2.setTab("napisz");
  };
  const partyLabel = (names) => names.length <= 1 ? names[0] ?? "" : `${names.slice(0, -1).join(", ")} i ${names[names.length - 1]}`;
  let composePreview = null;
  const repaintCompose = () => {
    if (!composePreview) return;
    const st = store2.state;
    composePreview.textContent = renderLetter(
      composeDraft.tresc,
      st.composeTemplate,
      st.composeWidth
    ).lines.join("\n");
  };
  const previewOpenBtn = () => {
    const btn = doc.createElement("button");
    btn.className = "arkmail-preview-open";
    btn.textContent = "Pelne okno";
    btn.addEventListener("click", () => {
      previewFull = true;
      render(store2.state);
    });
    return btn;
  };
  const renderPreviewFull = () => {
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane arkmail-preview-full-pane";
    pane.setAttribute("data-pane-key", "napisz:podglad-full");
    const bar = doc.createElement("div");
    bar.className = "arkmail-preview-bar";
    const lab = doc.createElement("label");
    lab.textContent = "Podglad wysylanego listu";
    bar.appendChild(lab);
    const close = doc.createElement("button");
    close.className = "arkmail-preview-close";
    close.textContent = "Zamknij podglad";
    close.addEventListener("click", () => {
      previewFull = false;
      render(store2.state);
    });
    bar.appendChild(close);
    pane.appendChild(bar);
    const pre = doc.createElement("pre");
    pre.className = "arkmail-preview";
    pane.appendChild(pre);
    composePreview = pre;
    repaintCompose();
    return pane;
  };
  const renderComposePreview = () => {
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane";
    pane.setAttribute("data-pane-key", "napisz:podglad");
    const bar = doc.createElement("div");
    bar.className = "arkmail-preview-bar";
    const lab = doc.createElement("label");
    lab.textContent = "Podglad wysylanego listu";
    bar.appendChild(lab);
    bar.appendChild(previewOpenBtn());
    pane.appendChild(bar);
    const pre = doc.createElement("pre");
    pre.className = "arkmail-preview";
    pane.appendChild(pre);
    composePreview = pre;
    repaintCompose();
    return pane;
  };
  let seenComposeClearSeq = 0;
  const renderNapisz = (state) => {
    if (state.composeClearSeq !== seenComposeClearSeq) {
      seenComposeClearSeq = state.composeClearSeq;
      composeDraft.adresat = "";
      composeDraft.temat = "";
      composeDraft.dw = "";
      composeDraft.tresc = "";
    }
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane arkmail-form";
    pane.setAttribute("data-pane-key", "napisz");
    const fields = [
      ["adresat", "Adresat"],
      ["temat", "Temat"],
      ["dw", "DW (opcjonalnie)"]
    ];
    for (const [field, label] of fields) {
      const lab2 = doc.createElement("label");
      lab2.textContent = label;
      pane.appendChild(lab2);
      const input = doc.createElement("input");
      input.setAttribute("data-field", field);
      input.value = composeDraft[field];
      input.addEventListener("input", () => {
        composeDraft[field] = input.value;
      });
      pane.appendChild(input);
      if (field === "temat") attachGhost(doc, input, subjectSource);
      else attachGhost(doc, input, adresatSource, { segment: true });
    }
    const labSz = doc.createElement("label");
    labSz.textContent = "Szablon";
    pane.appendChild(labSz);
    const sel = doc.createElement("select");
    sel.setAttribute("data-field", "szablon");
    for (const [value, label] of TEMPLATES) {
      const opt = doc.createElement("option");
      opt.setAttribute("value", value);
      opt.textContent = label;
      sel.appendChild(opt);
    }
    sel.value = state.composeTemplate;
    sel.addEventListener("change", () => {
      store2.setCompose({ template: sel.value });
    });
    pane.appendChild(sel);
    const labW = doc.createElement("label");
    labW.textContent = "Szerokosc linii (20-120)";
    pane.appendChild(labW);
    const width = doc.createElement("input");
    width.setAttribute("data-field", "szerokosc");
    width.value = String(state.composeWidth);
    width.addEventListener("change", () => {
      const parsed = Number.parseInt(width.value, 10);
      store2.setCompose({
        width: Number.isFinite(parsed) ? clampLineWidth(parsed) : 60
      });
    });
    pane.appendChild(width);
    const lab = doc.createElement("label");
    lab.textContent = "Tresc";
    pane.appendChild(lab);
    const tresc = doc.createElement("textarea");
    tresc.setAttribute("data-field", "tresc");
    tresc.value = composeDraft.tresc;
    pane.appendChild(tresc);
    if (!state.wide) {
      const barP = doc.createElement("div");
      barP.className = "arkmail-preview-bar";
      const labP = doc.createElement("label");
      labP.textContent = "Podglad wysylanego listu";
      barP.appendChild(labP);
      barP.appendChild(previewOpenBtn());
      pane.appendChild(barP);
      const preview = doc.createElement("pre");
      preview.className = "arkmail-preview";
      pane.appendChild(preview);
      composePreview = preview;
      repaintCompose();
    }
    tresc.addEventListener("input", () => {
      composeDraft.tresc = tresc.value;
      repaintCompose();
    });
    const send = doc.createElement("button");
    send.className = "arkmail-send arkmail-btn-primary";
    send.textContent = "Zapisz w niewyslanych";
    const SEND_LABEL = "Zapisz w niewyslanych";
    let sendTimer = null;
    const disarmSend = () => {
      setButtonLabel(send, SEND_LABEL);
    };
    send.addEventListener("click", () => {
      const st = store2.state;
      const val = (f) => pane.querySelector(`[data-field="${f}"]`).value;
      const input = {
        adresat: val("adresat"),
        temat: val("temat"),
        dw: val("dw"),
        tresc: tresc.value
      };
      const validationError = validateCompose(input);
      if (validationError) {
        if (sendTimer) clearTimeout(sendTimer);
        setButtonLabel(send, validationError);
        sendTimer = setTimeout(disarmSend, 3e3);
        return;
      }
      const rendered = renderLetter(input.tresc, st.composeTemplate, st.composeWidth);
      if (sendTimer) clearTimeout(sendTimer);
      disarmSend();
      handlers.onSendCompose({
        ...input,
        linie: rendered.lines
      });
    });
    pane.appendChild(send);
    const clearCompose = doc.createElement("button");
    clearCompose.className = "arkmail-compose-clear arkmail-btn-danger";
    clearCompose.textContent = "Wyczysc";
    let clearArmed = false;
    let clearTimer = null;
    clearCompose.addEventListener("click", () => {
      if (!clearArmed) {
        clearArmed = true;
        setButtonLabel(clearCompose, "Na pewno? Kliknij ponownie");
        clearTimer = setTimeout(() => {
          clearArmed = false;
          setButtonLabel(clearCompose, "Wyczysc");
        }, 3e3);
        return;
      }
      if (clearTimer) clearTimeout(clearTimer);
      clearArmed = false;
      setButtonLabel(clearCompose, "Wyczysc");
      composeDraft.adresat = "";
      composeDraft.temat = "";
      composeDraft.dw = "";
      composeDraft.tresc = "";
      for (const f of ["adresat", "temat", "dw", "tresc"]) {
        const el = pane.querySelector(`[data-field="${f}"]`);
        if (el) el.value = "";
      }
      repaintCompose();
    });
    pane.appendChild(clearCompose);
    return pane;
  };
  const renderGrupy = (state, pane) => {
    const error = doc.createElement("div");
    error.className = "arkmail-dim arkmail-group-error";
    error.setAttribute("data-group-error", "");
    const showError = (msg) => {
      error.textContent = msg;
    };
    const save = (groups) => {
      showError("");
      handlers.onSaveGroups?.(groups);
    };
    const nameTaken = (name, ignore) => state.groups.some(
      (g) => g.name !== ignore && g.name.toLowerCase() === name.toLowerCase()
    );
    const addRow = doc.createElement("div");
    addRow.className = "arkmail-group-add";
    const addInput = doc.createElement("input");
    addInput.setAttribute("data-group-add", "");
    addInput.setAttribute("placeholder", "Nazwa nowej grupy");
    const addBtn = doc.createElement("button");
    addBtn.textContent = "Utworz grupe";
    addBtn.setAttribute("data-group-create", "");
    addBtn.setAttribute("title", "Tworzy pusta grupe. Czlonkow dolaczysz po utworzeniu.");
    addBtn.addEventListener("click", () => {
      const name = addInput.value.trim();
      if (!name) {
        showError("Podaj nazwe grupy.");
        return;
      }
      if (nameTaken(name)) {
        showError(`Grupa "${name}" juz istnieje.`);
        return;
      }
      addInput.value = "";
      save([...state.groups, { name, members: [] }]);
    });
    addRow.appendChild(addInput);
    addRow.appendChild(addBtn);
    pane.appendChild(addRow);
    pane.appendChild(error);
    const filterRow = doc.createElement("div");
    filterRow.className = "arkmail-group-filter";
    const filterInput = doc.createElement("input");
    filterInput.setAttribute("data-group-filter", "");
    filterInput.setAttribute("placeholder", "Filtruj grupy");
    filterInput.setAttribute("title", "Pokazuje tylko grupy z nazwa zawierajaca wpisany fragment.");
    filterInput.value = groupFilter;
    const filterClear = doc.createElement("button");
    filterClear.textContent = "Wyczysc filtr";
    filterClear.setAttribute("data-group-filter-clear", "");
    filterClear.setAttribute("title", "Czysci filtr grup - znowu wszystkie grupy.");
    if (!groupFilter) filterClear.setAttribute("disabled", "1");
    filterClear.addEventListener("click", () => {
      groupFilter = "";
      filterInput.value = "";
      filterClear.setAttribute("disabled", "1");
      paintGroups();
    });
    filterInput.addEventListener("input", () => {
      groupFilter = filterInput.value;
      if (groupFilter) filterClear.removeAttribute("disabled");
      else filterClear.setAttribute("disabled", "1");
      paintGroups();
    });
    filterRow.appendChild(filterInput);
    filterRow.appendChild(filterClear);
    pane.appendChild(filterRow);
    const list = doc.createElement("div");
    pane.appendChild(list);
    const paintGroups = () => {
      const needle = groupFilter.trim().toLowerCase();
      const shown = needle ? state.groups.filter((g) => g.name.toLowerCase().includes(needle)) : state.groups;
      list.replaceChildren();
      for (const group of shown) {
        const row = doc.createElement("div");
        row.className = "arkmail-group";
        const expanded = expandedGroups.has(group.name);
        const toggle = doc.createElement("button");
        toggle.className = "arkmail-group-toggle";
        toggle.setAttribute("data-group-toggle", "");
        toggle.textContent = `${expanded ? "v" : ">"} ${group.name} (${group.members.length})`;
        toggle.setAttribute(
          "title",
          expanded ? "Zwija grupe." : "Rozwija grupe: edycja nazwy, czlonkowie, pisanie do grupy."
        );
        toggle.addEventListener("click", () => {
          if (expandedGroups.has(group.name)) expandedGroups.delete(group.name);
          else expandedGroups.add(group.name);
          store2.refresh();
        });
        row.appendChild(toggle);
        if (expanded) {
          const head = doc.createElement("div");
          head.className = "arkmail-group-head";
          const rename = doc.createElement("input");
          rename.setAttribute("data-group-rename", "");
          rename.value = group.name;
          rename.setAttribute("title", "Nazwa grupy - zapisz obok.");
          const renameOk = doc.createElement("button");
          renameOk.textContent = "Zapisz nazwe";
          renameOk.setAttribute("data-group-rename-ok", "");
          renameOk.setAttribute("title", "Zapisuje nowa nazwe grupy.");
          renameOk.addEventListener("click", () => {
            const name = rename.value.trim();
            if (!name) {
              showError("Podaj nazwe grupy.");
              return;
            }
            if (nameTaken(name, group.name)) {
              showError(`Grupa "${name}" juz istnieje.`);
              return;
            }
            save(state.groups.map((g) => g.name === group.name ? { ...g, name } : g));
          });
          const del = doc.createElement("button");
          del.className = "arkmail-btn-danger";
          del.textContent = "Usun grupe";
          del.setAttribute("data-group-delete", "");
          del.setAttribute("title", "Dwuklik: pierwszy klik pyta o potwierdzenie, drugi kasuje grupe.");
          guardDeleteButton(
            del,
            () => save(state.groups.filter((g) => g.name !== group.name)),
            { armedLabel: "Na pewno usunac?" }
          );
          head.appendChild(rename);
          head.appendChild(renameOk);
          head.appendChild(del);
          const write = doc.createElement("button");
          write.textContent = "Napisz do grupy";
          write.setAttribute("data-group-write", "");
          if (group.members.length === 0) {
            write.setAttribute("disabled", "1");
            write.setAttribute("title", "Pusta grupa - najpierw dodaj czlonkow.");
          } else {
            write.setAttribute("title", "Otwiera zakladke Napisz z czlonkami grupy jako adresatami.");
            write.addEventListener("click", () => writeTo(partyLabel(group.members)));
          }
          head.appendChild(write);
          row.appendChild(head);
          const members = doc.createElement("div");
          members.className = "arkmail-group-members";
          for (const member of group.members) {
            const chip = doc.createElement("span");
            chip.className = "arkmail-group-member";
            chip.textContent = member;
            const x = doc.createElement("button");
            x.className = "arkmail-btn-danger";
            x.textContent = "x";
            x.setAttribute("data-member-remove", "");
            x.setAttribute("title", `Usuwa ${member} z grupy.`);
            guardDeleteButton(
              x,
              () => save(
                state.groups.map(
                  (g) => g.name === group.name ? { ...g, members: g.members.filter((m) => m !== member) } : g
                )
              ),
              { armedTitle: `Kliknij ponownie, aby usunac ${member} z grupy.` }
            );
            chip.appendChild(x);
            members.appendChild(chip);
          }
          const addMember = doc.createElement("input");
          addMember.setAttribute("data-member-add", "");
          addMember.setAttribute("placeholder", "Dodaj osobe");
          attachGhost(doc, addMember, personSource);
          const addMemberOk = doc.createElement("button");
          addMemberOk.textContent = "Dodaj";
          addMemberOk.setAttribute("data-member-add-ok", "");
          addMemberOk.setAttribute("title", "Dodaje osobe do grupy (podpowiedz: strzalka w prawo).");
          addMemberOk.addEventListener("click", () => {
            const name = addMember.value.trim();
            if (!name) return;
            if (group.members.some((m) => m.toLowerCase() === name.toLowerCase())) {
              showError(`${name} juz jest w tej grupie.`);
              return;
            }
            save(
              state.groups.map(
                (g) => g.name === group.name ? { ...g, members: [...g.members, name] } : g
              )
            );
          });
          members.appendChild(addMember);
          members.appendChild(addMemberOk);
          row.appendChild(members);
        }
        list.appendChild(row);
      }
      if (shown.length === 0 && state.groups.length > 0) {
        const empty = doc.createElement("div");
        empty.className = "arkmail-dim";
        empty.textContent = "Brak grup pasujacych do filtra.";
        list.appendChild(empty);
      }
      if (state.groups.length === 0) {
        const empty = doc.createElement("div");
        empty.className = "arkmail-dim";
        empty.textContent = "Brak grup - utworz pierwsza grupe.";
        list.appendChild(empty);
      }
    };
    paintGroups();
    const ops = doc.createElement("div");
    ops.className = "arkmail-box-ops";
    const delAll = doc.createElement("button");
    delAll.className = "arkmail-btn-danger";
    delAll.textContent = "Usun wszystkie grupy";
    delAll.setAttribute("data-groups-delete-all", "");
    delAll.setAttribute("title", "Dwuklik: pierwszy klik pyta o potwierdzenie, drugi kasuje wszystkie grupy.");
    if (state.groups.length === 0) delAll.setAttribute("disabled", "1");
    guardDeleteButton(delAll, () => save([]), {
      armedLabel: "Na pewno usunac wszystkie?"
    });
    ops.appendChild(delAll);
    pane.appendChild(ops);
    fillButtonTitles(pane);
  };
  const renderKsiazka = (state, pane) => {
    if (bookPeopleRef !== state.people) {
      bookPeopleRef = state.people;
      bookSelection.clear();
    }
    const save = (people) => handlers.onSavePeople?.(people);
    const importRow = doc.createElement("div");
    importRow.className = "arkmail-import-row";
    const IMPORT_BTNS = [
      [
        "zapamietani",
        "Importuj zapamietanych",
        "Pobiera z gry osoby zapamietane na stale i zapisuje je jako baze osob. Grup nie tworzy."
      ],
      [
        "przedstawieni",
        "Importuj przedstawionych",
        "Pobiera z gry osoby, ktore zostaly ci ostatnio przedstawione, i zapisuje je jako baze osob. Grup nie tworzy."
      ],
      [
        "aliasy",
        "Importuj aliasy pocztowe",
        "Pobiera z gry aliasy pocztowe. Nie da sie ich edytowac - rozwija je serwer przy wysylce. Osoby z aliasow dolaczaja do bazy osob."
      ]
    ];
    for (const [kind, label, title] of IMPORT_BTNS) {
      const btn = doc.createElement("button");
      btn.className = "arkmail-import-btn";
      btn.setAttribute("data-import", kind);
      btn.textContent = label;
      btn.setAttribute("title", title);
      btn.addEventListener("click", () => {
        if (kind === "aliasy") handlers.onImportAliases?.();
        else handlers.onImportPeople?.(kind);
      });
      importRow.appendChild(btn);
    }
    pane.appendChild(importRow);
    const addRow = doc.createElement("div");
    addRow.className = "arkmail-book-add";
    const addInput = doc.createElement("input");
    addInput.setAttribute("data-book-new", "");
    addInput.setAttribute("placeholder", "Imie nowej osoby");
    const addBtn = doc.createElement("button");
    addBtn.className = "arkmail-btn-action";
    addBtn.textContent = "Dodaj";
    addBtn.setAttribute("data-book-add", "");
    addBtn.setAttribute("title", "Dodaje imie do ksiazki adresowej.");
    const addErr = doc.createElement("span");
    addErr.className = "arkmail-group-error";
    const showAddError = (msg) => {
      addErr.textContent = msg;
      addErr.setAttribute("data-book-error", "");
    };
    const clearAddError = () => {
      addErr.textContent = "";
      addErr.removeAttribute("data-book-error");
    };
    const tryAdd = () => {
      const name = addInput.value.trim();
      if (!name) {
        showAddError("Podaj imie.");
        return;
      }
      if (!/^[A-Za-z]+$/.test(name)) {
        showAddError("Imie: tylko litery.");
        return;
      }
      if (state.people.some((p) => p.toLowerCase() === name.toLowerCase())) {
        showAddError("To imie juz jest w ksiazce.");
        return;
      }
      clearAddError();
      addInput.value = "";
      save([...state.people, name]);
    };
    addBtn.addEventListener("click", tryAdd);
    addInput.addEventListener("keydown", (ev) => {
      if (ev.key === "Enter") tryAdd();
    });
    addRow.appendChild(addInput);
    addRow.appendChild(addBtn);
    addRow.appendChild(addErr);
    attachGhost(doc, addInput, personSource);
    pane.appendChild(addRow);
    const bulk = doc.createElement("button");
    bulk.className = "arkmail-btn-danger";
    bulk.textContent = "Usun zaznaczone imiona";
    bulk.setAttribute("data-book-delete-checked", "");
    bulk.setAttribute(
      "title",
      "Dwuklik: pierwszy klik pyta o potwierdzenie, drugi kasuje zaznaczone imiona."
    );
    if (bookSelection.size === 0) bulk.setAttribute("disabled", "1");
    guardDeleteButton(
      bulk,
      () => save(state.people.filter((p) => !bookSelection.has(p))),
      { armedLabel: `Na pewno usunac zaznaczone (${bookSelection.size})?` }
    );
    pane.appendChild(bulk);
    const sorted = [...state.people].sort((a, b) => {
      const la = a.toLowerCase();
      const lb = b.toLowerCase();
      if (la === lb) return 0;
      return la < lb ? -1 : 1;
    });
    const currentVisible = () => {
      const needle = bookFilter.trim().toLowerCase();
      return needle ? sorted.filter((p) => p.toLowerCase().includes(needle)) : sorted;
    };
    const visible = currentVisible();
    const writeBulk = doc.createElement("button");
    writeBulk.className = "arkmail-btn-action";
    writeBulk.textContent = `Napisz list do zaznaczonych (${bookSelection.size})`;
    writeBulk.setAttribute("data-book-write-checked", "");
    writeBulk.setAttribute(
      "title",
      "Otwiera zakladke Napisz z zaznaczonymi osobami jako adresatami."
    );
    if (bookSelection.size === 0) writeBulk.setAttribute("disabled", "1");
    writeBulk.addEventListener("click", () => {
      if (bookSelection.size === 0) return;
      const party = partyLabel(sorted.filter((p) => bookSelection.has(p)));
      bookSelection.clear();
      writeTo(party);
    });
    pane.appendChild(writeBulk);
    const selectAllBtn = doc.createElement("button");
    selectAllBtn.className = "arkmail-btn-action";
    selectAllBtn.textContent = "Zaznacz wszystkie";
    selectAllBtn.setAttribute("data-book-select-all", "");
    selectAllBtn.setAttribute("title", "Zaznacza wszystkie imiona na liscie.");
    if (visible.length === 0) selectAllBtn.setAttribute("disabled", "1");
    selectAllBtn.addEventListener("click", () => {
      for (const p of visible) bookSelection.add(p);
      store2.refresh();
    });
    pane.appendChild(selectAllBtn);
    const deselectAllBtn = doc.createElement("button");
    deselectAllBtn.className = "arkmail-btn-action";
    deselectAllBtn.textContent = "Odznacz wszystkie";
    deselectAllBtn.setAttribute("data-book-deselect-all", "");
    deselectAllBtn.setAttribute("title", "Czysci zaznaczenie imion.");
    if (visible.length === 0) deselectAllBtn.setAttribute("disabled", "1");
    deselectAllBtn.addEventListener("click", () => {
      bookSelection.clear();
      store2.refresh();
    });
    pane.appendChild(deselectAllBtn);
    const filterRow = doc.createElement("div");
    filterRow.className = "arkmail-book-filter";
    const filterInput = doc.createElement("input");
    filterInput.setAttribute("data-book-filter", "");
    filterInput.setAttribute("placeholder", "Filtruj imiona");
    filterInput.setAttribute("title", "Pokazuje tylko imiona zawierajace wpisany fragment.");
    filterInput.value = bookFilter;
    const filterClear = doc.createElement("button");
    filterClear.textContent = "Wyczysc filtr";
    filterClear.setAttribute("data-book-filter-clear", "");
    filterClear.setAttribute("title", "Czysci filtr imion - znowu cala ksiazka adresowa.");
    if (!bookFilter) filterClear.setAttribute("disabled", "1");
    filterClear.addEventListener("click", () => {
      bookFilter = "";
      filterInput.value = "";
      filterClear.setAttribute("disabled", "1");
      paintList();
    });
    filterInput.addEventListener("input", () => {
      bookFilter = filterInput.value;
      if (bookFilter) filterClear.removeAttribute("disabled");
      else filterClear.setAttribute("disabled", "1");
      paintList();
    });
    filterRow.appendChild(filterInput);
    filterRow.appendChild(filterClear);
    const scroll = doc.createElement("div");
    scroll.className = "arkmail-list-scroll";
    scroll.setAttribute("data-pane-key", "kontakty:ksiazka");
    scroll.appendChild(filterRow);
    const listWrap = doc.createElement("div");
    const paintList = () => {
      const shown = currentVisible();
      listWrap.replaceChildren();
      if (sorted.length === 0) {
        listWrap.appendChild(
          dim("Ksiazka adresowa jest pusta - zaimportuj osoby z gry albo dodaj recznie.")
        );
        return;
      }
      if (shown.length === 0) {
        listWrap.appendChild(dim("Brak imion pasujacych do filtra."));
        return;
      }
      for (const name of shown) {
        const row = doc.createElement("div");
        row.className = "arkmail-book-row";
        row.setAttribute("data-book-row", "");
        const check = doc.createElement("input");
        check.setAttribute("type", "checkbox");
        check.checked = bookSelection.has(name);
        check.addEventListener("change", () => {
          if (check.checked) bookSelection.add(name);
          else bookSelection.delete(name);
          store2.refresh();
        });
        const nameEl = doc.createElement("span");
        nameEl.className = "arkmail-book-name";
        nameEl.setAttribute("data-book-name", "");
        nameEl.textContent = name;
        const remove = doc.createElement("button");
        remove.className = "arkmail-book-remove arkmail-btn-danger";
        remove.setAttribute("data-book-remove", "");
        remove.textContent = "x";
        remove.setAttribute("title", `Usuwa ${name} z ksiazki adresowej.`);
        guardDeleteButton(remove, () => save(state.people.filter((p) => p !== name)), {
          armedTitle: `Kliknij ponownie, aby usunac ${name} z ksiazki adresowej.`
        });
        row.appendChild(check);
        row.appendChild(nameEl);
        row.appendChild(remove);
        const write = doc.createElement("button");
        write.className = "arkmail-book-write";
        write.setAttribute("data-book-write", "");
        write.textContent = "Napisz";
        write.setAttribute("title", `Otwiera zakladke Napisz z adresem: ${name}.`);
        write.addEventListener("click", () => writeTo(name));
        row.appendChild(write);
        listWrap.appendChild(row);
      }
    };
    paintList();
    scroll.appendChild(listWrap);
    pane.appendChild(scroll);
    fillButtonTitles(pane);
  };
  const renderKontakty = (state) => {
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane" + (contactView.sub === "ksiazka" ? " arkmail-listy" : "");
    pane.setAttribute("data-pane-key", "kontakty");
    const subRow = doc.createElement("div");
    subRow.className = "arkmail-boxes arkmail-subpills";
    const SUBPILLS = [
      ["ksiazka", "Ksiazka adresowa"],
      ["aliasy", "Aliasy Pocztowe"],
      ["grupy", "Grupy"],
      ["importeksport", "Import-Eksport"]
    ];
    for (const [sub, label] of SUBPILLS) {
      const pill = doc.createElement("button");
      pill.className = "arkmail-box arkmail-subpill" + (contactView.sub === sub ? " arkmail-box-active" : "");
      pill.textContent = label;
      pill.addEventListener("click", () => {
        contactView.sub = sub;
        store2.refresh();
      });
      subRow.appendChild(pill);
    }
    pane.appendChild(subRow);
    if (contactView.sub === "grupy") {
      renderGrupy(state, pane);
      return pane;
    }
    if (contactView.sub === "aliasy") {
      renderAliasy(state, pane);
      return pane;
    }
    if (contactView.sub === "importeksport") {
      renderImportEksport(state, pane);
      return pane;
    }
    if (contactView.sub === "ksiazka") {
      renderKsiazka(state, pane);
      return pane;
    }
    return pane;
  };
  const renderAliasy = (state, pane) => {
    const aliasSec = doc.createElement("div");
    aliasSec.className = "arkmail-book-aliases";
    aliasSec.setAttribute("data-book-aliases", "");
    const aliasNote = doc.createElement("div");
    aliasNote.className = "arkmail-dim";
    aliasNote.textContent = "Aliasy pocztowe z gry - tylko odczyt, nie sa zapisywane do pliku. Alias usuwasz w grze.";
    aliasSec.appendChild(aliasNote);
    if (state.importedAliases.length === 0) {
      aliasSec.appendChild(dim("Brak aliasow - aliasy pobiera sie z gry."));
    } else {
      for (const alias of state.importedAliases) {
        const row = doc.createElement("div");
        row.className = "arkmail-book-alias";
        row.textContent = `${alias.name} -> ${alias.targets.join(", ")}`;
        aliasSec.appendChild(row);
      }
    }
    const clearBtn = doc.createElement("button");
    clearBtn.className = "arkmail-btn-danger";
    clearBtn.textContent = "Wyczysc aliasy";
    clearBtn.setAttribute("data-aliases-clear", "");
    clearBtn.setAttribute(
      "title",
      "Kasuje lokalnie zaimportowane aliasy. Na serwerze Arkadii nic nie znika - aliasy pobierzesz z gry ponownie."
    );
    if (state.importedAliases.length === 0) clearBtn.setAttribute("disabled", "1");
    guardDeleteButton(clearBtn, () => handlers.onClearAliases?.(), {
      armedLabel: "Na pewno usunac aliasy?"
    });
    aliasSec.appendChild(clearBtn);
    pane.appendChild(aliasSec);
    fillButtonTitles(pane);
  };
  const renderImportEksport = (state, pane) => {
    const error = doc.createElement("div");
    error.className = "arkmail-dim arkmail-group-error";
    error.setAttribute("data-group-error", "");
    const showError = (msg) => {
      error.textContent = msg;
    };
    const addAll = doc.createElement("button");
    addAll.className = "arkmail-btn-action";
    addAll.textContent = "Dopisz wszystkie osoby z listow";
    addAll.setAttribute("data-book-add-all-contacts", "");
    addAll.setAttribute(
      "title",
      "Dopisuje do ksiazki wszystkie osoby zebrane z listow. Bez wzgledu na wielkosc liter nic nie duplikuje."
    );
    if (state.contacts.length === 0) addAll.setAttribute("disabled", "1");
    addAll.addEventListener("click", () => handlers.onAddAllContacts?.());
    pane.appendChild(addAll);
    pane.appendChild(doc.createElement("hr"));
    const expBtn = doc.createElement("button");
    expBtn.textContent = "Eksportuj ksiazke";
    expBtn.setAttribute("data-book-export", "");
    expBtn.setAttribute("title", "Pobiera plik JSON: imiona i grupy. Aliasy pocztowe nie wchodza do pliku - pobierasz je z gry.");
    expBtn.addEventListener("click", () => handlers.onExportAddressBook?.());
    pane.appendChild(expBtn);
    const impLabel = doc.createElement("label");
    impLabel.className = "arkmail-btn-action";
    impLabel.textContent = "Importuj ksiazke ";
    const modeRow = doc.createElement("div");
    modeRow.className = "arkmail-boxes arkmail-subpills";
    modeRow.setAttribute("data-book-import-mode", "");
    const MODES = [
      [
        "dolacz",
        "Dolacz do ksiazki",
        "Nowe grupy z pliku dolacza. Gdy grupa o tej samej nazwie juz jest, scala jej czlonkow. Imiona z pliku dolacza do ksiazki adresowej."
      ],
      [
        "zastap",
        "Zastap cala ksiazke",
        "Kasuje obecne imiona i grupy, a na ich miejsce wczytuje zawartosc pliku. Aliasy zostaja bez zmian."
      ]
    ];
    for (const [mode, label, title] of MODES) {
      const lab = doc.createElement("label");
      const radio = doc.createElement("input");
      radio.setAttribute("type", "radio");
      radio.setAttribute("name", "arkmail-import-mode");
      radio.setAttribute("title", title);
      radio.checked = bookImportMode === mode;
      radio.addEventListener("click", () => {
        bookImportMode = mode;
      });
      lab.appendChild(radio);
      lab.appendChild(doc.createTextNode(label));
      modeRow.appendChild(lab);
    }
    const impInput = doc.createElement("input");
    impInput.setAttribute("type", "file");
    impInput.setAttribute("data-book-import", "");
    impInput.setAttribute("accept", ".json,application/json");
    impInput.setAttribute(
      "title",
      "Wczytuje imiona i grupy z pliku JSON. Sposob zalezy od trybu: dolacz albo zastap. Aliasy pobierasz z gry."
    );
    impInput.addEventListener("change", () => {
      const file = impInput.files?.[0];
      if (!file) return;
      void file.text().then((content) => {
        const parsed = parseAddressBookExport(content);
        if (!parsed) {
          showError("Niepoprawny plik ksiazki adresowej.");
          return;
        }
        handlers.onImportAddressBook?.(parsed, bookImportMode);
      }).catch(() => showError("Nie udalo sie odczytac pliku."));
    });
    impLabel.appendChild(impInput);
    pane.appendChild(impLabel);
    pane.appendChild(modeRow);
    pane.appendChild(error);
    pane.appendChild(doc.createElement("hr"));
    const clearAll = doc.createElement("button");
    clearAll.className = "arkmail-btn-danger";
    clearAll.textContent = "Wyczysc cala ksiazke";
    clearAll.setAttribute("data-book-clear-all", "");
    clearAll.setAttribute(
      "title",
      "Kasuje lokalnie wszystkie imiona, grupy i aliasy. Na serwerze Arkadii nic nie znika - ksiazke zbudujesz od nowa."
    );
    guardDeleteButton(clearAll, () => handlers.onClearAddressBook?.(), {
      armedLabel: "Na pewno wyczyscic cala ksiazke?"
    });
    pane.appendChild(clearAll);
    fillButtonTitles(pane);
  };
  const renderArchPeople = (state) => {
    const panel = doc.createElement("div");
    panel.setAttribute("data-arch-people", "");
    const head = doc.createElement("div");
    head.className = "arkmail-arch-people-head";
    const toggle = doc.createElement("button");
    toggle.className = "arkmail-arch-people-toggle";
    toggle.setAttribute("data-arch-people-toggle", "");
    toggle.textContent = `${archPeopleOpen ? "v" : ">"} Osoby z listow (${state.contacts.length})`;
    toggle.setAttribute("title", "Zwija albo rozwija liste osob zebranych z listow.");
    toggle.addEventListener("click", () => {
      archPeopleOpen = !archPeopleOpen;
      store2.refresh();
    });
    head.appendChild(toggle);
    panel.appendChild(head);
    if (!archPeopleOpen) return panel;
    if (!allBoxesIndexed(state.indexMeta) || state.indexRun) {
      panel.appendChild(
        dim("Kontakty powstaja z listow zebranych ze wszystkich skrzynek.")
      );
    }
    const gaps = INDEX_BOXES.flatMap(
      (box) => (state.archiveGaps[box] ?? []).map((day) => `${box}: ${day}`)
    );
    if (gaps.length > 0) {
      const gapNote = doc.createElement("div");
      gapNote.className = "arkmail-dim arkmail-index-gaps";
      gapNote.textContent = `Brakuje danych z dni: ${gaps.join(", ")}`;
      panel.appendChild(gapNote);
    }
    const controls = doc.createElement("div");
    controls.className = "arkmail-contact-controls";
    const input = doc.createElement("input");
    input.className = "arkmail-contact-filter";
    input.setAttribute("data-filter", "kontakty");
    input.setAttribute("placeholder", "Filtr: nazwa lub alias");
    input.value = contactView.filter;
    const sel = doc.createElement("select");
    sel.className = "arkmail-contact-sort";
    const SORT_OPTS = [
      ["nazwa", "Nazwa A-Z"],
      ["liczba", "Liczba listow"],
      ["ostatni", "Ostatni kontakt"]
    ];
    for (const [value, label] of SORT_OPTS) {
      const o = doc.createElement("option");
      o.setAttribute("value", value);
      o.textContent = label;
      sel.appendChild(o);
    }
    sel.value = contactView.sort;
    controls.appendChild(input);
    controls.appendChild(sel);
    panel.appendChild(controls);
    attachGhost(doc, input, personSource);
    const list = doc.createElement("div");
    panel.appendChild(list);
    const repaint = () => {
      const rows = viewContacts(state.contacts, contactView);
      list.replaceChildren(
        ...rows.map((c) => {
          const row = doc.createElement("div");
          row.className = "arkmail-contact";
          const name = doc.createElement("span");
          name.className = "arkmail-contact-name";
          name.textContent = c.name;
          const jumpTo = (box) => {
            archFilter.osoba = c.name;
            archFilter.skrzynka = box;
            archFilter.temat = void 0;
            archFilter.tresc = void 0;
            archFilter.odDaty = void 0;
            archFilter.doDaty = void 0;
            archPeopleOpen = true;
            store2.setTab("archiwum");
          };
          name.setAttribute("title", "Pokaz listy tej osoby w archiwum (domyslnie: odebrane)");
          name.addEventListener("click", () => {
            if (c.lettersReceived > 0) jumpTo("odebrane");
            else if (c.lettersSent > 0) jumpTo("wyslane");
          });
          row.appendChild(name);
          const stats = doc.createElement("span");
          stats.className = "arkmail-contact-stats";
          stats.textContent = `(odebrane: ${c.lettersReceived}, wyslane: ${c.lettersSent})` + (c.mailAlias ? ` alias: ${c.mailAlias}` : "");
          row.appendChild(stats);
          if (c.lastContactRaw) {
            const last = doc.createElement("span");
            last.className = "arkmail-contact-last";
            last.textContent = c.lastContactRaw;
            row.appendChild(last);
          }
          const dirs = doc.createElement("span");
          dirs.className = "arkmail-contact-dirs";
          const DIR_OPTS = [
            ["odebrane", "Odebrane", c.lettersReceived],
            ["wyslane", "Wyslane", c.lettersSent]
          ];
          for (const [box, label, count] of DIR_OPTS) {
            const btn = doc.createElement("button");
            btn.className = "arkmail-contact-dir";
            btn.setAttribute("data-dir", box);
            btn.textContent = label;
            if (count === 0) {
              btn.setAttribute("disabled", "1");
              btn.setAttribute("title", "Brak listow.");
            } else {
              btn.addEventListener("click", () => jumpTo(box));
            }
            dirs.appendChild(btn);
          }
          row.appendChild(dirs);
          const addBook = doc.createElement("button");
          addBook.className = "arkmail-contact-addbook";
          addBook.setAttribute("data-arch-add-book", "");
          addBook.textContent = "Do ksiazki";
          if (state.people.some((p) => p.toLowerCase() === c.name.toLowerCase())) {
            addBook.setAttribute("disabled", "1");
            addBook.setAttribute("title", "Juz w ksiazce.");
          } else {
            addBook.setAttribute("title", `Dopisuje ${c.name} do ksiazki adresowej.`);
            addBook.addEventListener(
              "click",
              () => handlers.onSavePeople?.([...state.people, c.name])
            );
          }
          row.appendChild(addBook);
          return row;
        })
      );
      if (rows.length === 0) {
        list.replaceChildren(
          dim(
            state.contacts.length === 0 ? "Brak kontaktow - pojawia sie po pobraniu skrzynek." : "Zaden kontakt nie pasuje do filtra."
          )
        );
      }
      fillButtonTitles(list);
    };
    input.addEventListener("input", () => {
      contactView.filter = input.value;
      repaint();
    });
    sel.addEventListener("change", () => {
      contactView.sort = sel.value;
      repaint();
    });
    repaint();
    return panel;
  };
  const renderArchiwum = (state) => {
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane";
    pane.setAttribute("data-pane-key", "archiwum");
    const controls = doc.createElement("div");
    controls.className = "arkmail-arch-controls";
    const mkText = (key, placeholder, type = "text") => {
      const input = doc.createElement("input");
      input.setAttribute("data-filter", key);
      input.setAttribute("type", type);
      input.setAttribute("placeholder", placeholder);
      input.value = archFilter[key] ?? "";
      input.addEventListener("input", () => {
        archFilter[key] = input.value === "" ? void 0 : input.value;
        repaint();
      });
      return input;
    };
    const aOsoba = mkText("osoba", "Osoba (nadawca lub odbiorca)");
    controls.appendChild(aOsoba);
    attachGhost(doc, aOsoba, personSource);
    const skr = doc.createElement("select");
    skr.setAttribute("data-filter", "skrzynka");
    const SKR_OPTS = [
      ["", "Wszystkie skrzynki"],
      ["odebrane", "Odebrane"],
      ["nieprzeczytane", "Nieprzeczytane"],
      ["wyslane", "Wyslane"],
      ["niewyslane", "Niewyslane"]
    ];
    for (const [value, label] of SKR_OPTS) {
      const o = doc.createElement("option");
      o.setAttribute("value", value);
      o.textContent = label;
      skr.appendChild(o);
    }
    skr.value = archFilter.skrzynka ?? "";
    skr.addEventListener("change", () => {
      archFilter.skrzynka = skr.value === "" ? void 0 : skr.value;
      repaint();
    });
    controls.appendChild(skr);
    const aTemat = mkText("temat", "Temat");
    controls.appendChild(aTemat);
    attachGhost(doc, aTemat, subjectSource);
    controls.appendChild(mkText("tresc", "Tresc listu"));
    controls.appendChild(
      mkDateField(doc, mkText("odDaty", "Od dnia", "date"), "Od dnia (wlacznie)", "Archiwum pokaze listy od tego dnia WLACZNIE.")
    );
    controls.appendChild(
      mkDateField(doc, mkText("doDaty", "Do dnia", "date"), "Do dnia (wlacznie)", "Archiwum pokaze listy do tego dnia WLACZNIE.")
    );
    const clearFilters = doc.createElement("button");
    clearFilters.className = "arkmail-arch-clear arkmail-btn-danger";
    clearFilters.textContent = "Wyczysc filtry";
    clearFilters.addEventListener("click", () => {
      for (const key of ["osoba", "temat", "tresc", "odDaty", "doDaty"]) {
        archFilter[key] = void 0;
      }
      archFilter.skrzynka = void 0;
      contactView.filter = "";
      contactView.sort = "nazwa";
      controls.querySelectorAll("[data-filter]").forEach((el) => {
        el.value = "";
      });
      store2.refresh();
    });
    controls.appendChild(clearFilters);
    const steps = doc.createElement("div");
    steps.className = "arkmail-archive-steps";
    steps.setAttribute("aria-label", "Kolejne kroki pracy z archiwum");
    const makeStep = (title, status, tone) => {
      const step = doc.createElement("section");
      step.className = `arkmail-archive-step arkmail-step-${tone}`;
      const heading = doc.createElement("div");
      heading.className = "arkmail-archive-step-title";
      heading.textContent = title;
      const description = doc.createElement("div");
      description.className = "arkmail-archive-step-status";
      description.textContent = status;
      step.appendChild(heading);
      step.appendChild(description);
      steps.appendChild(step);
      return step;
    };
    const indexedCount = INDEX_BOXES.filter((box) => state.indexMeta[box] !== void 0).length;
    const gapCount = Object.values(state.archiveGaps).reduce((sum, days) => sum + days.length, 0);
    const indexDates = INDEX_BOXES.map((box) => state.indexMeta[box]).filter((d) => d !== void 0).sort();
    const earliestIndexDate = indexDates.length > 0 ? indexDates[0].slice(0, 10) : "";
    const gapPhrase = (days) => days === 1 ? "brakuje danych z 1 dnia" : `brakuje danych z ${days} dni`;
    const indexStatus = state.indexRun ? `W toku: ${state.indexRun.box}, stron: ${state.indexRun.pages}.` : allBoxesIndexed(state.indexMeta) ? gapCount > 0 ? `Gotowe, ale ${gapPhrase(gapCount)}.` : `Gotowe od ${earliestIndexDate}: wszystkie skrzynki zapisane.` : indexedCount > 0 || gapCount > 0 ? `Czesciowo: ${indexedCount} z ${INDEX_BOXES.length} skrzynek${gapCount > 0 ? ` (${gapPhrase(gapCount)})` : ""}.` : "Jeszcze nie zaczeto.";
    const archiveGroups = liveArchiveGroups(state.archive);
    let withBody = 0;
    let pendingBody = 0;
    let undatedBody = 0;
    for (const letter of state.archive) {
      if (letter.body.length > 0) {
        withBody += 1;
        continue;
      }
      const dateRaw = letter.dateRaw;
      if (dateRaw !== null && parseMailDate(dateRaw) !== null) pendingBody += 1;
      else undatedBody += 1;
    }
    const bodyWarnings = [
      undatedBody > 0 ? `${undatedBody} bez daty` : ""
    ].filter((text) => text !== "");
    const warningSuffix = bodyWarnings.length > 0 ? ` (${bodyWarnings.join(", ")})` : "";
    const downloadStatus = state.archiveDownload ? `Pobieram tresci: ${state.archiveDownload.done} z ${state.archiveDownload.total}.` : state.archive.length === 0 ? "Jeszcze nie pobrano." : pendingBody > 0 ? `Czesciowo: ${formatListCount(withBody)} z trescia. Do pobrania: ${pendingBody}${warningSuffix}.` : bodyWarnings.length > 0 ? `Gotowe: ${formatListCount(withBody)} z trescia${warningSuffix}.` : `Gotowe: ${formatListCount(withBody)} z trescia.`;
    const exportable = archiveExportEntries(state.archive);
    const exportStatus = exportable.entries.length === 0 ? "Brak listow z trescia - nie ma czego zapisywac." : exportable.skipped > 0 ? `Gotowe: ${formatListCount(exportable.entries.length)} do zapisu (${exportable.skipped} bez tresci).` : `Gotowe: ${formatListCount(exportable.entries.length)} do zapisu.`;
    const boxCounts = perBoxCounts(state.archive);
    let countsStrip = null;
    if (archiveGroups.length > 0) {
      const parts = [];
      for (const box of INDEX_BOXES) {
        const count = boxCounts.get(box);
        if (count !== void 0) parts.push(`${box}: ${formatListCount(count)}`);
      }
      countsStrip = doc.createElement("p");
      countsStrip.className = "arkmail-dim arkmail-arch-counts";
      countsStrip.textContent = `Listow w bazie: ${formatListCount(totalLive(state.archive))}${parts.length > 0 ? ` (${parts.join(", ")})` : ""}.`;
    }
    const indexStep = makeStep("1. Indeksacja", indexStatus, state.indexRun ? "active" : allBoxesIndexed(state.indexMeta) ? gapCount > 0 ? "warning" : "done" : indexedCount > 0 || gapCount > 0 ? "incomplete" : "idle");
    const downloadStep = makeStep("2. Pobranie tresci", downloadStatus, state.archiveDownload ? "active" : pendingBody > 0 ? "incomplete" : bodyWarnings.length > 0 ? "warning" : withBody > 0 ? "done" : "idle");
    const exportStep = makeStep("3. Zapis ZIP", exportStatus, exportable.entries.length > 0 ? exportable.skipped > 0 ? "warning" : "done" : "idle");
    const idxBtn = doc.createElement("button");
    idxBtn.className = "arkmail-index-all arkmail-btn-action";
    idxBtn.textContent = state.indexRun ? `Przerwij indeksowanie (${state.indexRun.boxIndex + 1}/${INDEX_BOXES.length})` : "Indeksuj wszystkie skrzynki";
    idxBtn.addEventListener("click", () => handlers.onIndexAll?.());
    indexStep.appendChild(idxBtn);
    const dlBtn = doc.createElement("button");
    dlBtn.className = "arkmail-arch-download arkmail-btn-action";
    dlBtn.textContent = state.archiveDownload ? `Przerwij (${state.archiveDownload.done}/${state.archiveDownload.total})` : "Pobierz tresci do archiwum";
    let dlArmed = false;
    let dlTimer = null;
    dlBtn.addEventListener("click", () => {
      if (state.archiveDownload) {
        handlers.onDownloadArchiveBodies?.();
        return;
      }
      if (!dlArmed) {
        dlArmed = true;
        setButtonLabel(dlBtn, "Pobieranie potrwa dlugo - kliknij ponownie");
        dlTimer = setTimeout(() => {
          dlArmed = false;
          setButtonLabel(dlBtn, "Pobierz tresci do archiwum");
        }, 3e3);
        return;
      }
      if (dlTimer) clearTimeout(dlTimer);
      dlArmed = false;
      setButtonLabel(dlBtn, "Pobierz tresci do archiwum");
      handlers.onDownloadArchiveBodies?.();
    });
    downloadStep.appendChild(dlBtn);
    const expBtn = doc.createElement("button");
    expBtn.className = "arkmail-arch-export arkmail-btn-primary";
    expBtn.textContent = "Zapisz wszystkie (ZIP)";
    expBtn.addEventListener("click", () => handlers.onExportArchive?.());
    exportStep.appendChild(expBtn);
    pane.appendChild(steps);
    pane.appendChild(controls);
    if (countsStrip) pane.appendChild(countsStrip);
    pane.appendChild(renderArchPeople(state));
    const list = doc.createElement("div");
    pane.appendChild(list);
    const repaint = () => {
      const datesInvalid = archFilter.odDaty !== void 0 && fromISODate(archFilter.odDaty) === null || archFilter.doDaty !== void 0 && fromISODate(archFilter.doDaty) === null;
      const datesClash = !datesInvalid && archFilter.odDaty !== void 0 && archFilter.doDaty !== void 0 && archFilter.odDaty > archFilter.doDaty;
      const effFilter = datesInvalid || datesClash ? { ...archFilter, odDaty: void 0, doDaty: void 0 } : archFilter;
      const oldErr = pane.querySelector(".arkmail-dates-error");
      if (oldErr) oldErr.remove();
      if (datesInvalid || datesClash) {
        const err = doc.createElement("div");
        err.className = "arkmail-dates-error";
        err.textContent = datesInvalid ? "Nieprawidlowa data - filtry dat pomijane." : "Od dnia pozniej niz Do dnia - daty pomijane.";
        pane.insertBefore(err, list);
      }
      const rows = filterVisibleArchive(state.archive, effFilter);
      const oldNote = pane.querySelector(".arkmail-tresc-note");
      if (oldNote) oldNote.remove();
      if (archFilter.tresc !== void 0) {
        const base = filterVisibleArchive(state.archive, { ...effFilter, tresc: void 0 });
        const withBody2 = base.filter((l) => l.body.length > 0).length;
        const note = doc.createElement("div");
        note.className = "arkmail-dim arkmail-tresc-note";
        note.textContent = `Filtr tresci obejmuje tylko listy z pobrana trescia (${withBody2} z ${base.length}).`;
        pane.insertBefore(note, list);
      }
      list.replaceChildren(
        ...rows.flatMap((l, idx) => {
          const row = doc.createElement("div");
          row.className = "arkmail-arch-entry";
          const subj = doc.createElement("span");
          subj.textContent = `${idx + 1}. ${l.subject}`;
          row.appendChild(subj);
          const meta = doc.createElement("span");
          meta.className = "arkmail-arch-meta";
          const dir = l.box === "odebrane" || l.box === "nieprzeczytane" ? "od" : "do";
          meta.textContent = `${dir} ${l.party} | ${l.box}`;
          row.appendChild(meta);
          row.addEventListener("click", () => handlers.onOpenArchiveLetter?.(l));
          return [row];
        })
      );
      if (rows.length === 0) {
        list.replaceChildren(dim("Archiwum puste albo zaden list nie pasuje do filtra."));
      }
    };
    repaint();
    return pane;
  };
  const dim = (text) => {
    const el = doc.createElement("div");
    el.className = "arkmail-dim";
    el.textContent = text;
    return el;
  };
  const mkDateField = (docRef, input, label, tooltip) => {
    const field = docRef.createElement("label");
    field.className = "arkmail-date-field";
    const caption = docRef.createElement("span");
    caption.className = "arkmail-date-label";
    caption.textContent = label;
    input.setAttribute("title", tooltip);
    field.appendChild(caption);
    field.appendChild(input);
    return field;
  };
  const off = store2.subscribe(render);
  render(store2.state);
  const onEscape = (event) => {
    if (event.key !== "Escape") return;
    disarmAllButtons();
    if (store2.state.deletion.armedAt !== 0) store2.disarmDeletionConfirm();
  };
  const canListen = typeof doc.addEventListener === "function";
  if (canListen) doc.addEventListener("keydown", onEscape);
  return () => {
    off();
    if (canListen) doc.removeEventListener("keydown", onEscape);
    container.replaceChildren();
  };
}

// src/arkmail/core/bulkDelete.ts
var entryKey2 = (entry) => [
  entry.party,
  entry.subject,
  entry.forwarded ? "f" : "",
  entry.date?.raw ?? ""
].join("|");
var compressRange = (numbers) => {
  const parts = [];
  for (let i = 0; i < numbers.length; ) {
    const from = numbers[i];
    let to = from;
    while (i + 1 < numbers.length && numbers[i + 1] === to + 1) to = numbers[++i];
    parts.push(from === to ? String(from) : `${from}-${to}`);
    i++;
  }
  return parts.join(",");
};
function matchSelectionOnFreshListing(selected, fresh) {
  if (selected.length === 0) return null;
  const available = /* @__PURE__ */ new Map();
  for (const entry of fresh) {
    const key = entryKey2(entry);
    const entries = available.get(key);
    if (entries) entries.push(entry);
    else available.set(key, [entry]);
  }
  const matched = [];
  for (const entry of selected) {
    const candidate = available.get(entryKey2(entry))?.shift();
    if (!candidate) return null;
    matched.push(candidate);
  }
  matched.sort((a, b) => a.number - b.number);
  const numbers = matched.map((entry) => entry.number);
  return { entries: matched, numbers, range: compressRange(numbers) };
}
function applyConfirmedDeletions(archive, box, fresh, confirmedNumbers) {
  const changedIds = /* @__PURE__ */ new Set();
  const changedBoxes = /* @__PURE__ */ new Set();
  if (confirmedNumbers.length === 0) return { letters: archive, changedIds, changedBoxes };
  const confirmed = new Set(confirmedNumbers);
  const remaining = /* @__PURE__ */ new Map();
  for (const entry of fresh) {
    const key = entryKey2(entry);
    remaining.set(key, (remaining.get(key) ?? 0) + 1);
  }
  const removedContentKeys = /* @__PURE__ */ new Set();
  for (const entry of fresh) {
    if (!confirmed.has(entry.number)) continue;
    const key = entryKey2(entry);
    const count = (remaining.get(key) ?? 1) - 1;
    remaining.set(key, count);
    if (count === 0) removedContentKeys.add(contentKeyOf(fromMailboxEntry(box, entry)));
  }
  if (removedContentKeys.size === 0) return { letters: archive, changedIds, changedBoxes };
  const incomingTwin = box === "odebrane" || box === "nieprzeczytane";
  const letters = archive.filter((letter) => {
    const samePhysicalLetter = letter.box === box || incomingTwin && (letter.box === "odebrane" || letter.box === "nieprzeczytane");
    if (!samePhysicalLetter || !removedContentKeys.has(contentKeyOf(letter))) {
      return true;
    }
    changedIds.add(letter.id);
    changedBoxes.add(letter.box);
    return false;
  });
  if (changedIds.size === 0) return { letters: archive, changedIds, changedBoxes };
  return { letters, changedIds, changedBoxes };
}

// src/arkmail/index.ts
var POPUP_ID = "arkmail";
var FOOTER_BUTTON_ID = "arkmail";
var FOOTER_STATE = "arkmail-poczta";
var ALIAS_REGEX = /^\/arkmail$/i;
var SESSION_OPTS = { timeoutMs: 8e3, idleMs: 400 };
var WIDE_MIN_WIDTH = 900;
var LOAD_ALL_PACE_MS = PAGE_PACE_MS;
var INDEX_PACE_MS = PAGE_PACE_MS;
var INDEX_ANCHOR_RETRY_WAITS_MS = ANCHOR_RETRY_WAITS_MS;
var PLAYER_MAIL_MODE_IDLE_MS = 18e4;
var INDEX_FULL_SWEEP_AGE_MS = 7 * 24 * 60 * 60 * 1e3;
var indexSweepMode = (meta, box, now) => {
  const stamp = meta[box];
  if (stamp === void 0) return "full";
  const t = Date.parse(stamp);
  if (Number.isNaN(t)) return "full";
  return now - t > INDEX_FULL_SWEEP_AGE_MS ? "full" : "incremental";
};
var SESSION_BUSY_MSG = "Poczekaj, az skoncze biezaca operacje.";
var MAIL_ENTRY_CMD_RE = /^\s*(?:list\b|listy\b|przec\w*|poczt\w*)/i;
var ANIMAL_TIMING = { flightTimeoutMs: 6e4, sluchamWindowMs: 2e3 };
var listingCtxSeq = 0;
var listingCtx = null;
var NOTIFY_KEY = "powiadomienia";
var COMPOSE_KEY = "compose";
var INDEX_KEY = "indeks";
var ARCHIVE_GAPS_KEY = "luki-archiwum";
var knownRecipientNames = (state) => {
  const known = /* @__PURE__ */ new Set();
  const add = (name) => {
    const key = name.trim().toLowerCase();
    if (key) known.add(key);
  };
  for (const c of state.contacts) {
    add(c.name);
    if (c.mailAlias) add(c.mailAlias);
  }
  for (const name of state.people) add(name);
  for (const alias of state.importedAliases) add(alias.name);
  for (const group of state.groups) for (const member of group.members) add(member);
  return known;
};
var apiRef = null;
var storageRef = null;
var popup = null;
var menuHandle = null;
var footerHandle = null;
var aliasId = null;
var transport = null;
var store = null;
var unmount = null;
var unsubBadge = null;
var wideObserver = null;
var animalTimer = null;
var sluchamTimer = null;
var unsentFlashTimer = null;
var delayedInboxTimers = [];
var DELAYED_INBOX_RETRY_MS = [1e4, 25e3];
var playerMailModeTimer = null;
var deactivateActiveCharacter = null;
var unsubscribeCharacter = null;
var lifecycleDestroyed = false;
function createContent() {
  const root = document.createElement("div");
  root.style.height = "100%";
  root.style.minHeight = "0";
  if (unmount) {
    unmount();
    unmount = null;
  }
  if (wideObserver) {
    wideObserver.disconnect();
    wideObserver = null;
  }
  if (store && handlersRef) {
    unmount = mountMailUi(root, store, handlersRef);
    if (typeof ResizeObserver !== "undefined") {
      const s = store;
      wideObserver = new ResizeObserver((entries) => {
        const w = entries[0]?.contentRect.width ?? 0;
        s.setWide(w >= WIDE_MIN_WIDTH);
      });
      wideObserver.observe(root);
    }
  }
  return root;
}
var handlersRef = null;
async function init(api) {
  apiRef = api;
  lifecycleDestroyed = false;
  cleanupLegacyStorage();
  popup = await api.ui.registerPersistentPopup({
    id: POPUP_ID,
    title: PLUGIN_NAME,
    // Start: szeroki dwupanelowy na normalnym ekranie, waski na komorce
    // (85vw). Rozmiar ustawiony przez gracza zawsze wygrywa z tymi
    // wartosciami - po zmianie domyslnego pomocny jest reset rozmiaru.
    initialWidth: "min(1400px, 85vw)",
    initialHeight: "min(850px, 80vh)",
    createContent
  });
  popup.onClose(() => store?.resetDeletion());
  const toggle = () => {
    if (!popup) return true;
    if (popup.isOpen) popup.close();
    else void popup.open();
    return true;
  };
  aliasId = api.aliases.register(ALIAS_REGEX, toggle);
  menuHandle = api.ui.addPopupMenuEntry(PLUGIN_NAME, () => {
    if (popup && !popup.isOpen) void popup.open();
  });
  footerHandle = api.ui.registerFooterButton(FOOTER_BUTTON_ID, {
    label: PLUGIN_NAME,
    command: "/arkmail",
    state: FOOTER_STATE
  });
  let requestedName = api.character.getName();
  let activeName = null;
  let switchQueue = Promise.resolve();
  const refreshPopup = () => {
    if (popup?.isOpen) popup.setBody(createContent());
  };
  const deactivateCurrent = async () => {
    const deactivate = deactivateActiveCharacter;
    deactivateActiveCharacter = null;
    if (deactivate) await deactivate();
    activeName = null;
    refreshPopup();
  };
  const activateCharacter = async (character) => {
    const storage = await openCharStorage(character, () => notify(api, STORAGE_WRITE_ERROR, { level: "error" }));
    if (lifecycleDestroyed || character.trim().toLowerCase() !== requestedName?.trim().toLowerCase()) {
      await storage.close();
      return false;
    }
    storageRef = storage;
    transport = new DargothTransport(api);
    const lock = new SessionLock();
    const tasks = /* @__PURE__ */ new Set();
    const trackTask = (task) => {
      const tracked = task.finally(() => tasks.delete(tracked));
      tasks.add(tracked);
      return tracked;
    };
    const runExclusive = (operation) => trackTask(lock.runExclusive(operation));
    let connectionGeneration = 0;
    const cancelListeners = /* @__PURE__ */ new Set();
    const sessionOpts = {
      ...SESSION_OPTS,
      onCancel: (cb) => {
        cancelListeners.add(cb);
        return () => cancelListeners.delete(cb);
      }
    };
    let composeVisible = false;
    transport.setGagPredicate(() => lock.locked && !composeVisible);
    const archive = normalizeArchive(storage.getLetters()).filter(
      (l) => l.missingOnServer !== true
    );
    storage.setLetters(archive);
    const composePrefs = storage.getJSON(COMPOSE_KEY);
    store = new MailUiStore({
      notifyEnabled: storage.getJSON(NOTIFY_KEY) ?? true,
      archive,
      composeTemplate: composePrefs?.template ?? "plain",
      composeWidth: composePrefs?.width ?? 60,
      // Fala 18c: flagi kompletnej indeksacji skrzynek (brama Kontaktow).
      indexMeta: storage.getJSON(INDEX_KEY) ?? {},
      archiveGaps: storage.getJSON(ARCHIVE_GAPS_KEY) ?? {},
      // Fala UI-2: ksiazka adresowa (osobne klucze; wipe jej nie tyka).
      // Imiona: migracja ze starego klucza pul jest jednorazowa i
      // zostawia stary klucz nietkniety (bezpieczny rollback).
      people: migratePeople(storage),
      importedAliases: loadImportedAliases(storage),
      groups: loadGroups(storage)
    });
    const ui = store;
    const mailbox = new MailboxSession(transport, sessionOpts);
    const pager = new PagerSession(transport, sessionOpts);
    const editor = new EditorSession(transport, sessionOpts);
    const importer = new ImportSession(transport, sessionOpts);
    const rebuildContacts = () => {
      ui.setContacts(
        contactsFromArchiveWithAliases(ui.state.archive, ui.state.importedAliases)
      );
    };
    const importPeople = (kind) => {
      if (lock.locked) {
        notify(api, SESSION_BUSY_MSG, { level: "warning" });
        return;
      }
      const label = kind === "zapamietani" ? "zapamietanych" : "przedstawionych";
      const generation = connectionGeneration;
      ui.setBusy(`Importuje ${label}...`);
      void runExclusive(async () => {
        const names = await importer.fetchPeople(kind);
        if (generation !== connectionGeneration) return;
        const before = ui.state.people.length;
        const people = unionPeople(ui.state.people, names);
        savePeople(storage, people);
        ui.setPeople(people);
        notify(api, `Osob pobranych z gry: ${names.length}. Nowych w ksiazce: ${people.length - before}.`, { level: "success" });
      }).catch((err) => {
        if (!isOperationCancelled(err)) {
          notify(api, "Nie udalo sie zaimportowac osob z gry.", { level: "error" });
        }
      }).finally(() => {
        if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
      });
    };
    const importAliases = () => {
      if (lock.locked) {
        notify(api, SESSION_BUSY_MSG, { level: "warning" });
        return;
      }
      const generation = connectionGeneration;
      ui.setBusy("Importuje aliasy pocztowe...");
      void runExclusive(async () => {
        const aliases = await importer.fetchAliases();
        if (generation !== connectionGeneration) return;
        saveImportedAliases(storage, aliases);
        ui.setImportedAliases(aliases);
        const before = ui.state.people.length;
        const people = unionPeople(
          ui.state.people,
          aliases.flatMap((a) => a.targets)
        );
        savePeople(storage, people);
        ui.setPeople(people);
        rebuildContacts();
        notify(api, `Aliasow pocztowych: ${aliases.length}. Osob dolaczonych do ksiazki: ${people.length - before}.`, { level: "success" });
      }).catch((err) => {
        if (!isOperationCancelled(err)) {
          notify(api, "Nie udalo sie zaimportowac aliasow z gry.", { level: "error" });
        }
      }).finally(() => {
        if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
      });
    };
    const flashUnsent = () => {
      ui.setUnsentFlash(true);
      if (unsentFlashTimer !== null) clearTimeout(unsentFlashTimer);
      unsentFlashTimer = setTimeout(() => {
        unsentFlashTimer = null;
        ui.setUnsentFlash(false);
      }, 3e3);
    };
    const fetchBoxes = async (boxes, mode) => {
      for (const box of boxes) {
        ui.setBusy(`Pobieram skrzynke ${box}...`);
        const res = await mailbox.fetch(box);
        const boundaryDay = (() => {
          if (res.kind !== "lista") return void 0;
          const oldest = oldestEntry(res.entries);
          if (!oldest?.date) return void 0;
          const p = (n) => String(n).padStart(2, "0");
          return `${oldest.date.year}-${p(oldest.date.month)}-${p(oldest.date.day)}`;
        })();
        let resolvedIds;
        if (res.kind === "lista") {
          const listingRecords = recordsOfListing(box, res.entries);
          if (!res.header.truncated) {
            const replaced = replaceBoxLetters(ui.state.archive, box, listingRecords);
            ui.setArchive(replaced.letters);
            resolvedIds = replaced.resolvedIds;
            if (replaced.removedIds.size > 0) pruneGoneFromView(box, replaced.removedIds);
            clearArchiveGaps(box);
            ui.setIndexMeta({ ...ui.state.indexMeta, [box]: (/* @__PURE__ */ new Date()).toISOString() });
            persistIndexMeta();
          } else {
            const merged = mergeListingPage(ui.state.archive, box, listingRecords);
            ui.setArchive(merged.letters);
            resolvedIds = merged.resolvedIds;
            if (boundaryDay !== void 0) {
              markGoneFromServerNewerThan(box, merged.freshIds, boundaryDay);
            }
          }
        } else if (res.kind === "pusta" && res.reason === "puste") {
          const replaced = replaceBoxLetters(ui.state.archive, box, []);
          ui.setArchive(replaced.letters);
          if (replaced.removedIds.size > 0) pruneGoneFromView(box, replaced.removedIds);
          clearArchiveGaps(box);
          ui.setIndexMeta({ ...ui.state.indexMeta, [box]: (/* @__PURE__ */ new Date()).toISOString() });
          persistIndexMeta();
        }
        if (res.kind === "lista") stampEntries(box, res.entries, resolvedIds);
        else bumpCtx(box);
        if (res.kind === "lista" && mode === "sync") {
          const synced = ui.syncMailboxPage(box, res.entries, res.header.truncated, boundaryDay);
          if (!synced) ui.applyMailbox(box, res);
        } else {
          ui.applyMailbox(box, res);
        }
      }
    };
    const pruneGoneFromView = (box, removedIds) => {
      ui.pruneMailboxEntries(box, removedIds);
    };
    const markGoneFromServerNewerThan = (box, freshIds, boundaryDay) => {
      const purged = purgeGoneLettersNewerThan(ui.state.archive, box, freshIds, boundaryDay);
      if (purged.removedIds.size === 0) return;
      ui.setArchive(purged.letters);
      persistArchive();
      pruneGoneFromView(box, purged.removedIds);
    };
    const refreshBoxes = (boxes, mode = "sync") => {
      if (ui.state.tab === "usuwanie") ui.resetDeletion();
      ui.clearSearchBoxes(boxes);
      const generation = connectionGeneration;
      void runExclusive(() => fetchBoxes(boxes, mode)).catch(() => {
      }).finally(() => {
        if (generation !== connectionGeneration) return;
        ui.setBusy(null);
        rebuildContacts();
        persistArchive();
      });
    };
    const cancelConnectionOperations = () => {
      connectionGeneration++;
      listingCtx = null;
      transport.setOnline(false);
      lock.cancelWaiting();
      for (const cancel of [...cancelListeners]) cancel();
      if (loadAllFlag) loadAllFlag.cancelled = true;
      if (indexFlag) indexFlag.cancelled = true;
      if (archiveDownloadFlag) archiveDownloadFlag.cancelled = true;
      loadAllFlag = null;
      indexFlag = null;
      archiveDownloadFlag = null;
      pendingRefresh.clear();
      drainScheduled = false;
      ui.setBusy(null);
      ui.setLoadAll(null);
      ui.setIndexRun(null);
      ui.setArchiveDownload(null);
      ui.resetDeletion();
    };
    let lastUpstreamClosed = false;
    const onClientConnect = () => {
      lastUpstreamClosed = false;
      cancelConnectionOperations();
    };
    const armGameTransport = () => {
      transport.setOnline(true);
    };
    const onGamePresence = () => {
      if (lastUpstreamClosed) return;
      armGameTransport();
    };
    const onAnyGmcp = () => {
      if (lastUpstreamClosed) return;
      armGameTransport();
    };
    const onProxySession = (session) => {
      const s = session;
      if (s?.resumed === true && !s?.upstreamClosed) {
        lastUpstreamClosed = false;
        armGameTransport();
        refreshBoxes(["odebrane", "nieprzeczytane", "wyslane", "niewyslane"]);
      } else if (s?.upstreamClosed === true) {
        lastUpstreamClosed = true;
        onClientDisconnect();
      } else {
        lastUpstreamClosed = false;
      }
    };
    const onClientDisconnect = () => {
      cancelConnectionOperations();
      playerMailMode = false;
      clearPlayerMailModeTimer();
    };
    const onSystemLogin = () => {
      onClientDisconnect();
    };
    api.events.on("client.connect", onClientConnect);
    api.events.on("client.disconnect", onClientDisconnect);
    api.events.on("gmcp", onAnyGmcp);
    api.events.on("gmcp.char.info", onGamePresence);
    api.events.on("gmcp.char.name", onGamePresence);
    api.events.on("gmcp.mail.state", onGamePresence);
    api.events.on("gmcp_msg.room.long", onGamePresence);
    api.events.on("proxy.session", onProxySession);
    api.events.on("gmcp_msg.system.login", onSystemLogin);
    const pendingRefresh = /* @__PURE__ */ new Set();
    let drainScheduled = false;
    let playerMailMode = false;
    const scheduleRefresh = (boxes) => {
      for (const b of boxes) pendingRefresh.add(b);
      if (playerMailMode) return;
      if (drainScheduled) return;
      drainScheduled = true;
      const generation = connectionGeneration;
      void runExclusive(async () => {
        const batch = [...pendingRefresh];
        pendingRefresh.clear();
        ui.clearSearchBoxes(batch);
        await fetchBoxes(batch, "sync");
      }).catch(() => {
      }).finally(() => {
        if (generation !== connectionGeneration) return;
        ui.setBusy(null);
        rebuildContacts();
        persistArchive();
        drainScheduled = false;
        if (pendingRefresh.size > 0) scheduleRefresh([]);
      });
    };
    const clearPlayerMailModeTimer = () => {
      if (playerMailModeTimer !== null) {
        clearTimeout(playerMailModeTimer);
        playerMailModeTimer = null;
      }
    };
    const exitPlayerMailMode = () => {
      if (!playerMailMode) return;
      playerMailMode = false;
      clearPlayerMailModeTimer();
      scheduleRefresh(["odebrane", "nieprzeczytane"]);
    };
    const armPlayerMailModeIdle = () => {
      clearPlayerMailModeTimer();
      playerMailModeTimer = setTimeout(() => {
        playerMailModeTimer = null;
        exitPlayerMailMode();
      }, PLAYER_MAIL_MODE_IDLE_MS);
    };
    const enterPlayerMailMode = () => {
      playerMailMode = true;
      armPlayerMailModeIdle();
    };
    const scheduleDelayedInboxRefresh = () => {
      for (const t of delayedInboxTimers) clearTimeout(t);
      delayedInboxTimers = DELAYED_INBOX_RETRY_MS.map(
        (ms) => setTimeout(() => scheduleRefresh(["odebrane", "nieprzeczytane"]), ms)
      );
    };
    let lastMailState = null;
    const onMailState = (d) => {
      if (!d || typeof d !== "object") return;
      const s = d;
      if (typeof s.unread !== "boolean" || typeof s.unreceived !== "boolean" || typeof s.unsent !== "boolean") {
        return;
      }
      const cur = { unread: s.unread, unreceived: s.unreceived, unsent: s.unsent };
      const prev = lastMailState;
      if (prev && cur.unread === prev.unread && cur.unreceived === prev.unreceived && cur.unsent === prev.unsent) {
        return;
      }
      lastMailState = cur;
      const boxes = /* @__PURE__ */ new Set();
      const inboxTouched = prev ? cur.unread !== prev.unread || cur.unreceived !== prev.unreceived : cur.unread || cur.unreceived;
      if (inboxTouched) {
        boxes.add("odebrane");
        boxes.add("nieprzeczytane");
      }
      if (prev ? cur.unsent !== prev.unsent : cur.unsent) {
        boxes.add("niewyslane");
        boxes.add("wyslane");
      }
      if (boxes.size > 0) scheduleRefresh([...boxes]);
    };
    api.events.on("gmcp.mail.state", onMailState);
    const persistArchive = () => {
      storage.setLetters(ui.state.archive);
    };
    const persistIndexMeta = () => {
      storage.setJSON(INDEX_KEY, ui.state.indexMeta);
    };
    const persistArchiveGaps = () => {
      storage.setJSON(ARCHIVE_GAPS_KEY, ui.state.archiveGaps);
    };
    const recordArchiveGap = (box, day) => {
      const days = [.../* @__PURE__ */ new Set([...ui.state.archiveGaps[box] ?? [], day])].sort();
      ui.setArchiveGaps({ ...ui.state.archiveGaps, [box]: days });
      persistArchiveGaps();
      if (ui.state.indexMeta[box] !== void 0) {
        const meta = { ...ui.state.indexMeta };
        delete meta[box];
        ui.setIndexMeta(meta);
        persistIndexMeta();
      }
    };
    const clearArchiveGaps = (box) => {
      if (ui.state.archiveGaps[box] === void 0) return;
      const gaps = { ...ui.state.archiveGaps };
      delete gaps[box];
      ui.setArchiveGaps(gaps);
      persistArchiveGaps();
    };
    const bumpCtx = (box) => {
      listingCtxSeq += 1;
      listingCtx = { box, stamp: listingCtxSeq };
    };
    const stampEntries = (box, entries, ids) => {
      bumpCtx(box);
      for (let i = 0; i < entries.length; i++) {
        entries[i].ctx = { box, stamp: listingCtxSeq };
        const id = ids?.[i];
        if (id !== void 0) entries[i].archiveId = id;
      }
    };
    const recordsOfListing = (box, entries) => {
      const scanKey = scanKeyOfEntries(entries);
      return entries.map((e, i) => fromMailboxEntry(box, e, scanKey, i));
    };
    const snapshotRecords = (box) => {
      const byId = new Map(ui.state.archive.map((l) => [l.id, l]));
      const out = [];
      for (const e of ui.state.boxes[box]?.entries ?? []) {
        const rec = e.archiveId !== void 0 ? byId.get(e.archiveId) : void 0;
        if (rec) out.push(rec);
      }
      return out;
    };
    const resolveEntry = async (box, entry) => {
      if (entry.ctx !== void 0 && listingCtx !== null && entry.ctx.stamp === listingCtx.stamp && entry.ctx.box === listingCtx.box) {
        return entry;
      }
      if (!entry.date) {
        notify(api, "Nie moge znalezc tego listu - odswiez skrzynke.", { level: "warning" });
        return null;
      }
      const generation = connectionGeneration;
      const flag = { cancelled: false };
      const offCancel = sessionOpts.onCancel(() => {
        flag.cancelled = true;
      });
      let fresh = null;
      try {
        const scan = await scanMailboxPages({
          box,
          initialCommand: olderListingCommand(box, nextDay(entry.date)),
          cancelled: () => flag.cancelled || generation !== connectionGeneration,
          fetchPage: (command) => mailbox.fetch(box, command),
          wait: (ms) => sleepOrCancel(ms, flag),
          onBaseRefresh: () => bumpCtx(box),
          onEmpty: () => bumpCtx(box),
          onGap: (day) => recordArchiveGap(box, day),
          onPage: (res) => {
            const records = recordsOfListing(box, res.entries);
            const merged = mergeListingPage(ui.state.archive, box, records);
            ui.setArchive(merged.letters);
            persistArchive();
            stampEntries(box, res.entries, merged.resolvedIds);
            if (entry.archiveId !== void 0) {
              fresh = res.entries.find((item) => item.archiveId === entry.archiveId) ?? null;
            } else {
              fresh = res.entries.find(
                (item) => entryKey(item) === entryKey(entry) && item.number === entry.number
              ) ?? null;
            }
            return { stop: fresh !== null };
          }
        });
        if (fresh) return fresh;
        if (scan.end === "cancelled") throw new Error("operacja anulowana");
        if (scan.end === "incomplete") {
          throw new Error("Nie mozna sprawdzic calej listy - sprobuj ponownie.");
        }
      } finally {
        offCancel();
      }
      notify(api, "Nie ma tego listu na liscie - odswiez skrzynke.", { level: "warning" });
      return null;
    };
    const loadOlder = (box) => {
      const generation = connectionGeneration;
      const flag = { cancelled: false };
      ui.setBusy("Wczytuje starsze listy...");
      void runExclusive(async () => {
        const view = ui.state.boxes[box];
        const oldest = oldestEntry(view?.entries ?? []);
        if (!oldest?.date) {
          notify(api, "Nie mozna wczytac starszych - najpierw pobierz skrzynke.", { level: "warning" });
          return;
        }
        const scan = await scanMailboxPages({
          box,
          initialCommand: olderListingCommand(box, nextDay(oldest.date)),
          singlePage: true,
          cancelled: () => flag.cancelled || generation !== connectionGeneration,
          fetchPage: (command) => mailbox.fetch(box, command),
          wait: (ms) => sleepOrCancel(ms, flag),
          onBaseRefresh: () => bumpCtx(box),
          onGap: (day) => recordArchiveGap(box, day),
          onEmpty: () => bumpCtx(box),
          onPage: (res) => {
            const records = recordsOfListing(box, res.entries);
            const merged = mergeListingPage(ui.state.archive, box, records);
            ui.setArchive(merged.letters);
            persistArchive();
            stampEntries(box, res.entries, merged.resolvedIds);
            const addedToView = ui.appendMailboxPage(box, res.entries, res.header.truncated);
            return { addedToView, archiveAdded: merged.added };
          }
        });
        if (scan.end === "cancelled") return;
        if (scan.end === "complete" && scan.pages === 0) {
          ui.appendMailboxPage(box, [], false);
          clearArchiveGaps(box);
          ui.setIndexMeta({ ...ui.state.indexMeta, [box]: (/* @__PURE__ */ new Date()).toISOString() });
          persistIndexMeta();
          notify(api, "Brak starszych listow.");
        } else if (scan.end === "incomplete") {
          notify(
            api,
            `W widoku: ${ui.state.boxes[box]?.entries.length ?? 0} (dodano: ${scan.addedToView}). ${scan.skipWhy ?? "Sprobuj ponownie za chwile"}.`,
            { title: "Wczytano dostepne listy", level: "warning" }
          );
        } else {
          notify(
            api,
            `W widoku: ${ui.state.boxes[box]?.entries.length ?? 0} (dodano: ${scan.addedToView}).`,
            { title: "Wczytano starsze listy", level: "success" }
          );
        }
      }).catch((err) => {
        if (!isOperationCancelled(err)) {
          notify(
            api,
            humanizeMailError(err instanceof Error ? err.message : String(err)),
            { title: "Blad wczytywania starszych", level: "error" }
          );
        }
      }).finally(() => {
        if (generation !== connectionGeneration) return;
        ui.setBusy(null);
        rebuildContacts();
      });
    };
    let loadAllFlag = null;
    const sleepOrCancel = async (ms, flag) => {
      const step = 50;
      for (let t = 0; t < ms && !flag.cancelled; t += step) {
        await new Promise((r) => setTimeout(r, Math.min(step, ms - t)));
      }
    };
    const loadAll = (box) => {
      if (loadAllFlag) {
        loadAllFlag.cancelled = true;
        return;
      }
      if (lock.locked) {
        notify(api, SESSION_BUSY_MSG, { level: "warning" });
        return;
      }
      const flag = { cancelled: false };
      loadAllFlag = flag;
      ui.setLoadAll({ box, pages: 0 });
      const generation = connectionGeneration;
      void runExclusive(async () => {
        try {
          const view = ui.state.boxes[box];
          const oldest = oldestEntry(view?.entries ?? []);
          if (!view?.truncated || !oldest?.date) return;
          const scan = await scanMailboxPages({
            box,
            initialCommand: olderListingCommand(box, nextDay(oldest.date)),
            cancelled: () => flag.cancelled || generation !== connectionGeneration,
            fetchPage: (command) => mailbox.fetch(box, command),
            wait: (ms) => sleepOrCancel(ms, flag),
            onBaseRefresh: () => bumpCtx(box),
            onGap: (day) => recordArchiveGap(box, day),
            onEmpty: () => bumpCtx(box),
            onPage: (res, pages) => {
              const records = recordsOfListing(box, res.entries);
              const merged = mergeListingPage(ui.state.archive, box, records);
              ui.setArchive(merged.letters);
              persistArchive();
              stampEntries(box, res.entries, merged.resolvedIds);
              const addedToView = ui.appendMailboxPage(box, res.entries, res.header.truncated);
              ui.setLoadAll({ box, pages });
              ui.setBusy(`Wczytuje wszystkie (${box}): strona ${pages}...`);
              return { addedToView, archiveAdded: merged.added };
            }
          });
          if (scan.end === "cancelled") {
            notify(
              api,
              `Dodano do widoku: ${scan.addedToView}.`,
              { title: "Przerwano wczytywanie", level: "warning" }
            );
            return;
          }
          if (scan.end === "complete") {
            ui.appendMailboxPage(box, [], false);
            clearArchiveGaps(box);
            const done = ui.state.boxes[box];
            if (done && !done.truncated) {
              const replaced = replaceBoxLetters(ui.state.archive, box, snapshotRecords(box));
              ui.setArchive(replaced.letters);
              if (replaced.removedIds.size > 0) pruneGoneFromView(box, replaced.removedIds);
              ui.setIndexMeta({ ...ui.state.indexMeta, [box]: (/* @__PURE__ */ new Date()).toISOString() });
              persistIndexMeta();
            }
            notify(
              api,
              `W widoku: ${ui.state.boxes[box]?.entries.length ?? 0} (dodano: ${scan.addedToView}).`,
              { title: "Wczytano wszystkie", level: "success" }
            );
          } else {
            notify(
              api,
              `W widoku: ${ui.state.boxes[box]?.entries.length ?? 0} (dodano: ${scan.addedToView}). ${scan.skipWhy ?? "Sprobuj ponownie za chwile"}.`,
              { title: "Wczytano dostepne listy", level: "warning" }
            );
          }
        } finally {
          if (generation !== connectionGeneration) return;
          loadAllFlag = null;
          ui.setLoadAll(null);
        }
      }).catch((err) => {
        if (!isOperationCancelled(err)) {
          notify(
            api,
            humanizeMailError(err instanceof Error ? err.message : String(err)),
            { title: "Blad wczytywania", level: "error" }
          );
        }
      }).finally(() => {
        if (generation !== connectionGeneration) return;
        ui.setBusy(null);
        rebuildContacts();
      });
    };
    let indexFlag = null;
    const indexAllBoxes = () => {
      if (indexFlag) {
        indexFlag.cancelled = true;
        return;
      }
      if (lock.locked) {
        notify(api, SESSION_BUSY_MSG, { level: "warning" });
        return;
      }
      const flag = { cancelled: false };
      indexFlag = flag;
      let done = 0;
      const generation = connectionGeneration;
      const skipped = [];
      void runExclusive(async () => {
        try {
          for (let i = 0; i < INDEX_BOXES.length; i++) {
            const box = INDEX_BOXES[i];
            if (flag.cancelled || generation !== connectionGeneration) break;
            ui.setIndexRun({ boxIndex: i, box, pages: 0 });
            ui.setBusy(`Indeksuje skrzynke ${box} (${i + 1}/${INDEX_BOXES.length})...`);
            const collectedFreshIds = /* @__PURE__ */ new Set();
            const sweepMode = indexSweepMode(ui.state.indexMeta, box, Date.now());
            const mergeIndexPage = (res) => {
              const records = recordsOfListing(box, res.entries);
              const merged = mergeListingPage(ui.state.archive, box, records);
              ui.setArchive(merged.letters);
              persistArchive();
              for (const id of merged.freshIds) collectedFreshIds.add(id);
              return merged;
            };
            const applyFirstIndexPage = (res, resolvedIds) => {
              stampEntries(box, res.entries, resolvedIds);
              const oldest = oldestEntry(res.entries);
              const boundaryDay = oldest?.date ? `${oldest.date.year}-${String(oldest.date.month).padStart(2, "0")}-${String(oldest.date.day).padStart(2, "0")}` : void 0;
              const synced = ui.syncMailboxPage(
                box,
                res.entries,
                res.header.truncated,
                boundaryDay
              );
              if (!synced) ui.applyMailbox(box, res);
            };
            const scan = await scanMailboxPages({
              box,
              cancelled: () => flag.cancelled || generation !== connectionGeneration,
              fetchPage: (command) => mailbox.fetch(box, command),
              wait: (ms) => sleepOrCancel(ms, flag),
              onGap: (day) => recordArchiveGap(box, day),
              onBaseRefresh: (res) => {
                if (res.kind === "lista") {
                  const merged = mergeIndexPage(res);
                  applyFirstIndexPage(res, merged.resolvedIds);
                } else {
                  bumpCtx(box);
                  ui.applyMailbox(box, res);
                }
                rebuildContacts();
              },
              onEmpty: (res) => {
                bumpCtx(box);
                if (collectedFreshIds.size === 0) {
                  ui.applyMailbox(box, res);
                  rebuildContacts();
                }
              },
              onPage: (res, pages) => {
                ui.setIndexRun({ boxIndex: i, box, pages });
                const merged = mergeIndexPage(res);
                if (pages === 1) {
                  applyFirstIndexPage(res, merged.resolvedIds);
                } else {
                  stampEntries(box, res.entries, merged.resolvedIds);
                  ui.appendMailboxPage(box, res.entries, res.header.truncated);
                }
                rebuildContacts();
                return {
                  archiveAdded: merged.added,
                  // Fala 41: strona bez ani jednego nowego rekordu =
                  // klamra doszla do znanego materiału - przeglad
                  // inkrementalny moze stac.
                  stop: sweepMode === "incremental" && merged.added === 0
                };
              }
            });
            if ((scan.end === "complete" || scan.end === "clamped") && !flag.cancelled) {
              if (scan.end === "complete" && collectedFreshIds.size > 0) {
                ui.appendMailboxPage(box, [], false);
              }
              if (scan.end === "clamped") {
                markGoneFromServerNewerThan(
                  box,
                  collectedFreshIds,
                  scan.oldestSeenDay ?? ""
                );
              } else {
                const replaced = replaceBoxLetters(ui.state.archive, box, snapshotRecords(box));
                ui.setArchive(replaced.letters);
                persistArchive();
                if (replaced.removedIds.size > 0) pruneGoneFromView(box, replaced.removedIds);
                clearArchiveGaps(box);
                ui.setIndexMeta({ ...ui.state.indexMeta, [box]: (/* @__PURE__ */ new Date()).toISOString() });
                persistIndexMeta();
              }
              done += 1;
            } else if (scan.end === "cancelled" || flag.cancelled) {
              break;
            } else {
              skipped.push(`${box} (${scan.skipWhy ?? "niekompletne"})`);
            }
          }
          if (flag.cancelled) {
            notify(
              api,
              `Zapisane skrzynki: ${done} z ${INDEX_BOXES.length}.`,
              { title: "Przerwano indeksowanie", level: "warning" }
            );
          } else if (skipped.length === 0) {
            rebuildContacts();
            notify(
              api,
              `${formatListCount(totalLive(ui.state.archive))} w bazie.`,
              { title: "Zindeksowano skrzynki", level: "success" }
            );
          } else {
            rebuildContacts();
            notify(
              api,
              `Pominiete: ${skipped.join(", ")}. Pozostale skrzynki zapisane.`,
              { title: "Indeksowanie niekompletne", level: "warning" }
            );
          }
        } finally {
          if (generation !== connectionGeneration) return;
          indexFlag = null;
          ui.setIndexRun(null);
          ui.setBusy(null);
        }
      }).catch((err) => {
        if (!isOperationCancelled(err)) {
          notify(
            api,
            humanizeMailError(err instanceof Error ? err.message : String(err)),
            { title: "Blad indeksowania", level: "error" }
          );
        }
      });
    };
    let animalFlight = false;
    let sluchamArmed = false;
    const disarmSlucham = () => {
      sluchamArmed = false;
      if (sluchamTimer !== null) {
        clearTimeout(sluchamTimer);
        sluchamTimer = null;
      }
    };
    const armSluchamWindow = () => {
      sluchamArmed = true;
      if (sluchamTimer !== null) clearTimeout(sluchamTimer);
      sluchamTimer = setTimeout(() => {
        sluchamTimer = null;
        sluchamArmed = false;
      }, ANIMAL_TIMING.sluchamWindowMs);
    };
    const endAnimalFlight = () => {
      animalFlight = false;
      if (animalTimer !== null) {
        clearTimeout(animalTimer);
        animalTimer = null;
      }
      ui.setAnimalFlying(false);
    };
    const startAnimalFlight = () => {
      animalFlight = true;
      if (animalTimer !== null) clearTimeout(animalTimer);
      animalTimer = setTimeout(() => {
        animalTimer = null;
        if (animalFlight) endAnimalFlight();
      }, ANIMAL_TIMING.flightTimeoutMs);
      ui.setAnimalFlying(true);
    };
    const openWithResolve = async (box, entry) => {
      for (let attempt = 0; attempt < 2; attempt++) {
        const fresh = await resolveEntry(box, entry);
        if (!fresh) return;
        transport.beginModal();
        try {
          const res = await pager.readLetter(fresh.number);
          ui.openLetter(box, res.letter, fresh);
          const merged = upsertLetters(ui.state.archive, [
            fromOpenedLetter(box, res.letter, fresh)
          ]);
          ui.setArchive(merged.letters);
          persistArchive();
          if (ui.state.search?.box !== box) refreshBoxes([box]);
          return;
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          const listingGone = /nie zostaly wybrane|Zly numer listu/.test(msg);
          if (attempt === 0 && listingGone) {
            bumpCtx(box);
            continue;
          }
          throw err;
        } finally {
          transport.endModal();
        }
      }
    };
    const archivePseudoEntry = (letter, box) => ({
      number: letter.number,
      isRead: letter.read,
      subject: letter.subject,
      forwarded: letter.forwarded === true,
      party: letter.party,
      partyKind: (box ?? letter.box) === "odebrane" || (box ?? letter.box) === "nieprzeczytane" ? "nadawca" : "odbiorcy",
      date: letter.dateRaw ? parseMailDate(letter.dateRaw) : null,
      // Fala 41: tozsamosc rekordu niesie pseudo-wpis - re-kotwica strony
      // wybiera wpis PO archiveId (blizniak o identycznych metadanych ma
      // wlasne id i wlasny wiersz listingu), a tresc z pagera laduje
      // dokladnie w tym rekordzie.
      archiveId: letter.id
    });
    const fetchArchiveBody = async (letter, opts) => {
      const box = opts?.box ?? letter.box;
      const pseudo = archivePseudoEntry(letter, box);
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          const fresh = await resolveEntry(box, pseudo);
          if (!fresh) return { kind: "missing" };
          transport.beginModal();
          try {
            const res = await pager.readLetter(fresh.number, opts?.shouldAbort);
            const merged = upsertLetters(ui.state.archive, [
              fromOpenedLetter(box, res.letter, fresh)
            ]);
            ui.setArchive(merged.letters);
            persistArchive();
            return { kind: "ok", body: res.letter.body };
          } finally {
            transport.endModal();
          }
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          const listingGone = /nie zostaly wybrane|Zly numer listu/.test(msg);
          if (attempt === 0 && listingGone) {
            bumpCtx(box);
            continue;
          }
          return { kind: "error" };
        }
      }
      return { kind: "error" };
    };
    let archiveDownloadFlag = null;
    const DOWNLOAD_BREAKER_LIMIT = 3;
    const runArchiveDownload = () => {
      if (archiveDownloadFlag) {
        archiveDownloadFlag.cancelled = true;
        return;
      }
      if (lock.locked) {
        notify(api, SESSION_BUSY_MSG, { level: "warning" });
        return;
      }
      if (playerMailMode) {
        notify(
          api,
          "Przed pobieraniem tresci zamknij poczte otwarta w grze (komenda q).",
          { level: "warning" }
        );
        return;
      }
      const noBody = ui.state.archive.filter((l) => l.body.length === 0);
      const candidates = noBody.filter(
        (l) => l.dateRaw !== null && parseMailDate(l.dateRaw) !== null
      );
      if (candidates.length === 0) {
        notify(
          api,
          ui.state.archive.length === 0 ? "Skrzynki sa puste - nie ma czego pobierac." : noBody.length > 0 ? `Nie mozna pobrac tresci - listy bez prawidlowej daty: ${noBody.length}.` : "Wszystkie listy w bazie maja tresci.",
          { level: "warning" }
        );
        return;
      }
      const flag = { cancelled: false };
      archiveDownloadFlag = flag;
      const total = candidates.length;
      let emaMs = null;
      let lastAt = Date.now();
      ui.setArchiveDownload({ done: 0, total, etaMs: null });
      ui.setBusy(`Pobieram tresci do archiwum (0/${total})...`);
      const generation = connectionGeneration;
      void runExclusive(async () => {
        let done = 0;
        let failed = 0;
        let missing = 0;
        let consecutiveErrors = 0;
        let breakerTripped = false;
        let playerEntry = false;
        const reportProgress = () => {
          const processed = done + failed + missing;
          const now = Date.now();
          const dt = now - lastAt;
          lastAt = now;
          emaMs = emaMs === null ? dt : 0.3 * dt + 0.7 * emaMs;
          const etaMs = processed >= 3 && emaMs !== null ? Math.max(1e3, Math.round(emaMs * (total - processed))) : null;
          ui.setArchiveDownload({ done: processed, total, etaMs });
          ui.setBusy(`Pobieram tresci do archiwum (${processed}/${total})...`);
        };
        try {
          for (const record of candidates) {
            if (flag.cancelled || breakerTripped) break;
            if (playerMailMode) {
              playerEntry = true;
              break;
            }
            const order = [record.box, "odebrane", "nieprzeczytane", "wyslane", "niewyslane"].filter((b, i, arr) => arr.indexOf(b) === i);
            let result = { kind: "error" };
            let attempted = false;
            for (const box of order) {
              if (flag.cancelled || playerMailMode) break;
              attempted = true;
              result = await fetchArchiveBody(record, {
                shouldAbort: () => flag.cancelled,
                box
              });
              if (result.kind === "ok") break;
              if (result.kind === "error") break;
            }
            if (playerMailMode && !attempted) {
              playerEntry = true;
              break;
            }
            if (playerMailMode) playerEntry = true;
            if (result.kind === "ok") {
              done += 1;
              consecutiveErrors = 0;
            } else if (result.kind === "missing" && !flag.cancelled) {
              missing += 1;
              consecutiveErrors = 0;
              ui.setArchive(ui.state.archive.filter((l) => l.id !== record.id));
              persistArchive();
              for (const b of ["odebrane", "nieprzeczytane", "wyslane", "niewyslane"]) {
                pruneGoneFromView(b, /* @__PURE__ */ new Set([record.id]));
              }
            } else if (!flag.cancelled) {
              failed += 1;
              consecutiveErrors += 1;
              if (consecutiveErrors >= DOWNLOAD_BREAKER_LIMIT) breakerTripped = true;
            }
            reportProgress();
            if (breakerTripped) break;
            if (flag.cancelled) break;
            if (playerEntry) break;
            await sleepOrCancel(LOAD_ALL_PACE_MS, flag);
          }
          if (playerEntry) {
            notify(
              api,
              `Poczta zostala otwarta w grze. Pobrano: ${done} z ${total}.`,
              { title: "Przerwano pobieranie", level: "warning" }
            );
          } else if (breakerTripped) {
            notify(
              api,
              "Serwer poczty nie odpowiada. Pobrane tresci sa zapisane - sprobuj ponownie pozniej.",
              { title: "Przerwano pobieranie", level: "warning" }
            );
          } else if (flag.cancelled) {
            notify(
              api,
              `Pobrano: ${done} z ${total}.`,
              { title: "Przerwano pobieranie", level: "warning" }
            );
          } else if (failed === 0 && missing === 0) {
            notify(api, `Pobrano tresci do archiwum (${formatListCount(done)}).`, { level: "success" });
          } else {
            const parts = [];
            if (failed > 0) parts.push(`nieudane: ${failed}`);
            if (missing > 0) parts.push(`nie ma juz w skrzynce: ${missing}`);
            notify(
              api,
              `${done} z ${total}; ${parts.join("; ")}.`,
              { title: "Pobrano tresci", level: "success" }
            );
          }
        } finally {
          if (generation !== connectionGeneration) return;
          archiveDownloadFlag = null;
          ui.setArchiveDownload(null);
          ui.setBusy(null);
        }
      }).catch((err) => {
        if (!isOperationCancelled(err)) notify(api, "Blad pobierania tresci do archiwum.", { level: "error" });
      });
    };
    const runExportArchive = () => {
      const { entries, skipped } = archiveExportEntries(ui.state.archive);
      if (entries.length === 0) {
        notify(
          api,
          ui.state.archive.length === 0 ? "Skrzynki sa puste - nie ma czego zapisywac." : "Brak listow z trescia w archiwum - najpierw pobierz tresci.",
          { level: "warning" }
        );
        return;
      }
      const enc = new TextEncoder();
      const zip = buildZip(entries.map((e) => ({ name: e.name, data: enc.encode(e.txt) })));
      const now = /* @__PURE__ */ new Date();
      const p22 = (n) => String(n).padStart(2, "0");
      const name = `arkmail_listy_${now.getFullYear()}-${p22(now.getMonth() + 1)}-${p22(now.getDate())}_${p22(now.getHours())}${p22(now.getMinutes())}.zip`;
      const ok = downloadBlob(name, new Blob([zip.buffer], { type: "application/zip" }));
      notify(
        api,
        ok ? `Zapisano listy do ZIP (${entries.length} ${entries.length === 1 ? "plik" : "plikow"})` + (skipped > 0 ? `; pominietych bez tresci: ${skipped}` : "") + "." : "Nie udalo sie zapisac pliku - klient nie obsluguje pobierania.",
        { title: "Zapis do ZIP", level: ok ? "success" : "error" }
      );
    };
    const deletionSelectionKey = (numbers) => [...numbers].sort((a, b) => a - b).join(",");
    const searchForDeletion = (box, command) => {
      if (lock.locked) {
        notify(api, SESSION_BUSY_MSG, { level: "warning" });
        return;
      }
      if (ui.state.tab !== "usuwanie") return;
      const revision = ui.state.deletion.revision;
      const generation = connectionGeneration;
      ui.setBusy(`Szukam w skrzynce ${box}...`);
      void runExclusive(async () => {
        const result = await mailbox.fetch(box, command);
        if (generation !== connectionGeneration) return;
        if (revision !== ui.state.deletion.revision || ui.state.tab !== "usuwanie" || ui.state.deletion.box !== box) {
          bumpCtx(box);
          return;
        }
        if (result.kind === "lista") stampEntries(box, result.entries);
        else bumpCtx(box);
        ui.applyDeletionResult(box, command, result);
      }).catch((err) => {
        if (isOperationCancelled(err) || generation !== connectionGeneration) return;
        if (revision === ui.state.deletion.revision && ui.state.tab === "usuwanie") {
          ui.clearDeletionResult("Blad wyszukiwania. Sprobuj ponownie.");
        }
      }).finally(() => {
        if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
      });
    };
    const deleteSelectedLetters = () => {
      if (lock.locked) {
        notify(api, SESSION_BUSY_MSG, { level: "warning" });
        return;
      }
      const current = ui.state.deletion;
      if (ui.state.tab !== "usuwanie" || current.result?.kind !== "lista" || current.command === null) {
        return;
      }
      const selected = current.result.entries.filter((entry) => current.selected.includes(entry.number));
      if (selected.length === 0) return;
      const box = current.box;
      const command = current.command;
      const revision = current.revision;
      const selectionKey = deletionSelectionKey(current.selected);
      const generation = connectionGeneration;
      let deleteStarted = false;
      ui.setBusy("Sprawdzam zaznaczone listy...");
      void runExclusive(async () => {
        transport.beginModal();
        try {
          const fresh = await mailbox.fetch(box, command);
          if (generation !== connectionGeneration) return;
          if (revision !== ui.state.deletion.revision || ui.state.tab !== "usuwanie" || ui.state.deletion.command !== command || deletionSelectionKey(ui.state.deletion.selected) !== selectionKey) {
            bumpCtx(box);
            return;
          }
          if (fresh.kind === "lista") stampEntries(box, fresh.entries);
          else bumpCtx(box);
          if (fresh.kind !== "lista") {
            ui.clearDeletionResult("Zaznaczone listy zmienily sie. Wyszukaj je ponownie.");
            return;
          }
          const match = matchSelectionOnFreshListing(selected, fresh.entries);
          if (!match) {
            ui.clearDeletionResult("Zaznaczone listy zmienily sie. Wyszukaj je ponownie.");
            return;
          }
          ui.setBusy("Usuwam zaznaczone listy...");
          deleteStarted = true;
          const result = await pager.deleteLetters(match.numbers[0], match.range);
          const confirmed = [.../* @__PURE__ */ new Set([...result.deletedNumbers, ...result.unexpectedNumbers])].sort((a, b) => a - b);
          const updated = applyConfirmedDeletions(ui.state.archive, box, fresh.entries, confirmed);
          if (updated.changedIds.size > 0) {
            ui.setArchive(updated.letters);
            persistArchive();
            rebuildContacts();
            for (const changedBox of updated.changedBoxes) {
              pruneGoneFromView(changedBox, updated.changedIds);
            }
          }
          let message;
          if (result.status === "complete") {
            message = `Usunieto: ${formatListCount(result.deletedNumbers.length)}.`;
          } else if (confirmed.length > 0) {
            message = `Usunieto: ${formatListCount(confirmed.length)}. Wynik pozostalych jest nieznany. Odswiez przed kolejna proba.`;
            if (result.unexpectedNumbers.length > 0) {
              message += " Potwierdzono tez usuniecie listow spoza zaznaczenia.";
            }
          } else if (result.status === "none") {
            message = "Nie usunieto listow.";
          } else {
            message = "Brak potwierdzenia usuniecia. Odswiez przed kolejna proba.";
          }
          if (revision === ui.state.deletion.revision && ui.state.tab === "usuwanie") {
            ui.clearDeletionResult(message);
          }
        } finally {
          transport.endModal();
        }
      }).catch((err) => {
        if (isOperationCancelled(err) || generation !== connectionGeneration) return;
        if (revision === ui.state.deletion.revision && ui.state.tab === "usuwanie") {
          ui.clearDeletionResult(
            deleteStarted ? "Wynik usuwania jest nieznany. Odswiez przed kolejna proba." : "Nie udalo sie sprawdzic listow. Sprobuj ponownie."
          );
        }
      }).finally(() => {
        if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
      });
    };
    const openArchiveFromServer = (letter) => {
      if (lock.locked) {
        notify(api, SESSION_BUSY_MSG, { level: "warning" });
        return;
      }
      ui.setBusy(`Czytam list: ${letter.subject}...`);
      const pseudo = archivePseudoEntry(letter);
      const generation = connectionGeneration;
      void runExclusive(() => openWithResolve(letter.box, pseudo)).catch((err) => {
        if (!isOperationCancelled(err)) notify(api, "Nie udalo sie odczytac listu.", { level: "error" });
      }).finally(() => {
        if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
      });
    };
    handlersRef = {
      onDeletionSearch: (box, query) => {
        const validationError = validateListingSearch(query);
        if (validationError) {
          notify(api, validationError, { level: "error" });
          return;
        }
        searchForDeletion(box, searchListingCommand(box, query));
      },
      onDeletionDelete: () => deleteSelectedLetters(),
      onSendAnimal: () => {
        if (lock.locked) {
          notify(api, SESSION_BUSY_MSG, { level: "warning" });
          return;
        }
        if (animalFlight) {
          notify(api, "Zwierze jest juz w drodze - poczekaj na jego powrot.", { level: "warning" });
          return;
        }
        startAnimalFlight();
        transport.send("wyslij zwierze", true);
        armSluchamWindow();
      },
      onOpenLetter: (box, entry) => {
        if (lock.locked) {
          notify(api, SESSION_BUSY_MSG, { level: "warning" });
          return;
        }
        ui.setBusy(`Czytam list: ${entry.subject}...`);
        const generation = connectionGeneration;
        void runExclusive(() => openWithResolve(box, entry)).catch((err) => {
          if (!isOperationCancelled(err)) notify(api, "Nie udalo sie odczytac listu.", { level: "error" });
        }).finally(() => {
          if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
        });
      },
      onOpenArchiveLetter: (letter) => {
        if (letter.body.length > 0) {
          const senderBox = letter.box === "odebrane" || letter.box === "nieprzeczytane";
          ui.openLetter(letter.box, {
            number: letter.number,
            from: senderBox ? letter.party : "",
            subject: letter.subject,
            to: senderBox ? "" : letter.party,
            cc: null,
            date: letter.dateRaw,
            body: letter.body
          });
          return;
        }
        openArchiveFromServer(letter);
      },
      onDownloadArchiveBodies: () => runArchiveDownload(),
      // Indeksacja wszystkich skrzynek jako osobna operacja.
      onIndexAll: () => indexAllBoxes(),
      // Fala UI-2: import bazy osob i aliasow z gry (pule ksiazki
      // adresowej; wipe "Wyczysc zapisane dane" ich nie tyka).
      onImportPeople: (kind) => importPeople(kind),
      onImportAliases: () => importAliases(),
      // Fala UI-2 krok 3: CRUD grup recznych - kazda mutacja zapisu
      // trwa w tym samym przebiegu (storage + stan UI).
      onSaveGroups: (groups) => {
        saveGroups(storage, groups);
        ui.setGroups(groups);
      },
      // Fala UI-2 krok 3: zapis plaskiej ksiazki imion po mutacji CRUD
      // (dodanie, usuniecie pojedyncze, usuniecie zaznaczonych) - storage
      // + stan UI w jednym przebiegu (jak onSaveGroups).
      onSavePeople: (people) => {
        savePeople(storage, people);
        ui.setPeople(people);
        rebuildContacts();
      },
      // Fala UI-2 krok 3: import ksiazki z pliku JSON (format v2; v1
      // czytany wstecz). Tryb "dolacz" scala grupy o tej samej nazwie i
      // uzupelnia ksiazke o czlonkow grup; "zastap" podmienia imiona i
      // grupy zawartoscia pliku (niezmiennik kompletnosci czlonkow i tak
      // obowiazuje). Aliasy sa lustrem z gry - import pliku ich nie rusza.
      onImportAddressBook: (data, mode = "dolacz") => {
        const { data: merged, stats } = applyBookImport(
          { people: ui.state.people, groups: ui.state.groups },
          data,
          mode
        );
        saveGroups(storage, merged.groups);
        savePeople(storage, merged.people);
        ui.setGroups(merged.groups);
        ui.setPeople(merged.people);
        rebuildContacts();
        notify(api, mode === "zastap" ? `Ksiazka adresowa zastapiona. Grup: ${merged.groups.length}, imion: ${merged.people.length}.` : `Dolaczono. Grup: ${data.groups.length} (nowe: ${stats.addedGroups}, scalone: ${stats.mergedGroups}). Imion: ${merged.people.length} (nowe: ${stats.addedPeople}).`, { level: "success" });
      },
      // Zgloszenie 2026-11-05: wyczyszczenie lokalnego lustra aliasow
      // (przycisk w pigulce "Aliasy Pocztowe"). Kasuje wylacznie lokalny
      // storage; na serwerze Arkadii nic nie znika - aliasy pobiera sie
      // z gry ponownie.
      onClearAliases: () => {
        saveImportedAliases(storage, []);
        ui.setImportedAliases([]);
        rebuildContacts();
        notify(api, "Wyczyszczono lokalne aliasy. Pobierz aliasy z gry ponownie, gdy beda potrzebne.", { level: "success" });
      },
      // Zgloszenie 2026-11-05: wyczyszczenie calej ksiazki adresowej
      // (imiona + grupy + aliasy) z guardem dwukliku w pigulce
      // "Import-Eksport". Kasuje wylacznie lokalny storage; na serwerze
      // Arkadii nic nie znika.
      onClearAddressBook: () => {
        savePeople(storage, []);
        saveGroups(storage, []);
        saveImportedAliases(storage, []);
        ui.setPeople([]);
        ui.setGroups([]);
        ui.setImportedAliases([]);
        rebuildContacts();
        notify(api, "Wyczyszczono cala ksiazke adresowa (imiona, grupy, aliasy).", { level: "success" });
      },
      // Zgloszenie 2026-11-05 (K7): eksport ksiazki do pliku JSON przez
      // handler - pobranie pliku + status + toast (jak eksport listu);
      // UI nie pobiera pliku bez potwierdzenia w pasku statusu.
      onExportAddressBook: () => {
        const json = buildAddressBookExport({
          people: ui.state.people,
          groups: ui.state.groups
        });
        const ok = downloadBlob(
          "arkmail-adresy.json",
          new Blob([json], { type: "application/json" })
        );
        notify(
          api,
          ok ? `Ksiazka adresowa zapisana do pliku (imion: ${ui.state.people.length}, grup: ${ui.state.groups.length}).` : "Nie udalo sie zapisac pliku - klient nie obsluguje pobierania.",
          { level: ok ? "success" : "error" }
        );
      },
      // Zgloszenie 2026-11-05: dopisanie wszystkich osob zebranych z
      // listow do ksiazki adresowej jednym klikiem. Dedup bez wielkosci
      // liter robi unionPeople; przycisk aktywny tylko gdy baza istnieje.
      onAddAllContacts: () => {
        const names = ui.state.contacts.map((c) => c.name);
        const before = ui.state.people.length;
        const people = unionPeople(ui.state.people, names);
        savePeople(storage, people);
        ui.setPeople(people);
        notify(api, `Dopisano do ksiazki: ${people.length - before} nowych osob (razem: ${people.length}).`, { level: "success" });
      },
      // Fala 17g: eksporty TXT/ZIP - operacje czysto lokalne (dane
      // z cache), bez locka i bez komend do serwera.
      onExportLetter: () => {
        const l = ui.state.letter;
        if (!l) return;
        const sender = l.box === "odebrane" || l.box === "nieprzeczytane";
        const party = sender ? l.from : l.to || l.cc || "";
        const txt = letterTxt({
          subject: l.subject,
          from: l.from,
          to: l.to,
          cc: l.cc,
          date: l.date,
          box: l.box,
          body: l.body
        });
        const blob = new Blob([txt], { type: "text/plain" });
        const ok = downloadBlob(txtFileName(party, l.subject, l.date), blob);
        notify(
          api,
          ok ? "Zapisano list do pliku TXT." : "Nie udalo sie zapisac pliku - klient nie obsluguje pobierania.",
          { level: ok ? "success" : "error" }
        );
      },
      onExportArchive: () => {
        runExportArchive();
      },
      onSendCompose: (input) => {
        const validationError = validateCompose(input);
        if (validationError) {
          notify(api, validationError, { level: "error" });
          return;
        }
        if (lock.locked) {
          notify(api, SESSION_BUSY_MSG, { level: "warning" });
          return;
        }
        const unknown = unknownRecipients(input, knownRecipientNames(ui.state));
        if (unknown.length > 0) {
          notify(api, `Poza baza osob: ${unknown.join(", ")}.`, { level: "warning" });
        }
        ui.setBusy("Wysylam list...");
        const generation = connectionGeneration;
        void runExclusive(async () => {
          transport.beginModal();
          composeVisible = true;
          try {
            const out = await editor.send({
              adresat: input.adresat.trim(),
              temat: input.temat,
              dw: input.dw.trim() === "" ? void 0 : input.dw.trim(),
              linie: input.linie
            });
            if (out.result === "wyslany") {
              notify(api, "List zostal wyslany.", { level: "success" });
              refreshBoxes(["wyslane", "niewyslane"]);
              ui.clearCompose();
            } else if (out.result === "gotowy") {
              notify(api, "List zapisany w niewyslanych.", { level: "success" });
              refreshBoxes(["niewyslane"]);
              flashUnsent();
              ui.clearCompose();
            } else if (out.result === "zaniechany") {
              notify(api, "Przerwano wysylke listu.", { level: "info" });
            } else if (out.result === "blad" && out.error.kind === "brak-adresata") {
              notify(api, `Nie ma takiego adresata: ${out.error.adresat}.`, {
                level: "error"
              });
            } else {
              notify(api, "Blad wysylki - sprawdz adresata.", { level: "error" });
            }
          } finally {
            composeVisible = false;
            transport.endModal();
          }
        }).catch((err) => {
          if (!isOperationCancelled(err)) notify(api, "Blad wysylki listu.", { level: "error" });
        }).finally(() => {
          if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
        });
      },
      onCloseLetter: () => ui.closeLetter(),
      // Fala 20e: guardy w handlerach, NIE w refreshBoxes - wewnetrzny
      // refresh po wysylce/kasowaniu kolejkuje celowo (wołany z wnetrza
      // sesji). Klik gracza przy zajetej blokadzie: odmowa z toastem,
      // zero cichego kolejkowania komend (audyt race 2026-10-21).
      onRefreshBox: (box) => {
        if (lock.locked) {
          notify(api, SESSION_BUSY_MSG, { level: "warning" });
          return;
        }
        refreshBoxes([box]);
      },
      onLoadOlder: (box) => {
        if (lock.locked) {
          notify(api, SESSION_BUSY_MSG, { level: "warning" });
          return;
        }
        loadOlder(box);
      },
      onLoadAll: (box) => loadAll(box),
      onSearch: (box, query) => {
        const validationError = validateListingSearch(query);
        if (validationError) {
          notify(api, validationError, { level: "error" });
          return;
        }
        if (lock.locked) {
          notify(api, SESSION_BUSY_MSG, { level: "warning" });
          return;
        }
        ui.setBusy(`Szukam w skrzynce ${box}...`);
        const generation = connectionGeneration;
        void runExclusive(async () => {
          const res = await mailbox.fetch(box, searchListingCommand(box, query));
          const searchRecords = res.kind === "lista" ? recordsOfListing(box, res.entries) : void 0;
          if (res.kind !== "lista") bumpCtx(box);
          ui.setSearch({ box, label: searchDescription(box, query) });
          ui.applySearchResults(box, res);
          if (res.kind === "lista" && searchRecords !== void 0) {
            const merged = mergeListingPage(ui.state.archive, box, searchRecords);
            ui.setArchive(merged.letters);
            stampEntries(box, res.entries, merged.resolvedIds);
            persistArchive();
            notify(api, `Wyniki szukania (${formatListCount(res.entries.length)}).`, { level: "success" });
          } else {
            notify(api, "Brak pasujacych listow.");
          }
        }).catch((err) => {
          if (!isOperationCancelled(err)) {
            notify(
              api,
              humanizeMailError(err instanceof Error ? err.message : String(err)),
              { title: "Blad szukania", level: "error" }
            );
          }
        }).finally(() => {
          if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
        });
      },
      onClearSearch: (box) => ui.clearSearch(box),
      // Fala 12e: czyszczenie pamieci podrecznej na zadanie gracza.
      // Kasuje archiwum (storage + RAM), widoki skrzynek i kontakty;
      // ZACHOWUJE ustawienia (powiadomienia, szablon compose) - one nie
      // sa cache, tylko preferencje.
      onClearCache: () => {
        if (lock.locked) {
          notify(api, SESSION_BUSY_MSG, { level: "warning" });
          return;
        }
        const generation = connectionGeneration;
        ui.setBusy("Czyszcze zapisane dane...");
        void runExclusive(async () => {
          await storage.clearMailData([INDEX_KEY, ARCHIVE_GAPS_KEY]);
          if (generation !== connectionGeneration) return;
          ui.clearCacheData();
          notify(api, "Zapisane dane wyczyszczone.", { level: "success" });
        }).catch((err) => {
          if (!isOperationCancelled(err)) {
            notify(api, "Nie udalo sie wyczyscic zapisanych danych.", { level: "error" });
          }
        }).finally(() => {
          if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
        });
      },
      onDeleteLetter: (box, entry) => {
        if (lock.locked) {
          notify(api, SESSION_BUSY_MSG, { level: "warning" });
          return;
        }
        ui.setBusy(`Usuwam list: ${entry.subject}...`);
        const generation = connectionGeneration;
        void runExclusive(async () => {
          const fresh = await resolveEntry(box, entry);
          if (!fresh) return;
          transport.beginModal();
          try {
            const res = await pager.deleteLetters(fresh.number, String(fresh.number));
            if (res.deleted) {
              notify(api, "List zostal usuniety.", { level: "success" });
              ui.closeLetter();
              refreshBoxes([box], "replace");
            } else {
              notify(api, "Nie udalo sie skasowac listu.", { level: "error" });
            }
          } finally {
            transport.endModal();
          }
        }).catch((err) => {
          if (!isOperationCancelled(err)) notify(api, "Blad kasowania listu.", { level: "error" });
        }).finally(() => {
          if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
        });
      },
      onForwardLetter: (box, entry, adresat) => {
        if (lock.locked) {
          notify(api, SESSION_BUSY_MSG, { level: "warning" });
          return;
        }
        ui.setBusy(`Przekazuje list: ${entry.subject}...`);
        const generation = connectionGeneration;
        void runExclusive(async () => {
          const fresh = await resolveEntry(box, entry);
          if (!fresh) return;
          transport.beginModal();
          try {
            const res = await pager.forwardLetter(fresh.number, adresat);
            if (res.queued) {
              notify(api, "List przekazany - czeka w niewyslanych.", { level: "success" });
              refreshBoxes(["niewyslane"]);
              flashUnsent();
            } else {
              notify(api, "Blad przekazania - sprawdz adresata.", { level: "error" });
            }
          } finally {
            transport.endModal();
          }
        }).catch((err) => {
          if (!isOperationCancelled(err)) notify(api, "Blad przekazania listu.", { level: "error" });
        }).finally(() => {
          if (generation === connectionGeneration && !lock.locked) ui.setBusy(null);
        });
      }
    };
    let lastWatchdogQ = 0;
    transport.subscribe((line) => {
      if (line.cls === "command" || isEchoLine(line.text)) {
        const cmd = isEchoLine(line.text) ? line.text.replace(/^→\s*/, "") : line.text;
        if (MAIL_ENTRY_CMD_RE.test(cmd)) {
          clearPagerOrphan();
          if (!line.own) enterPlayerMailMode();
        } else if (playerMailMode && !line.own && /^(?:q|x)$/i.test(cmd.trim())) {
          exitPlayerMailMode();
        }
        return;
      }
      if (!extractPagerPrompt(line.text)) return;
      if (playerMailMode) armPlayerMailModeIdle();
      if (lock.locked) return;
      if (!isPagerOrphanSuspected()) return;
      const now = Date.now();
      if (now - lastWatchdogQ < 2e3) return;
      lastWatchdogQ = now;
      transport.send("q");
      clearPagerOrphan();
    });
    transport.subscribe((line) => {
      const n = parseNotification(line.text);
      if (!n) return;
      if (n.kind === "nowa-poczte") {
        if (ui.state.notifyEnabled) notify(api, `Masz nowa poczte od ${n.nadawca}.`);
        scheduleRefresh(["odebrane", "nieprzeczytane"]);
        scheduleDelayedInboxRefresh();
      } else if (n.kind === "wysylasz") {
        if (!animalFlight) startAnimalFlight();
        disarmSlucham();
      } else if (n.kind === "slucham") {
        if (sluchamArmed) {
          disarmSlucham();
          endAnimalFlight();
          notify(api, "Zwierze nie odpowiada - sprawdz, czy masz zwierze pocztowe.", { level: "warning" });
        }
      } else if (n.kind === "powrot-zwierzecia") {
        disarmSlucham();
        endAnimalFlight();
        scheduleRefresh(["odebrane", "nieprzeczytane", "niewyslane", "wyslane"]);
      } else if (n.kind === "list-wyslany") {
        if (!lock.locked) scheduleRefresh(["niewyslane", "wyslane"]);
      } else if (n.kind === "kasowanie") {
        if (!lock.locked)
          scheduleRefresh(["odebrane", "nieprzeczytane", "wyslane", "niewyslane"]);
      }
    });
    unsubBadge = ui.subscribe((s) => {
      footerHandle?.update({ label: PLUGIN_NAME + formatBadgeSuffix(s.badge, s.badgeUnsent) });
      api.ui.setFooterButtonState(FOOTER_STATE, s.badge > 0 || s.badgeUnsent > 0);
      storage.setJSON(COMPOSE_KEY, { template: s.composeTemplate, width: s.composeWidth });
      storage.setJSON(NOTIFY_KEY, s.notifyEnabled);
    });
    refreshPopup();
    deactivateActiveCharacter = async () => {
      cancelConnectionOperations();
      api.events.off("client.connect", onClientConnect);
      api.events.off("client.disconnect", onClientDisconnect);
      api.events.off("gmcp.mail.state", onMailState);
      api.events.off("gmcp", onAnyGmcp);
      api.events.off("gmcp.char.info", onGamePresence);
      api.events.off("gmcp.char.name", onGamePresence);
      api.events.off("gmcp_msg.room.long", onGamePresence);
      api.events.off("proxy.session", onProxySession);
      api.events.off("gmcp_msg.system.login", onSystemLogin);
      api.events.off("gmcp.mail.state", onGamePresence);
      for (const timer of [animalTimer, sluchamTimer, unsentFlashTimer, playerMailModeTimer]) {
        if (timer !== null) clearTimeout(timer);
      }
      animalTimer = null;
      sluchamTimer = null;
      unsentFlashTimer = null;
      playerMailModeTimer = null;
      for (const timer of delayedInboxTimers) clearTimeout(timer);
      delayedInboxTimers = [];
      await Promise.allSettled([...tasks]);
      if (unsubBadge) {
        unsubBadge();
        unsubBadge = null;
      }
      if (unmount) {
        unmount();
        unmount = null;
      }
      if (wideObserver) {
        wideObserver.disconnect();
        wideObserver = null;
      }
      handlersRef = null;
      store = null;
      if (transport) {
        transport.dispose();
        transport = null;
      }
      if (storageRef === storage) storageRef = null;
      await storage.close();
    };
    return true;
  };
  const switchCharacter = async (name) => {
    const normalized = name?.trim() || null;
    const key = normalized?.toLowerCase() ?? null;
    if (key === activeName) return;
    await deactivateCurrent();
    if (lifecycleDestroyed || key !== (requestedName?.trim().toLowerCase() || null)) return;
    if (!normalized) return;
    if (await activateCharacter(normalized)) activeName = key;
  };
  unsubscribeCharacter = api.character.onChange((name) => {
    requestedName = name;
    switchQueue = switchQueue.then(() => switchCharacter(name)).catch(() => {
    });
  });
  await switchCharacter(requestedName);
  return {
    name: PLUGIN_NAME,
    version: PLUGIN_VERSION,
    // Literal wymagany przez katalog dargoth-plugins (metadata.test.mjs
    // czyta author regexem, nie rozwinie const-ref); zgodnosc z meta.ts
    // pilnuje tests/version.test.mjs (Fala 22a).
    author: "Isithunzi000",
    description: PLUGIN_DESCRIPTION
  };
}
async function destroy() {
  lifecycleDestroyed = true;
  if (unsubscribeCharacter) {
    unsubscribeCharacter();
    unsubscribeCharacter = null;
  }
  if (deactivateActiveCharacter) {
    const deactivate = deactivateActiveCharacter;
    deactivateActiveCharacter = null;
    await deactivate();
  }
  if (animalTimer !== null) {
    clearTimeout(animalTimer);
    animalTimer = null;
  }
  if (sluchamTimer !== null) {
    clearTimeout(sluchamTimer);
    sluchamTimer = null;
  }
  if (unsentFlashTimer !== null) {
    clearTimeout(unsentFlashTimer);
    unsentFlashTimer = null;
  }
  for (const t of delayedInboxTimers) clearTimeout(t);
  delayedInboxTimers = [];
  if (playerMailModeTimer !== null) {
    clearTimeout(playerMailModeTimer);
    playerMailModeTimer = null;
  }
  if (unsubBadge) {
    unsubBadge();
    unsubBadge = null;
  }
  if (unmount) {
    unmount();
    unmount = null;
  }
  if (wideObserver) {
    wideObserver.disconnect();
    wideObserver = null;
  }
  if (transport) {
    transport.dispose();
    transport = null;
  }
  handlersRef = null;
  store = null;
  if (aliasId !== null && apiRef) {
    apiRef.aliases.remove(aliasId);
    aliasId = null;
  }
  if (footerHandle) {
    footerHandle.remove();
    footerHandle = null;
  }
  if (menuHandle) {
    menuHandle.remove();
    menuHandle = null;
  }
  if (popup) {
    popup.close();
    popup = null;
  }
  if (storageRef) {
    const storage = storageRef;
    storageRef = null;
    await storage.close();
  }
  apiRef = null;
}
export {
  ANIMAL_TIMING,
  INDEX_ANCHOR_RETRY_WAITS_MS,
  INDEX_FULL_SWEEP_AGE_MS,
  INDEX_PACE_MS,
  LOAD_ALL_PACE_MS,
  PLAYER_MAIL_MODE_IDLE_MS,
  WIDE_MIN_WIDTH,
  destroy,
  indexSweepMode,
  init
};
