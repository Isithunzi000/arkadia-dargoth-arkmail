var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

// src/arkmail/meta.ts
const PLUGIN_VERSION = "1.1.0";
var PLUGIN_NAME = "ArkMail";
var PLUGIN_AUTHOR = "Isithunzi000";
var PLUGIN_DESCRIPTION = "ArkMail to kompleksowy system pocztowy dla klienta Dargoth: skrzynki, kontakty, archiwum i pisanie listow (alias /arkmail). Plugin w pelni zgodny z regulaminem gry - wszystkie komendy wysylane swiadomie przez gracza, bez automatyki.";

// src/arkmail/core/protocol/parser.ts
var CLIENT_PREFIX_RE = /^\s*\[ POCZTA \]\s+/;
function stripClientPrefix(text) {
  return text.replace(CLIENT_PREFIX_RE, "").trimStart();
}
var MONTHS = {
  I: 1,
  II: 2,
  III: 3,
  IV: 4,
  V: 5,
  VI: 6,
  VII: 7,
  VIII: 8,
  IX: 9,
  X: 10,
  XI: 11,
  XII: 12
};
var DATE_RE = /^([A-Za-z]+), (\d{1,2}) (XII|XI|IX|VIII|VII|VI|IV|V|III|II|I|X) (\d{4}), (\d{2}:\d{2}:\d{2})$/;
function parseMailDate(raw) {
  const m = raw.match(DATE_RE);
  if (!m) return null;
  return {
    raw,
    weekday: m[1],
    day: Number(m[2]),
    month: MONTHS[m[3]],
    year: Number(m[4]),
    time: m[5]
  };
}
var LISTING_HEADER_RE = /^Listy (nieprzeczytane|odebrane|wyslane|niewyslane)(?: \(([^)]*)\))?:$/;
function parseListingHeader(text) {
  const m = text.match(LISTING_HEADER_RE);
  if (!m) return null;
  return {
    box: m[1],
    truncated: m[2] !== void 0 && m[2].includes("pierwsze 50")
  };
}
var LISTING_ENTRY_RE = /^\s*(\d+)\.\s+(?:(\*R\*)\s+)?Temat: (.+)$/;
var FORWARDED_SUFFIX = " (forwardowany)";
function parseListingEntry(text) {
  const m = text.match(LISTING_ENTRY_RE);
  if (!m) return null;
  let subject = m[3];
  let forwarded = false;
  if (subject.endsWith(FORWARDED_SUFFIX)) {
    forwarded = true;
    subject = subject.slice(0, -FORWARDED_SUFFIX.length);
  }
  return { number: Number(m[1]), isRead: m[2] === "*R*", subject, forwarded };
}
var LISTING_PARTY_RE = /^(Nadawca|Odbiorc[ay]): (.+?)(?:\s{2,}(.+))?$/;
function parseListingParty(text) {
  const m = text.match(LISTING_PARTY_RE);
  if (!m) return null;
  return {
    kind: m[1] === "Nadawca" ? "nadawca" : "odbiorcy",
    names: m[2],
    date: m[3] ? parseMailDate(m[3]) : null
  };
}
var EMPTY_LISTING_RE = /^Nie masz zadnych (nieprzeczytanych|odebranych|wyslanych|niewyslanych) listow\.$/;
var FILTERED_EMPTY_RE = /^Nie znaleziono zadnych takich (nieprzeczytanych|odebranych|wyslanych|niewyslanych) listow\.$/;
var BOX_FROM_GENITIVE = {
  nieprzeczytanych: "nieprzeczytane",
  odebranych: "odebrane",
  wyslanych: "wyslane",
  niewyslanych: "niewyslane"
};
function parseEmptyListing(text) {
  const puste = text.match(EMPTY_LISTING_RE);
  if (puste) return { box: BOX_FROM_GENITIVE[puste[1]], reason: "puste" };
  const filtr = text.match(FILTERED_EMPTY_RE);
  if (filtr) return { box: BOX_FROM_GENITIVE[filtr[1]], reason: "filtr" };
  return null;
}
var LETTER_HEADER_RES = [
  { re: /^List\s*: ?(\d+)$/, field: "numer" },
  { re: /^Od\s*: ?(.+)$/, field: "od" },
  { re: /^Temat\s*: ?(.+)$/, field: "temat" },
  { re: /^Do\s*: ?(.*)$/, field: "do" },
  { re: /^DW\s*: ?(.+)$/, field: "dw" },
  { re: /^Data\s*: ?(.+)$/, field: "data" }
];
function parseLetterHeaderLine(text) {
  for (const { re, field } of LETTER_HEADER_RES) {
    const m = text.match(re);
    if (m) return { field, value: m[1] };
  }
  return null;
}
var PAGER_PROMPT_RE = /^\[(\d+)-(\d+) [a-zA-Z.!?+<>\-]+\] \(aktualny: (\d+)\) --\s*$/;
function isPagerPrompt(text) {
  const m = text.match(PAGER_PROMPT_RE);
  if (!m) return null;
  return { lo: Number(m[1]), hi: Number(m[2]), current: Number(m[3]) };
}
function parseNotification(text) {
  const t = stripClientPrefix(text);
  const nowa = t.match(/^Masz nowa poczte od ([A-Za-z]+)\.$/);
  if (nowa) return { kind: "nowa-poczte", nadawca: nowa[1] };
  if (t === "Goniec przyniosl nowa partie listow.") return { kind: "goniec" };
  const wysylasz = t.match(/^Wysylasz ([A-Za-z]+) na poczte\.$/);
  if (wysylasz) return { kind: "wysylasz", zwierze: wysylasz[1] };
  return null;
}
function parseMailError(text) {
  const zly = text.match(/^Zly numer listu: (\d+)\.$/);
  if (zly) return { kind: "zly-numer", numer: Number(zly[1]) };
  const adresat = text.match(/^(?:Adresat: |DW: |Temat: )?Nie ma takiego adresata \(gracza, aliasu\): (.+)\.$/);
  if (adresat) return { kind: "brak-adresata", adresat: adresat[1] };
  if (text === "Zadne listy nie zostaly wybrane.") return { kind: "brak-wyboru" };
  return null;
}
var COMPOSE_ECHO_RE = /^(?:(Adresat|Temat|DW): )+$/;
function parseComposeEcho(text) {
  if (!COMPOSE_ECHO_RE.test(text)) return null;
  const out = [];
  for (const m of text.matchAll(/(Adresat|Temat|DW): /g)) {
    out.push(m[1] === "Adresat" ? "adresat" : m[1] === "Temat" ? "temat" : "dw");
  }
  return out.length ? out : null;
}
var EDITOR_ECHO_RE = /^(\s*\d+\])+/;
var RESULT_WYSLANY = "List zostal pomyslnie wyslany.";
var RESULT_GOTOWY = "List jest gotowy do wyslania.";
function parseEditorEcho(text) {
  const m = text.match(EDITOR_ECHO_RE);
  if (!m) return null;
  const numbers = [...m[0].matchAll(/(\d+)\]/g)].map((x) => Number(x[1]));
  const rest = text.slice(m[0].length);
  let result = null;
  if (rest === RESULT_WYSLANY) result = "wyslany";
  else if (rest === RESULT_GOTOWY) result = "gotowy";
  else if (rest !== "") return null;
  return { consumed: Math.max(...numbers), result };
}
function parseComposeResult(text) {
  if (text === RESULT_WYSLANY) return "wyslany";
  if (text === RESULT_GOTOWY) return "gotowy";
  return null;
}

// src/arkmail/core/protocol/commands.ts
var ROMAN_MONTHS = [
  "I",
  "II",
  "III",
  "IV",
  "V",
  "VI",
  "VII",
  "VIII",
  "IX",
  "X",
  "XI",
  "XII"
];
function olderListingCommand(box, date) {
  const roman = ROMAN_MONTHS[date.month - 1];
  if (!roman) throw new RangeError(`nieprawidlowy miesiac: ${date.month}`);
  return `listy ${box} przed ${date.day} ${roman} ${date.year}`;
}

// src/arkmail/core/contacts.ts
function contactsFromBoxes(boxes, people) {
  const korespondencja = [];
  for (const [box, view] of Object.entries(boxes)) {
    const direction = box === "odebrane" || box === "nieprzeczytane" ? "in" : "out";
    for (const e of view?.entries ?? []) {
      if (!e.party) continue;
      korespondencja.push({
        name: e.party,
        direction,
        dateRaw: e.date?.raw
      });
    }
  }
  return mergeContacts({ people, przedstawieni: [], korespondencja, aliasy: [] });
}
var SOURCE_ORDER = ["people", "przedstawieni", "korespondencja", "alias"];
function mergeContacts(input) {
  const byKey = /* @__PURE__ */ new Map();
  const get = (name) => {
    const key = name.toLowerCase();
    let c = byKey.get(key);
    if (!c) {
      c = { name, sources: [], lettersReceived: 0, lettersSent: 0 };
      byKey.set(key, c);
    }
    return c;
  };
  const addSource = (c, s) => {
    if (!c.sources.includes(s)) c.sources.push(s);
  };
  for (const p of input.people) {
    const c = get(p.name);
    c.name = p.name;
    addSource(c, "people");
    if (p.description) c.description = p.description;
    if (p.guild) c.guild = p.guild;
  }
  for (const name of input.przedstawieni) {
    const c = get(name);
    addSource(c, "przedstawieni");
  }
  for (const k of input.korespondencja) {
    const c = get(k.name);
    addSource(c, "korespondencja");
    if (k.direction === "in") c.lettersReceived++;
    else c.lettersSent++;
    if (k.dateRaw && (!c.lastContactRaw || k.dateRaw > c.lastContactRaw)) {
      c.lastContactRaw = k.dateRaw;
    }
  }
  for (const a of input.aliasy) {
    for (const target of a.targets) {
      const c = get(target);
      addSource(c, "alias");
      if (!c.mailAlias) c.mailAlias = a.name;
    }
  }
  const out = [...byKey.values()];
  for (const c of out) {
    c.sources.sort((x, y) => SOURCE_ORDER.indexOf(x) - SOURCE_ORDER.indexOf(y));
  }
  out.sort((a, b) => a.name.localeCompare(b.name, "pl"));
  return out;
}

// src/arkmail/core/archive.ts
var SENDER_BOXES = /* @__PURE__ */ new Set(["odebrane", "nieprzeczytane"]);
var RECIPIENT_BOXES = /* @__PURE__ */ new Set(["wyslane", "niewyslane"]);
function fnv1a(input) {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16).padStart(8, "0");
}
function sortKeyOf(date) {
  if (!date) return "0000-00-00 00:00:00";
  const p = (n) => String(n).padStart(2, "0");
  return `${date.year}-${p(date.month)}-${p(date.day)} ${date.time}`;
}
function letterId(box, number, party, subject, dateRaw) {
  return fnv1a([box, number, party, subject, dateRaw ?? ""].join("|"));
}
function fromMailboxEntry(box, entry) {
  const dateRaw = entry.date?.raw ?? null;
  return {
    id: letterId(box, entry.number, entry.party, entry.subject, dateRaw),
    box,
    number: entry.number,
    party: entry.party,
    subject: entry.subject,
    dateRaw,
    sortKey: sortKeyOf(entry.date),
    read: entry.isRead,
    body: []
  };
}
function byNewest(a, b) {
  if (a.sortKey !== b.sortKey) return a.sortKey < b.sortKey ? 1 : -1;
  if (a.number !== b.number) return b.number - a.number;
  return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
}
function upsertLetters(existing, incoming) {
  const map = new Map(existing.map((l) => [l.id, l]));
  let added = 0;
  let updated = 0;
  for (const inc of incoming) {
    const prev = map.get(inc.id);
    if (!prev) {
      map.set(inc.id, inc);
      added++;
      continue;
    }
    map.set(inc.id, {
      ...prev,
      ...inc,
      body: inc.body.length > 0 ? inc.body : prev.body
    });
    updated++;
  }
  return { letters: [...map.values()].sort(byNewest), added, updated };
}
var norm = (s) => s.toLowerCase();
function filterLetters(letters, filter) {
  return letters.filter((l) => {
    if (filter.od !== void 0) {
      if (!SENDER_BOXES.has(l.box)) return false;
      if (!norm(l.party).includes(norm(filter.od))) return false;
    }
    if (filter.do !== void 0) {
      if (!RECIPIENT_BOXES.has(l.box)) return false;
      if (!norm(l.party).includes(norm(filter.do))) return false;
    }
    if (filter.temat !== void 0 && !norm(l.subject).includes(norm(filter.temat))) return false;
    if (filter.tresc !== void 0 && !norm(l.body.join("\n")).includes(norm(filter.tresc))) return false;
    if (filter.odDaty !== void 0 && l.sortKey.slice(0, 10) < filter.odDaty) return false;
    if (filter.doDaty !== void 0 && l.sortKey.slice(0, 10) > filter.doDaty) return false;
    return true;
  });
}

// src/arkmail/core/session/lines.ts
function isEchoLine(text) {
  return text.startsWith("\u2192 ") || text === "\u2192";
}
function isPromptLine(text) {
  return /^>+\s*$/.test(text);
}

// src/arkmail/core/session/mailbox.ts
var MailboxSession = class {
  constructor(transport2, opts) {
    this.transport = transport2;
    this.opts = opts;
  }
  /**
   * Pobiera listing skrzynki. command: wlasna komenda (paginacja wstecz
   * "listy <skrzynka> przed <data>", patrz protocol/commands.ts);
   * domyslnie "listy <skrzynka>".
   */
  fetch(box, command) {
    return new Promise((resolve, reject) => {
      let header = null;
      const entries = [];
      let done = false;
      const idleMs = this.opts.idleMs ?? 600;
      let idleTimer = null;
      const cleanup = () => {
        done = true;
        clearTimeout(timer);
        if (idleTimer) clearTimeout(idleTimer);
        unsub();
      };
      const finish = (r) => {
        cleanup();
        resolve(r);
      };
      const armIdle = () => {
        if (idleTimer) clearTimeout(idleTimer);
        idleTimer = setTimeout(() => {
          if (done || !header) return;
          finish({ kind: "lista", header, entries });
        }, idleMs);
      };
      const timer = setTimeout(() => {
        cleanup();
        reject(new Error(`timeout: mailbox fetch ${box}`));
      }, this.opts.timeoutMs);
      const unsub = this.transport.subscribe((line) => {
        if (done) return;
        if (!header) {
          if (line.cls === "command" || isEchoLine(line.text)) return;
          const empty = parseEmptyListing(line.text);
          if (empty) {
            finish({ kind: "pusta", box: empty.box, reason: empty.reason });
            return;
          }
          const h = parseListingHeader(line.text);
          if (h) {
            header = h;
            armIdle();
          }
          return;
        }
        if (line.cls === "prompt" || line.cls === "command" || isPromptLine(line.text) || isEchoLine(line.text)) {
          finish({ kind: "lista", header, entries });
          return;
        }
        armIdle();
        const entry = parseListingEntry(line.text);
        if (entry) {
          entries.push({ ...entry, party: "", partyKind: null, date: null });
          return;
        }
        const party = parseListingParty(line.text);
        if (party && entries.length > 0) {
          const last = entries[entries.length - 1];
          last.party = party.names;
          last.partyKind = party.kind;
          last.date = party.date;
        }
      });
      this.transport.send(command ?? `listy ${box}`);
    });
  }
};

// src/arkmail/core/session/pager.ts
var PagerSession = class {
  constructor(transport2, opts) {
    this.transport = transport2;
    this.opts = opts;
  }
  readLetter(numer) {
    return this.run(numer, () => null, (letter, pager) => ({ letter, pager }));
  }
  deleteLetters(numer, zakres) {
    let deletedNumbers = [];
    return this.run(
      numer,
      (ctx) => ({
        onPager: () => ctx.send(`d ${zakres}`),
        onLine: (line) => {
          const m = line.text.match(/^Zaznaczono do skasowania: ([\d, ]+)\.$/);
          if (m) {
            deletedNumbers = m[1].split(",").map((s) => Number(s.trim())).filter((n) => !Number.isNaN(n));
          }
          return m ? "close" : void 0;
        }
      }),
      () => ({ deleted: deletedNumbers.length > 0, deletedNumbers })
    );
  }
  forwardLetter(numer, adresat) {
    let queued = false;
    let error = null;
    let dwAnswered = false;
    return this.run(
      numer,
      (ctx) => ({
        onPager: () => ctx.send(`f ${adresat}`),
        onLine: (line) => {
          const err = parseMailError(line.text);
          if (err && err.kind === "brak-adresata") {
            if (!error) error = err;
            return void 0;
          }
          if (/^DW: *$/.test(line.text)) {
            if (!dwAnswered) {
              dwAnswered = true;
              ctx.send("");
            }
            return void 0;
          }
          if (line.text === "List jest gotowy do wyslania.") {
            queued = true;
            return "close";
          }
          return void 0;
        }
      }),
      () => ({ queued, error })
    );
  }
  /**
   * Otwiera pager na liscie `numer`, wykonuje akcje, zamyka "q".
   * onPager: odpalane przy pierwszym pager prompt (wyslij akcje).
   * onLine: moze zwrocic 'close' -> wysylamy "q" przy najblizszym
   * pager prompcie. Konczy sie na linii promptu (klasa albo tresc)
   * albo idle-flush po "q".
   */
  run(numer, makeActions, build) {
    return new Promise((resolve, reject) => {
      const letter = {
        number: numer,
        from: "",
        subject: "",
        to: "",
        cc: null,
        date: null,
        body: []
      };
      let pager = { lo: 0, hi: 0, current: numer };
      let state = "letter";
      let headersDone = false;
      let wantClose = false;
      let pagerFired = false;
      let done = false;
      const idleMs = this.opts.idleMs ?? 600;
      let idleTimer = null;
      const actions = makeActions({ send: (l) => this.transport.send(l) });
      const cleanup = () => {
        done = true;
        clearTimeout(timer);
        if (idleTimer) clearTimeout(idleTimer);
        unsub();
      };
      const finish = () => {
        cleanup();
        resolve(build(letter, pager));
      };
      const armIdle = () => {
        if (idleTimer) clearTimeout(idleTimer);
        idleTimer = setTimeout(() => {
          if (!done && state === "closing") finish();
        }, idleMs);
      };
      const timer = setTimeout(() => {
        cleanup();
        reject(new Error(`timeout: pager session list ${numer}`));
      }, this.opts.timeoutMs);
      const enterClosing = () => {
        wantClose = false;
        state = "closing";
        this.transport.send("q");
        armIdle();
      };
      const unsub = this.transport.subscribe((line) => {
        if (done || line.cls === "command" || isEchoLine(line.text)) return;
        if (state === "closing") {
          if (line.cls === "prompt" || isPromptLine(line.text)) {
            finish();
            return;
          }
          armIdle();
          return;
        }
        const pp = isPagerPrompt(line.text);
        if (pp) {
          pager = pp;
          state = "pager";
          if (pagerFired && wantClose) {
            enterClosing();
            return;
          }
          if (!pagerFired) {
            pagerFired = true;
            if (actions && actions.onPager) {
              actions.onPager();
              return;
            }
            enterClosing();
            return;
          }
          return;
        }
        if (state === "letter" && !headersDone) {
          const h = parseLetterHeaderLine(line.text);
          if (h) {
            if (h.field === "numer") letter.number = Number(h.value);
            else if (h.field === "od") letter.from = h.value;
            else if (h.field === "temat") letter.subject = h.value;
            else if (h.field === "do") letter.to = h.value;
            else if (h.field === "dw") letter.cc = h.value;
            else if (h.field === "data") {
              letter.date = h.value;
              headersDone = true;
            }
            return;
          }
          return;
        }
        if (state === "letter") {
          letter.body.push(line.text);
          return;
        }
        if (actions && actions.onLine) {
          const verdict = actions.onLine(line);
          if (verdict === "close") wantClose = true;
        }
      });
      this.transport.send(`przeczytaj list ${numer}`);
    });
  }
};

// src/arkmail/core/session/editor.ts
var EditorSession = class {
  constructor(transport2, opts) {
    this.transport = transport2;
    this.opts = opts;
  }
  send(input) {
    return new Promise((resolve) => {
      let stage = "adresat";
      let done = false;
      const dw = input.dw ?? "";
      const cleanup = () => {
        done = true;
        clearTimeout(timer);
        unsub();
      };
      const finish = (r) => {
        cleanup();
        resolve(r);
      };
      const timer = setTimeout(() => {
        cleanup();
        resolve({ result: "blad", error: { kind: "timeout" } });
      }, this.opts.timeoutMs);
      const flush = (confirmed) => {
        const order = ["adresat", "temat", "dw"];
        for (const c of confirmed) {
          const idx = order.indexOf(c);
          const cur = order.indexOf(stage);
          if (idx < cur) continue;
          if (c === "adresat") {
          } else if (c === "temat") {
            this.transport.send(input.temat);
          } else if (c === "dw") {
            this.transport.send(dw);
          }
          stage = order[idx + 1] ?? "tresc";
        }
        if (stage === "tresc") {
          for (const linia of input.linie) this.transport.send(linia);
          this.transport.send("**");
          stage = "tresc-wyslana";
        }
      };
      const unsub = this.transport.subscribe((line) => {
        if (done || line.cls === "command" || isEchoLine(line.text)) return;
        const err = parseMailError(line.text);
        if (err) {
          finish({ result: "blad", error: err });
          return;
        }
        const standalone = parseComposeResult(line.text);
        if (standalone) {
          finish({ result: standalone });
          return;
        }
        const echo = parseEditorEcho(line.text);
        if (echo?.result) {
          finish({ result: echo.result });
          return;
        }
        if (stage === "tresc-wyslana") return;
        const prompts = parseComposeEcho(line.text);
        if (prompts) {
          flush(prompts);
        }
      });
      this.transport.send("napisz list");
      this.transport.send(input.adresat);
    });
  }
};

// src/arkmail/core/sessionLock.ts
var SessionLock = class {
  constructor() {
    __publicField(this, "tail", Promise.resolve());
    __publicField(this, "active", 0);
  }
  /** true, gdy ktokolwiek trzyma blokade lub czeka w kolejce. */
  get locked() {
    return this.active > 0;
  }
  /** Czeka na swoja kolej i zwraca funkcje zwalniajaca (idempotentna). */
  async acquire() {
    this.active++;
    let releaseNext;
    const next = new Promise((resolve) => {
      releaseNext = resolve;
    });
    const prev = this.tail;
    this.tail = prev.then(() => next);
    await prev;
    let released = false;
    return () => {
      if (released) return;
      released = true;
      this.active--;
      releaseNext();
    };
  }
  /** Wykonuje fn pod blokada; zwalnia takze przy rzuceniu wyjatku. */
  async runExclusive(fn) {
    const release = await this.acquire();
    try {
      return await fn();
    } finally {
      release();
    }
  }
};

// src/arkmail/adapters/dargothTransport.ts
var MODAL_HOOK_PRIORITY = 100;
var DargothTransport = class {
  constructor(api) {
    this.api = api;
    __publicField(this, "subscribers", /* @__PURE__ */ new Set());
    __publicField(this, "triggerArmed", false);
    __publicField(this, "modalActive", false);
    __publicField(this, "hookId", null);
    __publicField(this, "queue", []);
    __publicField(this, "bypass", /* @__PURE__ */ new Set());
  }
  send(line) {
    if (this.modalActive) this.bypass.add(line);
    void this.api.command.send(line, false);
  }
  subscribe(cb) {
    this.armTrigger();
    this.subscribers.add(cb);
    return () => {
      this.subscribers.delete(cb);
    };
  }
  /** Liczba komend gracza odlozonych w trakcie sesji modalnej. */
  get modalQueueLength() {
    return this.queue.length;
  }
  beginModal() {
    if (this.modalActive) return;
    this.modalActive = true;
    this.hookId = this.api.commandHooks.register((command) => {
      if (this.bypass.delete(command)) return void 0;
      this.queue.push(command);
      return null;
    }, MODAL_HOOK_PRIORITY);
  }
  endModal() {
    if (!this.modalActive) return;
    this.modalActive = false;
    if (this.hookId !== null) {
      this.api.commandHooks.unregister(this.hookId);
      this.hookId = null;
    }
    this.bypass.clear();
    const pending = this.queue.splice(0);
    for (const command of pending) void this.api.command.send(command);
  }
  /** Zdejmuje trigger i modal-guard; do wywolania w destroy() pluginu. */
  dispose() {
    this.endModal();
    if (this.triggerArmed) {
      this.api.triggers.removeByTag("arkmail");
      this.triggerArmed = false;
    }
    this.subscribers.clear();
    this.queue = [];
    this.bypass.clear();
  }
  armTrigger() {
    if (this.triggerArmed) return;
    this.triggerArmed = true;
    this.api.triggers.register(
      /^/,
      (line, _matches, type) => {
        const proto = { text: line.text, cls: type ?? "" };
        for (const cb of [...this.subscribers]) cb(proto);
        return line;
      },
      "arkmail"
    );
  }
};

// src/arkmail/adapters/storage.ts
var CharStorage = class {
  constructor(kv) {
    this.kv = kv;
    __publicField(this, "char", "_unknown");
  }
  setCharacter(name) {
    const normalized = name.trim().toLowerCase();
    if (normalized) this.char = normalized;
  }
  get character() {
    return this.char;
  }
  getJSON(key) {
    const raw = this.kv.getItem(this.scoped(key));
    if (raw === null) return null;
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }
  setJSON(key, value) {
    this.kv.setItem(this.scoped(key), JSON.stringify(value));
  }
  remove(key) {
    this.kv.removeItem(this.scoped(key));
  }
  scoped(key) {
    return `arkmail.${this.char}.${key}`;
  }
};

// src/arkmail/adapters/notify.ts
function notify(api, text, opts = {}) {
  api.events.emit("notify", opts.time !== void 0 ? { text, time: opts.time } : { text });
}

// src/arkmail/ui/store.ts
var DEFAULT_STATE = {
  tab: "listy",
  wide: false,
  activeBox: "odebrane",
  boxes: {},
  badge: 0,
  busy: null,
  letter: null,
  contacts: [],
  archive: [],
  notifyEnabled: false,
  composeTemplate: "plain",
  composeWidth: 60
};
var MailUiStore = class {
  constructor(initial) {
    __publicField(this, "current");
    __publicField(this, "listeners", /* @__PURE__ */ new Set());
    this.current = { ...DEFAULT_STATE, ...initial };
  }
  get state() {
    return this.current;
  }
  subscribe(cb) {
    this.listeners.add(cb);
    return () => {
      this.listeners.delete(cb);
    };
  }
  setTab(tab) {
    this.update({ tab });
  }
  setWide(wide) {
    this.update({ wide });
  }
  setActiveBox(box) {
    this.update({ activeBox: box });
  }
  applyMailbox(box, result) {
    const view = result.kind === "lista" ? { entries: result.entries, truncated: result.header.truncated, empty: null } : { entries: [], truncated: false, empty: result.reason };
    const boxes = { ...this.current.boxes, [box]: view };
    this.update({ boxes, badge: computeBadge(boxes) });
  }
  setBusy(label) {
    this.update({ busy: label });
  }
  /** Otwiera list: waski -> zakladka 'list', szeroki -> zostaje w podziale. */
  openLetter(box, letter) {
    const next = { letter: { ...letter, box } };
    if (!this.current.wide) next.tab = "list";
    this.update(next);
  }
  closeLetter() {
    this.update({ letter: null, tab: "listy" });
  }
  setContacts(contacts) {
    this.update({ contacts });
  }
  setArchive(archive) {
    this.update({ archive });
  }
  setNotifyEnabled(notifyEnabled) {
    this.update({ notifyEnabled });
  }
  setCompose(prefs) {
    const patch = {};
    if (prefs.template !== void 0) patch.composeTemplate = prefs.template;
    if (prefs.width !== void 0) patch.composeWidth = prefs.width;
    this.update(patch);
  }
  update(patch) {
    this.current = { ...this.current, ...patch };
    for (const cb of [...this.listeners]) cb(this.current);
  }
};
function computeBadge(boxes) {
  const unread = boxes.nieprzeczytane;
  if (unread) return unread.entries.length;
  const odebrane = boxes.odebrane;
  if (odebrane) return odebrane.entries.filter((e) => !e.isRead).length;
  return 0;
}

// src/arkmail/core/letterRender.ts
var MIN_LINE_WIDTH = 20;
var MAX_LINE_WIDTH = 120;
var DEFAULT_LINE_WIDTH = 60;
function clampLineWidth(width) {
  const rounded = Math.round(width);
  return Math.min(MAX_LINE_WIDTH, Math.max(MIN_LINE_WIDTH, rounded));
}
function normalizeLine(line) {
  return line.replace(/\s+/g, " ").trim();
}
function splitLongWord(word, width) {
  const parts = [];
  for (let i = 0; i < word.length; i += width) {
    parts.push(word.slice(i, i + width));
  }
  return parts;
}
var DEFAULT_LETTER_ALIGNMENT = "justify";
function justifyWords(words, lettersLength, width) {
  if (words.length === 1) {
    return words[0];
  }
  const gaps = words.length - 1;
  const totalSpaces = width - lettersLength;
  const baseSpace = Math.max(1, Math.floor(totalSpaces / gaps));
  let extra = totalSpaces - baseSpace * gaps;
  let line = words[0];
  for (let i = 1; i < words.length; i += 1) {
    let spaces = baseSpace;
    if (extra > 0) {
      spaces += 1;
      extra -= 1;
    }
    line += " ".repeat(spaces) + words[i];
  }
  return line;
}
function alignWords(words, width, alignment, isLastLine) {
  if (alignment === "justify" && !isLastLine) {
    return justifyWords(words, words.reduce((sum, word) => sum + word.length, 0), width);
  }
  const text = words.join(" ");
  if (alignment === "right") {
    return text.padStart(width, " ");
  }
  if (alignment === "center") {
    return " ".repeat(Math.max(0, Math.floor((width - text.length) / 2))) + text;
  }
  return text;
}
function wrapWords(normalizedLine, width) {
  if (!normalizedLine) {
    return [];
  }
  const groups = [];
  let currentWords = [];
  let lettersLength = 0;
  const flush = () => {
    if (currentWords.length) {
      groups.push(currentWords);
    }
    currentWords = [];
    lettersLength = 0;
  };
  normalizedLine.split(" ").forEach((word) => {
    if (word.length > width) {
      flush();
      const parts = splitLongWord(word, width);
      const lastPart = parts.pop();
      parts.forEach((part) => groups.push([part]));
      if (lastPart) {
        currentWords = [lastPart];
        lettersLength = lastPart.length;
      }
      return;
    }
    const minimalSpaces = currentWords.length;
    if (lettersLength + word.length + minimalSpaces > width && currentWords.length) {
      flush();
    }
    currentWords.push(word);
    lettersLength += word.length;
  });
  flush();
  return groups;
}
function wrapLine(line, width, letterAlignment) {
  const alignRight = line.startsWith(">");
  const alignment = alignRight ? "right" : letterAlignment;
  const groups = wrapWords(normalizeLine(alignRight ? line.slice(1) : line), width);
  return groups.map((words, index) => alignWords(words, width, alignment, index === groups.length - 1));
}
function formatContent(content, width, alignment) {
  const rawLines = content.split(/\r?\n/);
  const result = [];
  let pendingBlankLine = false;
  let hasContent = false;
  rawLines.forEach((line) => {
    const wrapped = wrapLine(normalizeLine(line), width, alignment);
    if (!wrapped.length) {
      if (hasContent) {
        pendingBlankLine = true;
      }
      return;
    }
    if (pendingBlankLine && result.length) {
      result.push("");
      pendingBlankLine = false;
    }
    result.push(...wrapped);
    hasContent = true;
  });
  return result;
}
var FILL_PATTERN = /\{([^{}]+)\}/g;
function expandFillLine(line, width) {
  return line.replace(FILL_PATTERN, (_match, pattern) => pattern.repeat(Math.ceil(width / pattern.length)).slice(0, width));
}
function splitBodyPattern(pattern) {
  const lines = pattern.split(/\r?\n/);
  while (lines.length > 1 && lines[lines.length - 1] === "") {
    lines.pop();
  }
  return lines;
}
function longestLength(lines) {
  return lines.reduce((max, line) => Math.max(max, line.length), 0);
}
function getLayoutBodyWidth(layout, totalWidth) {
  if (layout.raw) {
    return Infinity;
  }
  const prefixWidth = longestLength(splitBodyPattern(layout.bodyPrefix));
  const suffixWidth = longestLength(splitBodyPattern(layout.bodySuffix));
  return Math.max(1, totalWidth - prefixWidth - suffixWidth);
}
function formatBody(layout, lines, width) {
  if (layout.raw) {
    return [...lines];
  }
  const prefixes = splitBodyPattern(layout.bodyPrefix);
  const suffixes = splitBodyPattern(layout.bodySuffix);
  const prefixWidth = longestLength(prefixes);
  const framed = prefixWidth > 0 || longestLength(suffixes) > 0;
  return lines.map((line, index) => {
    const trimmed = line.length > width ? line.slice(0, width) : line;
    if (!framed) {
      return trimmed.trimEnd();
    }
    const prefix = prefixes[index % prefixes.length].padEnd(prefixWidth, " ");
    const suffix = suffixes[index % suffixes.length];
    return `${prefix}${trimmed.padEnd(width, " ")}${suffix}`;
  });
}
var BUILTIN_LETTER_LAYOUTS = {
  none: {
    header: [],
    footer: [],
    bodyPrefix: "",
    bodySuffix: ""
  },
  plain: {
    header: [
      " +--{-}--+ ",
      " |  { }  | ",
      " |  { }  | "
    ],
    footer: [
      " |  { }  | ",
      " |  { }  | ",
      " +--{-}--+ "
    ],
    bodyPrefix: " |  ",
    bodySuffix: "  | "
  },
  parchment: {
    header: [
      "  ____{_}___  ",
      "/ \\   { }   \\.",
      "|  |  { }   |.",
      "\\_ |  { }   |.",
      "   |  { }   |."
    ],
    footer: [
      "   |  { }   |.   ",
      "   |   {_}__|___ ",
      "   |  /{ }     /.",
      "   \\_/_{_}____/. "
    ],
    bodyPrefix: "   |   ",
    bodySuffix: "  |."
  },
  parchment2: {
    header: [
      " ______{_}_____  ",
      " / _\\  { }     \\ ",
      "|/ >|  { }     | ",
      " |\\_/__{_}______/",
      " \\.    { }   ./  ",
      " |     { }   |   "
    ],
    footer: [
      " |  ___{_}___|   ",
      " |/\\   { }     \\ ",
      " \\_|   { }      |",
      "  \\_/_ {_}_____/ "
    ],
    bodyPrefix: " |     ",
    bodySuffix: "   |   "
  },
  parchment3: {
    header: [
      "             { }  .---.   ",
      "             { } /  .  \\ ",
      "             { }|\\_/|   |",
      "             { }|   |  /| ",
      "   .---------{-}-------'|",
      "  /  .-.     { }        | ",
      " |  /   \\   { }         |",
      " | |\\_.  |  { }         |",
      " |\\|  | /|  { }         |",
      " | `---' |  { }         |"
    ],
    footer: [
      " |       |   { }        /   ",
      " |       |---{-}--------' ",
      " \\       |  { }            ",
      " \\.___./    { }            "
    ],
    bodyPrefix: " |       |   ",
    bodySuffix: "        | "
  },
  raw: {
    header: [],
    footer: [],
    bodyPrefix: "",
    bodySuffix: "",
    raw: true
  }
};
function renderLetterLayout(content, layout, lineWidth = DEFAULT_LINE_WIDTH, alignment = DEFAULT_LETTER_ALIGNMENT) {
  const bodyWidth = getLayoutBodyWidth(layout, lineWidth);
  const baseLines = layout.raw ? content.split(/\r?\n/) : formatContent(content, bodyWidth, alignment);
  const bodySource = baseLines.length ? baseLines : [""];
  const lines = [
    ...layout.header.map((line) => expandFillLine(line, bodyWidth)),
    ...formatBody(layout, bodySource, bodyWidth),
    ...layout.footer.map((line) => expandFillLine(line, bodyWidth))
  ];
  const hasContent = baseLines.some((line) => line.length > 0);
  return { lines, hasContent };
}
function renderLetter(content, template, lineWidth = DEFAULT_LINE_WIDTH, alignment = DEFAULT_LETTER_ALIGNMENT) {
  return renderLetterLayout(content, BUILTIN_LETTER_LAYOUTS[template], lineWidth, alignment);
}

// src/arkmail/ui/styles.ts
var STYLES = `
.arkmail-root {
  container-type: inline-size;
  display: flex;
  flex-direction: column;
  height: 100%;
  font-size: 13px;
  color: inherit;
}
.arkmail-tabs { display: flex; gap: 2px; flex-wrap: wrap; margin-bottom: 6px; }
.arkmail-tab {
  padding: 4px 10px;
  border: 1px solid rgba(128, 128, 128, 0.4);
  border-radius: 4px;
  cursor: pointer;
  background: transparent;
  color: inherit;
  font: inherit;
}
.arkmail-tab-active { font-weight: bold; border-color: currentColor; }
.arkmail-busy {
  padding: 3px 8px;
  margin-bottom: 4px;
  border: 1px dashed rgba(128, 128, 128, 0.6);
  border-radius: 4px;
  opacity: 0.85;
}
.arkmail-pane { flex: 1; overflow: auto; min-height: 0; }
.arkmail-boxes { display: flex; gap: 2px; margin-bottom: 4px; flex-wrap: wrap; }
.arkmail-box {
  padding: 2px 8px;
  border: 1px solid rgba(128, 128, 128, 0.3);
  border-radius: 3px;
  cursor: pointer;
  background: transparent;
  color: inherit;
  font: inherit;
}
.arkmail-box-active { font-weight: bold; border-color: currentColor; }
.arkmail-entry {
  padding: 2px 4px;
  cursor: pointer;
  border-radius: 3px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.arkmail-entry:hover { background: rgba(128, 128, 128, 0.15); }
.arkmail-unread { font-weight: bold; }
.arkmail-entry-party { opacity: 0.75; }
.arkmail-older { margin-top: 6px; font: inherit; cursor: pointer; }
.arkmail-letter-head { margin-bottom: 6px; opacity: 0.9; }
.arkmail-letter-body { white-space: pre-wrap; font-family: inherit; }
.arkmail-form label { display: block; margin: 4px 0 2px; }
.arkmail-form input, .arkmail-form textarea {
  width: 100%;
  box-sizing: border-box;
  font: inherit;
  color: inherit;
  background: rgba(128, 128, 128, 0.08);
  border: 1px solid rgba(128, 128, 128, 0.4);
  border-radius: 3px;
  padding: 3px 6px;
}
.arkmail-form textarea { min-height: 120px; resize: vertical; }
.arkmail-send { margin-top: 8px; font: inherit; cursor: pointer; padding: 4px 14px; }
.arkmail-contact, .arkmail-arch-entry { padding: 2px 4px; }
.arkmail-dim { opacity: 0.65; }
.arkmail-split { display: block; }
@container (min-width: 900px) {
  .arkmail-split {
    display: grid;
    grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
    gap: 10px;
    flex: 1;
    min-height: 0;
  }
}
`;

// src/arkmail/ui/render.ts
var TEMPLATES = [
  ["none", "Bez ramki"],
  ["plain", "Prosta ramka"],
  ["parchment", "Pergamin"],
  ["parchment2", "Pergamin II"],
  ["parchment3", "Pergamin III"],
  ["raw", "Surowy (jak wpisane)"]
];
var TABS = [
  ["listy", "Listy"],
  ["list", "List"],
  ["napisz", "Napisz list"],
  ["kontakty", "Kontakty"],
  ["archiwum", "Archiwum"]
];
var BOXES = [
  ["odebrane", "Odebrane"],
  ["nieprzeczytane", "Nieprzeczytane"],
  ["wyslane", "Wys\u0142ane"],
  ["niewyslane", "Niewys\u0142ane"]
];
function mountMailUi(container, store2, handlers) {
  const doc = container.ownerDocument;
  const style = doc.createElement("style");
  style.textContent = STYLES;
  container.appendChild(style);
  const root = doc.createElement("div");
  container.appendChild(root);
  const archFilter = {};
  const render = (state) => {
    root.className = "arkmail-root" + (state.wide ? " arkmail-wide" : "");
    const nodes = [renderTabs(state)];
    if (state.busy !== null) nodes.push(renderBusy(state.busy));
    if (state.wide && state.tab === "listy" && state.letter) {
      const split = doc.createElement("div");
      split.className = "arkmail-split";
      split.appendChild(renderListy(state));
      split.appendChild(renderList(state));
      nodes.push(split);
    } else {
      nodes.push(renderPane(state));
    }
    root.replaceChildren(...nodes);
  };
  const renderTabs = (state) => {
    const bar = doc.createElement("div");
    bar.className = "arkmail-tabs";
    for (const [id, label] of TABS) {
      const btn = doc.createElement("button");
      btn.className = "arkmail-tab" + (state.tab === id ? " arkmail-tab-active" : "");
      btn.setAttribute("data-tab", id);
      btn.textContent = id === "listy" && state.badge > 0 ? `${label} (${state.badge})` : label;
      btn.addEventListener("click", () => store2.setTab(id));
      bar.appendChild(btn);
    }
    return bar;
  };
  const renderBusy = (label) => {
    const el = doc.createElement("div");
    el.className = "arkmail-busy";
    el.textContent = `Operacja pocztowa w toku: ${label}`;
    return el;
  };
  const renderPane = (state) => {
    switch (state.tab) {
      case "listy":
        return renderListy(state);
      case "list":
        return renderList(state);
      case "napisz":
        return renderNapisz(state);
      case "kontakty":
        return renderKontakty(state);
      case "archiwum":
        return renderArchiwum(state);
    }
  };
  const renderListy = (state) => {
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane";
    const boxes = doc.createElement("div");
    boxes.className = "arkmail-boxes";
    for (const [box, label] of BOXES) {
      const btn = doc.createElement("button");
      btn.className = "arkmail-box" + (state.activeBox === box ? " arkmail-box-active" : "");
      btn.setAttribute("data-box", box);
      btn.textContent = label;
      btn.addEventListener("click", () => {
        store2.setActiveBox(box);
        handlers.onRefreshBox(box);
      });
      boxes.appendChild(btn);
    }
    pane.appendChild(boxes);
    const notifyRow = doc.createElement("label");
    notifyRow.className = "arkmail-dim";
    const chk = doc.createElement("input");
    chk.setAttribute("type", "checkbox");
    chk.className = "arkmail-notify-toggle";
    chk.checked = state.notifyEnabled;
    chk.addEventListener("click", () => store2.setNotifyEnabled(!store2.state.notifyEnabled));
    notifyRow.appendChild(chk);
    notifyRow.appendChild(doc.createTextNode(" Powiadom o nowej poczcie (tost)"));
    pane.appendChild(notifyRow);
    const view = state.boxes[state.activeBox];
    if (!view) {
      pane.appendChild(dim("Skrzynka nie zaladowana - kliknij jej nazwe, aby pobrac."));
      return pane;
    }
    if (view.empty !== null) {
      pane.appendChild(dim(view.empty === "puste" ? "Skrzynka pusta." : "Brak pasujacych listow."));
      return pane;
    }
    for (const e of view.entries) {
      const row = doc.createElement("div");
      row.className = "arkmail-entry" + (e.isRead ? "" : " arkmail-unread");
      row.setAttribute("data-number", String(e.number));
      const dateTxt = e.date ? ` [${e.date.raw}]` : "";
      row.textContent = `${e.number}. ${e.subject} `;
      const party = doc.createElement("span");
      party.className = "arkmail-entry-party";
      party.textContent = `\u2014 ${e.party}${dateTxt}`;
      row.appendChild(party);
      row.addEventListener("click", () => handlers.onOpenLetter(state.activeBox, e.number));
      pane.appendChild(row);
    }
    if (view.truncated) {
      const btn = doc.createElement("button");
      btn.className = "arkmail-older";
      btn.textContent = "Wczytaj starsze";
      btn.addEventListener("click", () => handlers.onLoadOlder(state.activeBox));
      pane.appendChild(btn);
    }
    return pane;
  };
  const renderList = (state) => {
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane";
    const l = state.letter;
    if (!l) {
      pane.appendChild(dim("Nie otwarto zadnego listu."));
      return pane;
    }
    const head = doc.createElement("div");
    head.className = "arkmail-letter-head";
    head.textContent = `List ${l.number} \u2014 Od: ${l.from} \u2014 Do: ${l.to}` + (l.cc ? ` \u2014 DW: ${l.cc}` : "") + (l.date ? ` \u2014 ${l.date}` : "") + ` \u2014 Temat: ${l.subject}`;
    pane.appendChild(head);
    const body = doc.createElement("div");
    body.className = "arkmail-letter-body";
    body.textContent = l.body.join("\n");
    pane.appendChild(body);
    const ops = doc.createElement("div");
    ops.className = "arkmail-letter-ops";
    const del = doc.createElement("button");
    del.className = "arkmail-del";
    del.textContent = "Usu\u0144";
    del.addEventListener("click", () => handlers.onDeleteLetter(l.box, l.number));
    ops.appendChild(del);
    const fwdInput = doc.createElement("input");
    fwdInput.setAttribute("data-field", "forward");
    fwdInput.setAttribute("placeholder", "Przeka\u017C do (gracz/alias)");
    ops.appendChild(fwdInput);
    const fwd = doc.createElement("button");
    fwd.className = "arkmail-fwd";
    fwd.textContent = "Przeka\u017C";
    fwd.addEventListener("click", () => {
      const adresat = fwdInput.value.trim();
      if (adresat) handlers.onForwardLetter(l.box, l.number, adresat);
    });
    ops.appendChild(fwd);
    pane.appendChild(ops);
    if (!state.wide) {
      const back = doc.createElement("button");
      back.className = "arkmail-older";
      back.textContent = "Zamknij list";
      back.addEventListener("click", () => handlers.onCloseLetter());
      pane.appendChild(back);
    }
    return pane;
  };
  const composeDraft = { adresat: "", temat: "", dw: "", tresc: "" };
  const renderNapisz = (state) => {
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane arkmail-form";
    const fields = [
      ["adresat", "Adresat"],
      ["temat", "Temat"],
      ["dw", "DW (opcjonalnie)"]
    ];
    for (const [field, label] of fields) {
      const lab2 = doc.createElement("label");
      lab2.textContent = label;
      pane.appendChild(lab2);
      const input = doc.createElement("input");
      input.setAttribute("data-field", field);
      input.value = composeDraft[field];
      input.addEventListener("input", () => {
        composeDraft[field] = input.value;
      });
      pane.appendChild(input);
    }
    const labSz = doc.createElement("label");
    labSz.textContent = "Szablon";
    pane.appendChild(labSz);
    const sel = doc.createElement("select");
    sel.setAttribute("data-field", "szablon");
    for (const [value, label] of TEMPLATES) {
      const opt = doc.createElement("option");
      opt.setAttribute("value", value);
      opt.textContent = label;
      sel.appendChild(opt);
    }
    sel.value = state.composeTemplate;
    sel.addEventListener("change", () => {
      store2.setCompose({ template: sel.value });
    });
    pane.appendChild(sel);
    const labW = doc.createElement("label");
    labW.textContent = "Szeroko\u015B\u0107 linii (20-120)";
    pane.appendChild(labW);
    const width = doc.createElement("input");
    width.setAttribute("data-field", "szerokosc");
    width.value = String(state.composeWidth);
    width.addEventListener("change", () => {
      const parsed = Number.parseInt(width.value, 10);
      store2.setCompose({
        width: Number.isFinite(parsed) ? clampLineWidth(parsed) : 60
      });
    });
    pane.appendChild(width);
    const lab = doc.createElement("label");
    lab.textContent = "Tre\u015B\u0107";
    pane.appendChild(lab);
    const tresc = doc.createElement("textarea");
    tresc.setAttribute("data-field", "tresc");
    tresc.value = composeDraft.tresc;
    pane.appendChild(tresc);
    const labP = doc.createElement("label");
    labP.textContent = "Podgl\u0105d (tak list wyjedzie do gry)";
    pane.appendChild(labP);
    const preview = doc.createElement("pre");
    preview.className = "arkmail-preview";
    pane.appendChild(preview);
    const repaint = () => {
      const st = store2.state;
      preview.textContent = renderLetter(
        tresc.value,
        st.composeTemplate,
        st.composeWidth
      ).lines.join("\n");
    };
    tresc.addEventListener("input", () => {
      composeDraft.tresc = tresc.value;
      repaint();
    });
    repaint();
    const send = doc.createElement("button");
    send.className = "arkmail-send";
    send.textContent = "Wy\u015Blij";
    send.addEventListener("click", () => {
      const st = store2.state;
      const rendered = renderLetter(tresc.value, st.composeTemplate, st.composeWidth);
      if (!rendered.hasContent) return;
      const val = (f) => pane.querySelector(`[data-field="${f}"]`).value;
      handlers.onSendCompose({
        adresat: val("adresat"),
        temat: val("temat"),
        dw: val("dw"),
        linie: rendered.lines
      });
    });
    pane.appendChild(send);
    return pane;
  };
  const renderKontakty = (state) => {
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane";
    if (state.contacts.length === 0) {
      pane.appendChild(dim("Brak kontaktow - pojawia sie po pobraniu listingow."));
      return pane;
    }
    for (const c of state.contacts) {
      const row = doc.createElement("div");
      row.className = "arkmail-contact";
      const stats = `(odebrane: ${c.lettersReceived}, wyslane: ${c.lettersSent})`;
      row.textContent = `${c.name} ${stats}${c.mailAlias ? ` alias: ${c.mailAlias}` : ""}`;
      pane.appendChild(row);
    }
    return pane;
  };
  const renderArchiwum = (state) => {
    const pane = doc.createElement("div");
    pane.className = "arkmail-pane";
    const lab = doc.createElement("label");
    lab.textContent = "Filtr tematu";
    pane.appendChild(lab);
    const input = doc.createElement("input");
    input.setAttribute("data-filter", "temat");
    input.value = archFilter.temat ?? "";
    const list = doc.createElement("div");
    pane.appendChild(input);
    pane.appendChild(list);
    const repaint = () => {
      const rows = filterLetters(state.archive, archFilter);
      list.replaceChildren(
        ...rows.map((l) => {
          const row = doc.createElement("div");
          row.className = "arkmail-arch-entry";
          row.textContent = `${l.number}. ${l.subject} \u2014 ${l.party} [${l.box}]`;
          return row;
        })
      );
      if (rows.length === 0) {
        list.replaceChildren(dim("Archiwum puste albo filtr niczego nie trafia."));
      }
    };
    input.addEventListener("input", () => {
      archFilter.temat = input.value === "" ? void 0 : input.value;
      repaint();
    });
    repaint();
    return pane;
  };
  const dim = (text) => {
    const el = doc.createElement("div");
    el.className = "arkmail-dim";
    el.textContent = text;
    return el;
  };
  const off = store2.subscribe(render);
  render(store2.state);
  return () => {
    off();
    container.replaceChildren();
  };
}

// src/arkmail/index.ts
var POPUP_ID = "arkmail";
var FOOTER_BUTTON_ID = "arkmail";
var FOOTER_STATE = "arkmail-poczta";
var ALIAS_REGEX = /^\/arkmail$/i;
var SESSION_OPTS = { timeoutMs: 8e3, idleMs: 400 };
var ARCHIVE_KEY = "archiwum";
var NOTIFY_KEY = "powiadomienia";
var COMPOSE_KEY = "compose";
function memoryKv() {
  const map = /* @__PURE__ */ new Map();
  return {
    getItem: (k) => map.has(k) ? map.get(k) : null,
    setItem: (k, v) => void map.set(k, v),
    removeItem: (k) => void map.delete(k)
  };
}
var apiRef = null;
var popup = null;
var menuHandle = null;
var footerHandle = null;
var aliasId = null;
var transport = null;
var store = null;
var unmount = null;
var unsubBadge = null;
function createContent() {
  const root = document.createElement("div");
  if (unmount) {
    unmount();
    unmount = null;
  }
  if (store && handlersRef) {
    unmount = mountMailUi(root, store, handlersRef);
  }
  return root;
}
var handlersRef = null;
async function init(api) {
  apiRef = api;
  const kv = typeof localStorage !== "undefined" ? localStorage : memoryKv();
  const storage = new CharStorage(kv);
  transport = new DargothTransport(api);
  const lock = new SessionLock();
  const composePrefs = storage.getJSON(COMPOSE_KEY);
  store = new MailUiStore({
    notifyEnabled: storage.getJSON(NOTIFY_KEY) ?? false,
    archive: storage.getJSON(ARCHIVE_KEY) ?? [],
    composeTemplate: composePrefs?.template ?? "plain",
    composeWidth: composePrefs?.width ?? 60
  });
  const ui = store;
  const mailbox = new MailboxSession(transport, SESSION_OPTS);
  const pager = new PagerSession(transport, SESSION_OPTS);
  const editor = new EditorSession(transport, SESSION_OPTS);
  api.events.on("gmcp.char.info", (d) => {
    if (d?.name) storage.setCharacter(d.name);
  });
  const rebuildContacts = () => {
    ui.setContacts(contactsFromBoxes(ui.state.boxes, []));
  };
  const refreshBoxes = (boxes) => {
    void lock.runExclusive(async () => {
      for (const box of boxes) {
        ui.setBusy(`Pobieram skrzynke ${box}...`);
        ui.applyMailbox(box, await mailbox.fetch(box));
      }
    }).catch(() => {
    }).finally(() => {
      ui.setBusy(null);
      rebuildContacts();
    });
  };
  const persistArchive = () => {
    storage.setJSON(ARCHIVE_KEY, ui.state.archive);
  };
  const loadOlder = (box) => {
    const view = ui.state.boxes[box];
    let oldest = null;
    for (const e of view?.entries ?? []) {
      if (!e.date) continue;
      if (!oldest || e.date.year < oldest.date.year || e.date.year === oldest.date.year && (e.date.month < oldest.date.month || e.date.month === oldest.date.month && (e.date.day < oldest.date.day || e.date.day === oldest.date.day && e.date.time < oldest.date.time))) {
        oldest = e;
      }
    }
    if (!oldest?.date) {
      notify(api, "Brak daty do paginacji - najpierw pobierz skrzynke.");
      return;
    }
    ui.setBusy("Wczytuje starsze listy...");
    void lock.runExclusive(async () => {
      const res = await mailbox.fetch(box, olderListingCommand(box, oldest.date));
      if (res.kind === "lista") {
        const incoming = res.entries.map((e) => fromMailboxEntry(box, e));
        const merged = upsertLetters(ui.state.archive, incoming);
        ui.setArchive(merged.letters);
        persistArchive();
        notify(api, `Archiwum: +${merged.added} starszych listow.`);
      }
    }).catch(() => {
    }).finally(() => ui.setBusy(null));
  };
  handlersRef = {
    onOpenLetter: (box, number) => {
      ui.setBusy(`Czytam list ${number}...`);
      void lock.runExclusive(async () => {
        transport.beginModal();
        try {
          const res = await pager.readLetter(number);
          ui.openLetter(box, res.letter);
        } finally {
          transport.endModal();
        }
      }).catch(() => notify(api, "Nie udalo sie odczytac listu.")).finally(() => ui.setBusy(null));
    },
    onSendCompose: (input) => {
      if (!input.adresat.trim() || !input.temat.trim()) {
        notify(api, "Adresat i temat sa wymagane.");
        return;
      }
      ui.setBusy("Wysylam list...");
      void lock.runExclusive(async () => {
        transport.beginModal();
        try {
          const out = await editor.send({
            adresat: input.adresat.trim(),
            temat: input.temat,
            dw: input.dw.trim() === "" ? void 0 : input.dw.trim(),
            linie: input.linie
          });
          if (out.result === "wyslany") {
            notify(api, "List zostal wyslany.");
            refreshBoxes(["wyslane"]);
          } else if (out.result === "gotowy") {
            notify(api, "List odlozony w niewyslanych.");
            refreshBoxes(["niewyslane"]);
          } else {
            notify(api, "Blad wysylki - sprawdz adresata.");
          }
        } finally {
          transport.endModal();
        }
      }).catch(() => notify(api, "Blad wysylki listu.")).finally(() => ui.setBusy(null));
    },
    onCloseLetter: () => ui.closeLetter(),
    onRefreshBox: (box) => refreshBoxes([box]),
    onLoadOlder: (box) => loadOlder(box),
    onDeleteLetter: (box, number) => {
      ui.setBusy(`Kasuje list ${number}...`);
      void lock.runExclusive(async () => {
        transport.beginModal();
        try {
          const res = await pager.deleteLetters(number, String(number));
          if (res.deleted) {
            notify(api, `List ${number} oznaczony do skasowania.`);
            ui.closeLetter();
            refreshBoxes([box]);
          } else {
            notify(api, "Nie udalo sie skasowac listu.");
          }
        } finally {
          transport.endModal();
        }
      }).catch(() => notify(api, "Blad kasowania listu.")).finally(() => ui.setBusy(null));
    },
    onForwardLetter: (box, number, adresat) => {
      ui.setBusy(`Przekazuje list ${number}...`);
      void lock.runExclusive(async () => {
        transport.beginModal();
        try {
          const res = await pager.forwardLetter(number, adresat);
          if (res.queued) {
            notify(api, "List przekazany - czeka w niewyslanych.");
            refreshBoxes(["niewyslane"]);
          } else {
            notify(api, "Blad przekazania - sprawdz adresata.");
          }
        } finally {
          transport.endModal();
        }
      }).catch(() => notify(api, "Blad przekazania listu.")).finally(() => ui.setBusy(null));
    }
  };
  transport.subscribe((line) => {
    const n = parseNotification(line.text);
    if (!n) return;
    if (n.kind === "nowa-poczte") {
      if (ui.state.notifyEnabled) notify(api, `Masz nowa poczte od ${n.nadawca}.`);
      refreshBoxes(["odebrane", "nieprzeczytane"]);
    } else if (n.kind === "goniec") {
      refreshBoxes(["odebrane", "nieprzeczytane"]);
    }
  });
  unsubBadge = ui.subscribe((s) => {
    footerHandle?.update({ label: s.badge > 0 ? `${PLUGIN_NAME} (${s.badge})` : PLUGIN_NAME });
    api.ui.setFooterButtonState(FOOTER_STATE, s.badge > 0);
    storage.setJSON(COMPOSE_KEY, { template: s.composeTemplate, width: s.composeWidth });
    storage.setJSON(NOTIFY_KEY, s.notifyEnabled);
  });
  popup = await api.ui.registerPersistentPopup({
    id: POPUP_ID,
    title: PLUGIN_NAME,
    initialWidth: 480,
    initialHeight: 640,
    createContent
  });
  const toggle = () => {
    if (!popup) return true;
    if (popup.isOpen) popup.close();
    else void popup.open();
    return true;
  };
  aliasId = api.aliases.register(ALIAS_REGEX, toggle);
  menuHandle = api.ui.addPopupMenuEntry(PLUGIN_NAME, () => {
    if (popup && !popup.isOpen) void popup.open();
  });
  footerHandle = api.ui.registerFooterButton(FOOTER_BUTTON_ID, {
    label: PLUGIN_NAME,
    command: "/arkmail",
    state: FOOTER_STATE
  });
  return {
    name: PLUGIN_NAME,
    version: PLUGIN_VERSION,
    author: PLUGIN_AUTHOR,
    description: PLUGIN_DESCRIPTION
  };
}
async function destroy() {
  if (unsubBadge) {
    unsubBadge();
    unsubBadge = null;
  }
  if (unmount) {
    unmount();
    unmount = null;
  }
  if (transport) {
    transport.dispose();
    transport = null;
  }
  handlersRef = null;
  store = null;
  if (aliasId !== null && apiRef) {
    apiRef.aliases.remove(aliasId);
    aliasId = null;
  }
  if (footerHandle) {
    footerHandle.remove();
    footerHandle = null;
  }
  if (menuHandle) {
    menuHandle.remove();
    menuHandle = null;
  }
  if (popup) {
    popup.close();
    popup = null;
  }
  apiRef = null;
}
export {
  destroy,
  init
};
